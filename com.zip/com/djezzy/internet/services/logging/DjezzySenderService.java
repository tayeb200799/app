package com.djezzy.internet.services.logging;

import c.c.a.f.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\djezzy\internet\services\logging\DjezzySenderService.smali */
public class DjezzySenderService extends b {

    /* renamed from: d, reason: collision with root package name */
    public static final /* synthetic */ int f9675d = 0;
}