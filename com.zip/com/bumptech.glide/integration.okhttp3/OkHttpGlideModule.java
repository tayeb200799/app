package com.bumptech.glide.integration.okhttp3;

import android.content.Context;
import c.b.a.d;
import c.b.a.h;
import c.b.a.n.a.c;
import c.b.a.o.v.g;
import c.b.a.q.c;
import java.io.InputStream;

@Deprecated
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\bumptech\glide\integration\okhttp3\OkHttpGlideModule.smali */
public class OkHttpGlideModule implements c {
    @Override // c.b.a.q.b
    public void a(Context context, d dVar) {
    }

    @Override // c.b.a.q.f
    public void b(Context context, c.b.a.c cVar, h hVar) {
        hVar.i(g.class, InputStream.class, new c.a());
    }
}