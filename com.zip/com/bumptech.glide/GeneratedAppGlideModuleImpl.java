package com.bumptech.glide;

import android.content.Context;
import android.util.Log;
import c.b.a.c;
import c.b.a.d;
import c.b.a.h;
import c.b.a.n.a.a;
import c.b.a.p.p;
import com.djezzy.internet.webservice.ImageLoader.DjezzyGlideModule;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\bumptech\glide\GeneratedAppGlideModuleImpl.smali */
public final class GeneratedAppGlideModuleImpl extends GeneratedAppGlideModule {

    /* renamed from: a, reason: collision with root package name */
    public final DjezzyGlideModule f9642a = new DjezzyGlideModule();

    public GeneratedAppGlideModuleImpl(Context context) {
        if (Log.isLoggable("Glide", 3)) {
            Log.d("Glide", "Discovered AppGlideModule from annotation: com.djezzy.internet.webservice.ImageLoader.DjezzyGlideModule");
            Log.d("Glide", "Discovered LibraryGlideModule from annotation: com.bumptech.glide.integration.okhttp3.OkHttpLibraryGlideModule");
        }
    }

    @Override // c.b.a.q.a, c.b.a.q.b
    public void a(Context context, d dVar) {
        Objects.requireNonNull(this.f9642a);
    }

    @Override // c.b.a.q.d, c.b.a.q.f
    public void b(Context context, c cVar, h hVar) {
        new a().b(context, cVar, hVar);
        this.f9642a.b(context, cVar, hVar);
    }

    @Override // c.b.a.q.a
    public boolean c() {
        Objects.requireNonNull(this.f9642a);
        return true;
    }

    @Override // com.bumptech.glide.GeneratedAppGlideModule
    public Set<Class<?>> d() {
        return Collections.emptySet();
    }

    @Override // com.bumptech.glide.GeneratedAppGlideModule
    public p.b e() {
        return new c.b.a.a();
    }
}