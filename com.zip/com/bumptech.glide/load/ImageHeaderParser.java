package com.bumptech.glide.load;

import c.b.a.o.u.c0.b;
import java.io.InputStream;
import java.nio.ByteBuffer;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\bumptech\glide\load\ImageHeaderParser.smali */
public interface ImageHeaderParser {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\bumptech\glide\load\ImageHeaderParser$ImageType.smali */
    public enum ImageType {
        GIF(true),
        JPEG(false),
        RAW(false),
        PNG_A(true),
        PNG(false),
        WEBP_A(true),
        WEBP(false),
        UNKNOWN(false);


        /* renamed from: d, reason: collision with root package name */
        public final boolean f9643d;

        ImageType(boolean z) {
            this.f9643d = z;
        }

        public boolean hasAlpha() {
            return this.f9643d;
        }
    }

    ImageType a(ByteBuffer byteBuffer);

    int b(InputStream inputStream, b bVar);

    ImageType c(InputStream inputStream);
}