package com.google.android.datatransport.cct;

import androidx.annotation.Keep;
import c.d.a.a.j.q.d;
import c.d.a.a.j.q.h;
import c.d.a.a.j.q.m;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\datatransport\cct\CctBackendFactory.smali */
public class CctBackendFactory implements d {
    @Override // c.d.a.a.j.q.d
    public m create(h hVar) {
        return new c.d.a.a.i.d(hVar.a(), hVar.d(), hVar.c());
    }
}