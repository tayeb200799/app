package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import c.d.a.a.j.c;
import c.d.a.a.j.j;
import c.d.a.a.j.n;
import c.d.a.a.j.t.h.e;
import c.d.a.a.j.w.a;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.AlarmManagerSchedulerBroadcastReceiver;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\datatransport\runtime\scheduling\jobscheduling\AlarmManagerSchedulerBroadcastReceiver.smali */
public class AlarmManagerSchedulerBroadcastReceiver extends BroadcastReceiver {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f9722a = 0;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String queryParameter = intent.getData().getQueryParameter("backendName");
        String queryParameter2 = intent.getData().getQueryParameter("extras");
        int intValue = Integer.valueOf(intent.getData().getQueryParameter("priority")).intValue();
        int i2 = intent.getExtras().getInt("attemptNumber");
        n.b(context);
        j.a a2 = j.a();
        a2.b(queryParameter);
        a2.c(a.b(intValue));
        if (queryParameter2 != null) {
            ((c.b) a2).f4385b = Base64.decode(queryParameter2, 0);
        }
        c.d.a.a.j.t.h.n nVar = n.a().f4411d;
        nVar.f4508e.execute(new e(nVar, a2.a(), i2, new Runnable() { // from class: c.d.a.a.j.t.h.a
            @Override // java.lang.Runnable
            public final void run() {
                int i3 = AlarmManagerSchedulerBroadcastReceiver.f9722a;
            }
        }));
    }
}