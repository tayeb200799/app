package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.util.Base64;
import c.d.a.a.j.c;
import c.d.a.a.j.j;
import c.d.a.a.j.n;
import c.d.a.a.j.t.h.e;
import c.d.a.a.j.w.a;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\datatransport\runtime\scheduling\jobscheduling\JobInfoSchedulerService.smali */
public class JobInfoSchedulerService extends JobService {
    @Override // android.app.job.JobService
    public boolean onStartJob(final JobParameters jobParameters) {
        String string = jobParameters.getExtras().getString("backendName");
        String string2 = jobParameters.getExtras().getString("extras");
        int i2 = jobParameters.getExtras().getInt("priority");
        int i3 = jobParameters.getExtras().getInt("attemptNumber");
        n.b(getApplicationContext());
        j.a a2 = j.a();
        a2.b(string);
        a2.c(a.b(i2));
        if (string2 != null) {
            ((c.b) a2).f4385b = Base64.decode(string2, 0);
        }
        c.d.a.a.j.t.h.n nVar = n.a().f4411d;
        nVar.f4508e.execute(new e(nVar, a2.a(), i3, new Runnable() { // from class: c.d.a.a.j.t.h.c
            @Override // java.lang.Runnable
            public final void run() {
                JobInfoSchedulerService.this.jobFinished(jobParameters, false);
            }
        }));
        return true;
    }

    @Override // android.app.job.JobService
    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }
}