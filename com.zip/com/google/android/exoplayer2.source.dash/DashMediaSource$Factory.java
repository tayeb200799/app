package com.google.android.exoplayer2.source.dash;

import c.d.a.b.k2.c0;
import c.d.a.b.k2.r0.a;
import c.d.a.b.n2.k;
import java.util.Collections;
import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\exoplayer2\source\dash\DashMediaSource$Factory.smali */
public final class DashMediaSource$Factory implements c0 {

    /* renamed from: a, reason: collision with root package name */
    public final k.a f9723a;

    /* renamed from: b, reason: collision with root package name */
    public List<Object> f9724b;

    public DashMediaSource$Factory(k.a aVar) {
        int i2 = a.f6310d;
        this.f9723a = aVar;
        this.f9724b = Collections.emptyList();
    }
}