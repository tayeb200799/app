package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import b.h.k.q;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Deprecated
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\transformation\ExpandableBehavior.smali */
public abstract class ExpandableBehavior extends CoordinatorLayout.c<View> {

    /* renamed from: a, reason: collision with root package name */
    public int f9972a;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\transformation\ExpandableBehavior$a.smali */
    public class a implements ViewTreeObserver.OnPreDrawListener {

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ View f9973d;

        /* renamed from: e, reason: collision with root package name */
        public final /* synthetic */ int f9974e;

        /* renamed from: f, reason: collision with root package name */
        public final /* synthetic */ c.d.a.d.p.a f9975f;

        public a(View view, int i2, c.d.a.d.p.a aVar) {
            this.f9973d = view;
            this.f9974e = i2;
            this.f9975f = aVar;
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            this.f9973d.getViewTreeObserver().removeOnPreDrawListener(this);
            ExpandableBehavior expandableBehavior = ExpandableBehavior.this;
            if (expandableBehavior.f9972a == this.f9974e) {
                c.d.a.d.p.a aVar = this.f9975f;
                expandableBehavior.C((View) aVar, this.f9973d, aVar.a(), false);
            }
            return false;
        }
    }

    public ExpandableBehavior() {
        this.f9972a = 0;
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f9972a = 0;
    }

    public final boolean B(boolean z) {
        if (!z) {
            return this.f9972a == 1;
        }
        int i2 = this.f9972a;
        return i2 == 0 || i2 == 2;
    }

    public abstract boolean C(View view, View view2, boolean z, boolean z2);

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean g(CoordinatorLayout coordinatorLayout, View view, View view2) {
        c.d.a.d.p.a aVar = (c.d.a.d.p.a) view2;
        if (!B(aVar.a())) {
            return false;
        }
        this.f9972a = aVar.a() ? 1 : 2;
        return C((View) aVar, view, aVar.a(), true);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean k(CoordinatorLayout coordinatorLayout, View view, int i2) {
        c.d.a.d.p.a aVar;
        AtomicInteger atomicInteger = q.f1738a;
        if (!view.isLaidOut()) {
            List<View> e2 = coordinatorLayout.e(view);
            int size = e2.size();
            int i3 = 0;
            while (true) {
                if (i3 >= size) {
                    aVar = null;
                    break;
                }
                View view2 = e2.get(i3);
                if (d(coordinatorLayout, view, view2)) {
                    aVar = (c.d.a.d.p.a) view2;
                    break;
                }
                i3++;
            }
            if (aVar != null && B(aVar.a())) {
                int i4 = aVar.a() ? 1 : 2;
                this.f9972a = i4;
                view.getViewTreeObserver().addOnPreDrawListener(new a(view, i4, aVar));
            }
        }
        return false;
    }
}