package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import b.h.k.q;
import c.d.a.d.c.d;
import c.d.a.d.c.g;
import c.d.a.d.c.h;
import c.d.a.d.c.i;
import c.d.a.d.e0.e;
import c.d.a.d.m.c;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

@Deprecated
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\transformation\FabTransformationBehavior.smali */
public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {

    /* renamed from: c, reason: collision with root package name */
    public final Rect f9979c;

    /* renamed from: d, reason: collision with root package name */
    public final RectF f9980d;

    /* renamed from: e, reason: collision with root package name */
    public final RectF f9981e;

    /* renamed from: f, reason: collision with root package name */
    public final int[] f9982f;

    /* renamed from: g, reason: collision with root package name */
    public float f9983g;

    /* renamed from: h, reason: collision with root package name */
    public float f9984h;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\transformation\FabTransformationBehavior$a.smali */
    public class a extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ boolean f9985a;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ View f9986b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ View f9987c;

        public a(FabTransformationBehavior fabTransformationBehavior, boolean z, View view, View view2) {
            this.f9985a = z;
            this.f9986b = view;
            this.f9987c = view2;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f9985a) {
                return;
            }
            this.f9986b.setVisibility(4);
            this.f9987c.setAlpha(1.0f);
            this.f9987c.setVisibility(0);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            if (this.f9985a) {
                this.f9986b.setVisibility(0);
                this.f9987c.setAlpha(0.0f);
                this.f9987c.setVisibility(4);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\transformation\FabTransformationBehavior$b.smali */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public g f9988a;

        /* renamed from: b, reason: collision with root package name */
        public i f9989b;
    }

    public FabTransformationBehavior() {
        this.f9979c = new Rect();
        this.f9980d = new RectF();
        this.f9981e = new RectF();
        this.f9982f = new int[2];
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f9979c = new Rect();
        this.f9980d = new RectF();
        this.f9981e = new RectF();
        this.f9982f = new int[2];
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.google.android.material.transformation.ExpandableTransformationBehavior
    public AnimatorSet D(View view, View view2, boolean z, boolean z2) {
        ArrayList arrayList;
        b bVar;
        c cVar;
        Animator animator;
        ArrayList arrayList2;
        ObjectAnimator ofInt;
        b N = N(view2.getContext(), z);
        if (z) {
            this.f9983g = view.getTranslationX();
            this.f9984h = view.getTranslationY();
        }
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        L(view, view2, z, z2, N, arrayList3);
        RectF rectF = this.f9980d;
        M(view, view2, z, z2, N, arrayList3, rectF);
        float width = rectF.width();
        float height = rectF.height();
        float F = F(view, view2, N.f9989b);
        float G = G(view, view2, N.f9989b);
        Pair<h, h> E = E(F, G, z, N);
        h hVar = (h) E.first;
        h hVar2 = (h) E.second;
        Property property = View.TRANSLATION_X;
        float[] fArr = new float[1];
        if (!z) {
            F = this.f9983g;
        }
        fArr[0] = F;
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) property, fArr);
        Property property2 = View.TRANSLATION_Y;
        float[] fArr2 = new float[1];
        if (!z) {
            G = this.f9984h;
        }
        fArr2[0] = G;
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(view, (Property<View, Float>) property2, fArr2);
        hVar.a(ofFloat);
        hVar2.a(ofFloat2);
        arrayList3.add(ofFloat);
        arrayList3.add(ofFloat2);
        boolean z3 = view2 instanceof c;
        if (z3 && (view instanceof ImageView)) {
            c cVar2 = (c) view2;
            Drawable drawable = ((ImageView) view).getDrawable();
            if (drawable != null) {
                drawable.mutate();
                if (z) {
                    if (!z2) {
                        drawable.setAlpha(255);
                    }
                    ofInt = ObjectAnimator.ofInt(drawable, d.f8585b, 0);
                } else {
                    ofInt = ObjectAnimator.ofInt(drawable, d.f8585b, 255);
                }
                ofInt.addUpdateListener(new c.d.a.d.e0.a(this, view2));
                N.f9988a.d("iconFade").a(ofInt);
                arrayList3.add(ofInt);
                arrayList4.add(new c.d.a.d.e0.b(this, cVar2, drawable));
            }
        }
        if (z3) {
            c cVar3 = (c) view2;
            i iVar = N.f9989b;
            RectF rectF2 = this.f9980d;
            RectF rectF3 = this.f9981e;
            I(view, rectF2);
            rectF2.offset(this.f9983g, this.f9984h);
            I(view2, rectF3);
            rectF3.offset(-F(view, view2, iVar), 0.0f);
            float centerX = rectF2.centerX() - rectF3.left;
            i iVar2 = N.f9989b;
            RectF rectF4 = this.f9980d;
            RectF rectF5 = this.f9981e;
            I(view, rectF4);
            rectF4.offset(this.f9983g, this.f9984h);
            I(view2, rectF5);
            rectF5.offset(0.0f, -G(view, view2, iVar2));
            float centerY = rectF4.centerY() - rectF5.top;
            ((FloatingActionButton) view).g(this.f9979c);
            float width2 = this.f9979c.width() / 2.0f;
            h d2 = N.f9988a.d("expansion");
            if (z) {
                if (!z2) {
                    cVar3.setRevealInfo(new c.e(centerX, centerY, width2));
                }
                if (z2) {
                    width2 = cVar3.getRevealInfo().f8722c;
                }
                float r = c.d.a.d.a.r(centerX, centerY, 0.0f, 0.0f);
                float r2 = c.d.a.d.a.r(centerX, centerY, width, 0.0f);
                float r3 = c.d.a.d.a.r(centerX, centerY, width, height);
                float r4 = c.d.a.d.a.r(centerX, centerY, 0.0f, height);
                if (r <= r2 || r <= r3 || r <= r4) {
                    r = (r2 <= r3 || r2 <= r4) ? r3 > r4 ? r3 : r4 : r2;
                }
                animator = c.d.a.d.a.o(cVar3, centerX, centerY, r);
                animator.addListener(new c.d.a.d.e0.c(this, cVar3));
                long j2 = d2.f8593a;
                int i2 = (int) centerX;
                int i3 = (int) centerY;
                if (j2 > 0) {
                    Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view2, i2, i3, width2, width2);
                    createCircularReveal.setStartDelay(0L);
                    createCircularReveal.setDuration(j2);
                    arrayList3.add(createCircularReveal);
                }
                cVar = cVar3;
                arrayList = arrayList4;
                bVar = N;
            } else {
                float f2 = cVar3.getRevealInfo().f8722c;
                Animator o = c.d.a.d.a.o(cVar3, centerX, centerY, width2);
                long j3 = d2.f8593a;
                int i4 = (int) centerX;
                int i5 = (int) centerY;
                if (j3 > 0) {
                    Animator createCircularReveal2 = ViewAnimationUtils.createCircularReveal(view2, i4, i5, f2, f2);
                    createCircularReveal2.setStartDelay(0L);
                    createCircularReveal2.setDuration(j3);
                    arrayList3.add(createCircularReveal2);
                }
                long j4 = d2.f8593a;
                long j5 = d2.f8594b;
                g gVar = N.f9988a;
                int i6 = gVar.f8591a.f1197f;
                arrayList = arrayList4;
                bVar = N;
                int i7 = 0;
                long j6 = 0;
                while (i7 < i6) {
                    int i8 = i6;
                    h l = gVar.f8591a.l(i7);
                    j6 = Math.max(j6, l.f8593a + l.f8594b);
                    i7++;
                    i6 = i8;
                    cVar3 = cVar3;
                    i4 = i4;
                    gVar = gVar;
                }
                cVar = cVar3;
                int i9 = i4;
                long j7 = j4 + j5;
                if (j7 < j6) {
                    Animator createCircularReveal3 = ViewAnimationUtils.createCircularReveal(view2, i9, i5, width2, width2);
                    createCircularReveal3.setStartDelay(j7);
                    createCircularReveal3.setDuration(j6 - j7);
                    arrayList3.add(createCircularReveal3);
                }
                animator = o;
            }
            d2.a(animator);
            arrayList3.add(animator);
            arrayList2 = arrayList;
            arrayList2.add(new c.d.a.d.m.a(cVar));
        } else {
            bVar = N;
            arrayList2 = arrayList4;
        }
        K(view, view2, z, z2, bVar, arrayList3);
        J(view2, z, z2, bVar, arrayList3);
        AnimatorSet animatorSet = new AnimatorSet();
        c.d.a.d.a.T(animatorSet, arrayList3);
        animatorSet.addListener(new a(this, z, view2, view));
        int size = arrayList2.size();
        for (int i10 = 0; i10 < size; i10++) {
            animatorSet.addListener((Animator.AnimatorListener) arrayList2.get(i10));
        }
        return animatorSet;
    }

    public final Pair<h, h> E(float f2, float f3, boolean z, b bVar) {
        h d2;
        h d3;
        if (f2 == 0.0f || f3 == 0.0f) {
            d2 = bVar.f9988a.d("translationXLinear");
            d3 = bVar.f9988a.d("translationYLinear");
        } else if ((!z || f3 >= 0.0f) && (z || f3 <= 0.0f)) {
            d2 = bVar.f9988a.d("translationXCurveDownwards");
            d3 = bVar.f9988a.d("translationYCurveDownwards");
        } else {
            d2 = bVar.f9988a.d("translationXCurveUpwards");
            d3 = bVar.f9988a.d("translationYCurveUpwards");
        }
        return new Pair<>(d2, d3);
    }

    public final float F(View view, View view2, i iVar) {
        RectF rectF = this.f9980d;
        RectF rectF2 = this.f9981e;
        I(view, rectF);
        rectF.offset(this.f9983g, this.f9984h);
        I(view2, rectF2);
        Objects.requireNonNull(iVar);
        return (rectF2.centerX() - rectF.centerX()) + 0.0f;
    }

    public final float G(View view, View view2, i iVar) {
        RectF rectF = this.f9980d;
        RectF rectF2 = this.f9981e;
        I(view, rectF);
        rectF.offset(this.f9983g, this.f9984h);
        I(view2, rectF2);
        Objects.requireNonNull(iVar);
        return (rectF2.centerY() - rectF.centerY()) + 0.0f;
    }

    public final float H(b bVar, h hVar, float f2, float f3) {
        long j2 = hVar.f8593a;
        long j3 = hVar.f8594b;
        h d2 = bVar.f9988a.d("expansion");
        float interpolation = hVar.b().getInterpolation((((d2.f8593a + d2.f8594b) + 17) - j2) / j3);
        TimeInterpolator timeInterpolator = c.d.a.d.c.a.f8578a;
        return c.a.a.a.a.a(f3, f2, interpolation, f2);
    }

    public final void I(View view, RectF rectF) {
        rectF.set(0.0f, 0.0f, view.getWidth(), view.getHeight());
        view.getLocationInWindow(this.f9982f);
        rectF.offsetTo(r0[0], r0[1]);
        rectF.offset((int) (-view.getTranslationX()), (int) (-view.getTranslationY()));
    }

    public final void J(View view, boolean z, boolean z2, b bVar, List list) {
        ObjectAnimator ofFloat;
        if (view instanceof ViewGroup) {
            boolean z3 = view instanceof c;
            View findViewById = view.findViewById(2131362312);
            ViewGroup O = findViewById != null ? O(findViewById) : ((view instanceof e) || (view instanceof c.d.a.d.e0.d)) ? O(((ViewGroup) view).getChildAt(0)) : O(view);
            if (O == null) {
                return;
            }
            if (z) {
                if (!z2) {
                    c.d.a.d.c.c.f8584a.set(O, Float.valueOf(0.0f));
                }
                ofFloat = ObjectAnimator.ofFloat(O, c.d.a.d.c.c.f8584a, 1.0f);
            } else {
                ofFloat = ObjectAnimator.ofFloat(O, c.d.a.d.c.c.f8584a, 0.0f);
            }
            bVar.f9988a.d("contentFade").a(ofFloat);
            list.add(ofFloat);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void K(View view, View view2, boolean z, boolean z2, b bVar, List list) {
        ObjectAnimator ofInt;
        if (view2 instanceof c) {
            c cVar = (c) view2;
            AtomicInteger atomicInteger = q.f1738a;
            ColorStateList backgroundTintList = view.getBackgroundTintList();
            int colorForState = backgroundTintList != null ? backgroundTintList.getColorForState(view.getDrawableState(), backgroundTintList.getDefaultColor()) : 0;
            int i2 = 16777215 & colorForState;
            if (z) {
                if (!z2) {
                    cVar.setCircularRevealScrimColor(colorForState);
                }
                ofInt = ObjectAnimator.ofInt(cVar, c.d.f8719a, i2);
            } else {
                ofInt = ObjectAnimator.ofInt(cVar, c.d.f8719a, colorForState);
            }
            ofInt.setEvaluator(c.d.a.d.c.b.f8583a);
            bVar.f9988a.d("color").a(ofInt);
            list.add(ofInt);
        }
    }

    @TargetApi(21)
    public final void L(View view, View view2, boolean z, boolean z2, b bVar, List list) {
        ObjectAnimator ofFloat;
        AtomicInteger atomicInteger = q.f1738a;
        float elevation = view2.getElevation() - view.getElevation();
        if (z) {
            if (!z2) {
                view2.setTranslationZ(-elevation);
            }
            ofFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Z, 0.0f);
        } else {
            ofFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Z, -elevation);
        }
        bVar.f9988a.d("elevation").a(ofFloat);
        list.add(ofFloat);
    }

    public final void M(View view, View view2, boolean z, boolean z2, b bVar, List list, RectF rectF) {
        ObjectAnimator ofFloat;
        ObjectAnimator ofFloat2;
        float F = F(view, view2, bVar.f9989b);
        float G = G(view, view2, bVar.f9989b);
        Pair<h, h> E = E(F, G, z, bVar);
        h hVar = (h) E.first;
        h hVar2 = (h) E.second;
        if (z) {
            if (!z2) {
                view2.setTranslationX(-F);
                view2.setTranslationY(-G);
            }
            ofFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_X, 0.0f);
            ofFloat2 = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Y, 0.0f);
            float H = H(bVar, hVar, -F, 0.0f);
            float H2 = H(bVar, hVar2, -G, 0.0f);
            Rect rect = this.f9979c;
            view2.getWindowVisibleDisplayFrame(rect);
            RectF rectF2 = this.f9980d;
            rectF2.set(rect);
            RectF rectF3 = this.f9981e;
            I(view2, rectF3);
            rectF3.offset(H, H2);
            rectF3.intersect(rectF2);
            rectF.set(rectF3);
        } else {
            ofFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_X, -F);
            ofFloat2 = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Y, -G);
        }
        hVar.a(ofFloat);
        hVar2.a(ofFloat2);
        list.add(ofFloat);
        list.add(ofFloat2);
    }

    public abstract b N(Context context, boolean z);

    public final ViewGroup O(View view) {
        if (view instanceof ViewGroup) {
            return (ViewGroup) view;
        }
        return null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean d(CoordinatorLayout coordinatorLayout, View view, View view2) {
        if (view.getVisibility() == 8) {
            throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
        }
        if (!(view2 instanceof FloatingActionButton)) {
            return false;
        }
        int expandedComponentIdHint = ((FloatingActionButton) view2).getExpandedComponentIdHint();
        return expandedComponentIdHint == 0 || expandedComponentIdHint == view.getId();
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void f(CoordinatorLayout.f fVar) {
        if (fVar.f282h == 0) {
            fVar.f282h = 80;
        }
    }
}