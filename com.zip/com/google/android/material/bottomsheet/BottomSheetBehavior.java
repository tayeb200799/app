package com.google.android.material.bottomsheet;

import android.R;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import b.h.k.q;
import b.h.k.y.b;
import b.j.b.e;
import c.d.a.d.r.l;
import c.d.a.d.r.m;
import c.d.a.d.r.o;
import c.d.a.d.x.g;
import c.d.a.d.x.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior.smali */
public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.c<V> {
    public boolean A;
    public int B;
    public boolean C;
    public int D;
    public int E;
    public int F;
    public WeakReference<V> G;
    public WeakReference<View> H;
    public final ArrayList<c> I;
    public VelocityTracker J;
    public int K;
    public int L;
    public boolean M;
    public Map<View, Integer> N;
    public int O;
    public final e.c P;

    /* renamed from: a, reason: collision with root package name */
    public int f9814a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f9815b;

    /* renamed from: c, reason: collision with root package name */
    public float f9816c;

    /* renamed from: d, reason: collision with root package name */
    public int f9817d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f9818e;

    /* renamed from: f, reason: collision with root package name */
    public int f9819f;

    /* renamed from: g, reason: collision with root package name */
    public int f9820g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f9821h;

    /* renamed from: i, reason: collision with root package name */
    public g f9822i;

    /* renamed from: j, reason: collision with root package name */
    public int f9823j;
    public boolean k;
    public j l;
    public boolean m;
    public BottomSheetBehavior<V>.e n;
    public ValueAnimator o;
    public int p;
    public int q;
    public int r;
    public float s;
    public int t;
    public float u;
    public boolean v;
    public boolean w;
    public boolean x;
    public int y;
    public b.j.b.e z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior$a.smali */
    public class a implements Runnable {

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ View f9824d;

        /* renamed from: e, reason: collision with root package name */
        public final /* synthetic */ int f9825e;

        public a(View view, int i2) {
            this.f9824d = view;
            this.f9825e = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            BottomSheetBehavior.this.N(this.f9824d, this.f9825e);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior$b.smali */
    public class b extends e.c {
        public b() {
        }

        @Override // b.j.b.e.c
        public int a(View view, int i2, int i3) {
            return view.getLeft();
        }

        @Override // b.j.b.e.c
        public int b(View view, int i2, int i3) {
            int H = BottomSheetBehavior.this.H();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return b.h.a.i(i2, H, bottomSheetBehavior.v ? bottomSheetBehavior.F : bottomSheetBehavior.t);
        }

        @Override // b.j.b.e.c
        public int d(View view) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return bottomSheetBehavior.v ? bottomSheetBehavior.F : bottomSheetBehavior.t;
        }

        @Override // b.j.b.e.c
        public void f(int i2) {
            if (i2 == 1) {
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
                if (bottomSheetBehavior.x) {
                    bottomSheetBehavior.M(1);
                }
            }
        }

        @Override // b.j.b.e.c
        public void g(View view, int i2, int i3, int i4, int i5) {
            BottomSheetBehavior.this.E(i3);
        }

        @Override // b.j.b.e.c
        public void h(View view, float f2, float f3) {
            int i2;
            int i3 = 4;
            if (f3 < 0.0f) {
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
                if (bottomSheetBehavior.f9815b) {
                    i2 = bottomSheetBehavior.q;
                } else {
                    int top = view.getTop();
                    BottomSheetBehavior bottomSheetBehavior2 = BottomSheetBehavior.this;
                    int i4 = bottomSheetBehavior2.r;
                    if (top > i4) {
                        i2 = i4;
                        i3 = 6;
                    } else {
                        i2 = bottomSheetBehavior2.p;
                    }
                }
                i3 = 3;
            } else {
                BottomSheetBehavior bottomSheetBehavior3 = BottomSheetBehavior.this;
                if (bottomSheetBehavior3.v && bottomSheetBehavior3.P(view, f3)) {
                    if (Math.abs(f2) >= Math.abs(f3) || f3 <= 500.0f) {
                        int top2 = view.getTop();
                        BottomSheetBehavior bottomSheetBehavior4 = BottomSheetBehavior.this;
                        if (!(top2 > (bottomSheetBehavior4.H() + bottomSheetBehavior4.F) / 2)) {
                            BottomSheetBehavior bottomSheetBehavior5 = BottomSheetBehavior.this;
                            if (bottomSheetBehavior5.f9815b) {
                                i2 = bottomSheetBehavior5.q;
                            } else if (Math.abs(view.getTop() - BottomSheetBehavior.this.p) < Math.abs(view.getTop() - BottomSheetBehavior.this.r)) {
                                i2 = BottomSheetBehavior.this.p;
                            } else {
                                i2 = BottomSheetBehavior.this.r;
                                i3 = 6;
                            }
                            i3 = 3;
                        }
                    }
                    i2 = BottomSheetBehavior.this.F;
                    i3 = 5;
                } else if (f3 == 0.0f || Math.abs(f2) > Math.abs(f3)) {
                    int top3 = view.getTop();
                    BottomSheetBehavior bottomSheetBehavior6 = BottomSheetBehavior.this;
                    if (!bottomSheetBehavior6.f9815b) {
                        int i5 = bottomSheetBehavior6.r;
                        if (top3 < i5) {
                            if (top3 < Math.abs(top3 - bottomSheetBehavior6.t)) {
                                i2 = BottomSheetBehavior.this.p;
                                i3 = 3;
                            } else {
                                i2 = BottomSheetBehavior.this.r;
                            }
                        } else if (Math.abs(top3 - i5) < Math.abs(top3 - BottomSheetBehavior.this.t)) {
                            i2 = BottomSheetBehavior.this.r;
                        } else {
                            i2 = BottomSheetBehavior.this.t;
                        }
                        i3 = 6;
                    } else if (Math.abs(top3 - bottomSheetBehavior6.q) < Math.abs(top3 - BottomSheetBehavior.this.t)) {
                        i2 = BottomSheetBehavior.this.q;
                        i3 = 3;
                    } else {
                        i2 = BottomSheetBehavior.this.t;
                    }
                } else {
                    BottomSheetBehavior bottomSheetBehavior7 = BottomSheetBehavior.this;
                    if (bottomSheetBehavior7.f9815b) {
                        i2 = bottomSheetBehavior7.t;
                    } else {
                        int top4 = view.getTop();
                        if (Math.abs(top4 - BottomSheetBehavior.this.r) < Math.abs(top4 - BottomSheetBehavior.this.t)) {
                            i2 = BottomSheetBehavior.this.r;
                            i3 = 6;
                        } else {
                            i2 = BottomSheetBehavior.this.t;
                        }
                    }
                }
            }
            BottomSheetBehavior.this.Q(view, i3, i2, true);
        }

        @Override // b.j.b.e.c
        public boolean i(View view, int i2) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            int i3 = bottomSheetBehavior.y;
            if (i3 == 1 || bottomSheetBehavior.M) {
                return false;
            }
            if (i3 == 3 && bottomSheetBehavior.K == i2) {
                WeakReference<View> weakReference = bottomSheetBehavior.H;
                View view2 = weakReference != null ? weakReference.get() : null;
                if (view2 != null && view2.canScrollVertically(-1)) {
                    return false;
                }
            }
            WeakReference<V> weakReference2 = BottomSheetBehavior.this.G;
            return weakReference2 != null && weakReference2.get() == view;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior$c.smali */
    public static abstract class c {
        public abstract void a(View view, float f2);

        public abstract void b(View view, int i2);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior$d.smali */
    public static class d extends b.j.a.a {
        public static final Parcelable.Creator<d> CREATOR = new a();

        /* renamed from: f, reason: collision with root package name */
        public final int f9828f;

        /* renamed from: g, reason: collision with root package name */
        public int f9829g;

        /* renamed from: h, reason: collision with root package name */
        public boolean f9830h;

        /* renamed from: i, reason: collision with root package name */
        public boolean f9831i;

        /* renamed from: j, reason: collision with root package name */
        public boolean f9832j;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior$d$a.smali */
        public static class a implements Parcelable.ClassLoaderCreator<d> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new d(parcel, (ClassLoader) null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public d createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new d(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new d[i2];
            }
        }

        public d(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f9828f = parcel.readInt();
            this.f9829g = parcel.readInt();
            this.f9830h = parcel.readInt() == 1;
            this.f9831i = parcel.readInt() == 1;
            this.f9832j = parcel.readInt() == 1;
        }

        public d(Parcelable parcelable, BottomSheetBehavior<?> bottomSheetBehavior) {
            super(parcelable);
            this.f9828f = bottomSheetBehavior.y;
            this.f9829g = bottomSheetBehavior.f9817d;
            this.f9830h = bottomSheetBehavior.f9815b;
            this.f9831i = bottomSheetBehavior.v;
            this.f9832j = bottomSheetBehavior.w;
        }

        @Override // b.j.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.f1843d, i2);
            parcel.writeInt(this.f9828f);
            parcel.writeInt(this.f9829g);
            parcel.writeInt(this.f9830h ? 1 : 0);
            parcel.writeInt(this.f9831i ? 1 : 0);
            parcel.writeInt(this.f9832j ? 1 : 0);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomsheet\BottomSheetBehavior$e.smali */
    public class e implements Runnable {

        /* renamed from: d, reason: collision with root package name */
        public final View f9833d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f9834e;

        /* renamed from: f, reason: collision with root package name */
        public int f9835f;

        public e(View view, int i2) {
            this.f9833d = view;
            this.f9835f = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            b.j.b.e eVar = BottomSheetBehavior.this.z;
            if (eVar == null || !eVar.i(true)) {
                BottomSheetBehavior.this.M(this.f9835f);
            } else {
                View view = this.f9833d;
                AtomicInteger atomicInteger = q.f1738a;
                view.postOnAnimation(this);
            }
            this.f9834e = false;
        }
    }

    public BottomSheetBehavior() {
        this.f9814a = 0;
        this.f9815b = true;
        this.n = null;
        this.s = 0.5f;
        this.u = -1.0f;
        this.x = true;
        this.y = 4;
        this.I = new ArrayList<>();
        this.O = -1;
        this.P = new b();
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int i2;
        this.f9814a = 0;
        this.f9815b = true;
        this.n = null;
        this.s = 0.5f;
        this.u = -1.0f;
        this.x = true;
        this.y = 4;
        this.I = new ArrayList<>();
        this.O = -1;
        this.P = new b();
        this.f9820g = context.getResources().getDimensionPixelSize(2131165496);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, c.d.a.d.b.f8502e);
        this.f9821h = obtainStyledAttributes.hasValue(11);
        boolean hasValue = obtainStyledAttributes.hasValue(1);
        if (hasValue) {
            D(context, attributeSet, hasValue, c.d.a.d.a.C(context, obtainStyledAttributes, 1));
        } else {
            D(context, attributeSet, hasValue, null);
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.o = ofFloat;
        ofFloat.setDuration(500L);
        this.o.addUpdateListener(new c.d.a.d.h.a(this));
        this.u = obtainStyledAttributes.getDimension(0, -1.0f);
        TypedValue peekValue = obtainStyledAttributes.peekValue(7);
        if (peekValue == null || (i2 = peekValue.data) != -1) {
            K(obtainStyledAttributes.getDimensionPixelSize(7, -1));
        } else {
            K(i2);
        }
        J(obtainStyledAttributes.getBoolean(6, false));
        this.k = obtainStyledAttributes.getBoolean(10, false);
        boolean z = obtainStyledAttributes.getBoolean(4, true);
        if (this.f9815b != z) {
            this.f9815b = z;
            if (this.G != null) {
                B();
            }
            M((this.f9815b && this.y == 6) ? 3 : this.y);
            R();
        }
        this.w = obtainStyledAttributes.getBoolean(9, false);
        this.x = obtainStyledAttributes.getBoolean(2, true);
        this.f9814a = obtainStyledAttributes.getInt(8, 0);
        float f2 = obtainStyledAttributes.getFloat(5, 0.5f);
        if (f2 <= 0.0f || f2 >= 1.0f) {
            throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
        }
        this.s = f2;
        if (this.G != null) {
            this.r = (int) ((1.0f - f2) * this.F);
        }
        TypedValue peekValue2 = obtainStyledAttributes.peekValue(3);
        if (peekValue2 == null || peekValue2.type != 16) {
            int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(3, 0);
            if (dimensionPixelOffset < 0) {
                throw new IllegalArgumentException("offset must be greater than or equal to 0");
            }
            this.p = dimensionPixelOffset;
        } else {
            int i3 = peekValue2.data;
            if (i3 < 0) {
                throw new IllegalArgumentException("offset must be greater than or equal to 0");
            }
            this.p = i3;
        }
        obtainStyledAttributes.recycle();
        this.f9816c = ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    public static <V extends View> BottomSheetBehavior<V> G(V v) {
        ViewGroup.LayoutParams layoutParams = v.getLayoutParams();
        if (!(layoutParams instanceof CoordinatorLayout.f)) {
            throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
        }
        CoordinatorLayout.c cVar = ((CoordinatorLayout.f) layoutParams).f275a;
        if (cVar instanceof BottomSheetBehavior) {
            return (BottomSheetBehavior) cVar;
        }
        throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean A(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.y == 1 && actionMasked == 0) {
            return true;
        }
        b.j.b.e eVar = this.z;
        if (eVar != null) {
            eVar.n(motionEvent);
        }
        if (actionMasked == 0) {
            this.K = -1;
            VelocityTracker velocityTracker = this.J;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.J = null;
            }
        }
        if (this.J == null) {
            this.J = VelocityTracker.obtain();
        }
        this.J.addMovement(motionEvent);
        if (this.z != null && actionMasked == 2 && !this.A) {
            float abs = Math.abs(this.L - motionEvent.getY());
            b.j.b.e eVar2 = this.z;
            if (abs > eVar2.f1857b) {
                eVar2.b(v, motionEvent.getPointerId(motionEvent.getActionIndex()));
            }
        }
        return !this.A;
    }

    public final void B() {
        int C = C();
        if (this.f9815b) {
            this.t = Math.max(this.F - C, this.q);
        } else {
            this.t = this.F - C;
        }
    }

    public final int C() {
        int i2;
        return this.f9818e ? Math.min(Math.max(this.f9819f, this.F - ((this.E * 9) / 16)), this.D) : (this.k || (i2 = this.f9823j) <= 0) ? this.f9817d : Math.max(this.f9817d, i2 + this.f9820g);
    }

    public final void D(Context context, AttributeSet attributeSet, boolean z, ColorStateList colorStateList) {
        if (this.f9821h) {
            this.l = j.b(context, attributeSet, 2130968677, 2131952276, new c.d.a.d.x.a(0)).a();
            g gVar = new g(this.l);
            this.f9822i = gVar;
            gVar.f8986d.f8995b = new c.d.a.d.o.a(context);
            gVar.y();
            if (z && colorStateList != null) {
                this.f9822i.q(colorStateList);
                return;
            }
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(R.attr.colorBackground, typedValue, true);
            this.f9822i.setTint(typedValue.data);
        }
    }

    public void E(int i2) {
        float f2;
        float f3;
        V v = this.G.get();
        if (v == null || this.I.isEmpty()) {
            return;
        }
        int i3 = this.t;
        if (i2 > i3 || i3 == H()) {
            int i4 = this.t;
            f2 = i4 - i2;
            f3 = this.F - i4;
        } else {
            int i5 = this.t;
            f2 = i5 - i2;
            f3 = i5 - H();
        }
        float f4 = f2 / f3;
        for (int i6 = 0; i6 < this.I.size(); i6++) {
            this.I.get(i6).a(v, f4);
        }
    }

    public View F(View view) {
        AtomicInteger atomicInteger = q.f1738a;
        if (view.isNestedScrollingEnabled()) {
            return view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View F = F(viewGroup.getChildAt(i2));
            if (F != null) {
                return F;
            }
        }
        return null;
    }

    public int H() {
        return this.f9815b ? this.q : this.p;
    }

    public final void I(V v, b.a aVar, int i2) {
        q.r(v, aVar, null, new c.d.a.d.h.c(this, i2));
    }

    public void J(boolean z) {
        if (this.v != z) {
            this.v = z;
            if (!z && this.y == 5) {
                L(4);
            }
            R();
        }
    }

    public void K(int i2) {
        boolean z = true;
        if (i2 == -1) {
            if (!this.f9818e) {
                this.f9818e = true;
            }
            z = false;
        } else {
            if (this.f9818e || this.f9817d != i2) {
                this.f9818e = false;
                this.f9817d = Math.max(0, i2);
            }
            z = false;
        }
        if (z) {
            U(false);
        }
    }

    public void L(int i2) {
        if (i2 == this.y) {
            return;
        }
        if (this.G != null) {
            O(i2);
            return;
        }
        if (i2 == 4 || i2 == 3 || i2 == 6 || (this.v && i2 == 5)) {
            this.y = i2;
        }
    }

    public void M(int i2) {
        V v;
        if (this.y == i2) {
            return;
        }
        this.y = i2;
        WeakReference<V> weakReference = this.G;
        if (weakReference == null || (v = weakReference.get()) == null) {
            return;
        }
        if (i2 == 3) {
            T(true);
        } else if (i2 == 6 || i2 == 5 || i2 == 4) {
            T(false);
        }
        S(i2);
        for (int i3 = 0; i3 < this.I.size(); i3++) {
            this.I.get(i3).b(v, i2);
        }
        R();
    }

    public void N(View view, int i2) {
        int i3;
        int i4;
        if (i2 == 4) {
            i3 = this.t;
        } else if (i2 == 6) {
            i3 = this.r;
            if (this.f9815b && i3 <= (i4 = this.q)) {
                i2 = 3;
                i3 = i4;
            }
        } else if (i2 == 3) {
            i3 = H();
        } else {
            if (!this.v || i2 != 5) {
                throw new IllegalArgumentException(c.a.a.a.a.c("Illegal state argument: ", i2));
            }
            i3 = this.F;
        }
        Q(view, i2, i3, false);
    }

    public final void O(int i2) {
        V v = this.G.get();
        if (v == null) {
            return;
        }
        ViewParent parent = v.getParent();
        if (parent != null && parent.isLayoutRequested()) {
            AtomicInteger atomicInteger = q.f1738a;
            if (v.isAttachedToWindow()) {
                v.post(new a(v, i2));
                return;
            }
        }
        N(v, i2);
    }

    public boolean P(View view, float f2) {
        if (this.w) {
            return true;
        }
        if (view.getTop() < this.t) {
            return false;
        }
        return Math.abs(((f2 * 0.1f) + ((float) view.getTop())) - ((float) this.t)) / ((float) C()) > 0.5f;
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x002d, code lost:
    
        if (r7 != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0010, code lost:
    
        if (r0.t(r5.getLeft(), r7) != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x002f, code lost:
    
        r2 = true;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Q(android.view.View r5, int r6, int r7, boolean r8) {
        /*
            r4 = this;
            b.j.b.e r0 = r4.z
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L30
            if (r8 == 0) goto L13
            int r8 = r5.getLeft()
            boolean r7 = r0.t(r8, r7)
            if (r7 == 0) goto L30
            goto L2f
        L13:
            int r8 = r5.getLeft()
            r0.r = r5
            r3 = -1
            r0.f1858c = r3
            boolean r7 = r0.l(r8, r7, r2, r2)
            if (r7 != 0) goto L2d
            int r8 = r0.f1856a
            if (r8 != 0) goto L2d
            android.view.View r8 = r0.r
            if (r8 == 0) goto L2d
            r8 = 0
            r0.r = r8
        L2d:
            if (r7 == 0) goto L30
        L2f:
            r2 = 1
        L30:
            if (r2 == 0) goto L59
            r7 = 2
            r4.M(r7)
            r4.S(r6)
            com.google.android.material.bottomsheet.BottomSheetBehavior<V>$e r7 = r4.n
            if (r7 != 0) goto L44
            com.google.android.material.bottomsheet.BottomSheetBehavior$e r7 = new com.google.android.material.bottomsheet.BottomSheetBehavior$e
            r7.<init>(r5, r6)
            r4.n = r7
        L44:
            com.google.android.material.bottomsheet.BottomSheetBehavior<V>$e r7 = r4.n
            boolean r8 = r7.f9834e
            if (r8 != 0) goto L56
            r7.f9835f = r6
            java.util.concurrent.atomic.AtomicInteger r6 = b.h.k.q.f1738a
            r5.postOnAnimation(r7)
            com.google.android.material.bottomsheet.BottomSheetBehavior<V>$e r5 = r4.n
            r5.f9834e = r1
            goto L5c
        L56:
            r7.f9835f = r6
            goto L5c
        L59:
            r4.M(r6)
        L5c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.Q(android.view.View, int, int, boolean):void");
    }

    public final void R() {
        V v;
        int i2;
        WeakReference<V> weakReference = this.G;
        if (weakReference == null || (v = weakReference.get()) == null) {
            return;
        }
        q.q(524288, v);
        q.m(v, 0);
        q.q(262144, v);
        q.m(v, 0);
        q.q(1048576, v);
        q.m(v, 0);
        int i3 = this.O;
        if (i3 != -1) {
            q.q(i3, v);
            q.m(v, 0);
        }
        if (this.y != 6) {
            String string = v.getResources().getString(2131886228);
            c.d.a.d.h.c cVar = new c.d.a.d.h.c(this, 6);
            List<b.a> j2 = q.j(v);
            int i4 = 0;
            while (true) {
                if (i4 >= j2.size()) {
                    int i5 = -1;
                    int i6 = 0;
                    while (true) {
                        int[] iArr = q.f1743f;
                        if (i6 >= iArr.length || i5 != -1) {
                            break;
                        }
                        int i7 = iArr[i6];
                        boolean z = true;
                        for (int i8 = 0; i8 < j2.size(); i8++) {
                            z &= j2.get(i8).a() != i7;
                        }
                        if (z) {
                            i5 = i7;
                        }
                        i6++;
                    }
                    i2 = i5;
                } else {
                    if (TextUtils.equals(string, j2.get(i4).b())) {
                        i2 = j2.get(i4).a();
                        break;
                    }
                    i4++;
                }
            }
            if (i2 != -1) {
                q.a(v, new b.a(null, i2, string, cVar, null));
            }
            this.O = i2;
        }
        if (this.v && this.y != 5) {
            I(v, b.a.f1798j, 5);
        }
        int i9 = this.y;
        if (i9 == 3) {
            I(v, b.a.f1797i, this.f9815b ? 4 : 6);
            return;
        }
        if (i9 == 4) {
            I(v, b.a.f1796h, this.f9815b ? 3 : 6);
        } else {
            if (i9 != 6) {
                return;
            }
            I(v, b.a.f1797i, 4);
            I(v, b.a.f1796h, 3);
        }
    }

    public final void S(int i2) {
        ValueAnimator valueAnimator;
        if (i2 == 2) {
            return;
        }
        boolean z = i2 == 3;
        if (this.m != z) {
            this.m = z;
            if (this.f9822i == null || (valueAnimator = this.o) == null) {
                return;
            }
            if (valueAnimator.isRunning()) {
                this.o.reverse();
                return;
            }
            float f2 = z ? 0.0f : 1.0f;
            this.o.setFloatValues(1.0f - f2, f2);
            this.o.start();
        }
    }

    public final void T(boolean z) {
        WeakReference<V> weakReference = this.G;
        if (weakReference == null) {
            return;
        }
        ViewParent parent = weakReference.get().getParent();
        if (parent instanceof CoordinatorLayout) {
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
            int childCount = coordinatorLayout.getChildCount();
            if (z) {
                if (this.N != null) {
                    return;
                } else {
                    this.N = new HashMap(childCount);
                }
            }
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                if (childAt != this.G.get() && z) {
                    this.N.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                }
            }
            if (z) {
                return;
            }
            this.N = null;
        }
    }

    public final void U(boolean z) {
        V v;
        if (this.G != null) {
            B();
            if (this.y != 4 || (v = this.G.get()) == null) {
                return;
            }
            if (z) {
                O(this.y);
            } else {
                v.requestLayout();
            }
        }
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void f(CoordinatorLayout.f fVar) {
        this.G = null;
        this.z = null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void i() {
        this.G = null;
        this.z = null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean j(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        b.j.b.e eVar;
        if (!v.isShown() || !this.x) {
            this.A = true;
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.K = -1;
            VelocityTracker velocityTracker = this.J;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.J = null;
            }
        }
        if (this.J == null) {
            this.J = VelocityTracker.obtain();
        }
        this.J.addMovement(motionEvent);
        if (actionMasked == 0) {
            int x = (int) motionEvent.getX();
            this.L = (int) motionEvent.getY();
            if (this.y != 2) {
                WeakReference<View> weakReference = this.H;
                View view = weakReference != null ? weakReference.get() : null;
                if (view != null && coordinatorLayout.q(view, x, this.L)) {
                    this.K = motionEvent.getPointerId(motionEvent.getActionIndex());
                    this.M = true;
                }
            }
            this.A = this.K == -1 && !coordinatorLayout.q(v, x, this.L);
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.M = false;
            this.K = -1;
            if (this.A) {
                this.A = false;
                return false;
            }
        }
        if (!this.A && (eVar = this.z) != null && eVar.u(motionEvent)) {
            return true;
        }
        WeakReference<View> weakReference2 = this.H;
        View view2 = weakReference2 != null ? weakReference2.get() : null;
        return (actionMasked != 2 || view2 == null || this.A || this.y == 1 || coordinatorLayout.q(view2, (int) motionEvent.getX(), (int) motionEvent.getY()) || this.z == null || Math.abs(((float) this.L) - motionEvent.getY()) <= ((float) this.z.f1857b)) ? false : true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean k(CoordinatorLayout coordinatorLayout, V v, int i2) {
        g gVar;
        AtomicInteger atomicInteger = q.f1738a;
        if (coordinatorLayout.getFitsSystemWindows() && !v.getFitsSystemWindows()) {
            v.setFitsSystemWindows(true);
        }
        if (this.G == null) {
            this.f9819f = coordinatorLayout.getResources().getDimensionPixelSize(2131165293);
            if (Build.VERSION.SDK_INT >= 29 && !this.k && !this.f9818e) {
                q.u(v, new l(new c.d.a.d.h.b(this), new o(v.getPaddingStart(), v.getPaddingTop(), v.getPaddingEnd(), v.getPaddingBottom())));
                if (v.isAttachedToWindow()) {
                    v.requestApplyInsets();
                } else {
                    v.addOnAttachStateChangeListener(new m());
                }
            }
            this.G = new WeakReference<>(v);
            if (this.f9821h && (gVar = this.f9822i) != null) {
                v.setBackground(gVar);
            }
            g gVar2 = this.f9822i;
            if (gVar2 != null) {
                float f2 = this.u;
                if (f2 == -1.0f) {
                    f2 = v.getElevation();
                }
                gVar2.p(f2);
                boolean z = this.y == 3;
                this.m = z;
                this.f9822i.r(z ? 0.0f : 1.0f);
            }
            R();
            if (v.getImportantForAccessibility() == 0) {
                v.setImportantForAccessibility(1);
            }
        }
        if (this.z == null) {
            this.z = new b.j.b.e(coordinatorLayout.getContext(), coordinatorLayout, this.P);
        }
        int top = v.getTop();
        coordinatorLayout.s(v, i2);
        this.E = coordinatorLayout.getWidth();
        this.F = coordinatorLayout.getHeight();
        int height = v.getHeight();
        this.D = height;
        this.q = Math.max(0, this.F - height);
        this.r = (int) ((1.0f - this.s) * this.F);
        B();
        int i3 = this.y;
        if (i3 == 3) {
            q.o(v, H());
        } else if (i3 == 6) {
            q.o(v, this.r);
        } else if (this.v && i3 == 5) {
            q.o(v, this.F);
        } else if (i3 == 4) {
            q.o(v, this.t);
        } else if (i3 == 1 || i3 == 2) {
            q.o(v, top - v.getTop());
        }
        this.H = new WeakReference<>(F(v));
        return true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean n(CoordinatorLayout coordinatorLayout, V v, View view, float f2, float f3) {
        WeakReference<View> weakReference = this.H;
        return (weakReference == null || view != weakReference.get() || this.y == 3) ? false : true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void p(CoordinatorLayout coordinatorLayout, V v, View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 1) {
            return;
        }
        WeakReference<View> weakReference = this.H;
        if (view != (weakReference != null ? weakReference.get() : null)) {
            return;
        }
        int top = v.getTop();
        int i5 = top - i3;
        if (i3 > 0) {
            if (i5 < H()) {
                iArr[1] = top - H();
                q.o(v, -iArr[1]);
                M(3);
            } else {
                if (!this.x) {
                    return;
                }
                iArr[1] = i3;
                q.o(v, -i3);
                M(1);
            }
        } else if (i3 < 0 && !view.canScrollVertically(-1)) {
            int i6 = this.t;
            if (i5 > i6 && !this.v) {
                iArr[1] = top - i6;
                q.o(v, -iArr[1]);
                M(4);
            } else {
                if (!this.x) {
                    return;
                }
                iArr[1] = i3;
                q.o(v, -i3);
                M(1);
            }
        }
        E(v.getTop());
        this.B = i3;
        this.C = true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void r(CoordinatorLayout coordinatorLayout, V v, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void u(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        d dVar = (d) parcelable;
        int i2 = this.f9814a;
        if (i2 != 0) {
            if (i2 == -1 || (i2 & 1) == 1) {
                this.f9817d = dVar.f9829g;
            }
            if (i2 == -1 || (i2 & 2) == 2) {
                this.f9815b = dVar.f9830h;
            }
            if (i2 == -1 || (i2 & 4) == 4) {
                this.v = dVar.f9831i;
            }
            if (i2 == -1 || (i2 & 8) == 8) {
                this.w = dVar.f9832j;
            }
        }
        int i3 = dVar.f9828f;
        if (i3 == 1 || i3 == 2) {
            this.y = 4;
        } else {
            this.y = i3;
        }
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public Parcelable v(CoordinatorLayout coordinatorLayout, V v) {
        return new d((Parcelable) View.BaseSavedState.EMPTY_STATE, (BottomSheetBehavior<?>) this);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean x(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i2, int i3) {
        this.B = 0;
        this.C = false;
        return (i2 & 2) != 0;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public void z(CoordinatorLayout coordinatorLayout, V v, View view, int i2) {
        int i3;
        float yVelocity;
        int i4 = 3;
        if (v.getTop() == H()) {
            M(3);
            return;
        }
        WeakReference<View> weakReference = this.H;
        if (weakReference != null && view == weakReference.get() && this.C) {
            if (this.B <= 0) {
                if (this.v) {
                    VelocityTracker velocityTracker = this.J;
                    if (velocityTracker == null) {
                        yVelocity = 0.0f;
                    } else {
                        velocityTracker.computeCurrentVelocity(1000, this.f9816c);
                        yVelocity = this.J.getYVelocity(this.K);
                    }
                    if (P(v, yVelocity)) {
                        i3 = this.F;
                        i4 = 5;
                    }
                }
                if (this.B == 0) {
                    int top = v.getTop();
                    if (!this.f9815b) {
                        int i5 = this.r;
                        if (top < i5) {
                            if (top < Math.abs(top - this.t)) {
                                i3 = this.p;
                            } else {
                                i3 = this.r;
                            }
                        } else if (Math.abs(top - i5) < Math.abs(top - this.t)) {
                            i3 = this.r;
                        } else {
                            i3 = this.t;
                            i4 = 4;
                        }
                        i4 = 6;
                    } else if (Math.abs(top - this.q) < Math.abs(top - this.t)) {
                        i3 = this.q;
                    } else {
                        i3 = this.t;
                        i4 = 4;
                    }
                } else {
                    if (this.f9815b) {
                        i3 = this.t;
                    } else {
                        int top2 = v.getTop();
                        if (Math.abs(top2 - this.r) < Math.abs(top2 - this.t)) {
                            i3 = this.r;
                            i4 = 6;
                        } else {
                            i3 = this.t;
                        }
                    }
                    i4 = 4;
                }
            } else if (this.f9815b) {
                i3 = this.q;
            } else {
                int top3 = v.getTop();
                int i6 = this.r;
                if (top3 > i6) {
                    i3 = i6;
                    i4 = 6;
                } else {
                    i3 = this.p;
                }
            }
            Q(v, i4, i3, false);
            this.C = false;
        }
    }
}