package com.google.android.material.textfield;

import android.R;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatTextView;
import b.b.i.i;
import b.b.i.z;
import b.h.k.q;
import c.d.a.d.b0.m;
import c.d.a.d.b0.n;
import c.d.a.d.x.j;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout.smali */
public class TextInputLayout extends LinearLayout {
    public final TextView A;
    public int A0;
    public boolean B;
    public int B0;
    public CharSequence C;
    public int C0;
    public boolean D;
    public int D0;
    public c.d.a.d.x.g E;
    public int E0;
    public c.d.a.d.x.g F;
    public boolean F0;
    public j G;
    public final c.d.a.d.r.c G0;
    public final int H;
    public boolean H0;
    public int I;
    public boolean I0;
    public int J;
    public ValueAnimator J0;
    public int K;
    public boolean K0;
    public int L;
    public boolean L0;
    public int M;
    public int N;
    public int O;
    public final Rect P;
    public final Rect Q;
    public final RectF R;
    public Typeface S;
    public final CheckableImageButton T;
    public ColorStateList U;
    public boolean V;
    public PorterDuff.Mode W;
    public boolean a0;
    public Drawable b0;
    public int c0;

    /* renamed from: d, reason: collision with root package name */
    public final FrameLayout f9941d;
    public View.OnLongClickListener d0;

    /* renamed from: e, reason: collision with root package name */
    public final LinearLayout f9942e;
    public final LinkedHashSet<f> e0;

    /* renamed from: f, reason: collision with root package name */
    public final LinearLayout f9943f;
    public int f0;

    /* renamed from: g, reason: collision with root package name */
    public final FrameLayout f9944g;
    public final SparseArray<m> g0;

    /* renamed from: h, reason: collision with root package name */
    public EditText f9945h;
    public final CheckableImageButton h0;

    /* renamed from: i, reason: collision with root package name */
    public CharSequence f9946i;
    public final LinkedHashSet<g> i0;

    /* renamed from: j, reason: collision with root package name */
    public final n f9947j;
    public ColorStateList j0;
    public boolean k;
    public boolean k0;
    public int l;
    public PorterDuff.Mode l0;
    public boolean m;
    public boolean m0;
    public TextView n;
    public Drawable n0;
    public int o;
    public int o0;
    public int p;
    public Drawable p0;
    public CharSequence q;
    public View.OnLongClickListener q0;
    public boolean r;
    public View.OnLongClickListener r0;
    public TextView s;
    public final CheckableImageButton s0;
    public ColorStateList t;
    public ColorStateList t0;
    public int u;
    public ColorStateList u0;
    public ColorStateList v;
    public ColorStateList v0;
    public ColorStateList w;
    public int w0;
    public CharSequence x;
    public int x0;
    public final TextView y;
    public int y0;
    public CharSequence z;
    public ColorStateList z0;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$a.smali */
    public class a implements TextWatcher {
        public a() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            TextInputLayout.this.y(!r0.L0, false);
            TextInputLayout textInputLayout = TextInputLayout.this;
            if (textInputLayout.k) {
                textInputLayout.t(editable.length());
            }
            TextInputLayout textInputLayout2 = TextInputLayout.this;
            if (textInputLayout2.r) {
                textInputLayout2.z(editable.length());
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$b.smali */
    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            TextInputLayout.this.h0.performClick();
            TextInputLayout.this.h0.jumpDrawablesToCurrentState();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$c.smali */
    public class c implements Runnable {
        public c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            TextInputLayout.this.f9945h.requestLayout();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$d.smali */
    public class d implements ValueAnimator.AnimatorUpdateListener {
        public d() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TextInputLayout.this.G0.o(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$e.smali */
    public static class e extends b.h.k.a {

        /* renamed from: d, reason: collision with root package name */
        public final TextInputLayout f9952d;

        public e(TextInputLayout textInputLayout) {
            this.f9952d = textInputLayout;
        }

        @Override // b.h.k.a
        public void d(View view, b.h.k.y.b bVar) {
            this.f1718a.onInitializeAccessibilityNodeInfo(view, bVar.f1790a);
            EditText editText = this.f9952d.getEditText();
            Editable text = editText != null ? editText.getText() : null;
            CharSequence hint = this.f9952d.getHint();
            CharSequence error = this.f9952d.getError();
            CharSequence placeholderText = this.f9952d.getPlaceholderText();
            int counterMaxLength = this.f9952d.getCounterMaxLength();
            CharSequence counterOverflowDescription = this.f9952d.getCounterOverflowDescription();
            boolean z = !TextUtils.isEmpty(text);
            boolean z2 = !TextUtils.isEmpty(hint);
            boolean z3 = !this.f9952d.F0;
            boolean z4 = !TextUtils.isEmpty(error);
            boolean z5 = z4 || !TextUtils.isEmpty(counterOverflowDescription);
            String charSequence = z2 ? hint.toString() : "";
            if (z) {
                bVar.f1790a.setText(text);
            } else if (!TextUtils.isEmpty(charSequence)) {
                bVar.f1790a.setText(charSequence);
                if (z3 && placeholderText != null) {
                    bVar.f1790a.setText(charSequence + ", " + ((Object) placeholderText));
                }
            } else if (placeholderText != null) {
                bVar.f1790a.setText(placeholderText);
            }
            if (!TextUtils.isEmpty(charSequence)) {
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 26) {
                    bVar.k(charSequence);
                } else {
                    if (z) {
                        charSequence = ((Object) text) + ", " + charSequence;
                    }
                    bVar.f1790a.setText(charSequence);
                }
                boolean z6 = !z;
                if (i2 >= 26) {
                    bVar.f1790a.setShowingHintText(z6);
                } else {
                    bVar.h(4, z6);
                }
            }
            if (text == null || text.length() != counterMaxLength) {
                counterMaxLength = -1;
            }
            bVar.f1790a.setMaxTextLength(counterMaxLength);
            if (z5) {
                if (!z4) {
                    error = counterOverflowDescription;
                }
                bVar.f1790a.setError(error);
            }
            if (editText != null) {
                editText.setLabelFor(2131362561);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$f.smali */
    public interface f {
        void a(TextInputLayout textInputLayout);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$g.smali */
    public interface g {
        void a(TextInputLayout textInputLayout, int i2);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$h.smali */
    public static class h extends b.j.a.a {
        public static final Parcelable.Creator<h> CREATOR = new a();

        /* renamed from: f, reason: collision with root package name */
        public CharSequence f9953f;

        /* renamed from: g, reason: collision with root package name */
        public boolean f9954g;

        /* renamed from: h, reason: collision with root package name */
        public CharSequence f9955h;

        /* renamed from: i, reason: collision with root package name */
        public CharSequence f9956i;

        /* renamed from: j, reason: collision with root package name */
        public CharSequence f9957j;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\textfield\TextInputLayout$h$a.smali */
        public static class a implements Parcelable.ClassLoaderCreator<h> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new h(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public h createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new h(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new h[i2];
            }
        }

        public h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f9953f = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f9954g = parcel.readInt() == 1;
            this.f9955h = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f9956i = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f9957j = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        }

        public h(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder n = c.a.a.a.a.n("TextInputLayout.SavedState{");
            n.append(Integer.toHexString(System.identityHashCode(this)));
            n.append(" error=");
            n.append((Object) this.f9953f);
            n.append(" hint=");
            n.append((Object) this.f9955h);
            n.append(" helperText=");
            n.append((Object) this.f9956i);
            n.append(" placeholderText=");
            n.append((Object) this.f9957j);
            n.append("}");
            return n.toString();
        }

        @Override // b.j.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.f1843d, i2);
            TextUtils.writeToParcel(this.f9953f, parcel, i2);
            parcel.writeInt(this.f9954g ? 1 : 0);
            TextUtils.writeToParcel(this.f9955h, parcel, i2);
            TextUtils.writeToParcel(this.f9956i, parcel, i2);
            TextUtils.writeToParcel(this.f9957j, parcel, i2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x05e0  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x056b  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x057a  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x058b  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x059c  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x05ad  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x05be  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x05cf  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public TextInputLayout(android.content.Context r31, android.util.AttributeSet r32) {
        /*
            Method dump skipped, instructions count: 1578
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    private m getEndIconDelegate() {
        m mVar = this.g0.get(this.f0);
        return mVar != null ? mVar : this.g0.get(0);
    }

    private CheckableImageButton getEndIconToUpdateDummyDrawable() {
        if (this.s0.getVisibility() == 0) {
            return this.s0;
        }
        if (j() && k()) {
            return this.h0;
        }
        return null;
    }

    public static void n(ViewGroup viewGroup, boolean z) {
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            childAt.setEnabled(z);
            if (childAt instanceof ViewGroup) {
                n((ViewGroup) childAt, z);
            }
        }
    }

    public static void q(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        AtomicInteger atomicInteger = q.f1738a;
        boolean hasOnClickListeners = checkableImageButton.hasOnClickListeners();
        boolean z = onLongClickListener != null;
        boolean z2 = hasOnClickListeners || z;
        checkableImageButton.setFocusable(z2);
        checkableImageButton.setClickable(hasOnClickListeners);
        checkableImageButton.setPressable(hasOnClickListeners);
        checkableImageButton.setLongClickable(z);
        checkableImageButton.setImportantForAccessibility(z2 ? 1 : 2);
    }

    private void setEditText(EditText editText) {
        if (this.f9945h != null) {
            throw new IllegalArgumentException("We already have an EditText, can only have one");
        }
        if (this.f0 != 3 && !(editText instanceof TextInputEditText)) {
            Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead.");
        }
        this.f9945h = editText;
        l();
        setTextInputAccessibilityDelegate(new e(this));
        this.G0.q(this.f9945h.getTypeface());
        c.d.a.d.r.c cVar = this.G0;
        float textSize = this.f9945h.getTextSize();
        if (cVar.f8848i != textSize) {
            cVar.f8848i = textSize;
            cVar.k();
        }
        int gravity = this.f9945h.getGravity();
        this.G0.n((gravity & (-113)) | 48);
        c.d.a.d.r.c cVar2 = this.G0;
        if (cVar2.f8846g != gravity) {
            cVar2.f8846g = gravity;
            cVar2.k();
        }
        this.f9945h.addTextChangedListener(new a());
        if (this.u0 == null) {
            this.u0 = this.f9945h.getHintTextColors();
        }
        if (this.B) {
            if (TextUtils.isEmpty(this.C)) {
                CharSequence hint = this.f9945h.getHint();
                this.f9946i = hint;
                setHint(hint);
                this.f9945h.setHint((CharSequence) null);
            }
            this.D = true;
        }
        if (this.n != null) {
            t(this.f9945h.getText().length());
        }
        w();
        this.f9947j.b();
        this.f9942e.bringToFront();
        this.f9943f.bringToFront();
        this.f9944g.bringToFront();
        this.s0.bringToFront();
        Iterator<f> it = this.e0.iterator();
        while (it.hasNext()) {
            it.next().a(this);
        }
        A();
        D();
        if (!isEnabled()) {
            editText.setEnabled(false);
        }
        y(false, true);
    }

    private void setErrorIconVisible(boolean z) {
        this.s0.setVisibility(z ? 0 : 8);
        this.f9944g.setVisibility(z ? 8 : 0);
        D();
        if (j()) {
            return;
        }
        v();
    }

    private void setHintInternal(CharSequence charSequence) {
        if (TextUtils.equals(charSequence, this.C)) {
            return;
        }
        this.C = charSequence;
        c.d.a.d.r.c cVar = this.G0;
        if (charSequence == null || !TextUtils.equals(cVar.w, charSequence)) {
            cVar.w = charSequence;
            cVar.x = null;
            Bitmap bitmap = cVar.z;
            if (bitmap != null) {
                bitmap.recycle();
                cVar.z = null;
            }
            cVar.k();
        }
        if (this.F0) {
            return;
        }
        m();
    }

    private void setPlaceholderTextEnabled(boolean z) {
        if (this.r == z) {
            return;
        }
        if (z) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null);
            this.s = appCompatTextView;
            appCompatTextView.setId(2131362562);
            TextView textView = this.s;
            AtomicInteger atomicInteger = q.f1738a;
            textView.setAccessibilityLiveRegion(1);
            setPlaceholderTextAppearance(this.u);
            setPlaceholderTextColor(this.t);
            TextView textView2 = this.s;
            if (textView2 != null) {
                this.f9941d.addView(textView2);
                this.s.setVisibility(0);
            }
        } else {
            TextView textView3 = this.s;
            if (textView3 != null) {
                textView3.setVisibility(8);
            }
            this.s = null;
        }
        this.r = z;
    }

    public final void A() {
        if (this.f9945h == null) {
            return;
        }
        int i2 = 0;
        if (!(this.T.getVisibility() == 0)) {
            EditText editText = this.f9945h;
            AtomicInteger atomicInteger = q.f1738a;
            i2 = editText.getPaddingStart();
        }
        TextView textView = this.y;
        int compoundPaddingTop = this.f9945h.getCompoundPaddingTop();
        int dimensionPixelSize = getContext().getResources().getDimensionPixelSize(2131165366);
        int compoundPaddingBottom = this.f9945h.getCompoundPaddingBottom();
        AtomicInteger atomicInteger2 = q.f1738a;
        textView.setPaddingRelative(i2, compoundPaddingTop, dimensionPixelSize, compoundPaddingBottom);
    }

    public final void B() {
        this.y.setVisibility((this.x == null || this.F0) ? 8 : 0);
        v();
    }

    public final void C(boolean z, boolean z2) {
        int defaultColor = this.z0.getDefaultColor();
        int colorForState = this.z0.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, defaultColor);
        int colorForState2 = this.z0.getColorForState(new int[]{R.attr.state_activated, R.attr.state_enabled}, defaultColor);
        if (z) {
            this.N = colorForState2;
        } else if (z2) {
            this.N = colorForState;
        } else {
            this.N = defaultColor;
        }
    }

    public final void D() {
        if (this.f9945h == null) {
            return;
        }
        int i2 = 0;
        if (!k()) {
            if (!(this.s0.getVisibility() == 0)) {
                EditText editText = this.f9945h;
                AtomicInteger atomicInteger = q.f1738a;
                i2 = editText.getPaddingEnd();
            }
        }
        TextView textView = this.A;
        int dimensionPixelSize = getContext().getResources().getDimensionPixelSize(2131165366);
        int paddingTop = this.f9945h.getPaddingTop();
        int paddingBottom = this.f9945h.getPaddingBottom();
        AtomicInteger atomicInteger2 = q.f1738a;
        textView.setPaddingRelative(dimensionPixelSize, paddingTop, i2, paddingBottom);
    }

    public final void E() {
        int visibility = this.A.getVisibility();
        boolean z = (this.z == null || this.F0) ? false : true;
        this.A.setVisibility(z ? 0 : 8);
        if (visibility != this.A.getVisibility()) {
            getEndIconDelegate().c(z);
        }
        v();
    }

    public void F() {
        TextView textView;
        EditText editText;
        EditText editText2;
        if (this.E == null || this.I == 0) {
            return;
        }
        boolean z = false;
        boolean z2 = isFocused() || ((editText2 = this.f9945h) != null && editText2.hasFocus());
        boolean z3 = isHovered() || ((editText = this.f9945h) != null && editText.isHovered());
        if (!isEnabled()) {
            this.N = this.E0;
        } else if (this.f9947j.e()) {
            if (this.z0 != null) {
                C(z2, z3);
            } else {
                this.N = this.f9947j.g();
            }
        } else if (!this.m || (textView = this.n) == null) {
            if (z2) {
                this.N = this.y0;
            } else if (z3) {
                this.N = this.x0;
            } else {
                this.N = this.w0;
            }
        } else if (this.z0 != null) {
            C(z2, z3);
        } else {
            this.N = textView.getCurrentTextColor();
        }
        if (getErrorIconDrawable() != null) {
            n nVar = this.f9947j;
            if (nVar.k && nVar.e()) {
                z = true;
            }
        }
        setErrorIconVisible(z);
        p(this.s0, this.t0);
        p(this.T, this.U);
        o();
        if (getEndIconDelegate().d()) {
            if (!this.f9947j.e() || getEndIconDrawable() == null) {
                d();
            } else {
                Drawable mutate = b.h.a.X(getEndIconDrawable()).mutate();
                mutate.setTint(this.f9947j.g());
                this.h0.setImageDrawable(mutate);
            }
        }
        if (z2 && isEnabled()) {
            this.K = this.M;
        } else {
            this.K = this.L;
        }
        if (this.I == 1) {
            if (!isEnabled()) {
                this.O = this.B0;
            } else if (z3 && !z2) {
                this.O = this.D0;
            } else if (z2) {
                this.O = this.C0;
            } else {
                this.O = this.A0;
            }
        }
        c();
    }

    public void a(f fVar) {
        this.e0.add(fVar);
        if (this.f9945h != null) {
            fVar.a(this);
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!(view instanceof EditText)) {
            super.addView(view, i2, layoutParams);
            return;
        }
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
        layoutParams2.gravity = (layoutParams2.gravity & (-113)) | 16;
        this.f9941d.addView(view, layoutParams2);
        this.f9941d.setLayoutParams(layoutParams);
        x();
        setEditText((EditText) view);
    }

    public void b(float f2) {
        if (this.G0.f8842c == f2) {
            return;
        }
        if (this.J0 == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.J0 = valueAnimator;
            valueAnimator.setInterpolator(c.d.a.d.c.a.f8579b);
            this.J0.setDuration(167L);
            this.J0.addUpdateListener(new d());
        }
        this.J0.setFloatValues(this.G0.f8842c, f2);
        this.J0.start();
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0063  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c() {
        /*
            r6 = this;
            c.d.a.d.x.g r0 = r6.E
            if (r0 != 0) goto L5
            return
        L5:
            c.d.a.d.x.j r1 = r6.G
            r0.setShapeAppearanceModel(r1)
            int r0 = r6.I
            r1 = 2
            r2 = -1
            r3 = 0
            r4 = 1
            if (r0 != r1) goto L21
            int r0 = r6.K
            if (r0 <= r2) goto L1c
            int r0 = r6.N
            if (r0 == 0) goto L1c
            r0 = 1
            goto L1d
        L1c:
            r0 = 0
        L1d:
            if (r0 == 0) goto L21
            r0 = 1
            goto L22
        L21:
            r0 = 0
        L22:
            if (r0 == 0) goto L2e
            c.d.a.d.x.g r0 = r6.E
            int r1 = r6.K
            float r1 = (float) r1
            int r5 = r6.N
            r0.t(r1, r5)
        L2e:
            int r0 = r6.O
            int r1 = r6.I
            if (r1 != r4) goto L45
            r0 = 2130968823(0x7f0400f7, float:1.754631E38)
            android.content.Context r1 = r6.getContext()
            int r0 = c.d.a.d.a.A(r1, r0, r3)
            int r1 = r6.O
            int r0 = b.h.e.a.a(r1, r0)
        L45:
            r6.O = r0
            c.d.a.d.x.g r1 = r6.E
            android.content.res.ColorStateList r0 = android.content.res.ColorStateList.valueOf(r0)
            r1.q(r0)
            int r0 = r6.f0
            r1 = 3
            if (r0 != r1) goto L5e
            android.widget.EditText r0 = r6.f9945h
            android.graphics.drawable.Drawable r0 = r0.getBackground()
            r0.invalidateSelf()
        L5e:
            c.d.a.d.x.g r0 = r6.F
            if (r0 != 0) goto L63
            goto L7a
        L63:
            int r1 = r6.K
            if (r1 <= r2) goto L6c
            int r1 = r6.N
            if (r1 == 0) goto L6c
            r3 = 1
        L6c:
            if (r3 == 0) goto L77
            int r1 = r6.N
            android.content.res.ColorStateList r1 = android.content.res.ColorStateList.valueOf(r1)
            r0.q(r1)
        L77:
            r6.invalidate()
        L7a:
            r6.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.c():void");
    }

    public final void d() {
        e(this.h0, this.k0, this.j0, this.m0, this.l0);
    }

    @Override // android.view.ViewGroup, android.view.View
    @TargetApi(26)
    public void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i2) {
        EditText editText = this.f9945h;
        if (editText == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i2);
            return;
        }
        if (this.f9946i != null) {
            boolean z = this.D;
            this.D = false;
            CharSequence hint = editText.getHint();
            this.f9945h.setHint(this.f9946i);
            try {
                super.dispatchProvideAutofillStructure(viewStructure, i2);
                return;
            } finally {
                this.f9945h.setHint(hint);
                this.D = z;
            }
        }
        viewStructure.setAutofillId(getAutofillId());
        onProvideAutofillStructure(viewStructure, i2);
        onProvideAutofillVirtualStructure(viewStructure, i2);
        viewStructure.setChildCount(this.f9941d.getChildCount());
        for (int i3 = 0; i3 < this.f9941d.getChildCount(); i3++) {
            View childAt = this.f9941d.getChildAt(i3);
            ViewStructure newChild = viewStructure.newChild(i3);
            childAt.dispatchProvideAutofillStructure(newChild, i2);
            if (childAt == this.f9945h) {
                newChild.setHint(getHint());
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        this.L0 = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.L0 = false;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.B) {
            c.d.a.d.r.c cVar = this.G0;
            Objects.requireNonNull(cVar);
            int save = canvas.save();
            if (cVar.x != null && cVar.f8841b) {
                cVar.N.getLineLeft(0);
                cVar.E.setTextSize(cVar.B);
                float f2 = cVar.q;
                float f3 = cVar.r;
                float f4 = cVar.A;
                if (f4 != 1.0f) {
                    canvas.scale(f4, f4, f2, f3);
                }
                canvas.translate(f2, f3);
                cVar.N.draw(canvas);
                canvas.restoreToCount(save);
            }
        }
        c.d.a.d.x.g gVar = this.F;
        if (gVar != null) {
            Rect bounds = gVar.getBounds();
            bounds.top = bounds.bottom - this.K;
            this.F.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        boolean z;
        ColorStateList colorStateList;
        boolean z2;
        if (this.K0) {
            return;
        }
        this.K0 = true;
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        c.d.a.d.r.c cVar = this.G0;
        if (cVar != null) {
            cVar.C = drawableState;
            ColorStateList colorStateList2 = cVar.l;
            if ((colorStateList2 != null && colorStateList2.isStateful()) || ((colorStateList = cVar.k) != null && colorStateList.isStateful())) {
                cVar.k();
                z2 = true;
            } else {
                z2 = false;
            }
            z = z2 | false;
        } else {
            z = false;
        }
        if (this.f9945h != null) {
            AtomicInteger atomicInteger = q.f1738a;
            y(isLaidOut() && isEnabled(), false);
        }
        w();
        F();
        if (z) {
            invalidate();
        }
        this.K0 = false;
    }

    public final void e(CheckableImageButton checkableImageButton, boolean z, ColorStateList colorStateList, boolean z2, PorterDuff.Mode mode) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (drawable != null && (z || z2)) {
            drawable = b.h.a.X(drawable).mutate();
            if (z) {
                drawable.setTintList(colorStateList);
            }
            if (z2) {
                drawable.setTintMode(mode);
            }
        }
        if (checkableImageButton.getDrawable() != drawable) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    public final int f() {
        float f2;
        if (!this.B) {
            return 0;
        }
        int i2 = this.I;
        if (i2 == 0 || i2 == 1) {
            f2 = this.G0.f();
        } else {
            if (i2 != 2) {
                return 0;
            }
            f2 = this.G0.f() / 2.0f;
        }
        return (int) f2;
    }

    public final boolean g() {
        return this.B && !TextUtils.isEmpty(this.C) && (this.E instanceof c.d.a.d.b0.g);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public int getBaseline() {
        EditText editText = this.f9945h;
        if (editText == null) {
            return super.getBaseline();
        }
        return f() + getPaddingTop() + editText.getBaseline();
    }

    public c.d.a.d.x.g getBoxBackground() {
        int i2 = this.I;
        if (i2 == 1 || i2 == 2) {
            return this.E;
        }
        throw new IllegalStateException();
    }

    public int getBoxBackgroundColor() {
        return this.O;
    }

    public int getBoxBackgroundMode() {
        return this.I;
    }

    public float getBoxCornerRadiusBottomEnd() {
        c.d.a.d.x.g gVar = this.E;
        return gVar.f8986d.f8994a.f9012h.a(gVar.h());
    }

    public float getBoxCornerRadiusBottomStart() {
        c.d.a.d.x.g gVar = this.E;
        return gVar.f8986d.f8994a.f9011g.a(gVar.h());
    }

    public float getBoxCornerRadiusTopEnd() {
        c.d.a.d.x.g gVar = this.E;
        return gVar.f8986d.f8994a.f9010f.a(gVar.h());
    }

    public float getBoxCornerRadiusTopStart() {
        return this.E.l();
    }

    public int getBoxStrokeColor() {
        return this.y0;
    }

    public ColorStateList getBoxStrokeErrorColor() {
        return this.z0;
    }

    public int getBoxStrokeWidth() {
        return this.L;
    }

    public int getBoxStrokeWidthFocused() {
        return this.M;
    }

    public int getCounterMaxLength() {
        return this.l;
    }

    public CharSequence getCounterOverflowDescription() {
        TextView textView;
        if (this.k && this.m && (textView = this.n) != null) {
            return textView.getContentDescription();
        }
        return null;
    }

    public ColorStateList getCounterOverflowTextColor() {
        return this.v;
    }

    public ColorStateList getCounterTextColor() {
        return this.v;
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.u0;
    }

    public EditText getEditText() {
        return this.f9945h;
    }

    public CharSequence getEndIconContentDescription() {
        return this.h0.getContentDescription();
    }

    public Drawable getEndIconDrawable() {
        return this.h0.getDrawable();
    }

    public int getEndIconMode() {
        return this.f0;
    }

    public CheckableImageButton getEndIconView() {
        return this.h0;
    }

    public CharSequence getError() {
        n nVar = this.f9947j;
        if (nVar.k) {
            return nVar.f8559j;
        }
        return null;
    }

    public CharSequence getErrorContentDescription() {
        return this.f9947j.m;
    }

    public int getErrorCurrentTextColors() {
        return this.f9947j.g();
    }

    public Drawable getErrorIconDrawable() {
        return this.s0.getDrawable();
    }

    public final int getErrorTextCurrentColor() {
        return this.f9947j.g();
    }

    public CharSequence getHelperText() {
        n nVar = this.f9947j;
        if (nVar.q) {
            return nVar.p;
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        TextView textView = this.f9947j.r;
        if (textView != null) {
            return textView.getCurrentTextColor();
        }
        return -1;
    }

    public CharSequence getHint() {
        if (this.B) {
            return this.C;
        }
        return null;
    }

    public final float getHintCollapsedTextHeight() {
        return this.G0.f();
    }

    public final int getHintCurrentCollapsedTextColor() {
        return this.G0.g();
    }

    public ColorStateList getHintTextColor() {
        return this.v0;
    }

    @Deprecated
    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.h0.getContentDescription();
    }

    @Deprecated
    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.h0.getDrawable();
    }

    public CharSequence getPlaceholderText() {
        if (this.r) {
            return this.q;
        }
        return null;
    }

    public int getPlaceholderTextAppearance() {
        return this.u;
    }

    public ColorStateList getPlaceholderTextColor() {
        return this.t;
    }

    public CharSequence getPrefixText() {
        return this.x;
    }

    public ColorStateList getPrefixTextColor() {
        return this.y.getTextColors();
    }

    public TextView getPrefixTextView() {
        return this.y;
    }

    public CharSequence getStartIconContentDescription() {
        return this.T.getContentDescription();
    }

    public Drawable getStartIconDrawable() {
        return this.T.getDrawable();
    }

    public CharSequence getSuffixText() {
        return this.z;
    }

    public ColorStateList getSuffixTextColor() {
        return this.A.getTextColors();
    }

    public TextView getSuffixTextView() {
        return this.A;
    }

    public Typeface getTypeface() {
        return this.S;
    }

    public final int h(int i2, boolean z) {
        int compoundPaddingLeft = this.f9945h.getCompoundPaddingLeft() + i2;
        return (this.x == null || z) ? compoundPaddingLeft : (compoundPaddingLeft - this.y.getMeasuredWidth()) + this.y.getPaddingLeft();
    }

    public final int i(int i2, boolean z) {
        int compoundPaddingRight = i2 - this.f9945h.getCompoundPaddingRight();
        return (this.x == null || !z) ? compoundPaddingRight : compoundPaddingRight + (this.y.getMeasuredWidth() - this.y.getPaddingRight());
    }

    public final boolean j() {
        return this.f0 != 0;
    }

    public boolean k() {
        return this.f9944g.getVisibility() == 0 && this.h0.getVisibility() == 0;
    }

    public final void l() {
        int i2 = this.I;
        if (i2 == 0) {
            this.E = null;
            this.F = null;
        } else if (i2 == 1) {
            this.E = new c.d.a.d.x.g(this.G);
            this.F = new c.d.a.d.x.g();
        } else {
            if (i2 != 2) {
                throw new IllegalArgumentException(this.I + " is illegal; only @BoxBackgroundMode constants are supported.");
            }
            if (!this.B || (this.E instanceof c.d.a.d.b0.g)) {
                this.E = new c.d.a.d.x.g(this.G);
            } else {
                this.E = new c.d.a.d.b0.g(this.G);
            }
            this.F = null;
        }
        EditText editText = this.f9945h;
        if ((editText == null || this.E == null || editText.getBackground() != null || this.I == 0) ? false : true) {
            EditText editText2 = this.f9945h;
            c.d.a.d.x.g gVar = this.E;
            AtomicInteger atomicInteger = q.f1738a;
            editText2.setBackground(gVar);
        }
        F();
        if (this.I == 1) {
            if (c.d.a.d.a.L(getContext())) {
                this.J = getResources().getDimensionPixelSize(2131165362);
            } else if (c.d.a.d.a.K(getContext())) {
                this.J = getResources().getDimensionPixelSize(2131165361);
            }
        }
        if (this.f9945h != null && this.I == 1) {
            if (c.d.a.d.a.L(getContext())) {
                EditText editText3 = this.f9945h;
                AtomicInteger atomicInteger2 = q.f1738a;
                editText3.setPaddingRelative(editText3.getPaddingStart(), getResources().getDimensionPixelSize(2131165360), this.f9945h.getPaddingEnd(), getResources().getDimensionPixelSize(2131165359));
            } else if (c.d.a.d.a.K(getContext())) {
                EditText editText4 = this.f9945h;
                AtomicInteger atomicInteger3 = q.f1738a;
                editText4.setPaddingRelative(editText4.getPaddingStart(), getResources().getDimensionPixelSize(2131165358), this.f9945h.getPaddingEnd(), getResources().getDimensionPixelSize(2131165357));
            }
        }
        if (this.I != 0) {
            x();
        }
    }

    public final void m() {
        float f2;
        float b2;
        float f3;
        float b3;
        int i2;
        float b4;
        int i3;
        if (g()) {
            RectF rectF = this.R;
            c.d.a.d.r.c cVar = this.G0;
            int width = this.f9945h.getWidth();
            int gravity = this.f9945h.getGravity();
            boolean c2 = cVar.c(cVar.w);
            cVar.y = c2;
            if (gravity != 17 && (gravity & 7) != 1) {
                if ((gravity & 8388613) == 8388613 || (gravity & 5) == 5) {
                    if (c2) {
                        i3 = cVar.f8844e.left;
                        f3 = i3;
                    } else {
                        f2 = cVar.f8844e.right;
                        b2 = cVar.b();
                    }
                } else if (c2) {
                    f2 = cVar.f8844e.right;
                    b2 = cVar.b();
                } else {
                    i3 = cVar.f8844e.left;
                    f3 = i3;
                }
                rectF.left = f3;
                Rect rect = cVar.f8844e;
                rectF.top = rect.top;
                if (gravity != 17 || (gravity & 7) == 1) {
                    b3 = (width / 2.0f) + (cVar.b() / 2.0f);
                } else if ((gravity & 8388613) == 8388613 || (gravity & 5) == 5) {
                    if (cVar.y) {
                        b4 = cVar.b();
                        b3 = b4 + f3;
                    } else {
                        i2 = rect.right;
                        b3 = i2;
                    }
                } else if (cVar.y) {
                    i2 = rect.right;
                    b3 = i2;
                } else {
                    b4 = cVar.b();
                    b3 = b4 + f3;
                }
                rectF.right = b3;
                float f4 = cVar.f() + cVar.f8844e.top;
                rectF.bottom = f4;
                float f5 = rectF.left;
                float f6 = this.H;
                rectF.left = f5 - f6;
                rectF.top -= f6;
                rectF.right += f6;
                rectF.bottom = f4 + f6;
                rectF.offset(-getPaddingLeft(), -getPaddingTop());
                c.d.a.d.b0.g gVar = (c.d.a.d.b0.g) this.E;
                Objects.requireNonNull(gVar);
                gVar.z(rectF.left, rectF.top, rectF.right, rectF.bottom);
            }
            f2 = width / 2.0f;
            b2 = cVar.b() / 2.0f;
            f3 = f2 - b2;
            rectF.left = f3;
            Rect rect2 = cVar.f8844e;
            rectF.top = rect2.top;
            if (gravity != 17) {
            }
            b3 = (width / 2.0f) + (cVar.b() / 2.0f);
            rectF.right = b3;
            float f42 = cVar.f() + cVar.f8844e.top;
            rectF.bottom = f42;
            float f52 = rectF.left;
            float f62 = this.H;
            rectF.left = f52 - f62;
            rectF.top -= f62;
            rectF.right += f62;
            rectF.bottom = f42 + f62;
            rectF.offset(-getPaddingLeft(), -getPaddingTop());
            c.d.a.d.b0.g gVar2 = (c.d.a.d.b0.g) this.E;
            Objects.requireNonNull(gVar2);
            gVar2.z(rectF.left, rectF.top, rectF.right, rectF.bottom);
        }
    }

    public void o() {
        p(this.h0, this.j0);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        EditText editText = this.f9945h;
        if (editText != null) {
            Rect rect = this.P;
            c.d.a.d.r.d.a(this, editText, rect);
            c.d.a.d.x.g gVar = this.F;
            if (gVar != null) {
                int i6 = rect.bottom;
                gVar.setBounds(rect.left, i6 - this.M, rect.right, i6);
            }
            if (this.B) {
                c.d.a.d.r.c cVar = this.G0;
                float textSize = this.f9945h.getTextSize();
                if (cVar.f8848i != textSize) {
                    cVar.f8848i = textSize;
                    cVar.k();
                }
                int gravity = this.f9945h.getGravity();
                this.G0.n((gravity & (-113)) | 48);
                c.d.a.d.r.c cVar2 = this.G0;
                if (cVar2.f8846g != gravity) {
                    cVar2.f8846g = gravity;
                    cVar2.k();
                }
                c.d.a.d.r.c cVar3 = this.G0;
                if (this.f9945h == null) {
                    throw new IllegalStateException();
                }
                Rect rect2 = this.Q;
                AtomicInteger atomicInteger = q.f1738a;
                boolean z2 = false;
                boolean z3 = getLayoutDirection() == 1;
                rect2.bottom = rect.bottom;
                int i7 = this.I;
                if (i7 == 1) {
                    rect2.left = h(rect.left, z3);
                    rect2.top = rect.top + this.J;
                    rect2.right = i(rect.right, z3);
                } else if (i7 != 2) {
                    rect2.left = h(rect.left, z3);
                    rect2.top = getPaddingTop();
                    rect2.right = i(rect.right, z3);
                } else {
                    rect2.left = this.f9945h.getPaddingLeft() + rect.left;
                    rect2.top = rect.top - f();
                    rect2.right = rect.right - this.f9945h.getPaddingRight();
                }
                Objects.requireNonNull(cVar3);
                int i8 = rect2.left;
                int i9 = rect2.top;
                int i10 = rect2.right;
                int i11 = rect2.bottom;
                if (!c.d.a.d.r.c.l(cVar3.f8844e, i8, i9, i10, i11)) {
                    cVar3.f8844e.set(i8, i9, i10, i11);
                    cVar3.D = true;
                    cVar3.j();
                }
                c.d.a.d.r.c cVar4 = this.G0;
                if (this.f9945h == null) {
                    throw new IllegalStateException();
                }
                Rect rect3 = this.Q;
                TextPaint textPaint = cVar4.F;
                textPaint.setTextSize(cVar4.f8848i);
                textPaint.setTypeface(cVar4.t);
                textPaint.setLetterSpacing(0.0f);
                float f2 = -cVar4.F.ascent();
                rect3.left = this.f9945h.getCompoundPaddingLeft() + rect.left;
                rect3.top = this.I == 1 && this.f9945h.getMinLines() <= 1 ? (int) (rect.centerY() - (f2 / 2.0f)) : rect.top + this.f9945h.getCompoundPaddingTop();
                rect3.right = rect.right - this.f9945h.getCompoundPaddingRight();
                if (this.I == 1 && this.f9945h.getMinLines() <= 1) {
                    z2 = true;
                }
                int compoundPaddingBottom = z2 ? (int) (rect3.top + f2) : rect.bottom - this.f9945h.getCompoundPaddingBottom();
                rect3.bottom = compoundPaddingBottom;
                int i12 = rect3.left;
                int i13 = rect3.top;
                int i14 = rect3.right;
                if (!c.d.a.d.r.c.l(cVar4.f8843d, i12, i13, i14, compoundPaddingBottom)) {
                    cVar4.f8843d.set(i12, i13, i14, compoundPaddingBottom);
                    cVar4.D = true;
                    cVar4.j();
                }
                this.G0.k();
                if (!g() || this.F0) {
                    return;
                }
                m();
            }
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        EditText editText;
        int max;
        super.onMeasure(i2, i3);
        boolean z = false;
        if (this.f9945h != null && this.f9945h.getMeasuredHeight() < (max = Math.max(this.f9943f.getMeasuredHeight(), this.f9942e.getMeasuredHeight()))) {
            this.f9945h.setMinimumHeight(max);
            z = true;
        }
        boolean v = v();
        if (z || v) {
            this.f9945h.post(new c());
        }
        if (this.s != null && (editText = this.f9945h) != null) {
            this.s.setGravity(editText.getGravity());
            this.s.setPadding(this.f9945h.getCompoundPaddingLeft(), this.f9945h.getCompoundPaddingTop(), this.f9945h.getCompoundPaddingRight(), this.f9945h.getCompoundPaddingBottom());
        }
        A();
        D();
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        h hVar = (h) parcelable;
        super.onRestoreInstanceState(hVar.f1843d);
        setError(hVar.f9953f);
        if (hVar.f9954g) {
            this.h0.post(new b());
        }
        setHint(hVar.f9955h);
        setHelperText(hVar.f9956i);
        setPlaceholderText(hVar.f9957j);
        requestLayout();
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        h hVar = new h(super.onSaveInstanceState());
        if (this.f9947j.e()) {
            hVar.f9953f = getError();
        }
        hVar.f9954g = j() && this.h0.isChecked();
        hVar.f9955h = getHint();
        hVar.f9956i = getHelperText();
        hVar.f9957j = getPlaceholderText();
        return hVar;
    }

    public final void p(CheckableImageButton checkableImageButton, ColorStateList colorStateList) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (checkableImageButton.getDrawable() == null || colorStateList == null || !colorStateList.isStateful()) {
            return;
        }
        int[] drawableState = getDrawableState();
        int[] drawableState2 = checkableImageButton.getDrawableState();
        int length = drawableState.length;
        int[] copyOf = Arrays.copyOf(drawableState, drawableState.length + drawableState2.length);
        System.arraycopy(drawableState2, 0, copyOf, length, drawableState2.length);
        int colorForState = colorStateList.getColorForState(copyOf, colorStateList.getDefaultColor());
        Drawable mutate = b.h.a.X(drawable).mutate();
        mutate.setTintList(ColorStateList.valueOf(colorForState));
        checkableImageButton.setImageDrawable(mutate);
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0015, code lost:
    
        if (r3.getTextColors().getDefaultColor() == (-65281)) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void r(android.widget.TextView r3, int r4) {
        /*
            r2 = this;
            r0 = 1
            b.h.a.O(r3, r4)     // Catch: java.lang.Exception -> L1b
            int r4 = android.os.Build.VERSION.SDK_INT     // Catch: java.lang.Exception -> L1b
            r1 = 23
            if (r4 < r1) goto L18
            android.content.res.ColorStateList r4 = r3.getTextColors()     // Catch: java.lang.Exception -> L1b
            int r4 = r4.getDefaultColor()     // Catch: java.lang.Exception -> L1b
            r1 = -65281(0xffffffffffff00ff, float:NaN)
            if (r4 != r1) goto L18
            goto L1c
        L18:
            r4 = 0
            r0 = 0
            goto L1c
        L1b:
        L1c:
            if (r0 == 0) goto L32
            r4 = 2131951977(0x7f130169, float:1.9540384E38)
            b.h.a.O(r3, r4)
            android.content.Context r4 = r2.getContext()
            r0 = 2131099757(0x7f06006d, float:1.7811876E38)
            int r4 = b.h.d.a.b(r4, r0)
            r3.setTextColor(r4)
        L32:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.r(android.widget.TextView, int):void");
    }

    public final void s() {
        if (this.n != null) {
            EditText editText = this.f9945h;
            t(editText == null ? 0 : editText.getText().length());
        }
    }

    public void setBoxBackgroundColor(int i2) {
        if (this.O != i2) {
            this.O = i2;
            this.A0 = i2;
            this.C0 = i2;
            this.D0 = i2;
            c();
        }
    }

    public void setBoxBackgroundColorResource(int i2) {
        setBoxBackgroundColor(b.h.d.a.b(getContext(), i2));
    }

    public void setBoxBackgroundColorStateList(ColorStateList colorStateList) {
        int defaultColor = colorStateList.getDefaultColor();
        this.A0 = defaultColor;
        this.O = defaultColor;
        this.B0 = colorStateList.getColorForState(new int[]{-16842910}, -1);
        this.C0 = colorStateList.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
        this.D0 = colorStateList.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
        c();
    }

    public void setBoxBackgroundMode(int i2) {
        if (i2 == this.I) {
            return;
        }
        this.I = i2;
        if (this.f9945h != null) {
            l();
        }
    }

    public void setBoxStrokeColor(int i2) {
        if (this.y0 != i2) {
            this.y0 = i2;
            F();
        }
    }

    public void setBoxStrokeColorStateList(ColorStateList colorStateList) {
        if (colorStateList.isStateful()) {
            this.w0 = colorStateList.getDefaultColor();
            this.E0 = colorStateList.getColorForState(new int[]{-16842910}, -1);
            this.x0 = colorStateList.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
            this.y0 = colorStateList.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
        } else if (this.y0 != colorStateList.getDefaultColor()) {
            this.y0 = colorStateList.getDefaultColor();
        }
        F();
    }

    public void setBoxStrokeErrorColor(ColorStateList colorStateList) {
        if (this.z0 != colorStateList) {
            this.z0 = colorStateList;
            F();
        }
    }

    public void setBoxStrokeWidth(int i2) {
        this.L = i2;
        F();
    }

    public void setBoxStrokeWidthFocused(int i2) {
        this.M = i2;
        F();
    }

    public void setBoxStrokeWidthFocusedResource(int i2) {
        setBoxStrokeWidthFocused(getResources().getDimensionPixelSize(i2));
    }

    public void setBoxStrokeWidthResource(int i2) {
        setBoxStrokeWidth(getResources().getDimensionPixelSize(i2));
    }

    public void setCounterEnabled(boolean z) {
        if (this.k != z) {
            if (z) {
                AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null);
                this.n = appCompatTextView;
                appCompatTextView.setId(2131362559);
                Typeface typeface = this.S;
                if (typeface != null) {
                    this.n.setTypeface(typeface);
                }
                this.n.setMaxLines(1);
                this.f9947j.a(this.n, 2);
                ((ViewGroup.MarginLayoutParams) this.n.getLayoutParams()).setMarginStart(getResources().getDimensionPixelOffset(2131165542));
                u();
                s();
            } else {
                this.f9947j.j(this.n, 2);
                this.n = null;
            }
            this.k = z;
        }
    }

    public void setCounterMaxLength(int i2) {
        if (this.l != i2) {
            if (i2 > 0) {
                this.l = i2;
            } else {
                this.l = -1;
            }
            if (this.k) {
                s();
            }
        }
    }

    public void setCounterOverflowTextAppearance(int i2) {
        if (this.o != i2) {
            this.o = i2;
            u();
        }
    }

    public void setCounterOverflowTextColor(ColorStateList colorStateList) {
        if (this.w != colorStateList) {
            this.w = colorStateList;
            u();
        }
    }

    public void setCounterTextAppearance(int i2) {
        if (this.p != i2) {
            this.p = i2;
            u();
        }
    }

    public void setCounterTextColor(ColorStateList colorStateList) {
        if (this.v != colorStateList) {
            this.v = colorStateList;
            u();
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.u0 = colorStateList;
        this.v0 = colorStateList;
        if (this.f9945h != null) {
            y(false, false);
        }
    }

    @Override // android.view.View
    public void setEnabled(boolean z) {
        n(this, z);
        super.setEnabled(z);
    }

    public void setEndIconActivated(boolean z) {
        this.h0.setActivated(z);
    }

    public void setEndIconCheckable(boolean z) {
        this.h0.setCheckable(z);
    }

    public void setEndIconContentDescription(int i2) {
        setEndIconContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setEndIconContentDescription(CharSequence charSequence) {
        if (getEndIconContentDescription() != charSequence) {
            this.h0.setContentDescription(charSequence);
        }
    }

    public void setEndIconDrawable(int i2) {
        setEndIconDrawable(i2 != 0 ? b.b.d.a.a.b(getContext(), i2) : null);
    }

    public void setEndIconDrawable(Drawable drawable) {
        this.h0.setImageDrawable(drawable);
        o();
    }

    public void setEndIconMode(int i2) {
        int i3 = this.f0;
        this.f0 = i2;
        Iterator<g> it = this.i0.iterator();
        while (it.hasNext()) {
            it.next().a(this, i3);
        }
        setEndIconVisible(i2 != 0);
        if (getEndIconDelegate().b(this.I)) {
            getEndIconDelegate().a();
            d();
        } else {
            StringBuilder n = c.a.a.a.a.n("The current box background mode ");
            n.append(this.I);
            n.append(" is not supported by the end icon mode ");
            n.append(i2);
            throw new IllegalStateException(n.toString());
        }
    }

    public void setEndIconOnClickListener(View.OnClickListener onClickListener) {
        CheckableImageButton checkableImageButton = this.h0;
        View.OnLongClickListener onLongClickListener = this.q0;
        checkableImageButton.setOnClickListener(onClickListener);
        q(checkableImageButton, onLongClickListener);
    }

    public void setEndIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.q0 = onLongClickListener;
        CheckableImageButton checkableImageButton = this.h0;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        q(checkableImageButton, onLongClickListener);
    }

    public void setEndIconTintList(ColorStateList colorStateList) {
        if (this.j0 != colorStateList) {
            this.j0 = colorStateList;
            this.k0 = true;
            d();
        }
    }

    public void setEndIconTintMode(PorterDuff.Mode mode) {
        if (this.l0 != mode) {
            this.l0 = mode;
            this.m0 = true;
            d();
        }
    }

    public void setEndIconVisible(boolean z) {
        if (k() != z) {
            this.h0.setVisibility(z ? 0 : 8);
            D();
            v();
        }
    }

    public void setError(CharSequence charSequence) {
        if (!this.f9947j.k) {
            if (TextUtils.isEmpty(charSequence)) {
                return;
            } else {
                setErrorEnabled(true);
            }
        }
        if (TextUtils.isEmpty(charSequence)) {
            this.f9947j.i();
            return;
        }
        n nVar = this.f9947j;
        nVar.c();
        nVar.f8559j = charSequence;
        nVar.l.setText(charSequence);
        int i2 = nVar.f8557h;
        if (i2 != 1) {
            nVar.f8558i = 1;
        }
        nVar.l(i2, nVar.f8558i, nVar.k(nVar.l, charSequence));
    }

    public void setErrorContentDescription(CharSequence charSequence) {
        n nVar = this.f9947j;
        nVar.m = charSequence;
        TextView textView = nVar.l;
        if (textView != null) {
            textView.setContentDescription(charSequence);
        }
    }

    public void setErrorEnabled(boolean z) {
        n nVar = this.f9947j;
        if (nVar.k == z) {
            return;
        }
        nVar.c();
        if (z) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(nVar.f8550a, null);
            nVar.l = appCompatTextView;
            appCompatTextView.setId(2131362560);
            nVar.l.setTextAlignment(5);
            Typeface typeface = nVar.u;
            if (typeface != null) {
                nVar.l.setTypeface(typeface);
            }
            int i2 = nVar.n;
            nVar.n = i2;
            TextView textView = nVar.l;
            if (textView != null) {
                nVar.f8551b.r(textView, i2);
            }
            ColorStateList colorStateList = nVar.o;
            nVar.o = colorStateList;
            TextView textView2 = nVar.l;
            if (textView2 != null && colorStateList != null) {
                textView2.setTextColor(colorStateList);
            }
            CharSequence charSequence = nVar.m;
            nVar.m = charSequence;
            TextView textView3 = nVar.l;
            if (textView3 != null) {
                textView3.setContentDescription(charSequence);
            }
            nVar.l.setVisibility(4);
            TextView textView4 = nVar.l;
            AtomicInteger atomicInteger = q.f1738a;
            textView4.setAccessibilityLiveRegion(1);
            nVar.a(nVar.l, 0);
        } else {
            nVar.i();
            nVar.j(nVar.l, 0);
            nVar.l = null;
            nVar.f8551b.w();
            nVar.f8551b.F();
        }
        nVar.k = z;
    }

    public void setErrorIconDrawable(int i2) {
        setErrorIconDrawable(i2 != 0 ? b.b.d.a.a.b(getContext(), i2) : null);
        p(this.s0, this.t0);
    }

    public void setErrorIconDrawable(Drawable drawable) {
        this.s0.setImageDrawable(drawable);
        setErrorIconVisible(drawable != null && this.f9947j.k);
    }

    public void setErrorIconOnClickListener(View.OnClickListener onClickListener) {
        CheckableImageButton checkableImageButton = this.s0;
        View.OnLongClickListener onLongClickListener = this.r0;
        checkableImageButton.setOnClickListener(onClickListener);
        q(checkableImageButton, onLongClickListener);
    }

    public void setErrorIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.r0 = onLongClickListener;
        CheckableImageButton checkableImageButton = this.s0;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        q(checkableImageButton, onLongClickListener);
    }

    public void setErrorIconTintList(ColorStateList colorStateList) {
        this.t0 = colorStateList;
        Drawable drawable = this.s0.getDrawable();
        if (drawable != null) {
            drawable = b.h.a.X(drawable).mutate();
            drawable.setTintList(colorStateList);
        }
        if (this.s0.getDrawable() != drawable) {
            this.s0.setImageDrawable(drawable);
        }
    }

    public void setErrorIconTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.s0.getDrawable();
        if (drawable != null) {
            drawable = b.h.a.X(drawable).mutate();
            drawable.setTintMode(mode);
        }
        if (this.s0.getDrawable() != drawable) {
            this.s0.setImageDrawable(drawable);
        }
    }

    public void setErrorTextAppearance(int i2) {
        n nVar = this.f9947j;
        nVar.n = i2;
        TextView textView = nVar.l;
        if (textView != null) {
            nVar.f8551b.r(textView, i2);
        }
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        n nVar = this.f9947j;
        nVar.o = colorStateList;
        TextView textView = nVar.l;
        if (textView == null || colorStateList == null) {
            return;
        }
        textView.setTextColor(colorStateList);
    }

    public void setExpandedHintEnabled(boolean z) {
        if (this.H0 != z) {
            this.H0 = z;
            y(false, false);
        }
    }

    public void setHelperText(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            if (this.f9947j.q) {
                setHelperTextEnabled(false);
                return;
            }
            return;
        }
        if (!this.f9947j.q) {
            setHelperTextEnabled(true);
        }
        n nVar = this.f9947j;
        nVar.c();
        nVar.p = charSequence;
        nVar.r.setText(charSequence);
        int i2 = nVar.f8557h;
        if (i2 != 2) {
            nVar.f8558i = 2;
        }
        nVar.l(i2, nVar.f8558i, nVar.k(nVar.r, charSequence));
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        n nVar = this.f9947j;
        nVar.t = colorStateList;
        TextView textView = nVar.r;
        if (textView == null || colorStateList == null) {
            return;
        }
        textView.setTextColor(colorStateList);
    }

    public void setHelperTextEnabled(boolean z) {
        n nVar = this.f9947j;
        if (nVar.q == z) {
            return;
        }
        nVar.c();
        if (z) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(nVar.f8550a, null);
            nVar.r = appCompatTextView;
            appCompatTextView.setId(2131362561);
            nVar.r.setTextAlignment(5);
            Typeface typeface = nVar.u;
            if (typeface != null) {
                nVar.r.setTypeface(typeface);
            }
            nVar.r.setVisibility(4);
            TextView textView = nVar.r;
            AtomicInteger atomicInteger = q.f1738a;
            textView.setAccessibilityLiveRegion(1);
            int i2 = nVar.s;
            nVar.s = i2;
            TextView textView2 = nVar.r;
            if (textView2 != null) {
                b.h.a.O(textView2, i2);
            }
            ColorStateList colorStateList = nVar.t;
            nVar.t = colorStateList;
            TextView textView3 = nVar.r;
            if (textView3 != null && colorStateList != null) {
                textView3.setTextColor(colorStateList);
            }
            nVar.a(nVar.r, 1);
        } else {
            nVar.c();
            int i3 = nVar.f8557h;
            if (i3 == 2) {
                nVar.f8558i = 0;
            }
            nVar.l(i3, nVar.f8558i, nVar.k(nVar.r, null));
            nVar.j(nVar.r, 1);
            nVar.r = null;
            nVar.f8551b.w();
            nVar.f8551b.F();
        }
        nVar.q = z;
    }

    public void setHelperTextTextAppearance(int i2) {
        n nVar = this.f9947j;
        nVar.s = i2;
        TextView textView = nVar.r;
        if (textView != null) {
            b.h.a.O(textView, i2);
        }
    }

    public void setHint(int i2) {
        setHint(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setHint(CharSequence charSequence) {
        if (this.B) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z) {
        this.I0 = z;
    }

    public void setHintEnabled(boolean z) {
        if (z != this.B) {
            this.B = z;
            if (z) {
                CharSequence hint = this.f9945h.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.C)) {
                        setHint(hint);
                    }
                    this.f9945h.setHint((CharSequence) null);
                }
                this.D = true;
            } else {
                this.D = false;
                if (!TextUtils.isEmpty(this.C) && TextUtils.isEmpty(this.f9945h.getHint())) {
                    this.f9945h.setHint(this.C);
                }
                setHintInternal(null);
            }
            if (this.f9945h != null) {
                x();
            }
        }
    }

    public void setHintTextAppearance(int i2) {
        c.d.a.d.r.c cVar = this.G0;
        c.d.a.d.u.b bVar = new c.d.a.d.u.b(cVar.f8840a.getContext(), i2);
        ColorStateList colorStateList = bVar.f8948a;
        if (colorStateList != null) {
            cVar.l = colorStateList;
        }
        float f2 = bVar.k;
        if (f2 != 0.0f) {
            cVar.f8849j = f2;
        }
        ColorStateList colorStateList2 = bVar.f8949b;
        if (colorStateList2 != null) {
            cVar.L = colorStateList2;
        }
        cVar.J = bVar.f8953f;
        cVar.K = bVar.f8954g;
        cVar.I = bVar.f8955h;
        cVar.M = bVar.f8957j;
        c.d.a.d.u.a aVar = cVar.v;
        if (aVar != null) {
            aVar.f8947c = true;
        }
        c.d.a.d.r.b bVar2 = new c.d.a.d.r.b(cVar);
        bVar.a();
        cVar.v = new c.d.a.d.u.a(bVar2, bVar.n);
        bVar.b(cVar.f8840a.getContext(), cVar.v);
        cVar.k();
        this.v0 = this.G0.l;
        if (this.f9945h != null) {
            y(false, false);
            x();
        }
    }

    public void setHintTextColor(ColorStateList colorStateList) {
        if (this.v0 != colorStateList) {
            if (this.u0 == null) {
                c.d.a.d.r.c cVar = this.G0;
                if (cVar.l != colorStateList) {
                    cVar.l = colorStateList;
                    cVar.k();
                }
            }
            this.v0 = colorStateList;
            if (this.f9945h != null) {
                y(false, false);
            }
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(int i2) {
        setPasswordVisibilityToggleContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.h0.setContentDescription(charSequence);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(int i2) {
        setPasswordVisibilityToggleDrawable(i2 != 0 ? b.b.d.a.a.b(getContext(), i2) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.h0.setImageDrawable(drawable);
    }

    @Deprecated
    public void setPasswordVisibilityToggleEnabled(boolean z) {
        if (z && this.f0 != 1) {
            setEndIconMode(1);
        } else {
            if (z) {
                return;
            }
            setEndIconMode(0);
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        this.j0 = colorStateList;
        this.k0 = true;
        d();
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        this.l0 = mode;
        this.m0 = true;
        d();
    }

    public void setPlaceholderText(CharSequence charSequence) {
        if (this.r && TextUtils.isEmpty(charSequence)) {
            setPlaceholderTextEnabled(false);
        } else {
            if (!this.r) {
                setPlaceholderTextEnabled(true);
            }
            this.q = charSequence;
        }
        EditText editText = this.f9945h;
        z(editText != null ? editText.getText().length() : 0);
    }

    public void setPlaceholderTextAppearance(int i2) {
        this.u = i2;
        TextView textView = this.s;
        if (textView != null) {
            b.h.a.O(textView, i2);
        }
    }

    public void setPlaceholderTextColor(ColorStateList colorStateList) {
        if (this.t != colorStateList) {
            this.t = colorStateList;
            TextView textView = this.s;
            if (textView == null || colorStateList == null) {
                return;
            }
            textView.setTextColor(colorStateList);
        }
    }

    public void setPrefixText(CharSequence charSequence) {
        this.x = TextUtils.isEmpty(charSequence) ? null : charSequence;
        this.y.setText(charSequence);
        B();
    }

    public void setPrefixTextAppearance(int i2) {
        b.h.a.O(this.y, i2);
    }

    public void setPrefixTextColor(ColorStateList colorStateList) {
        this.y.setTextColor(colorStateList);
    }

    public void setStartIconCheckable(boolean z) {
        this.T.setCheckable(z);
    }

    public void setStartIconContentDescription(int i2) {
        setStartIconContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setStartIconContentDescription(CharSequence charSequence) {
        if (getStartIconContentDescription() != charSequence) {
            this.T.setContentDescription(charSequence);
        }
    }

    public void setStartIconDrawable(int i2) {
        setStartIconDrawable(i2 != 0 ? b.b.d.a.a.b(getContext(), i2) : null);
    }

    public void setStartIconDrawable(Drawable drawable) {
        this.T.setImageDrawable(drawable);
        if (drawable != null) {
            setStartIconVisible(true);
            p(this.T, this.U);
        } else {
            setStartIconVisible(false);
            setStartIconOnClickListener(null);
            setStartIconOnLongClickListener(null);
            setStartIconContentDescription((CharSequence) null);
        }
    }

    public void setStartIconOnClickListener(View.OnClickListener onClickListener) {
        CheckableImageButton checkableImageButton = this.T;
        View.OnLongClickListener onLongClickListener = this.d0;
        checkableImageButton.setOnClickListener(onClickListener);
        q(checkableImageButton, onLongClickListener);
    }

    public void setStartIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.d0 = onLongClickListener;
        CheckableImageButton checkableImageButton = this.T;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        q(checkableImageButton, onLongClickListener);
    }

    public void setStartIconTintList(ColorStateList colorStateList) {
        if (this.U != colorStateList) {
            this.U = colorStateList;
            this.V = true;
            e(this.T, true, colorStateList, this.a0, this.W);
        }
    }

    public void setStartIconTintMode(PorterDuff.Mode mode) {
        if (this.W != mode) {
            this.W = mode;
            this.a0 = true;
            e(this.T, this.V, this.U, true, mode);
        }
    }

    public void setStartIconVisible(boolean z) {
        if ((this.T.getVisibility() == 0) != z) {
            this.T.setVisibility(z ? 0 : 8);
            A();
            v();
        }
    }

    public void setSuffixText(CharSequence charSequence) {
        this.z = TextUtils.isEmpty(charSequence) ? null : charSequence;
        this.A.setText(charSequence);
        E();
    }

    public void setSuffixTextAppearance(int i2) {
        b.h.a.O(this.A, i2);
    }

    public void setSuffixTextColor(ColorStateList colorStateList) {
        this.A.setTextColor(colorStateList);
    }

    public void setTextInputAccessibilityDelegate(e eVar) {
        EditText editText = this.f9945h;
        if (editText != null) {
            q.t(editText, eVar);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.S) {
            this.S = typeface;
            this.G0.q(typeface);
            n nVar = this.f9947j;
            if (typeface != nVar.u) {
                nVar.u = typeface;
                TextView textView = nVar.l;
                if (textView != null) {
                    textView.setTypeface(typeface);
                }
                TextView textView2 = nVar.r;
                if (textView2 != null) {
                    textView2.setTypeface(typeface);
                }
            }
            TextView textView3 = this.n;
            if (textView3 != null) {
                textView3.setTypeface(typeface);
            }
        }
    }

    public void t(int i2) {
        boolean z = this.m;
        int i3 = this.l;
        if (i3 == -1) {
            this.n.setText(String.valueOf(i2));
            this.n.setContentDescription(null);
            this.m = false;
        } else {
            this.m = i2 > i3;
            Context context = getContext();
            this.n.setContentDescription(context.getString(this.m ? 2131886230 : 2131886229, Integer.valueOf(i2), Integer.valueOf(this.l)));
            if (z != this.m) {
                u();
            }
            b.h.i.a c2 = b.h.i.a.c();
            TextView textView = this.n;
            String string = getContext().getString(2131886231, Integer.valueOf(i2), Integer.valueOf(this.l));
            textView.setText(string != null ? c2.d(string, c2.f1694c, true).toString() : null);
        }
        if (this.f9945h == null || z == this.m) {
            return;
        }
        y(false, false);
        F();
        w();
    }

    public final void u() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        TextView textView = this.n;
        if (textView != null) {
            r(textView, this.m ? this.o : this.p);
            if (!this.m && (colorStateList2 = this.v) != null) {
                this.n.setTextColor(colorStateList2);
            }
            if (!this.m || (colorStateList = this.w) == null) {
                return;
            }
            this.n.setTextColor(colorStateList);
        }
    }

    public final boolean v() {
        boolean z;
        if (this.f9945h == null) {
            return false;
        }
        boolean z2 = true;
        if (!(getStartIconDrawable() == null && this.x == null) && this.f9942e.getMeasuredWidth() > 0) {
            int measuredWidth = this.f9942e.getMeasuredWidth() - this.f9945h.getPaddingLeft();
            if (this.b0 == null || this.c0 != measuredWidth) {
                ColorDrawable colorDrawable = new ColorDrawable();
                this.b0 = colorDrawable;
                this.c0 = measuredWidth;
                colorDrawable.setBounds(0, 0, measuredWidth, 1);
            }
            Drawable[] compoundDrawablesRelative = this.f9945h.getCompoundDrawablesRelative();
            Drawable drawable = compoundDrawablesRelative[0];
            Drawable drawable2 = this.b0;
            if (drawable != drawable2) {
                this.f9945h.setCompoundDrawablesRelative(drawable2, compoundDrawablesRelative[1], compoundDrawablesRelative[2], compoundDrawablesRelative[3]);
                z = true;
            }
            z = false;
        } else {
            if (this.b0 != null) {
                Drawable[] compoundDrawablesRelative2 = this.f9945h.getCompoundDrawablesRelative();
                this.f9945h.setCompoundDrawablesRelative(null, compoundDrawablesRelative2[1], compoundDrawablesRelative2[2], compoundDrawablesRelative2[3]);
                this.b0 = null;
                z = true;
            }
            z = false;
        }
        if ((this.s0.getVisibility() == 0 || ((j() && k()) || this.z != null)) && this.f9943f.getMeasuredWidth() > 0) {
            int measuredWidth2 = this.A.getMeasuredWidth() - this.f9945h.getPaddingRight();
            CheckableImageButton endIconToUpdateDummyDrawable = getEndIconToUpdateDummyDrawable();
            if (endIconToUpdateDummyDrawable != null) {
                measuredWidth2 = ((ViewGroup.MarginLayoutParams) endIconToUpdateDummyDrawable.getLayoutParams()).getMarginStart() + endIconToUpdateDummyDrawable.getMeasuredWidth() + measuredWidth2;
            }
            Drawable[] compoundDrawablesRelative3 = this.f9945h.getCompoundDrawablesRelative();
            Drawable drawable3 = this.n0;
            if (drawable3 == null || this.o0 == measuredWidth2) {
                if (drawable3 == null) {
                    ColorDrawable colorDrawable2 = new ColorDrawable();
                    this.n0 = colorDrawable2;
                    this.o0 = measuredWidth2;
                    colorDrawable2.setBounds(0, 0, measuredWidth2, 1);
                }
                Drawable drawable4 = compoundDrawablesRelative3[2];
                Drawable drawable5 = this.n0;
                if (drawable4 != drawable5) {
                    this.p0 = compoundDrawablesRelative3[2];
                    this.f9945h.setCompoundDrawablesRelative(compoundDrawablesRelative3[0], compoundDrawablesRelative3[1], drawable5, compoundDrawablesRelative3[3]);
                } else {
                    z2 = z;
                }
            } else {
                this.o0 = measuredWidth2;
                drawable3.setBounds(0, 0, measuredWidth2, 1);
                this.f9945h.setCompoundDrawablesRelative(compoundDrawablesRelative3[0], compoundDrawablesRelative3[1], this.n0, compoundDrawablesRelative3[3]);
            }
        } else {
            if (this.n0 == null) {
                return z;
            }
            Drawable[] compoundDrawablesRelative4 = this.f9945h.getCompoundDrawablesRelative();
            if (compoundDrawablesRelative4[2] == this.n0) {
                this.f9945h.setCompoundDrawablesRelative(compoundDrawablesRelative4[0], compoundDrawablesRelative4[1], this.p0, compoundDrawablesRelative4[3]);
            } else {
                z2 = z;
            }
            this.n0 = null;
        }
        return z2;
    }

    public void w() {
        Drawable background;
        TextView textView;
        EditText editText = this.f9945h;
        if (editText == null || this.I != 0 || (background = editText.getBackground()) == null) {
            return;
        }
        if (z.a(background)) {
            background = background.mutate();
        }
        if (this.f9947j.e()) {
            background.setColorFilter(i.c(this.f9947j.g(), PorterDuff.Mode.SRC_IN));
        } else if (this.m && (textView = this.n) != null) {
            background.setColorFilter(i.c(textView.getCurrentTextColor(), PorterDuff.Mode.SRC_IN));
        } else {
            b.h.a.j(background);
            this.f9945h.refreshDrawableState();
        }
    }

    public final void x() {
        if (this.I != 1) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f9941d.getLayoutParams();
            int f2 = f();
            if (f2 != layoutParams.topMargin) {
                layoutParams.topMargin = f2;
                this.f9941d.requestLayout();
            }
        }
    }

    public final void y(boolean z, boolean z2) {
        ColorStateList colorStateList;
        TextView textView;
        boolean isEnabled = isEnabled();
        EditText editText = this.f9945h;
        boolean z3 = (editText == null || TextUtils.isEmpty(editText.getText())) ? false : true;
        EditText editText2 = this.f9945h;
        boolean z4 = editText2 != null && editText2.hasFocus();
        boolean e2 = this.f9947j.e();
        ColorStateList colorStateList2 = this.u0;
        if (colorStateList2 != null) {
            c.d.a.d.r.c cVar = this.G0;
            if (cVar.l != colorStateList2) {
                cVar.l = colorStateList2;
                cVar.k();
            }
            c.d.a.d.r.c cVar2 = this.G0;
            ColorStateList colorStateList3 = this.u0;
            if (cVar2.k != colorStateList3) {
                cVar2.k = colorStateList3;
                cVar2.k();
            }
        }
        if (!isEnabled) {
            ColorStateList colorStateList4 = this.u0;
            int colorForState = colorStateList4 != null ? colorStateList4.getColorForState(new int[]{-16842910}, this.E0) : this.E0;
            this.G0.m(ColorStateList.valueOf(colorForState));
            c.d.a.d.r.c cVar3 = this.G0;
            ColorStateList valueOf = ColorStateList.valueOf(colorForState);
            if (cVar3.k != valueOf) {
                cVar3.k = valueOf;
                cVar3.k();
            }
        } else if (e2) {
            c.d.a.d.r.c cVar4 = this.G0;
            TextView textView2 = this.f9947j.l;
            cVar4.m(textView2 != null ? textView2.getTextColors() : null);
        } else if (this.m && (textView = this.n) != null) {
            this.G0.m(textView.getTextColors());
        } else if (z4 && (colorStateList = this.v0) != null) {
            c.d.a.d.r.c cVar5 = this.G0;
            if (cVar5.l != colorStateList) {
                cVar5.l = colorStateList;
                cVar5.k();
            }
        }
        if (z3 || !this.H0 || (isEnabled() && z4)) {
            if (z2 || this.F0) {
                ValueAnimator valueAnimator = this.J0;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.J0.cancel();
                }
                if (z && this.I0) {
                    b(1.0f);
                } else {
                    this.G0.o(1.0f);
                }
                this.F0 = false;
                if (g()) {
                    m();
                }
                EditText editText3 = this.f9945h;
                z(editText3 != null ? editText3.getText().length() : 0);
                B();
                E();
                return;
            }
            return;
        }
        if (z2 || !this.F0) {
            ValueAnimator valueAnimator2 = this.J0;
            if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                this.J0.cancel();
            }
            if (z && this.I0) {
                b(0.0f);
            } else {
                this.G0.o(0.0f);
            }
            if (g() && (!((c.d.a.d.b0.g) this.E).C.isEmpty()) && g()) {
                ((c.d.a.d.b0.g) this.E).z(0.0f, 0.0f, 0.0f, 0.0f);
            }
            this.F0 = true;
            TextView textView3 = this.s;
            if (textView3 != null && this.r) {
                textView3.setText((CharSequence) null);
                this.s.setVisibility(4);
            }
            B();
            E();
        }
    }

    public final void z(int i2) {
        if (i2 != 0 || this.F0) {
            TextView textView = this.s;
            if (textView == null || !this.r) {
                return;
            }
            textView.setText((CharSequence) null);
            this.s.setVisibility(4);
            return;
        }
        TextView textView2 = this.s;
        if (textView2 == null || !this.r) {
            return;
        }
        textView2.setText(this.q);
        this.s.setVisibility(0);
        this.s.bringToFront();
    }
}