package com.google.android.material.timepicker;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import b.h.k.q;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ClockHandView.smali */
public class ClockHandView extends View {
    public static final /* synthetic */ int s = 0;

    /* renamed from: d, reason: collision with root package name */
    public ValueAnimator f9963d;

    /* renamed from: e, reason: collision with root package name */
    public float f9964e;

    /* renamed from: f, reason: collision with root package name */
    public float f9965f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f9966g;

    /* renamed from: h, reason: collision with root package name */
    public int f9967h;

    /* renamed from: i, reason: collision with root package name */
    public final List<c> f9968i;

    /* renamed from: j, reason: collision with root package name */
    public final int f9969j;
    public final float k;
    public final Paint l;
    public final RectF m;
    public final int n;
    public float o;
    public boolean p;
    public double q;
    public int r;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ClockHandView$a.smali */
    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            ClockHandView clockHandView = ClockHandView.this;
            int i2 = ClockHandView.s;
            clockHandView.c(floatValue, true);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ClockHandView$b.smali */
    public class b extends AnimatorListenerAdapter {
        public b(ClockHandView clockHandView) {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            animator.end();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ClockHandView$c.smali */
    public interface c {
        void a(float f2, boolean z);
    }

    public ClockHandView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969208);
        this.f9968i = new ArrayList();
        Paint paint = new Paint();
        this.l = paint;
        this.m = new RectF();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, c.d.a.d.b.f8507j, 2130969208, 2131952389);
        this.r = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        this.f9969j = obtainStyledAttributes.getDimensionPixelSize(2, 0);
        this.n = getResources().getDimensionPixelSize(2131165345);
        this.k = r4.getDimensionPixelSize(2131165343);
        int color = obtainStyledAttributes.getColor(0, 0);
        paint.setAntiAlias(true);
        paint.setColor(color);
        b(0.0f, false);
        this.f9967h = ViewConfiguration.get(context).getScaledTouchSlop();
        AtomicInteger atomicInteger = q.f1738a;
        setImportantForAccessibility(2);
        obtainStyledAttributes.recycle();
    }

    public final int a(float f2, float f3) {
        int degrees = ((int) Math.toDegrees(Math.atan2(f3 - (getHeight() / 2), f2 - (getWidth() / 2)))) + 90;
        return degrees < 0 ? degrees + 360 : degrees;
    }

    public void b(float f2, boolean z) {
        ValueAnimator valueAnimator = this.f9963d;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        if (!z) {
            c(f2, false);
            return;
        }
        float f3 = this.o;
        if (Math.abs(f3 - f2) > 180.0f) {
            if (f3 > 180.0f && f2 < 180.0f) {
                f2 += 360.0f;
            }
            if (f3 < 180.0f && f2 > 180.0f) {
                f3 += 360.0f;
            }
        }
        Pair pair = new Pair(Float.valueOf(f3), Float.valueOf(f2));
        ValueAnimator ofFloat = ValueAnimator.ofFloat(((Float) pair.first).floatValue(), ((Float) pair.second).floatValue());
        this.f9963d = ofFloat;
        ofFloat.setDuration(200L);
        this.f9963d.addUpdateListener(new a());
        this.f9963d.addListener(new b(this));
        this.f9963d.start();
    }

    public final void c(float f2, boolean z) {
        float f3 = f2 % 360.0f;
        this.o = f3;
        this.q = Math.toRadians(f3 - 90.0f);
        int height = getHeight() / 2;
        float cos = (this.r * ((float) Math.cos(this.q))) + (getWidth() / 2);
        float sin = (this.r * ((float) Math.sin(this.q))) + height;
        RectF rectF = this.m;
        int i2 = this.f9969j;
        rectF.set(cos - i2, sin - i2, cos + i2, sin + i2);
        Iterator<c> it = this.f9968i.iterator();
        while (it.hasNext()) {
            it.next().a(f3, z);
        }
        invalidate();
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int height = getHeight() / 2;
        float width = getWidth() / 2;
        float cos = (this.r * ((float) Math.cos(this.q))) + width;
        float f2 = height;
        float sin = (this.r * ((float) Math.sin(this.q))) + f2;
        this.l.setStrokeWidth(0.0f);
        canvas.drawCircle(cos, sin, this.f9969j, this.l);
        double sin2 = Math.sin(this.q);
        double cos2 = Math.cos(this.q);
        this.l.setStrokeWidth(this.n);
        canvas.drawLine(width, f2, r1 + ((int) (cos2 * r6)), height + ((int) (r6 * sin2)), this.l);
        canvas.drawCircle(width, f2, this.k, this.l);
    }

    @Override // android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        b(this.o, false);
    }

    @Override // android.view.View
    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        boolean z2;
        int actionMasked = motionEvent.getActionMasked();
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        boolean z3 = false;
        if (actionMasked != 0) {
            if (actionMasked == 1 || actionMasked == 2) {
                int i2 = (int) (x - this.f9964e);
                int i3 = (int) (y - this.f9965f);
                this.f9966g = (i3 * i3) + (i2 * i2) > this.f9967h;
                z = this.p;
                if (actionMasked == 1) {
                }
            } else {
                z = false;
            }
            z2 = false;
        } else {
            this.f9964e = x;
            this.f9965f = y;
            this.f9966g = true;
            this.p = false;
            z = false;
            z2 = true;
        }
        boolean z4 = this.p;
        float a2 = a(x, y);
        boolean z5 = this.o != a2;
        if (!z2 || !z5) {
            if (z5 || z) {
                b(a2, false);
            }
            this.p = z4 | z3;
            return true;
        }
        z3 = true;
        this.p = z4 | z3;
        return true;
    }
}