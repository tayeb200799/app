package com.google.android.material.timepicker;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import b.f.c.d;
import b.h.k.q;
import c.d.a.d.d0.d;
import c.d.a.d.d0.e;
import c.d.a.d.d0.f;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\TimePickerView.smali */
public class TimePickerView extends ConstraintLayout {
    public static final /* synthetic */ int B = 0;
    public final View.OnClickListener A;
    public final Chip x;
    public final Chip y;
    public final MaterialButtonToggleGroup z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\TimePickerView$a.smali */
    public class a implements View.OnClickListener {
        public a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            TimePickerView timePickerView = TimePickerView.this;
            int i2 = TimePickerView.B;
            Objects.requireNonNull(timePickerView);
        }
    }

    public TimePickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        a aVar = new a();
        this.A = aVar;
        LayoutInflater.from(context).inflate(2131558551, this);
        MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) findViewById(2131362224);
        this.z = materialButtonToggleGroup;
        materialButtonToggleGroup.f9846g.add(new d(this));
        Chip chip = (Chip) findViewById(2131362229);
        this.x = chip;
        Chip chip2 = (Chip) findViewById(2131362226);
        this.y = chip2;
        f fVar = new f(this, new GestureDetector(getContext(), new e(this)));
        chip.setOnTouchListener(fVar);
        chip2.setOnTouchListener(fVar);
        chip.setTag(2131362478, 12);
        chip2.setTag(2131362478, 10);
        chip.setOnClickListener(aVar);
        chip2.setOnClickListener(aVar);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        s();
    }

    @Override // android.view.View
    public void onVisibilityChanged(View view, int i2) {
        super.onVisibilityChanged(view, i2);
        if (view == this && i2 == 0) {
            s();
        }
    }

    public final void s() {
        d.a aVar;
        if (this.z.getVisibility() == 0) {
            b.f.c.d dVar = new b.f.c.d();
            dVar.c(this);
            AtomicInteger atomicInteger = q.f1738a;
            char c2 = getLayoutDirection() == 0 ? (char) 2 : (char) 1;
            if (dVar.f1419c.containsKey(2131362219) && (aVar = dVar.f1419c.get(2131362219)) != null) {
                switch (c2) {
                    case 1:
                        d.b bVar = aVar.f1423d;
                        bVar.f1446j = -1;
                        bVar.f1445i = -1;
                        bVar.G = -1;
                        bVar.N = Integer.MIN_VALUE;
                        break;
                    case 2:
                        d.b bVar2 = aVar.f1423d;
                        bVar2.l = -1;
                        bVar2.k = -1;
                        bVar2.H = -1;
                        bVar2.P = Integer.MIN_VALUE;
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        d.b bVar3 = aVar.f1423d;
                        bVar3.n = -1;
                        bVar3.m = -1;
                        bVar3.I = 0;
                        bVar3.O = Integer.MIN_VALUE;
                        break;
                    case 4:
                        d.b bVar4 = aVar.f1423d;
                        bVar4.o = -1;
                        bVar4.p = -1;
                        bVar4.J = 0;
                        bVar4.Q = Integer.MIN_VALUE;
                        break;
                    case 5:
                        d.b bVar5 = aVar.f1423d;
                        bVar5.q = -1;
                        bVar5.r = -1;
                        bVar5.s = -1;
                        bVar5.M = 0;
                        bVar5.T = Integer.MIN_VALUE;
                        break;
                    case 6:
                        d.b bVar6 = aVar.f1423d;
                        bVar6.t = -1;
                        bVar6.u = -1;
                        bVar6.L = 0;
                        bVar6.S = Integer.MIN_VALUE;
                        break;
                    case 7:
                        d.b bVar7 = aVar.f1423d;
                        bVar7.v = -1;
                        bVar7.w = -1;
                        bVar7.K = 0;
                        bVar7.R = Integer.MIN_VALUE;
                        break;
                    case '\b':
                        d.b bVar8 = aVar.f1423d;
                        bVar8.C = -1.0f;
                        bVar8.B = -1;
                        bVar8.A = -1;
                        break;
                    default:
                        throw new IllegalArgumentException("unknown constraint");
                }
            }
            dVar.b(this, true);
            setConstraintSet(null);
            requestLayout();
        }
    }
}