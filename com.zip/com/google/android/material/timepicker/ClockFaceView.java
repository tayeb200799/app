package com.google.android.material.timepicker;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import b.h.k.a;
import b.h.k.q;
import b.h.k.y.b;
import c.d.a.d.b;
import c.d.a.d.d0.c;
import com.google.android.material.timepicker.ClockHandView;
import java.util.Arrays;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ClockFaceView.smali */
public class ClockFaceView extends c implements ClockHandView.c {
    public final ClockHandView A;
    public final Rect B;
    public final RectF C;
    public final SparseArray<TextView> D;
    public final a E;
    public final int[] F;
    public final float[] G;
    public final int H;
    public String[] I;
    public float J;
    public final ColorStateList K;

    public ClockFaceView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969208);
        this.B = new Rect();
        this.C = new RectF();
        SparseArray<TextView> sparseArray = new SparseArray<>();
        this.D = sparseArray;
        this.G = new float[]{0.0f, 0.9f, 1.0f};
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.f8506i, 2130969208, 2131952389);
        Resources resources = getResources();
        ColorStateList C = c.d.a.d.a.C(context, obtainStyledAttributes, 1);
        this.K = C;
        LayoutInflater.from(context).inflate(2131558546, (ViewGroup) this, true);
        ClockHandView clockHandView = (ClockHandView) findViewById(2131362221);
        this.A = clockHandView;
        this.H = resources.getDimensionPixelSize(2131165344);
        int colorForState = C.getColorForState(new int[]{R.attr.state_selected}, C.getDefaultColor());
        this.F = new int[]{colorForState, colorForState, C.getDefaultColor()};
        clockHandView.f9968i.add(this);
        int defaultColor = b.b.d.a.a.a(context, 2131099809).getDefaultColor();
        ColorStateList C2 = c.d.a.d.a.C(context, obtainStyledAttributes, 0);
        setBackgroundColor(C2 != null ? C2.getDefaultColor() : defaultColor);
        getViewTreeObserver().addOnPreDrawListener(new c.d.a.d.d0.a(this));
        setFocusable(true);
        obtainStyledAttributes.recycle();
        this.E = new c.d.a.d.d0.b(this);
        String[] strArr = new String[12];
        Arrays.fill(strArr, "");
        this.I = strArr;
        LayoutInflater from = LayoutInflater.from(getContext());
        int size = sparseArray.size();
        for (int i2 = 0; i2 < Math.max(this.I.length, size); i2++) {
            TextView textView = this.D.get(i2);
            if (i2 >= this.I.length) {
                removeView(textView);
                this.D.remove(i2);
            } else {
                if (textView == null) {
                    textView = (TextView) from.inflate(2131558545, (ViewGroup) this, false);
                    this.D.put(i2, textView);
                    addView(textView);
                }
                textView.setVisibility(0);
                textView.setText(this.I[i2]);
                textView.setTag(2131362237, Integer.valueOf(i2));
                q.t(textView, this.E);
                textView.setTextColor(this.K);
            }
        }
    }

    @Override // com.google.android.material.timepicker.ClockHandView.c
    public void a(float f2, boolean z) {
        if (Math.abs(this.J - f2) > 0.001f) {
            this.J = f2;
            t();
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) b.C0033b.a(1, this.I.length, false, 1).f1803a);
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        t();
    }

    public final void t() {
        RectF rectF = this.A.m;
        for (int i2 = 0; i2 < this.D.size(); i2++) {
            TextView textView = this.D.get(i2);
            if (textView != null) {
                textView.getDrawingRect(this.B);
                this.B.offset(textView.getPaddingLeft(), textView.getPaddingTop());
                offsetDescendantRectToMyCoords(textView, this.B);
                this.C.set(this.B);
                textView.getPaint().setShader(!RectF.intersects(rectF, this.C) ? null : new RadialGradient(rectF.centerX() - this.C.left, rectF.centerY() - this.C.top, 0.5f * rectF.width(), this.F, this.G, Shader.TileMode.CLAMP));
                textView.invalidate();
            }
        }
    }
}