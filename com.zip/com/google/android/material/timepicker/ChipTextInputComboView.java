package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.FrameLayout;
import c.d.a.d.r.j;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.TextInputLayout;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ChipTextInputComboView.smali */
public class ChipTextInputComboView extends FrameLayout implements Checkable {

    /* renamed from: d, reason: collision with root package name */
    public final Chip f9958d;

    /* renamed from: e, reason: collision with root package name */
    public final TextInputLayout f9959e;

    /* renamed from: f, reason: collision with root package name */
    public final EditText f9960f;

    /* renamed from: g, reason: collision with root package name */
    public TextWatcher f9961g;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\timepicker\ChipTextInputComboView$b.smali */
    public class b extends j {
        public b(a aVar) {
        }

        @Override // c.d.a.d.r.j, android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (TextUtils.isEmpty(editable)) {
                ChipTextInputComboView chipTextInputComboView = ChipTextInputComboView.this;
                chipTextInputComboView.f9958d.setText(ChipTextInputComboView.a(chipTextInputComboView, "00"));
            } else {
                ChipTextInputComboView chipTextInputComboView2 = ChipTextInputComboView.this;
                chipTextInputComboView2.f9958d.setText(ChipTextInputComboView.a(chipTextInputComboView2, editable));
            }
        }
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        LayoutInflater from = LayoutInflater.from(context);
        Chip chip = (Chip) from.inflate(2131558549, (ViewGroup) this, false);
        this.f9958d = chip;
        TextInputLayout textInputLayout = (TextInputLayout) from.inflate(2131558550, (ViewGroup) this, false);
        this.f9959e = textInputLayout;
        EditText editText = textInputLayout.getEditText();
        this.f9960f = editText;
        editText.setVisibility(4);
        b bVar = new b(null);
        this.f9961g = bVar;
        editText.addTextChangedListener(bVar);
        b();
        addView(chip);
        addView(textInputLayout);
        editText.setSaveEnabled(false);
    }

    public static String a(ChipTextInputComboView chipTextInputComboView, CharSequence charSequence) {
        return String.format(chipTextInputComboView.getResources().getConfiguration().locale, "%02d", Integer.valueOf(Integer.parseInt(String.valueOf(charSequence))));
    }

    public final void b() {
        if (Build.VERSION.SDK_INT >= 24) {
            this.f9960f.setImeHintLocales(getContext().getResources().getConfiguration().getLocales());
        }
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.f9958d.isChecked();
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        b();
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        this.f9958d.setChecked(z);
        this.f9960f.setVisibility(z ? 0 : 4);
        this.f9958d.setVisibility(z ? 8 : 0);
        if (isChecked()) {
            this.f9960f.requestFocus();
            if (TextUtils.isEmpty(this.f9960f.getText())) {
                return;
            }
            EditText editText = this.f9960f;
            editText.setSelection(editText.getText().length());
        }
    }

    @Override // android.view.View
    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.f9958d.setOnClickListener(onClickListener);
    }

    @Override // android.view.View
    public void setTag(int i2, Object obj) {
        this.f9958d.setTag(i2, obj);
    }

    @Override // android.widget.Checkable
    public void toggle() {
        this.f9958d.toggle();
    }
}