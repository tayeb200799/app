package com.google.android.material.progressindicator;

import android.content.Context;
import android.util.AttributeSet;
import b.h.k.q;
import c.d.a.d.s.b;
import c.d.a.d.s.d;
import c.d.a.d.s.j;
import c.d.a.d.s.k;
import c.d.a.d.s.m;
import c.d.a.d.s.o;
import c.d.a.d.s.p;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\progressindicator\LinearProgressIndicator.smali */
public final class LinearProgressIndicator extends b<p> {
    public static final /* synthetic */ int q = 0;

    public LinearProgressIndicator(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969165, 2131952336);
        Context context2 = getContext();
        p pVar = (p) this.f8889d;
        setIndeterminateDrawable(new j(context2, pVar, new k(pVar), pVar.f8939g == 0 ? new m(pVar) : new o(context2, pVar)));
        Context context3 = getContext();
        p pVar2 = (p) this.f8889d;
        setProgressDrawable(new d(context3, pVar2, new k(pVar2)));
    }

    @Override // c.d.a.d.s.b
    public void b(int i2, boolean z) {
        S s = this.f8889d;
        if (s != 0 && ((p) s).f8939g == 0 && isIndeterminate()) {
            return;
        }
        super.b(i2, z);
    }

    public int getIndeterminateAnimationType() {
        return ((p) this.f8889d).f8939g;
    }

    public int getIndicatorDirection() {
        return ((p) this.f8889d).f8940h;
    }

    @Override // android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        S s = this.f8889d;
        p pVar = (p) s;
        boolean z2 = true;
        if (((p) s).f8940h != 1) {
            AtomicInteger atomicInteger = q.f1738a;
            if ((getLayoutDirection() != 1 || ((p) this.f8889d).f8940h != 2) && (getLayoutDirection() != 0 || ((p) this.f8889d).f8940h != 3)) {
                z2 = false;
            }
        }
        pVar.f8941i = z2;
    }

    @Override // android.widget.ProgressBar, android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        int paddingRight = i2 - (getPaddingRight() + getPaddingLeft());
        int paddingBottom = i3 - (getPaddingBottom() + getPaddingTop());
        j<p> indeterminateDrawable = getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setBounds(0, 0, paddingRight, paddingBottom);
        }
        d<p> progressDrawable = getProgressDrawable();
        if (progressDrawable != null) {
            progressDrawable.setBounds(0, 0, paddingRight, paddingBottom);
        }
    }

    public void setIndeterminateAnimationType(int i2) {
        if (((p) this.f8889d).f8939g == i2) {
            return;
        }
        if (c() && isIndeterminate()) {
            throw new IllegalStateException("Cannot change indeterminate animation type while the progress indicator is show in indeterminate mode.");
        }
        p pVar = (p) this.f8889d;
        pVar.f8939g = i2;
        pVar.a();
        if (i2 == 0) {
            j<p> indeterminateDrawable = getIndeterminateDrawable();
            m mVar = new m((p) this.f8889d);
            indeterminateDrawable.p = mVar;
            mVar.f8917a = indeterminateDrawable;
        } else {
            j<p> indeterminateDrawable2 = getIndeterminateDrawable();
            o oVar = new o(getContext(), (p) this.f8889d);
            indeterminateDrawable2.p = oVar;
            oVar.f8917a = indeterminateDrawable2;
        }
        invalidate();
    }

    @Override // c.d.a.d.s.b
    public void setIndicatorColor(int... iArr) {
        super.setIndicatorColor(iArr);
        ((p) this.f8889d).a();
    }

    public void setIndicatorDirection(int i2) {
        S s = this.f8889d;
        ((p) s).f8940h = i2;
        p pVar = (p) s;
        boolean z = true;
        if (i2 != 1) {
            AtomicInteger atomicInteger = q.f1738a;
            if ((getLayoutDirection() != 1 || ((p) this.f8889d).f8940h != 2) && (getLayoutDirection() != 0 || i2 != 3)) {
                z = false;
            }
        }
        pVar.f8941i = z;
        invalidate();
    }

    @Override // c.d.a.d.s.b
    public void setTrackCornerRadius(int i2) {
        super.setTrackCornerRadius(i2);
        ((p) this.f8889d).a();
        invalidate();
    }
}