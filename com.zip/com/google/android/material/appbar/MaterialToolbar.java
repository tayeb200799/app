package com.google.android.material.appbar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import androidx.appcompat.widget.Toolbar;
import b.h.k.q;
import c.d.a.d.b;
import c.d.a.d.c0.a.a;
import c.d.a.d.r.k;
import c.d.a.d.x.g;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\appbar\MaterialToolbar.smali */
public class MaterialToolbar extends Toolbar {
    public Integer Q;

    public MaterialToolbar(Context context, AttributeSet attributeSet) {
        super(a.a(context, attributeSet, 2130969547, 2131952394), attributeSet, 2130969547);
        Context context2 = getContext();
        TypedArray d2 = k.d(context2, attributeSet, b.B, 2130969547, 2131952394, new int[0]);
        if (d2.hasValue(0)) {
            setNavigationIconTint(d2.getColor(0, -1));
        }
        d2.recycle();
        Drawable background = getBackground();
        if (background == null || (background instanceof ColorDrawable)) {
            g gVar = new g();
            gVar.q(ColorStateList.valueOf(background != null ? ((ColorDrawable) background).getColor() : 0));
            gVar.f8986d.f8995b = new c.d.a.d.o.a(context2);
            gVar.y();
            AtomicInteger atomicInteger = q.f1738a;
            gVar.p(getElevation());
            setBackground(gVar);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof g) {
            c.d.a.d.a.f0(this, (g) background);
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        c.d.a.d.a.e0(this, f2);
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null && this.Q != null) {
            drawable = b.h.a.X(drawable);
            drawable.setTint(this.Q.intValue());
        }
        super.setNavigationIcon(drawable);
    }

    public void setNavigationIconTint(int i2) {
        this.Q = Integer.valueOf(i2);
        Drawable navigationIcon = getNavigationIcon();
        if (navigationIcon != null) {
            setNavigationIcon(navigationIcon);
        }
    }
}