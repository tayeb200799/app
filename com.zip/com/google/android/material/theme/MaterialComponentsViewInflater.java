package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import b.b.c.r;
import b.b.i.d;
import b.b.i.f;
import b.b.i.n;
import c.d.a.d.b0.p;
import c.d.a.d.k.a;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\theme\MaterialComponentsViewInflater.smali */
public class MaterialComponentsViewInflater extends r {
    @Override // b.b.c.r
    public d a(Context context, AttributeSet attributeSet) {
        return new p(context, attributeSet);
    }

    @Override // b.b.c.r
    public AppCompatButton b(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }

    @Override // b.b.c.r
    public f c(Context context, AttributeSet attributeSet) {
        return new a(context, attributeSet);
    }

    @Override // b.b.c.r
    public n d(Context context, AttributeSet attributeSet) {
        return new c.d.a.d.t.a(context, attributeSet);
    }

    @Override // b.b.c.r
    public AppCompatTextView e(Context context, AttributeSet attributeSet) {
        return new MaterialTextView(context, attributeSet);
    }
}