package com.google.android.material.card;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import android.widget.FrameLayout;
import androidx.cardview.widget.CardView;
import b.h.k.q;
import c.d.a.d.b;
import c.d.a.d.r.k;
import c.d.a.d.x.g;
import c.d.a.d.x.j;
import c.d.a.d.x.n;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\card\MaterialCardView.smali */
public class MaterialCardView extends CardView implements Checkable, n {
    public static final int[] r = {R.attr.state_checkable};
    public static final int[] s = {R.attr.state_checked};
    public static final int[] t = {2130969416};
    public final c.d.a.d.j.a m;
    public boolean n;
    public boolean o;
    public boolean p;
    public a q;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\card\MaterialCardView$a.smali */
    public interface a {
        void a(MaterialCardView materialCardView, boolean z);
    }

    public MaterialCardView(Context context, AttributeSet attributeSet) {
        super(c.d.a.d.c0.a.a.a(context, attributeSet, 2130969206, 2131952317), attributeSet, 2130969206);
        this.o = false;
        this.p = false;
        this.n = true;
        TypedArray d2 = k.d(getContext(), attributeSet, b.v, 2130969206, 2131952317, new int[0]);
        c.d.a.d.j.a aVar = new c.d.a.d.j.a(this, attributeSet, 2130969206, 2131952317);
        this.m = aVar;
        aVar.f8703c.q(super.getCardBackgroundColor());
        aVar.f8702b.set(super.getContentPaddingLeft(), super.getContentPaddingTop(), super.getContentPaddingRight(), super.getContentPaddingBottom());
        aVar.k();
        ColorStateList C = c.d.a.d.a.C(aVar.f8701a.getContext(), d2, 10);
        aVar.m = C;
        if (C == null) {
            aVar.m = ColorStateList.valueOf(-1);
        }
        aVar.f8707g = d2.getDimensionPixelSize(11, 0);
        boolean z = d2.getBoolean(0, false);
        aVar.s = z;
        aVar.f8701a.setLongClickable(z);
        aVar.k = c.d.a.d.a.C(aVar.f8701a.getContext(), d2, 5);
        aVar.g(c.d.a.d.a.F(aVar.f8701a.getContext(), d2, 2));
        aVar.f8706f = d2.getDimensionPixelSize(4, 0);
        aVar.f8705e = d2.getDimensionPixelSize(3, 0);
        ColorStateList C2 = c.d.a.d.a.C(aVar.f8701a.getContext(), d2, 6);
        aVar.f8710j = C2;
        if (C2 == null) {
            aVar.f8710j = ColorStateList.valueOf(c.d.a.d.a.B(aVar.f8701a, 2130968807));
        }
        ColorStateList C3 = c.d.a.d.a.C(aVar.f8701a.getContext(), d2, 1);
        aVar.f8704d.q(C3 == null ? ColorStateList.valueOf(0) : C3);
        aVar.m();
        aVar.f8703c.p(aVar.f8701a.getCardElevation());
        aVar.n();
        aVar.f8701a.setBackgroundInternal(aVar.f(aVar.f8703c));
        Drawable e2 = aVar.f8701a.isClickable() ? aVar.e() : aVar.f8704d;
        aVar.f8708h = e2;
        aVar.f8701a.setForeground(aVar.f(e2));
        d2.recycle();
    }

    private RectF getBoundsAsRectF() {
        RectF rectF = new RectF();
        rectF.set(this.m.f8703c.getBounds());
        return rectF;
    }

    public final void d() {
        c.d.a.d.j.a aVar;
        Drawable drawable;
        if (Build.VERSION.SDK_INT <= 26 || (drawable = (aVar = this.m).n) == null) {
            return;
        }
        Rect bounds = drawable.getBounds();
        int i2 = bounds.bottom;
        aVar.n.setBounds(bounds.left, bounds.top, bounds.right, i2 - 1);
        aVar.n.setBounds(bounds.left, bounds.top, bounds.right, i2);
    }

    public boolean e() {
        c.d.a.d.j.a aVar = this.m;
        return aVar != null && aVar.s;
    }

    @Override // androidx.cardview.widget.CardView
    public ColorStateList getCardBackgroundColor() {
        return this.m.f8703c.f8986d.f8997d;
    }

    public ColorStateList getCardForegroundColor() {
        return this.m.f8704d.f8986d.f8997d;
    }

    public float getCardViewRadius() {
        return super.getRadius();
    }

    public Drawable getCheckedIcon() {
        return this.m.f8709i;
    }

    public int getCheckedIconMargin() {
        return this.m.f8705e;
    }

    public int getCheckedIconSize() {
        return this.m.f8706f;
    }

    public ColorStateList getCheckedIconTint() {
        return this.m.k;
    }

    @Override // androidx.cardview.widget.CardView
    public int getContentPaddingBottom() {
        return this.m.f8702b.bottom;
    }

    @Override // androidx.cardview.widget.CardView
    public int getContentPaddingLeft() {
        return this.m.f8702b.left;
    }

    @Override // androidx.cardview.widget.CardView
    public int getContentPaddingRight() {
        return this.m.f8702b.right;
    }

    @Override // androidx.cardview.widget.CardView
    public int getContentPaddingTop() {
        return this.m.f8702b.top;
    }

    public float getProgress() {
        return this.m.f8703c.f8986d.k;
    }

    @Override // androidx.cardview.widget.CardView
    public float getRadius() {
        return this.m.f8703c.l();
    }

    public ColorStateList getRippleColor() {
        return this.m.f8710j;
    }

    public j getShapeAppearanceModel() {
        return this.m.l;
    }

    @Deprecated
    public int getStrokeColor() {
        ColorStateList colorStateList = this.m.m;
        if (colorStateList == null) {
            return -1;
        }
        return colorStateList.getDefaultColor();
    }

    public ColorStateList getStrokeColorStateList() {
        return this.m.m;
    }

    public int getStrokeWidth() {
        return this.m.f8707g;
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.o;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        c.d.a.d.a.f0(this, this.m.f8703c);
    }

    @Override // android.view.ViewGroup, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 3);
        if (e()) {
            FrameLayout.mergeDrawableStates(onCreateDrawableState, r);
        }
        if (isChecked()) {
            FrameLayout.mergeDrawableStates(onCreateDrawableState, s);
        }
        if (this.p) {
            FrameLayout.mergeDrawableStates(onCreateDrawableState, t);
        }
        return onCreateDrawableState;
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.cardview.widget.CardView");
        accessibilityEvent.setChecked(isChecked());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.cardview.widget.CardView");
        accessibilityNodeInfo.setCheckable(e());
        accessibilityNodeInfo.setClickable(isClickable());
        accessibilityNodeInfo.setChecked(isChecked());
    }

    @Override // androidx.cardview.widget.CardView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        super.onMeasure(i2, i3);
        c.d.a.d.j.a aVar = this.m;
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (aVar.o != null) {
            int i6 = aVar.f8705e;
            int i7 = aVar.f8706f;
            int i8 = (measuredWidth - i6) - i7;
            int i9 = (measuredHeight - i6) - i7;
            if (aVar.f8701a.getUseCompatPadding()) {
                i9 -= (int) Math.ceil(aVar.d() * 2.0f);
                i8 -= (int) Math.ceil(aVar.c() * 2.0f);
            }
            int i10 = i9;
            int i11 = aVar.f8705e;
            MaterialCardView materialCardView = aVar.f8701a;
            AtomicInteger atomicInteger = q.f1738a;
            if (materialCardView.getLayoutDirection() == 1) {
                i5 = i8;
                i4 = i11;
            } else {
                i4 = i8;
                i5 = i11;
            }
            aVar.o.setLayerInset(2, i4, aVar.f8705e, i5, i10);
        }
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (this.n) {
            if (!this.m.r) {
                Log.i("MaterialCardView", "Setting a custom background is not supported.");
                this.m.r = true;
            }
            super.setBackgroundDrawable(drawable);
        }
    }

    public void setBackgroundInternal(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    @Override // androidx.cardview.widget.CardView
    public void setCardBackgroundColor(int i2) {
        c.d.a.d.j.a aVar = this.m;
        aVar.f8703c.q(ColorStateList.valueOf(i2));
    }

    @Override // androidx.cardview.widget.CardView
    public void setCardBackgroundColor(ColorStateList colorStateList) {
        this.m.f8703c.q(colorStateList);
    }

    @Override // androidx.cardview.widget.CardView
    public void setCardElevation(float f2) {
        super.setCardElevation(f2);
        c.d.a.d.j.a aVar = this.m;
        aVar.f8703c.p(aVar.f8701a.getCardElevation());
    }

    public void setCardForegroundColor(ColorStateList colorStateList) {
        g gVar = this.m.f8704d;
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        gVar.q(colorStateList);
    }

    public void setCheckable(boolean z) {
        this.m.s = z;
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        if (this.o != z) {
            toggle();
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        this.m.g(drawable);
    }

    public void setCheckedIconMargin(int i2) {
        this.m.f8705e = i2;
    }

    public void setCheckedIconMarginResource(int i2) {
        if (i2 != -1) {
            this.m.f8705e = getResources().getDimensionPixelSize(i2);
        }
    }

    public void setCheckedIconResource(int i2) {
        this.m.g(b.b.d.a.a.b(getContext(), i2));
    }

    public void setCheckedIconSize(int i2) {
        this.m.f8706f = i2;
    }

    public void setCheckedIconSizeResource(int i2) {
        if (i2 != 0) {
            this.m.f8706f = getResources().getDimensionPixelSize(i2);
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        c.d.a.d.j.a aVar = this.m;
        aVar.k = colorStateList;
        Drawable drawable = aVar.f8709i;
        if (drawable != null) {
            drawable.setTintList(colorStateList);
        }
    }

    @Override // android.view.View
    public void setClickable(boolean z) {
        super.setClickable(z);
        c.d.a.d.j.a aVar = this.m;
        if (aVar != null) {
            Drawable drawable = aVar.f8708h;
            Drawable e2 = aVar.f8701a.isClickable() ? aVar.e() : aVar.f8704d;
            aVar.f8708h = e2;
            if (drawable != e2) {
                if (Build.VERSION.SDK_INT < 23 || !(aVar.f8701a.getForeground() instanceof InsetDrawable)) {
                    aVar.f8701a.setForeground(aVar.f(e2));
                } else {
                    ((InsetDrawable) aVar.f8701a.getForeground()).setDrawable(e2);
                }
            }
        }
    }

    public void setDragged(boolean z) {
        if (this.p != z) {
            this.p = z;
            refreshDrawableState();
            d();
            invalidate();
        }
    }

    @Override // androidx.cardview.widget.CardView
    public void setMaxCardElevation(float f2) {
        super.setMaxCardElevation(f2);
        this.m.l();
    }

    public void setOnCheckedChangeListener(a aVar) {
        this.q = aVar;
    }

    @Override // androidx.cardview.widget.CardView
    public void setPreventCornerOverlap(boolean z) {
        super.setPreventCornerOverlap(z);
        this.m.l();
        this.m.k();
    }

    public void setProgress(float f2) {
        c.d.a.d.j.a aVar = this.m;
        aVar.f8703c.r(f2);
        g gVar = aVar.f8704d;
        if (gVar != null) {
            gVar.r(f2);
        }
        g gVar2 = aVar.q;
        if (gVar2 != null) {
            gVar2.r(f2);
        }
    }

    @Override // androidx.cardview.widget.CardView
    public void setRadius(float f2) {
        super.setRadius(f2);
        c.d.a.d.j.a aVar = this.m;
        aVar.h(aVar.l.e(f2));
        aVar.f8708h.invalidateSelf();
        if (aVar.j() || aVar.i()) {
            aVar.k();
        }
        if (aVar.j()) {
            aVar.l();
        }
    }

    public void setRippleColor(ColorStateList colorStateList) {
        c.d.a.d.j.a aVar = this.m;
        aVar.f8710j = colorStateList;
        aVar.m();
    }

    public void setRippleColorResource(int i2) {
        c.d.a.d.j.a aVar = this.m;
        aVar.f8710j = b.b.d.a.a.a(getContext(), i2);
        aVar.m();
    }

    @Override // c.d.a.d.x.n
    public void setShapeAppearanceModel(j jVar) {
        setClipToOutline(jVar.d(getBoundsAsRectF()));
        this.m.h(jVar);
    }

    public void setStrokeColor(int i2) {
        c.d.a.d.j.a aVar = this.m;
        ColorStateList valueOf = ColorStateList.valueOf(i2);
        if (aVar.m == valueOf) {
            return;
        }
        aVar.m = valueOf;
        aVar.n();
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        c.d.a.d.j.a aVar = this.m;
        if (aVar.m == colorStateList) {
            return;
        }
        aVar.m = colorStateList;
        aVar.n();
    }

    public void setStrokeWidth(int i2) {
        c.d.a.d.j.a aVar = this.m;
        if (i2 == aVar.f8707g) {
            return;
        }
        aVar.f8707g = i2;
        aVar.n();
    }

    @Override // androidx.cardview.widget.CardView
    public void setUseCompatPadding(boolean z) {
        super.setUseCompatPadding(z);
        this.m.l();
        this.m.k();
    }

    @Override // android.widget.Checkable
    public void toggle() {
        if (e() && isEnabled()) {
            this.o = !this.o;
            refreshDrawableState();
            d();
            a aVar = this.q;
            if (aVar != null) {
                aVar.a(this, this.o);
            }
        }
    }
}