package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import b.h.k.q;
import b.h.k.y.b;
import b.j.b.e;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\behavior\SwipeDismissBehavior.smali */
public class SwipeDismissBehavior<V extends View> extends CoordinatorLayout.c<V> {

    /* renamed from: a, reason: collision with root package name */
    public e f9794a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f9795b;

    /* renamed from: c, reason: collision with root package name */
    public int f9796c = 2;

    /* renamed from: d, reason: collision with root package name */
    public float f9797d = 0.5f;

    /* renamed from: e, reason: collision with root package name */
    public float f9798e = 0.0f;

    /* renamed from: f, reason: collision with root package name */
    public float f9799f = 0.5f;

    /* renamed from: g, reason: collision with root package name */
    public final e.c f9800g = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\behavior\SwipeDismissBehavior$a.smali */
    public class a extends e.c {

        /* renamed from: a, reason: collision with root package name */
        public int f9801a;

        /* renamed from: b, reason: collision with root package name */
        public int f9802b = -1;

        public a() {
        }

        @Override // b.j.b.e.c
        public int a(View view, int i2, int i3) {
            int width;
            int width2;
            int width3;
            AtomicInteger atomicInteger = q.f1738a;
            boolean z = view.getLayoutDirection() == 1;
            int i4 = SwipeDismissBehavior.this.f9796c;
            if (i4 == 0) {
                if (z) {
                    width = this.f9801a - view.getWidth();
                    width2 = this.f9801a;
                } else {
                    width = this.f9801a;
                    width3 = view.getWidth();
                    width2 = width3 + width;
                }
            } else if (i4 != 1) {
                width = this.f9801a - view.getWidth();
                width2 = view.getWidth() + this.f9801a;
            } else if (z) {
                width = this.f9801a;
                width3 = view.getWidth();
                width2 = width3 + width;
            } else {
                width = this.f9801a - view.getWidth();
                width2 = this.f9801a;
            }
            return Math.min(Math.max(width, i2), width2);
        }

        @Override // b.j.b.e.c
        public int b(View view, int i2, int i3) {
            return view.getTop();
        }

        @Override // b.j.b.e.c
        public int c(View view) {
            return view.getWidth();
        }

        @Override // b.j.b.e.c
        public void e(View view, int i2) {
            this.f9802b = i2;
            this.f9801a = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }

        @Override // b.j.b.e.c
        public void f(int i2) {
            Objects.requireNonNull(SwipeDismissBehavior.this);
        }

        @Override // b.j.b.e.c
        public void g(View view, int i2, int i3, int i4, int i5) {
            float width = (view.getWidth() * SwipeDismissBehavior.this.f9798e) + this.f9801a;
            float width2 = (view.getWidth() * SwipeDismissBehavior.this.f9799f) + this.f9801a;
            float f2 = i2;
            if (f2 <= width) {
                view.setAlpha(1.0f);
            } else if (f2 >= width2) {
                view.setAlpha(0.0f);
            } else {
                view.setAlpha(SwipeDismissBehavior.C(0.0f, 1.0f - ((f2 - width) / (width2 - width)), 1.0f));
            }
        }

        /* JADX WARN: Code restructure failed: missing block: B:38:0x0056, code lost:
        
            if (java.lang.Math.abs(r8.getLeft() - r7.f9801a) >= java.lang.Math.round(r8.getWidth() * r7.f9803c.f9797d)) goto L17;
         */
        @Override // b.j.b.e.c
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void h(android.view.View r8, float r9, float r10) {
            /*
                r7 = this;
                r10 = -1
                r7.f9802b = r10
                int r10 = r8.getWidth()
                r0 = 0
                r1 = 0
                r2 = 1
                int r3 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r3 == 0) goto L3c
                java.util.concurrent.atomic.AtomicInteger r4 = b.h.k.q.f1738a
                int r4 = r8.getLayoutDirection()
                if (r4 != r2) goto L18
                r4 = 1
                goto L19
            L18:
                r4 = 0
            L19:
                com.google.android.material.behavior.SwipeDismissBehavior r5 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r5 = r5.f9796c
                r6 = 2
                if (r5 != r6) goto L21
                goto L2c
            L21:
                if (r5 != 0) goto L30
                if (r4 == 0) goto L2a
                int r9 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r9 >= 0) goto L2e
                goto L2c
            L2a:
                if (r3 <= 0) goto L2e
            L2c:
                r9 = 1
                goto L59
            L2e:
                r9 = 0
                goto L59
            L30:
                if (r5 != r2) goto L2e
                if (r4 == 0) goto L37
                if (r3 <= 0) goto L2e
                goto L3b
            L37:
                int r9 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r9 >= 0) goto L2e
            L3b:
                goto L2c
            L3c:
                int r9 = r8.getLeft()
                int r0 = r7.f9801a
                int r9 = r9 - r0
                int r0 = r8.getWidth()
                float r0 = (float) r0
                com.google.android.material.behavior.SwipeDismissBehavior r3 = com.google.android.material.behavior.SwipeDismissBehavior.this
                float r3 = r3.f9797d
                float r0 = r0 * r3
                int r0 = java.lang.Math.round(r0)
                int r9 = java.lang.Math.abs(r9)
                if (r9 < r0) goto L2e
                goto L2c
            L59:
                if (r9 == 0) goto L68
                int r9 = r8.getLeft()
                int r0 = r7.f9801a
                if (r9 >= r0) goto L65
                int r0 = r0 - r10
                goto L66
            L65:
                int r0 = r0 + r10
            L66:
                r1 = 1
                goto L6a
            L68:
                int r0 = r7.f9801a
            L6a:
                com.google.android.material.behavior.SwipeDismissBehavior r9 = com.google.android.material.behavior.SwipeDismissBehavior.this
                b.j.b.e r9 = r9.f9794a
                int r10 = r8.getTop()
                boolean r9 = r9.t(r0, r10)
                if (r9 == 0) goto L85
                com.google.android.material.behavior.SwipeDismissBehavior$b r9 = new com.google.android.material.behavior.SwipeDismissBehavior$b
                com.google.android.material.behavior.SwipeDismissBehavior r10 = com.google.android.material.behavior.SwipeDismissBehavior.this
                r9.<init>(r8, r1)
                java.util.concurrent.atomic.AtomicInteger r10 = b.h.k.q.f1738a
                r8.postOnAnimation(r9)
                goto L8c
            L85:
                if (r1 == 0) goto L8c
                com.google.android.material.behavior.SwipeDismissBehavior r8 = com.google.android.material.behavior.SwipeDismissBehavior.this
                java.util.Objects.requireNonNull(r8)
            L8c:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.a.h(android.view.View, float, float):void");
        }

        @Override // b.j.b.e.c
        public boolean i(View view, int i2) {
            int i3 = this.f9802b;
            return (i3 == -1 || i3 == i2) && SwipeDismissBehavior.this.B(view);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\behavior\SwipeDismissBehavior$b.smali */
    public class b implements Runnable {

        /* renamed from: d, reason: collision with root package name */
        public final View f9804d;

        /* renamed from: e, reason: collision with root package name */
        public final boolean f9805e;

        public b(View view, boolean z) {
            this.f9804d = view;
            this.f9805e = z;
        }

        @Override // java.lang.Runnable
        public void run() {
            e eVar = SwipeDismissBehavior.this.f9794a;
            if (eVar == null || !eVar.i(true)) {
                if (this.f9805e) {
                    Objects.requireNonNull(SwipeDismissBehavior.this);
                }
            } else {
                View view = this.f9804d;
                AtomicInteger atomicInteger = q.f1738a;
                view.postOnAnimation(this);
            }
        }
    }

    public static float C(float f2, float f3, float f4) {
        return Math.min(Math.max(f2, f3), f4);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean A(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        e eVar = this.f9794a;
        if (eVar == null) {
            return false;
        }
        eVar.n(motionEvent);
        return true;
    }

    public boolean B(View view) {
        return true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean j(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        boolean z = this.f9795b;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            z = coordinatorLayout.q(v, (int) motionEvent.getX(), (int) motionEvent.getY());
            this.f9795b = z;
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f9795b = false;
        }
        if (!z) {
            return false;
        }
        if (this.f9794a == null) {
            this.f9794a = new e(coordinatorLayout.getContext(), coordinatorLayout, this.f9800g);
        }
        return this.f9794a.u(motionEvent);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
    public boolean k(CoordinatorLayout coordinatorLayout, V v, int i2) {
        AtomicInteger atomicInteger = q.f1738a;
        if (v.getImportantForAccessibility() == 0) {
            v.setImportantForAccessibility(1);
            q.q(1048576, v);
            q.m(v, 0);
            if (B(v)) {
                q.r(v, b.a.f1798j, null, new c.d.a.d.f.a(this));
            }
        }
        return false;
    }
}