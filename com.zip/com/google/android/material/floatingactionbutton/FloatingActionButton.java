package com.google.android.material.floatingactionbutton;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import b.b.i.i;
import b.b.i.j;
import b.h.k.q;
import c.d.a.d.c.g;
import c.d.a.d.q.e;
import c.d.a.d.q.h;
import c.d.a.d.r.d;
import c.d.a.d.r.k;
import c.d.a.d.r.p;
import c.d.a.d.x.n;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\floatingactionbutton\FloatingActionButton.smali */
public class FloatingActionButton extends p implements c.d.a.d.p.a, n, CoordinatorLayout.b {

    /* renamed from: e, reason: collision with root package name */
    public ColorStateList f9875e;

    /* renamed from: f, reason: collision with root package name */
    public PorterDuff.Mode f9876f;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f9877g;

    /* renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f9878h;

    /* renamed from: i, reason: collision with root package name */
    public ColorStateList f9879i;

    /* renamed from: j, reason: collision with root package name */
    public int f9880j;
    public int k;
    public int l;
    public int m;
    public int n;
    public boolean o;
    public final Rect p;
    public final Rect q;
    public final j r;
    public final c.d.a.d.p.b s;
    public e t;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\floatingactionbutton\FloatingActionButton$BaseBehavior.smali */
    public static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.c<T> {

        /* renamed from: a, reason: collision with root package name */
        public Rect f9881a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f9882b;

        public BaseBehavior() {
            this.f9882b = true;
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, c.d.a.d.b.m);
            this.f9882b = obtainStyledAttributes.getBoolean(0, true);
            obtainStyledAttributes.recycle();
        }

        public boolean B(FloatingActionButton floatingActionButton, Rect rect) {
            Rect rect2 = floatingActionButton.p;
            rect.set(floatingActionButton.getLeft() + rect2.left, floatingActionButton.getTop() + rect2.top, floatingActionButton.getRight() - rect2.right, floatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        public final boolean C(View view, FloatingActionButton floatingActionButton) {
            return this.f9882b && ((CoordinatorLayout.f) floatingActionButton.getLayoutParams()).f280f == view.getId() && floatingActionButton.getUserSetVisibility() == 0;
        }

        public final boolean D(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!C(appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.f9881a == null) {
                this.f9881a = new Rect();
            }
            Rect rect = this.f9881a;
            d.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.i(null, false);
                return true;
            }
            floatingActionButton.o(null, false);
            return true;
        }

        public final boolean E(View view, FloatingActionButton floatingActionButton) {
            if (!C(view, floatingActionButton)) {
                return false;
            }
            if (view.getTop() < (floatingActionButton.getHeight() / 2) + ((ViewGroup.MarginLayoutParams) ((CoordinatorLayout.f) floatingActionButton.getLayoutParams())).topMargin) {
                floatingActionButton.i(null, false);
                return true;
            }
            floatingActionButton.o(null, false);
            return true;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public /* bridge */ /* synthetic */ boolean a(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            return B((FloatingActionButton) view, rect);
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public void f(CoordinatorLayout.f fVar) {
            if (fVar.f282h == 0) {
                fVar.f282h = 80;
            }
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public boolean g(CoordinatorLayout coordinatorLayout, View view, View view2) {
            FloatingActionButton floatingActionButton = (FloatingActionButton) view;
            if (view2 instanceof AppBarLayout) {
                D(coordinatorLayout, (AppBarLayout) view2, floatingActionButton);
            } else {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                if (layoutParams instanceof CoordinatorLayout.f ? ((CoordinatorLayout.f) layoutParams).f275a instanceof BottomSheetBehavior : false) {
                    E(view2, floatingActionButton);
                }
            }
            return false;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public boolean k(CoordinatorLayout coordinatorLayout, View view, int i2) {
            FloatingActionButton floatingActionButton = (FloatingActionButton) view;
            List<View> e2 = coordinatorLayout.e(floatingActionButton);
            int size = e2.size();
            int i3 = 0;
            for (int i4 = 0; i4 < size; i4++) {
                View view2 = e2.get(i4);
                if (!(view2 instanceof AppBarLayout)) {
                    ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                    if ((layoutParams instanceof CoordinatorLayout.f ? ((CoordinatorLayout.f) layoutParams).f275a instanceof BottomSheetBehavior : false) && E(view2, floatingActionButton)) {
                        break;
                    }
                } else {
                    if (D(coordinatorLayout, (AppBarLayout) view2, floatingActionButton)) {
                        break;
                    }
                }
            }
            coordinatorLayout.s(floatingActionButton, i2);
            Rect rect = floatingActionButton.p;
            if (rect == null || rect.centerX() <= 0 || rect.centerY() <= 0) {
                return true;
            }
            CoordinatorLayout.f fVar = (CoordinatorLayout.f) floatingActionButton.getLayoutParams();
            int i5 = floatingActionButton.getRight() >= coordinatorLayout.getWidth() - ((ViewGroup.MarginLayoutParams) fVar).rightMargin ? rect.right : floatingActionButton.getLeft() <= ((ViewGroup.MarginLayoutParams) fVar).leftMargin ? -rect.left : 0;
            if (floatingActionButton.getBottom() >= coordinatorLayout.getHeight() - ((ViewGroup.MarginLayoutParams) fVar).bottomMargin) {
                i3 = rect.bottom;
            } else if (floatingActionButton.getTop() <= ((ViewGroup.MarginLayoutParams) fVar).topMargin) {
                i3 = -rect.top;
            }
            if (i3 != 0) {
                q.o(floatingActionButton, i3);
            }
            if (i5 == 0) {
                return true;
            }
            q.n(floatingActionButton, i5);
            return true;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\floatingactionbutton\FloatingActionButton$Behavior.smali */
    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\floatingactionbutton\FloatingActionButton$a.smali */
    public static abstract class a {
        public void a(FloatingActionButton floatingActionButton) {
        }

        public void b(FloatingActionButton floatingActionButton) {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\floatingactionbutton\FloatingActionButton$b.smali */
    public class b implements c.d.a.d.w.b {
        public b() {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\floatingactionbutton\FloatingActionButton$c.smali */
    public class c<T extends FloatingActionButton> implements e.InterfaceC0133e {

        /* renamed from: a, reason: collision with root package name */
        public final c.d.a.d.c.j<T> f9884a;

        public c(c.d.a.d.c.j<T> jVar) {
            this.f9884a = jVar;
        }

        @Override // c.d.a.d.q.e.InterfaceC0133e
        public void a() {
            this.f9884a.a(FloatingActionButton.this);
        }

        @Override // c.d.a.d.q.e.InterfaceC0133e
        public void b() {
            this.f9884a.b(FloatingActionButton.this);
        }

        public boolean equals(Object obj) {
            return (obj instanceof c) && ((c) obj).f9884a.equals(this.f9884a);
        }

        public int hashCode() {
            return this.f9884a.hashCode();
        }
    }

    public FloatingActionButton(Context context, AttributeSet attributeSet) {
        super(c.d.a.d.c0.a.a.a(context, attributeSet, 2130968966, 2131952278), attributeSet, 2130968966);
        this.p = new Rect();
        this.q = new Rect();
        Context context2 = getContext();
        TypedArray d2 = k.d(context2, attributeSet, c.d.a.d.b.l, 2130968966, 2131952278, new int[0]);
        this.f9875e = c.d.a.d.a.C(context2, d2, 1);
        this.f9876f = c.d.a.d.a.R(d2.getInt(2, -1), null);
        this.f9879i = c.d.a.d.a.C(context2, d2, 12);
        this.k = d2.getInt(7, -1);
        this.l = d2.getDimensionPixelSize(6, 0);
        this.f9880j = d2.getDimensionPixelSize(3, 0);
        float dimension = d2.getDimension(4, 0.0f);
        float dimension2 = d2.getDimension(9, 0.0f);
        float dimension3 = d2.getDimension(11, 0.0f);
        this.o = d2.getBoolean(16, false);
        int dimensionPixelSize = getResources().getDimensionPixelSize(2131165484);
        this.n = d2.getDimensionPixelSize(10, 0);
        g a2 = g.a(context2, d2, 15);
        g a3 = g.a(context2, d2, 8);
        c.d.a.d.x.j a4 = c.d.a.d.x.j.b(context2, attributeSet, 2130968966, 2131952278, c.d.a.d.x.j.m).a();
        boolean z = d2.getBoolean(5, false);
        setEnabled(d2.getBoolean(0, true));
        d2.recycle();
        j jVar = new j(this);
        this.r = jVar;
        jVar.b(attributeSet, 2130968966);
        this.s = new c.d.a.d.p.b(this);
        getImpl().r(a4);
        getImpl().f(this.f9875e, this.f9876f, this.f9879i, this.f9880j);
        getImpl().k = dimensionPixelSize;
        e impl = getImpl();
        if (impl.f8825h != dimension) {
            impl.f8825h = dimension;
            impl.l(dimension, impl.f8826i, impl.f8827j);
        }
        e impl2 = getImpl();
        if (impl2.f8826i != dimension2) {
            impl2.f8826i = dimension2;
            impl2.l(impl2.f8825h, dimension2, impl2.f8827j);
        }
        e impl3 = getImpl();
        if (impl3.f8827j != dimension3) {
            impl3.f8827j = dimension3;
            impl3.l(impl3.f8825h, impl3.f8826i, dimension3);
        }
        e impl4 = getImpl();
        int i2 = this.n;
        if (impl4.t != i2) {
            impl4.t = i2;
            impl4.p(impl4.s);
        }
        getImpl().p = a2;
        getImpl().q = a3;
        getImpl().f8823f = z;
        setScaleType(ImageView.ScaleType.MATRIX);
    }

    private e getImpl() {
        if (this.t == null) {
            this.t = new h(this, new b());
        }
        return this.t;
    }

    public static int n(int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        if (mode == Integer.MIN_VALUE) {
            return Math.min(i2, size);
        }
        if (mode == 0) {
            return i2;
        }
        if (mode == 1073741824) {
            return size;
        }
        throw new IllegalArgumentException();
    }

    @Override // c.d.a.d.p.a
    public boolean a() {
        return this.s.f8796b;
    }

    public void d(Animator.AnimatorListener animatorListener) {
        e impl = getImpl();
        if (impl.w == null) {
            impl.w = new ArrayList<>();
        }
        impl.w.add(null);
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        getImpl().k(getDrawableState());
    }

    public void e(Animator.AnimatorListener animatorListener) {
        e impl = getImpl();
        if (impl.v == null) {
            impl.v = new ArrayList<>();
        }
        impl.v.add(animatorListener);
    }

    public void f(c.d.a.d.c.j<? extends FloatingActionButton> jVar) {
        e impl = getImpl();
        c cVar = new c(null);
        if (impl.x == null) {
            impl.x = new ArrayList<>();
        }
        impl.x.add(cVar);
    }

    @Deprecated
    public boolean g(Rect rect) {
        AtomicInteger atomicInteger = q.f1738a;
        if (!isLaidOut()) {
            return false;
        }
        rect.set(0, 0, getWidth(), getHeight());
        l(rect);
        return true;
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return this.f9875e;
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return this.f9876f;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public CoordinatorLayout.c<FloatingActionButton> getBehavior() {
        return new Behavior();
    }

    public float getCompatElevation() {
        return getImpl().d();
    }

    public float getCompatHoveredFocusedTranslationZ() {
        return getImpl().f8826i;
    }

    public float getCompatPressedTranslationZ() {
        return getImpl().f8827j;
    }

    public Drawable getContentBackground() {
        return getImpl().f8822e;
    }

    public int getCustomSize() {
        return this.l;
    }

    public int getExpandedComponentIdHint() {
        return this.s.f8797c;
    }

    public g getHideMotionSpec() {
        return getImpl().q;
    }

    @Deprecated
    public int getRippleColor() {
        ColorStateList colorStateList = this.f9879i;
        if (colorStateList != null) {
            return colorStateList.getDefaultColor();
        }
        return 0;
    }

    public ColorStateList getRippleColorStateList() {
        return this.f9879i;
    }

    public c.d.a.d.x.j getShapeAppearanceModel() {
        c.d.a.d.x.j jVar = getImpl().f8818a;
        Objects.requireNonNull(jVar);
        return jVar;
    }

    public g getShowMotionSpec() {
        return getImpl().p;
    }

    public int getSize() {
        return this.k;
    }

    public int getSizeDimension() {
        return h(this.k);
    }

    public ColorStateList getSupportBackgroundTintList() {
        return getBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return getBackgroundTintMode();
    }

    public ColorStateList getSupportImageTintList() {
        return this.f9877g;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        return this.f9878h;
    }

    public boolean getUseCompatPadding() {
        return this.o;
    }

    public final int h(int i2) {
        int i3 = this.l;
        if (i3 != 0) {
            return i3;
        }
        Resources resources = getResources();
        return i2 != -1 ? i2 != 1 ? resources.getDimensionPixelSize(2131165298) : resources.getDimensionPixelSize(2131165297) : Math.max(resources.getConfiguration().screenWidthDp, resources.getConfiguration().screenHeightDp) < 470 ? h(1) : h(0);
    }

    public void i(a aVar, boolean z) {
        e impl = getImpl();
        c.d.a.d.q.b bVar = aVar == null ? null : new c.d.a.d.q.b(this, aVar);
        if (impl.g()) {
            return;
        }
        Animator animator = impl.o;
        if (animator != null) {
            animator.cancel();
        }
        if (!impl.t()) {
            impl.y.b(z ? 8 : 4, z);
            if (bVar != null) {
                bVar.f8809a.a(bVar.f8810b);
                return;
            }
            return;
        }
        g gVar = impl.q;
        if (gVar == null) {
            if (impl.n == null) {
                impl.n = g.b(impl.y.getContext(), 2130837505);
            }
            gVar = impl.n;
            Objects.requireNonNull(gVar);
        }
        AnimatorSet b2 = impl.b(gVar, 0.0f, 0.0f, 0.0f);
        b2.addListener(new c.d.a.d.q.c(impl, z, bVar));
        ArrayList<Animator.AnimatorListener> arrayList = impl.w;
        if (arrayList != null) {
            Iterator<Animator.AnimatorListener> it = arrayList.iterator();
            while (it.hasNext()) {
                b2.addListener(it.next());
            }
        }
        b2.start();
    }

    public boolean j() {
        return getImpl().g();
    }

    @Override // android.widget.ImageView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        getImpl().i();
    }

    public boolean k() {
        return getImpl().h();
    }

    public final void l(Rect rect) {
        int i2 = rect.left;
        Rect rect2 = this.p;
        rect.left = i2 + rect2.left;
        rect.top += rect2.top;
        rect.right -= rect2.right;
        rect.bottom -= rect2.bottom;
    }

    public final void m() {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            return;
        }
        ColorStateList colorStateList = this.f9877g;
        if (colorStateList == null) {
            b.h.a.j(drawable);
            return;
        }
        int colorForState = colorStateList.getColorForState(getDrawableState(), 0);
        PorterDuff.Mode mode = this.f9878h;
        if (mode == null) {
            mode = PorterDuff.Mode.SRC_IN;
        }
        drawable.mutate().setColorFilter(i.c(colorForState, mode));
    }

    public void o(a aVar, boolean z) {
        e impl = getImpl();
        c.d.a.d.q.b bVar = aVar == null ? null : new c.d.a.d.q.b(this, aVar);
        if (impl.h()) {
            return;
        }
        Animator animator = impl.o;
        if (animator != null) {
            animator.cancel();
        }
        if (!impl.t()) {
            impl.y.b(0, z);
            impl.y.setAlpha(1.0f);
            impl.y.setScaleY(1.0f);
            impl.y.setScaleX(1.0f);
            impl.p(1.0f);
            if (bVar != null) {
                bVar.f8809a.b(bVar.f8810b);
                return;
            }
            return;
        }
        if (impl.y.getVisibility() != 0) {
            impl.y.setAlpha(0.0f);
            impl.y.setScaleY(0.0f);
            impl.y.setScaleX(0.0f);
            impl.p(0.0f);
        }
        g gVar = impl.p;
        if (gVar == null) {
            if (impl.m == null) {
                impl.m = g.b(impl.y.getContext(), 2130837506);
            }
            gVar = impl.m;
            Objects.requireNonNull(gVar);
        }
        AnimatorSet b2 = impl.b(gVar, 1.0f, 1.0f, 1.0f);
        b2.addListener(new c.d.a.d.q.d(impl, z, bVar));
        ArrayList<Animator.AnimatorListener> arrayList = impl.v;
        if (arrayList != null) {
            Iterator<Animator.AnimatorListener> it = arrayList.iterator();
            while (it.hasNext()) {
                b2.addListener(it.next());
            }
        }
        b2.start();
    }

    @Override // android.widget.ImageView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        e impl = getImpl();
        c.d.a.d.x.g gVar = impl.f8819b;
        if (gVar != null) {
            c.d.a.d.a.f0(impl.y, gVar);
        }
        if (impl.o()) {
            ViewTreeObserver viewTreeObserver = impl.y.getViewTreeObserver();
            if (impl.E == null) {
                impl.E = new c.d.a.d.q.g(impl);
            }
            viewTreeObserver.addOnPreDrawListener(impl.E);
        }
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        e impl = getImpl();
        ViewTreeObserver viewTreeObserver = impl.y.getViewTreeObserver();
        ViewTreeObserver.OnPreDrawListener onPreDrawListener = impl.E;
        if (onPreDrawListener != null) {
            viewTreeObserver.removeOnPreDrawListener(onPreDrawListener);
            impl.E = null;
        }
    }

    @Override // android.widget.ImageView, android.view.View
    public void onMeasure(int i2, int i3) {
        int sizeDimension = getSizeDimension();
        this.m = (sizeDimension - this.n) / 2;
        getImpl().w();
        int min = Math.min(n(sizeDimension, i2), n(sizeDimension, i3));
        Rect rect = this.p;
        setMeasuredDimension(rect.left + min + rect.right, min + rect.top + rect.bottom);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof c.d.a.d.z.a)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c.d.a.d.z.a aVar = (c.d.a.d.z.a) parcelable;
        super.onRestoreInstanceState(aVar.f1843d);
        c.d.a.d.p.b bVar = this.s;
        Bundle orDefault = aVar.f9072f.getOrDefault("expandableWidgetHelper", null);
        Objects.requireNonNull(orDefault);
        Bundle bundle = orDefault;
        Objects.requireNonNull(bVar);
        bVar.f8796b = bundle.getBoolean("expanded", false);
        bVar.f8797c = bundle.getInt("expandedComponentIdHint", 0);
        if (bVar.f8796b) {
            ViewParent parent = bVar.f8795a.getParent();
            if (parent instanceof CoordinatorLayout) {
                ((CoordinatorLayout) parent).c(bVar.f8795a);
            }
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        if (onSaveInstanceState == null) {
            onSaveInstanceState = new Bundle();
        }
        c.d.a.d.z.a aVar = new c.d.a.d.z.a(onSaveInstanceState);
        b.e.h<String, Bundle> hVar = aVar.f9072f;
        c.d.a.d.p.b bVar = this.s;
        Objects.requireNonNull(bVar);
        Bundle bundle = new Bundle();
        bundle.putBoolean("expanded", bVar.f8796b);
        bundle.putInt("expandedComponentIdHint", bVar.f8797c);
        hVar.put("expandableWidgetHelper", bundle);
        return aVar;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0 && g(this.q) && !this.q.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
            return false;
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f9875e != colorStateList) {
            this.f9875e = colorStateList;
            e impl = getImpl();
            c.d.a.d.x.g gVar = impl.f8819b;
            if (gVar != null) {
                gVar.setTintList(colorStateList);
            }
            c.d.a.d.q.a aVar = impl.f8821d;
            if (aVar != null) {
                aVar.b(colorStateList);
            }
        }
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        if (this.f9876f != mode) {
            this.f9876f = mode;
            c.d.a.d.x.g gVar = getImpl().f8819b;
            if (gVar != null) {
                gVar.setTintMode(mode);
            }
        }
    }

    public void setCompatElevation(float f2) {
        e impl = getImpl();
        if (impl.f8825h != f2) {
            impl.f8825h = f2;
            impl.l(f2, impl.f8826i, impl.f8827j);
        }
    }

    public void setCompatElevationResource(int i2) {
        setCompatElevation(getResources().getDimension(i2));
    }

    public void setCompatHoveredFocusedTranslationZ(float f2) {
        e impl = getImpl();
        if (impl.f8826i != f2) {
            impl.f8826i = f2;
            impl.l(impl.f8825h, f2, impl.f8827j);
        }
    }

    public void setCompatHoveredFocusedTranslationZResource(int i2) {
        setCompatHoveredFocusedTranslationZ(getResources().getDimension(i2));
    }

    public void setCompatPressedTranslationZ(float f2) {
        e impl = getImpl();
        if (impl.f8827j != f2) {
            impl.f8827j = f2;
            impl.l(impl.f8825h, impl.f8826i, f2);
        }
    }

    public void setCompatPressedTranslationZResource(int i2) {
        setCompatPressedTranslationZ(getResources().getDimension(i2));
    }

    public void setCustomSize(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("Custom size must be non-negative");
        }
        if (i2 != this.l) {
            this.l = i2;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        getImpl().x(f2);
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        if (z != getImpl().f8823f) {
            getImpl().f8823f = z;
            requestLayout();
        }
    }

    public void setExpandedComponentIdHint(int i2) {
        this.s.f8797c = i2;
    }

    public void setHideMotionSpec(g gVar) {
        getImpl().q = gVar;
    }

    public void setHideMotionSpecResource(int i2) {
        setHideMotionSpec(g.b(getContext(), i2));
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        if (getDrawable() != drawable) {
            super.setImageDrawable(drawable);
            e impl = getImpl();
            impl.p(impl.s);
            if (this.f9877g != null) {
                m();
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        this.r.c(i2);
        m();
    }

    public void setRippleColor(int i2) {
        setRippleColor(ColorStateList.valueOf(i2));
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (this.f9879i != colorStateList) {
            this.f9879i = colorStateList;
            getImpl().q(this.f9879i);
        }
    }

    @Override // android.view.View
    public void setScaleX(float f2) {
        super.setScaleX(f2);
        getImpl().m();
    }

    @Override // android.view.View
    public void setScaleY(float f2) {
        super.setScaleY(f2);
        getImpl().m();
    }

    public void setShadowPaddingEnabled(boolean z) {
        e impl = getImpl();
        impl.f8824g = z;
        impl.w();
    }

    @Override // c.d.a.d.x.n
    public void setShapeAppearanceModel(c.d.a.d.x.j jVar) {
        getImpl().r(jVar);
    }

    public void setShowMotionSpec(g gVar) {
        getImpl().p = gVar;
    }

    public void setShowMotionSpecResource(int i2) {
        setShowMotionSpec(g.b(getContext(), i2));
    }

    public void setSize(int i2) {
        this.l = 0;
        if (i2 != this.k) {
            this.k = i2;
            requestLayout();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        setBackgroundTintList(colorStateList);
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        setBackgroundTintMode(mode);
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f9877g != colorStateList) {
            this.f9877g = colorStateList;
            m();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        if (this.f9878h != mode) {
            this.f9878h = mode;
            m();
        }
    }

    @Override // android.view.View
    public void setTranslationX(float f2) {
        super.setTranslationX(f2);
        getImpl().n();
    }

    @Override // android.view.View
    public void setTranslationY(float f2) {
        super.setTranslationY(f2);
        getImpl().n();
    }

    @Override // android.view.View
    public void setTranslationZ(float f2) {
        super.setTranslationZ(f2);
        getImpl().n();
    }

    public void setUseCompatPadding(boolean z) {
        if (this.o != z) {
            this.o = z;
            getImpl().j();
        }
    }

    @Override // c.d.a.d.r.p, android.widget.ImageView, android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
    }
}