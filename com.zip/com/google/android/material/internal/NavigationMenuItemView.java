package com.google.android.material.internal;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import b.b.h.i.i;
import b.b.h.i.n;
import b.b.i.d0;
import b.h.d.b.h;
import b.h.k.q;
import b.h.k.y.b;
import c.d.a.d.r.f;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\internal\NavigationMenuItemView.smali */
public class NavigationMenuItemView extends f implements n.a {
    public static final int[] I = {R.attr.state_checked};
    public boolean A;
    public final CheckedTextView B;
    public FrameLayout C;
    public i D;
    public ColorStateList E;
    public boolean F;
    public Drawable G;
    public final b.h.k.a H;
    public int y;
    public boolean z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\internal\NavigationMenuItemView$a.smali */
    public class a extends b.h.k.a {
        public a() {
        }

        @Override // b.h.k.a
        public void d(View view, b bVar) {
            this.f1718a.onInitializeAccessibilityNodeInfo(view, bVar.f1790a);
            bVar.f1790a.setCheckable(NavigationMenuItemView.this.A);
        }
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        a aVar = new a();
        this.H = aVar;
        setOrientation(0);
        LayoutInflater.from(context).inflate(2131558454, (ViewGroup) this, true);
        setIconSize(context.getResources().getDimensionPixelSize(2131165303));
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(2131362019);
        this.B = checkedTextView;
        checkedTextView.setDuplicateParentStateEnabled(true);
        q.t(checkedTextView, aVar);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.C == null) {
                this.C = (FrameLayout) ((ViewStub) findViewById(2131362018)).inflate();
            }
            this.C.removeAllViews();
            this.C.addView(view);
        }
    }

    @Override // b.b.h.i.n.a
    public void d(i iVar, int i2) {
        StateListDrawable stateListDrawable;
        this.D = iVar;
        int i3 = iVar.f834a;
        if (i3 > 0) {
            setId(i3);
        }
        setVisibility(iVar.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(2130968807, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(I, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            AtomicInteger atomicInteger = q.f1738a;
            setBackground(stateListDrawable);
        }
        setCheckable(iVar.isCheckable());
        setChecked(iVar.isChecked());
        setEnabled(iVar.isEnabled());
        setTitle(iVar.f838e);
        setIcon(iVar.getIcon());
        setActionView(iVar.getActionView());
        setContentDescription(iVar.q);
        b.b.a.c(this, iVar.r);
        i iVar2 = this.D;
        if (iVar2.f838e == null && iVar2.getIcon() == null && this.D.getActionView() != null) {
            this.B.setVisibility(8);
            FrameLayout frameLayout = this.C;
            if (frameLayout != null) {
                d0.a aVar = (d0.a) frameLayout.getLayoutParams();
                ((ViewGroup.MarginLayoutParams) aVar).width = -1;
                this.C.setLayoutParams(aVar);
                return;
            }
            return;
        }
        this.B.setVisibility(0);
        FrameLayout frameLayout2 = this.C;
        if (frameLayout2 != null) {
            d0.a aVar2 = (d0.a) frameLayout2.getLayoutParams();
            ((ViewGroup.MarginLayoutParams) aVar2).width = -2;
            this.C.setLayoutParams(aVar2);
        }
    }

    @Override // b.b.h.i.n.a
    public i getItemData() {
        return this.D;
    }

    @Override // android.view.ViewGroup, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 1);
        i iVar = this.D;
        if (iVar != null && iVar.isCheckable() && this.D.isChecked()) {
            ViewGroup.mergeDrawableStates(onCreateDrawableState, I);
        }
        return onCreateDrawableState;
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.A != z) {
            this.A = z;
            this.H.h(this.B, 2048);
        }
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        this.B.setChecked(z);
    }

    public void setHorizontalPadding(int i2) {
        setPadding(i2, 0, i2, 0);
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.F) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = b.h.a.X(drawable).mutate();
                drawable.setTintList(this.E);
            }
            int i2 = this.y;
            drawable.setBounds(0, 0, i2, i2);
        } else if (this.z) {
            if (this.G == null) {
                Resources resources = getResources();
                Resources.Theme theme = getContext().getTheme();
                ThreadLocal<TypedValue> threadLocal = h.f1586a;
                Drawable drawable2 = resources.getDrawable(2131231037, theme);
                this.G = drawable2;
                if (drawable2 != null) {
                    int i3 = this.y;
                    drawable2.setBounds(0, 0, i3, i3);
                }
            }
            drawable = this.G;
        }
        this.B.setCompoundDrawablesRelative(drawable, null, null, null);
    }

    public void setIconPadding(int i2) {
        this.B.setCompoundDrawablePadding(i2);
    }

    public void setIconSize(int i2) {
        this.y = i2;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.E = colorStateList;
        this.F = colorStateList != null;
        i iVar = this.D;
        if (iVar != null) {
            setIcon(iVar.getIcon());
        }
    }

    public void setMaxLines(int i2) {
        this.B.setMaxLines(i2);
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.z = z;
    }

    public void setTextAppearance(int i2) {
        b.h.a.O(this.B, i2);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.B.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.B.setText(charSequence);
    }
}