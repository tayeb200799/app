package com.google.android.material.chip;

import android.R;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import b.b.i.f;
import b.h.k.q;
import b.h.k.y.b;
import c.d.a.d.c.g;
import c.d.a.d.l.b;
import c.d.a.d.r.k;
import c.d.a.d.u.d;
import c.d.a.d.x.g;
import c.d.a.d.x.j;
import c.d.a.d.x.n;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\chip\Chip.smali */
public class Chip extends f implements b.a, n {
    public static final Rect w = new Rect();
    public static final int[] x = {R.attr.state_selected};
    public static final int[] y = {R.attr.state_checkable};

    /* renamed from: g, reason: collision with root package name */
    public c.d.a.d.l.b f9859g;

    /* renamed from: h, reason: collision with root package name */
    public InsetDrawable f9860h;

    /* renamed from: i, reason: collision with root package name */
    public RippleDrawable f9861i;

    /* renamed from: j, reason: collision with root package name */
    public View.OnClickListener f9862j;
    public CompoundButton.OnCheckedChangeListener k;
    public boolean l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public int q;
    public int r;
    public final b s;
    public final Rect t;
    public final RectF u;
    public final d v;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\chip\Chip$a.smali */
    public class a extends d {
        public a() {
        }

        @Override // c.d.a.d.u.d
        public void a(int i2) {
        }

        @Override // c.d.a.d.u.d
        public void b(Typeface typeface, boolean z) {
            Chip chip = Chip.this;
            c.d.a.d.l.b bVar = chip.f9859g;
            chip.setText(bVar.H0 ? bVar.I : chip.getText());
            Chip.this.requestLayout();
            Chip.this.invalidate();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\chip\Chip$b.smali */
    public class b extends b.j.b.a {
        public b(Chip chip) {
            super(chip);
        }

        @Override // b.j.b.a
        public int n(float f2, float f3) {
            Chip chip = Chip.this;
            Rect rect = Chip.w;
            return (chip.e() && Chip.this.getCloseIconTouchBounds().contains(f2, f3)) ? 1 : 0;
        }

        @Override // b.j.b.a
        public void o(List<Integer> list) {
            boolean z = false;
            list.add(0);
            Chip chip = Chip.this;
            Rect rect = Chip.w;
            if (chip.e()) {
                Chip chip2 = Chip.this;
                c.d.a.d.l.b bVar = chip2.f9859g;
                if (bVar != null && bVar.O) {
                    z = true;
                }
                if (!z || chip2.f9862j == null) {
                    return;
                }
                list.add(1);
            }
        }

        @Override // b.j.b.a
        public boolean r(int i2, int i3, Bundle bundle) {
            boolean z = false;
            if (i3 == 16) {
                if (i2 == 0) {
                    return Chip.this.performClick();
                }
                if (i2 == 1) {
                    Chip chip = Chip.this;
                    chip.playSoundEffect(0);
                    View.OnClickListener onClickListener = chip.f9862j;
                    if (onClickListener != null) {
                        onClickListener.onClick(chip);
                        z = true;
                    }
                    chip.s.w(1, 1);
                }
            }
            return z;
        }

        @Override // b.j.b.a
        public void s(b.h.k.y.b bVar) {
            bVar.f1790a.setCheckable(Chip.this.f());
            bVar.f1790a.setClickable(Chip.this.isClickable());
            if (Chip.this.f() || Chip.this.isClickable()) {
                bVar.f1790a.setClassName(Chip.this.f() ? "android.widget.CompoundButton" : "android.widget.Button");
            } else {
                bVar.f1790a.setClassName("android.view.View");
            }
            CharSequence text = Chip.this.getText();
            if (Build.VERSION.SDK_INT >= 23) {
                bVar.f1790a.setText(text);
            } else {
                bVar.f1790a.setContentDescription(text);
            }
        }

        @Override // b.j.b.a
        public void t(int i2, b.h.k.y.b bVar) {
            if (i2 != 1) {
                bVar.f1790a.setContentDescription("");
                bVar.f1790a.setBoundsInParent(Chip.w);
                return;
            }
            CharSequence closeIconContentDescription = Chip.this.getCloseIconContentDescription();
            if (closeIconContentDescription != null) {
                bVar.f1790a.setContentDescription(closeIconContentDescription);
            } else {
                CharSequence text = Chip.this.getText();
                Context context = Chip.this.getContext();
                Object[] objArr = new Object[1];
                objArr[0] = TextUtils.isEmpty(text) ? "" : text;
                bVar.f1790a.setContentDescription(context.getString(2131886442, objArr).trim());
            }
            bVar.f1790a.setBoundsInParent(Chip.this.getCloseIconTouchBoundsInt());
            bVar.a(b.a.f1793e);
            bVar.f1790a.setEnabled(Chip.this.isEnabled());
        }

        @Override // b.j.b.a
        public void u(int i2, boolean z) {
            if (i2 == 1) {
                Chip chip = Chip.this;
                chip.o = z;
                chip.refreshDrawableState();
            }
        }
    }

    public Chip(Context context, AttributeSet attributeSet) {
        super(c.d.a.d.c0.a.a.a(context, attributeSet, 2130968760, 2131952319), attributeSet, 2130968760);
        int resourceId;
        this.t = new Rect();
        this.u = new RectF();
        this.v = new a();
        Context context2 = getContext();
        if (attributeSet != null) {
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "background") != null) {
                Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
            }
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableLeft") != null) {
                throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
            }
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableStart") != null) {
                throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
            }
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableEnd") != null) {
                throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
            }
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableRight") != null) {
                throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
            }
            if (!attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res/android", "singleLine", true) || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "lines", 1) != 1 || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "minLines", 1) != 1 || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "maxLines", 1) != 1) {
                throw new UnsupportedOperationException("Chip does not support multi-line text");
            }
            if (attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "gravity", 8388627) != 8388627) {
                Log.w("Chip", "Chip text must be vertically center and start aligned");
            }
        }
        c.d.a.d.l.b bVar = new c.d.a.d.l.b(context2, attributeSet, 2130968760, 2131952319);
        Context context3 = bVar.i0;
        int[] iArr = c.d.a.d.b.f8504g;
        TypedArray d2 = k.d(context3, attributeSet, iArr, 2130968760, 2131952319, new int[0]);
        bVar.J0 = d2.hasValue(37);
        ColorStateList C = c.d.a.d.a.C(bVar.i0, d2, 24);
        if (bVar.B != C) {
            bVar.B = C;
            bVar.onStateChange(bVar.getState());
        }
        bVar.Q(c.d.a.d.a.C(bVar.i0, d2, 11));
        bVar.X(d2.getDimension(19, 0.0f));
        if (d2.hasValue(12)) {
            bVar.R(d2.getDimension(12, 0.0f));
        }
        bVar.Z(c.d.a.d.a.C(bVar.i0, d2, 22));
        bVar.a0(d2.getDimension(23, 0.0f));
        bVar.k0(c.d.a.d.a.C(bVar.i0, d2, 36));
        bVar.l0(d2.getText(5));
        c.d.a.d.u.b bVar2 = (!d2.hasValue(0) || (resourceId = d2.getResourceId(0, 0)) == 0) ? null : new c.d.a.d.u.b(bVar.i0, resourceId);
        bVar2.k = d2.getDimension(1, bVar2.k);
        bVar.o0.b(bVar2, bVar.i0);
        int i2 = d2.getInt(3, 0);
        if (i2 == 1) {
            bVar.G0 = TextUtils.TruncateAt.START;
        } else if (i2 == 2) {
            bVar.G0 = TextUtils.TruncateAt.MIDDLE;
        } else if (i2 == 3) {
            bVar.G0 = TextUtils.TruncateAt.END;
        }
        bVar.W(d2.getBoolean(18, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconVisible") == null) {
            bVar.W(d2.getBoolean(15, false));
        }
        bVar.T(c.d.a.d.a.F(bVar.i0, d2, 14));
        if (d2.hasValue(17)) {
            bVar.V(c.d.a.d.a.C(bVar.i0, d2, 17));
        }
        bVar.U(d2.getDimension(16, -1.0f));
        bVar.h0(d2.getBoolean(31, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconVisible") == null) {
            bVar.h0(d2.getBoolean(26, false));
        }
        bVar.b0(c.d.a.d.a.F(bVar.i0, d2, 25));
        bVar.g0(c.d.a.d.a.C(bVar.i0, d2, 30));
        bVar.d0(d2.getDimension(28, 0.0f));
        bVar.M(d2.getBoolean(6, false));
        bVar.P(d2.getBoolean(10, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconVisible") == null) {
            bVar.P(d2.getBoolean(8, false));
        }
        bVar.N(c.d.a.d.a.F(bVar.i0, d2, 7));
        if (d2.hasValue(9)) {
            bVar.O(c.d.a.d.a.C(bVar.i0, d2, 9));
        }
        bVar.Y = g.a(bVar.i0, d2, 39);
        bVar.Z = g.a(bVar.i0, d2, 33);
        bVar.Y(d2.getDimension(21, 0.0f));
        bVar.j0(d2.getDimension(35, 0.0f));
        bVar.i0(d2.getDimension(34, 0.0f));
        bVar.n0(d2.getDimension(41, 0.0f));
        bVar.m0(d2.getDimension(40, 0.0f));
        bVar.e0(d2.getDimension(29, 0.0f));
        bVar.c0(d2.getDimension(27, 0.0f));
        bVar.S(d2.getDimension(13, 0.0f));
        bVar.I0 = d2.getDimensionPixelSize(4, Integer.MAX_VALUE);
        d2.recycle();
        k.a(context2, attributeSet, 2130968760, 2131952319);
        k.b(context2, attributeSet, iArr, 2130968760, 2131952319, new int[0]);
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, iArr, 2130968760, 2131952319);
        this.p = obtainStyledAttributes.getBoolean(32, false);
        this.r = (int) Math.ceil(obtainStyledAttributes.getDimension(20, (float) Math.ceil(c.d.a.d.a.s(getContext(), 48))));
        obtainStyledAttributes.recycle();
        setChipDrawable(bVar);
        bVar.p(getElevation());
        k.a(context2, attributeSet, 2130968760, 2131952319);
        k.b(context2, attributeSet, iArr, 2130968760, 2131952319, new int[0]);
        TypedArray obtainStyledAttributes2 = context2.obtainStyledAttributes(attributeSet, iArr, 2130968760, 2131952319);
        if (Build.VERSION.SDK_INT < 23) {
            setTextColor(c.d.a.d.a.C(context2, obtainStyledAttributes2, 2));
        }
        boolean hasValue = obtainStyledAttributes2.hasValue(37);
        obtainStyledAttributes2.recycle();
        this.s = new b(this);
        h();
        if (!hasValue) {
            setOutlineProvider(new c.d.a.d.l.a(this));
        }
        setChecked(this.l);
        setText(bVar.I);
        setEllipsize(bVar.G0);
        k();
        if (!this.f9859g.H0) {
            setLines(1);
            setHorizontallyScrolling(true);
        }
        setGravity(8388627);
        j();
        if (this.p) {
            setMinHeight(this.r);
        }
        this.q = getLayoutDirection();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public RectF getCloseIconTouchBounds() {
        this.u.setEmpty();
        if (e() && this.f9862j != null) {
            c.d.a.d.l.b bVar = this.f9859g;
            bVar.D(bVar.getBounds(), this.u);
        }
        return this.u;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Rect getCloseIconTouchBoundsInt() {
        RectF closeIconTouchBounds = getCloseIconTouchBounds();
        this.t.set((int) closeIconTouchBounds.left, (int) closeIconTouchBounds.top, (int) closeIconTouchBounds.right, (int) closeIconTouchBounds.bottom);
        return this.t;
    }

    private c.d.a.d.u.b getTextAppearance() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.o0.f8878f;
        }
        return null;
    }

    private void setCloseIconHovered(boolean z) {
        if (this.n != z) {
            this.n = z;
            refreshDrawableState();
        }
    }

    private void setCloseIconPressed(boolean z) {
        if (this.m != z) {
            this.m = z;
            refreshDrawableState();
        }
    }

    @Override // c.d.a.d.l.b.a
    public void a() {
        d(this.r);
        requestLayout();
        invalidateOutline();
    }

    public boolean d(int i2) {
        this.r = i2;
        if (!this.p) {
            if (this.f9860h != null) {
                g();
            } else {
                int[] iArr = c.d.a.d.v.a.f8963a;
                i();
            }
            return false;
        }
        int max = Math.max(0, i2 - ((int) this.f9859g.D));
        int max2 = Math.max(0, i2 - this.f9859g.getIntrinsicWidth());
        if (max2 <= 0 && max <= 0) {
            if (this.f9860h != null) {
                g();
            } else {
                int[] iArr2 = c.d.a.d.v.a.f8963a;
                i();
            }
            return false;
        }
        int i3 = max2 > 0 ? max2 / 2 : 0;
        int i4 = max > 0 ? max / 2 : 0;
        if (this.f9860h != null) {
            Rect rect = new Rect();
            this.f9860h.getPadding(rect);
            if (rect.top == i4 && rect.bottom == i4 && rect.left == i3 && rect.right == i3) {
                int[] iArr3 = c.d.a.d.v.a.f8963a;
                i();
                return true;
            }
        }
        if (getMinHeight() != i2) {
            setMinHeight(i2);
        }
        if (getMinWidth() != i2) {
            setMinWidth(i2);
        }
        this.f9860h = new InsetDrawable((Drawable) this.f9859g, i3, i4, i3, i4);
        int[] iArr4 = c.d.a.d.v.a.f8963a;
        i();
        return true;
    }

    @Override // android.view.View
    public boolean dispatchHoverEvent(MotionEvent motionEvent) {
        Field declaredField;
        boolean z;
        if (motionEvent.getAction() == 10) {
            try {
                declaredField = b.j.b.a.class.getDeclaredField("m");
                declaredField.setAccessible(true);
            } catch (IllegalAccessException e2) {
                Log.e("Chip", "Unable to send Accessibility Exit event", e2);
            } catch (NoSuchFieldException e3) {
                Log.e("Chip", "Unable to send Accessibility Exit event", e3);
            } catch (NoSuchMethodException e4) {
                Log.e("Chip", "Unable to send Accessibility Exit event", e4);
            } catch (InvocationTargetException e5) {
                Log.e("Chip", "Unable to send Accessibility Exit event", e5);
            }
            if (((Integer) declaredField.get(this.s)).intValue() != Integer.MIN_VALUE) {
                Method declaredMethod = b.j.b.a.class.getDeclaredMethod("x", Integer.TYPE);
                declaredMethod.setAccessible(true);
                declaredMethod.invoke(this.s, Integer.MIN_VALUE);
                z = true;
                return !z ? true : true;
            }
        }
        z = false;
        return !z ? true : true;
    }

    @Override // android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        b bVar = this.s;
        Objects.requireNonNull(bVar);
        boolean z = false;
        int i2 = 0;
        z = false;
        z = false;
        z = false;
        z = false;
        z = false;
        if (keyEvent.getAction() != 1) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 61) {
                int i3 = 66;
                if (keyCode != 66) {
                    switch (keyCode) {
                        case 19:
                        case 20:
                        case 21:
                        case 22:
                            if (keyEvent.hasNoModifiers()) {
                                if (keyCode == 19) {
                                    i3 = 33;
                                } else if (keyCode == 21) {
                                    i3 = 17;
                                } else if (keyCode != 22) {
                                    i3 = 130;
                                }
                                int repeatCount = keyEvent.getRepeatCount() + 1;
                                boolean z2 = false;
                                while (i2 < repeatCount && bVar.p(i3, null)) {
                                    i2++;
                                    z2 = true;
                                }
                                z = z2;
                                break;
                            }
                            break;
                    }
                }
                if (keyEvent.hasNoModifiers() && keyEvent.getRepeatCount() == 0) {
                    int i4 = bVar.l;
                    if (i4 != Integer.MIN_VALUE) {
                        bVar.r(i4, 16, null);
                    }
                    z = true;
                }
            } else if (keyEvent.hasNoModifiers()) {
                z = bVar.p(2, null);
            } else if (keyEvent.hasModifiers(1)) {
                z = bVar.p(1, null);
            }
        }
        if (!z || this.s.l == Integer.MIN_VALUE) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [boolean, int] */
    @Override // b.b.i.f, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        c.d.a.d.l.b bVar = this.f9859g;
        boolean z = false;
        int i2 = 0;
        z = false;
        if (bVar != null && c.d.a.d.l.b.J(bVar.P)) {
            c.d.a.d.l.b bVar2 = this.f9859g;
            ?? isEnabled = isEnabled();
            int i3 = isEnabled;
            if (this.o) {
                i3 = isEnabled + 1;
            }
            int i4 = i3;
            if (this.n) {
                i4 = i3 + 1;
            }
            int i5 = i4;
            if (this.m) {
                i5 = i4 + 1;
            }
            int i6 = i5;
            if (isChecked()) {
                i6 = i5 + 1;
            }
            int[] iArr = new int[i6];
            if (isEnabled()) {
                iArr[0] = 16842910;
                i2 = 1;
            }
            if (this.o) {
                iArr[i2] = 16842908;
                i2++;
            }
            if (this.n) {
                iArr[i2] = 16843623;
                i2++;
            }
            if (this.m) {
                iArr[i2] = 16842919;
                i2++;
            }
            if (isChecked()) {
                iArr[i2] = 16842913;
            }
            z = bVar2.f0(iArr);
        }
        if (z) {
            invalidate();
        }
    }

    public final boolean e() {
        c.d.a.d.l.b bVar = this.f9859g;
        return (bVar == null || bVar.G() == null) ? false : true;
    }

    public boolean f() {
        c.d.a.d.l.b bVar = this.f9859g;
        return bVar != null && bVar.U;
    }

    public final void g() {
        if (this.f9860h != null) {
            this.f9860h = null;
            setMinWidth(0);
            setMinHeight((int) getChipMinHeight());
            int[] iArr = c.d.a.d.v.a.f8963a;
            i();
        }
    }

    public Drawable getBackgroundDrawable() {
        InsetDrawable insetDrawable = this.f9860h;
        return insetDrawable == null ? this.f9859g : insetDrawable;
    }

    public Drawable getCheckedIcon() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.W;
        }
        return null;
    }

    public ColorStateList getCheckedIconTint() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.X;
        }
        return null;
    }

    public ColorStateList getChipBackgroundColor() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.C;
        }
        return null;
    }

    public float getChipCornerRadius() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return Math.max(0.0f, bVar.F());
        }
        return 0.0f;
    }

    public Drawable getChipDrawable() {
        return this.f9859g;
    }

    public float getChipEndPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.h0;
        }
        return 0.0f;
    }

    public Drawable getChipIcon() {
        Drawable drawable;
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || (drawable = bVar.K) == null) {
            return null;
        }
        return b.h.a.W(drawable);
    }

    public float getChipIconSize() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.M;
        }
        return 0.0f;
    }

    public ColorStateList getChipIconTint() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.L;
        }
        return null;
    }

    public float getChipMinHeight() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.D;
        }
        return 0.0f;
    }

    public float getChipStartPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.a0;
        }
        return 0.0f;
    }

    public ColorStateList getChipStrokeColor() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.F;
        }
        return null;
    }

    public float getChipStrokeWidth() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.G;
        }
        return 0.0f;
    }

    @Deprecated
    public CharSequence getChipText() {
        return getText();
    }

    public Drawable getCloseIcon() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.G();
        }
        return null;
    }

    public CharSequence getCloseIconContentDescription() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.T;
        }
        return null;
    }

    public float getCloseIconEndPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.g0;
        }
        return 0.0f;
    }

    public float getCloseIconSize() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.S;
        }
        return 0.0f;
    }

    public float getCloseIconStartPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.f0;
        }
        return 0.0f;
    }

    public ColorStateList getCloseIconTint() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.R;
        }
        return null;
    }

    @Override // android.widget.TextView
    public TextUtils.TruncateAt getEllipsize() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.G0;
        }
        return null;
    }

    @Override // android.widget.TextView, android.view.View
    public void getFocusedRect(Rect rect) {
        b bVar = this.s;
        if (bVar.l == 1 || bVar.k == 1) {
            rect.set(getCloseIconTouchBoundsInt());
        } else {
            super.getFocusedRect(rect);
        }
    }

    public g getHideMotionSpec() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.Z;
        }
        return null;
    }

    public float getIconEndPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.c0;
        }
        return 0.0f;
    }

    public float getIconStartPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.b0;
        }
        return 0.0f;
    }

    public ColorStateList getRippleColor() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.H;
        }
        return null;
    }

    public j getShapeAppearanceModel() {
        return this.f9859g.f8986d.f8994a;
    }

    public g getShowMotionSpec() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.Y;
        }
        return null;
    }

    public float getTextEndPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.e0;
        }
        return 0.0f;
    }

    public float getTextStartPadding() {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            return bVar.d0;
        }
        return 0.0f;
    }

    public final void h() {
        if (e()) {
            c.d.a.d.l.b bVar = this.f9859g;
            if ((bVar != null && bVar.O) && this.f9862j != null) {
                q.t(this, this.s);
                return;
            }
        }
        q.t(this, null);
    }

    public final void i() {
        this.f9861i = new RippleDrawable(c.d.a.d.v.a.b(this.f9859g.H), getBackgroundDrawable(), null);
        this.f9859g.o0(false);
        RippleDrawable rippleDrawable = this.f9861i;
        AtomicInteger atomicInteger = q.f1738a;
        setBackground(rippleDrawable);
        j();
    }

    public final void j() {
        c.d.a.d.l.b bVar;
        if (TextUtils.isEmpty(getText()) || (bVar = this.f9859g) == null) {
            return;
        }
        int E = (int) (bVar.E() + bVar.h0 + bVar.e0);
        c.d.a.d.l.b bVar2 = this.f9859g;
        int B = (int) (bVar2.B() + bVar2.a0 + bVar2.d0);
        if (this.f9860h != null) {
            Rect rect = new Rect();
            this.f9860h.getPadding(rect);
            B += rect.left;
            E += rect.right;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        AtomicInteger atomicInteger = q.f1738a;
        setPaddingRelative(B, paddingTop, E, paddingBottom);
    }

    public final void k() {
        TextPaint paint = getPaint();
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            paint.drawableState = bVar.getState();
        }
        c.d.a.d.u.b textAppearance = getTextAppearance();
        if (textAppearance != null) {
            textAppearance.c(getContext(), paint, this.v);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        c.d.a.d.a.f0(this, this.f9859g);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 2);
        if (isChecked()) {
            CheckBox.mergeDrawableStates(onCreateDrawableState, x);
        }
        if (f()) {
            CheckBox.mergeDrawableStates(onCreateDrawableState, y);
        }
        return onCreateDrawableState;
    }

    @Override // android.widget.TextView, android.view.View
    public void onFocusChanged(boolean z, int i2, Rect rect) {
        super.onFocusChanged(z, i2, rect);
        b bVar = this.s;
        int i3 = bVar.l;
        if (i3 != Integer.MIN_VALUE) {
            bVar.k(i3);
        }
        if (z) {
            bVar.p(i2, rect);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 7) {
            setCloseIconHovered(getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()));
        } else if (actionMasked == 10) {
            setCloseIconHovered(false);
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        int i2;
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        if (f() || isClickable()) {
            accessibilityNodeInfo.setClassName(f() ? "android.widget.CompoundButton" : "android.widget.Button");
        } else {
            accessibilityNodeInfo.setClassName("android.view.View");
        }
        accessibilityNodeInfo.setCheckable(f());
        accessibilityNodeInfo.setClickable(isClickable());
        if (getParent() instanceof ChipGroup) {
            ChipGroup chipGroup = (ChipGroup) getParent();
            if (chipGroup.f8854f) {
                int i3 = 0;
                int i4 = 0;
                while (true) {
                    if (i3 >= chipGroup.getChildCount()) {
                        i4 = -1;
                        break;
                    }
                    if (chipGroup.getChildAt(i3) instanceof Chip) {
                        if (((Chip) chipGroup.getChildAt(i3)) == this) {
                            break;
                        } else {
                            i4++;
                        }
                    }
                    i3++;
                }
                i2 = i4;
            } else {
                i2 = -1;
            }
            Object tag = getTag(2131362449);
            accessibilityNodeInfo.setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo) b.c.a(!(tag instanceof Integer) ? -1 : ((Integer) tag).intValue(), 1, i2, 1, false, isChecked()).f1804a);
        }
    }

    @Override // android.widget.Button, android.widget.TextView, android.view.View
    @TargetApi(24)
    public PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i2) {
        if (getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()) && isEnabled()) {
            return PointerIcon.getSystemIcon(getContext(), 1002);
        }
        return null;
    }

    @Override // android.widget.TextView, android.view.View
    @TargetApi(17)
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        if (this.q != i2) {
            this.q = i2;
            j();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x001e, code lost:
    
        if (r0 != 3) goto L25;
     */
    @Override // android.widget.TextView, android.view.View
    @android.annotation.SuppressLint({"ClickableViewAccessibility"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            int r0 = r6.getActionMasked()
            android.graphics.RectF r1 = r5.getCloseIconTouchBounds()
            float r2 = r6.getX()
            float r3 = r6.getY()
            boolean r1 = r1.contains(r2, r3)
            r2 = 0
            r3 = 1
            if (r0 == 0) goto L45
            if (r0 == r3) goto L2b
            r4 = 2
            if (r0 == r4) goto L21
            r1 = 3
            if (r0 == r1) goto L40
            goto L4c
        L21:
            boolean r0 = r5.m
            if (r0 == 0) goto L4c
            if (r1 != 0) goto L4a
            r5.setCloseIconPressed(r2)
            goto L4a
        L2b:
            boolean r0 = r5.m
            if (r0 == 0) goto L40
            r5.playSoundEffect(r2)
            android.view.View$OnClickListener r0 = r5.f9862j
            if (r0 == 0) goto L39
            r0.onClick(r5)
        L39:
            com.google.android.material.chip.Chip$b r0 = r5.s
            r0.w(r3, r3)
            r0 = 1
            goto L41
        L40:
            r0 = 0
        L41:
            r5.setCloseIconPressed(r2)
            goto L4d
        L45:
            if (r1 == 0) goto L4c
            r5.setCloseIconPressed(r3)
        L4a:
            r0 = 1
            goto L4d
        L4c:
            r0 = 0
        L4d:
            if (r0 != 0) goto L55
            boolean r6 = super.onTouchEvent(r6)
            if (r6 == 0) goto L56
        L55:
            r2 = 1
        L56:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f9861i) {
            super.setBackground(drawable);
        } else {
            Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
        }
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        Log.w("Chip", "Do not set the background color; Chip manages its own background drawable.");
    }

    @Override // b.b.i.f, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f9861i) {
            super.setBackgroundDrawable(drawable);
        } else {
            Log.w("Chip", "Do not set the background drawable; Chip manages its own background drawable.");
        }
    }

    @Override // b.b.i.f, android.view.View
    public void setBackgroundResource(int i2) {
        Log.w("Chip", "Do not set the background resource; Chip manages its own background drawable.");
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        Log.w("Chip", "Do not set the background tint list; Chip manages its own background drawable.");
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        Log.w("Chip", "Do not set the background tint mode; Chip manages its own background drawable.");
    }

    public void setCheckable(boolean z) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.M(z);
        }
    }

    public void setCheckableResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.M(bVar.i0.getResources().getBoolean(i2));
        }
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z) {
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null) {
            this.l = z;
            return;
        }
        if (bVar.U) {
            boolean isChecked = isChecked();
            super.setChecked(z);
            if (isChecked == z || (onCheckedChangeListener = this.k) == null) {
                return;
            }
            onCheckedChangeListener.onCheckedChanged(this, z);
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.N(drawable);
        }
    }

    @Deprecated
    public void setCheckedIconEnabled(boolean z) {
        setCheckedIconVisible(z);
    }

    @Deprecated
    public void setCheckedIconEnabledResource(int i2) {
        setCheckedIconVisible(i2);
    }

    public void setCheckedIconResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.N(b.b.d.a.a.b(bVar.i0, i2));
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.O(colorStateList);
        }
    }

    public void setCheckedIconTintResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.O(b.b.d.a.a.a(bVar.i0, i2));
        }
    }

    public void setCheckedIconVisible(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.P(bVar.i0.getResources().getBoolean(i2));
        }
    }

    public void setCheckedIconVisible(boolean z) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.P(z);
        }
    }

    public void setChipBackgroundColor(ColorStateList colorStateList) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.C == colorStateList) {
            return;
        }
        bVar.C = colorStateList;
        bVar.onStateChange(bVar.getState());
    }

    public void setChipBackgroundColorResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Q(b.b.d.a.a.a(bVar.i0, i2));
        }
    }

    @Deprecated
    public void setChipCornerRadius(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.R(f2);
        }
    }

    @Deprecated
    public void setChipCornerRadiusResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.R(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setChipDrawable(c.d.a.d.l.b bVar) {
        c.d.a.d.l.b bVar2 = this.f9859g;
        if (bVar2 != bVar) {
            if (bVar2 != null) {
                bVar2.F0 = new WeakReference<>(null);
            }
            this.f9859g = bVar;
            bVar.H0 = false;
            Objects.requireNonNull(bVar);
            bVar.F0 = new WeakReference<>(this);
            d(this.r);
        }
    }

    public void setChipEndPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.h0 == f2) {
            return;
        }
        bVar.h0 = f2;
        bVar.invalidateSelf();
        bVar.K();
    }

    public void setChipEndPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.S(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setChipIcon(Drawable drawable) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.T(drawable);
        }
    }

    @Deprecated
    public void setChipIconEnabled(boolean z) {
        setChipIconVisible(z);
    }

    @Deprecated
    public void setChipIconEnabledResource(int i2) {
        setChipIconVisible(i2);
    }

    public void setChipIconResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.T(b.b.d.a.a.b(bVar.i0, i2));
        }
    }

    public void setChipIconSize(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.U(f2);
        }
    }

    public void setChipIconSizeResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.U(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setChipIconTint(ColorStateList colorStateList) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.V(colorStateList);
        }
    }

    public void setChipIconTintResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.V(b.b.d.a.a.a(bVar.i0, i2));
        }
    }

    public void setChipIconVisible(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.W(bVar.i0.getResources().getBoolean(i2));
        }
    }

    public void setChipIconVisible(boolean z) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.W(z);
        }
    }

    public void setChipMinHeight(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.D == f2) {
            return;
        }
        bVar.D = f2;
        bVar.invalidateSelf();
        bVar.K();
    }

    public void setChipMinHeightResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.X(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setChipStartPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.a0 == f2) {
            return;
        }
        bVar.a0 = f2;
        bVar.invalidateSelf();
        bVar.K();
    }

    public void setChipStartPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Y(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setChipStrokeColor(ColorStateList colorStateList) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Z(colorStateList);
        }
    }

    public void setChipStrokeColorResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Z(b.b.d.a.a.a(bVar.i0, i2));
        }
    }

    public void setChipStrokeWidth(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.a0(f2);
        }
    }

    public void setChipStrokeWidthResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.a0(bVar.i0.getResources().getDimension(i2));
        }
    }

    @Deprecated
    public void setChipText(CharSequence charSequence) {
        setText(charSequence);
    }

    @Deprecated
    public void setChipTextResource(int i2) {
        setText(getResources().getString(i2));
    }

    public void setCloseIcon(Drawable drawable) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.b0(drawable);
        }
        h();
    }

    public void setCloseIconContentDescription(CharSequence charSequence) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.T == charSequence) {
            return;
        }
        b.h.i.a c2 = b.h.i.a.c();
        bVar.T = c2.d(charSequence, c2.f1694c, true);
        bVar.invalidateSelf();
    }

    @Deprecated
    public void setCloseIconEnabled(boolean z) {
        setCloseIconVisible(z);
    }

    @Deprecated
    public void setCloseIconEnabledResource(int i2) {
        setCloseIconVisible(i2);
    }

    public void setCloseIconEndPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.c0(f2);
        }
    }

    public void setCloseIconEndPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.c0(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setCloseIconResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.b0(b.b.d.a.a.b(bVar.i0, i2));
        }
        h();
    }

    public void setCloseIconSize(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.d0(f2);
        }
    }

    public void setCloseIconSizeResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.d0(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setCloseIconStartPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.e0(f2);
        }
    }

    public void setCloseIconStartPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.e0(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setCloseIconTint(ColorStateList colorStateList) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.g0(colorStateList);
        }
    }

    public void setCloseIconTintResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.g0(b.b.d.a.a.a(bVar.i0, i2));
        }
    }

    public void setCloseIconVisible(int i2) {
        setCloseIconVisible(getResources().getBoolean(i2));
    }

    public void setCloseIconVisible(boolean z) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.h0(z);
        }
        h();
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (i4 != 0) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(i2, i3, i4, i5);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (i4 != 0) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesWithIntrinsicBounds(i2, i3, i4, i5);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        }
        if (drawable3 != null) {
            throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            g.b bVar2 = bVar.f8986d;
            if (bVar2.o != f2) {
                bVar2.o = f2;
                bVar.y();
            }
        }
    }

    @Override // android.widget.TextView
    public void setEllipsize(TextUtils.TruncateAt truncateAt) {
        if (this.f9859g == null) {
            return;
        }
        if (truncateAt == TextUtils.TruncateAt.MARQUEE) {
            throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
        }
        super.setEllipsize(truncateAt);
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.G0 = truncateAt;
        }
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        this.p = z;
        d(this.r);
    }

    @Override // android.widget.TextView
    public void setGravity(int i2) {
        if (i2 != 8388627) {
            Log.w("Chip", "Chip text must be vertically center and start aligned");
        } else {
            super.setGravity(i2);
        }
    }

    public void setHideMotionSpec(c.d.a.d.c.g gVar) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Z = gVar;
        }
    }

    public void setHideMotionSpecResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Z = c.d.a.d.c.g.b(bVar.i0, i2);
        }
    }

    public void setIconEndPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.i0(f2);
        }
    }

    public void setIconEndPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.i0(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setIconStartPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.j0(f2);
        }
    }

    public void setIconStartPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.j0(bVar.i0.getResources().getDimension(i2));
        }
    }

    @Override // android.view.View
    public void setLayoutDirection(int i2) {
        if (this.f9859g == null) {
            return;
        }
        super.setLayoutDirection(i2);
    }

    @Override // android.widget.TextView
    public void setLines(int i2) {
        if (i2 > 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setLines(i2);
    }

    @Override // android.widget.TextView
    public void setMaxLines(int i2) {
        if (i2 > 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setMaxLines(i2);
    }

    @Override // android.widget.TextView
    public void setMaxWidth(int i2) {
        super.setMaxWidth(i2);
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.I0 = i2;
        }
    }

    @Override // android.widget.TextView
    public void setMinLines(int i2) {
        if (i2 > 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setMinLines(i2);
    }

    public void setOnCheckedChangeListenerInternal(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.k = onCheckedChangeListener;
    }

    public void setOnCloseIconClickListener(View.OnClickListener onClickListener) {
        this.f9862j = onClickListener;
        h();
    }

    public void setRippleColor(ColorStateList colorStateList) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.k0(colorStateList);
        }
        if (this.f9859g.D0) {
            return;
        }
        i();
    }

    public void setRippleColorResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.k0(b.b.d.a.a.a(bVar.i0, i2));
            if (this.f9859g.D0) {
                return;
            }
            i();
        }
    }

    @Override // c.d.a.d.x.n
    public void setShapeAppearanceModel(j jVar) {
        c.d.a.d.l.b bVar = this.f9859g;
        bVar.f8986d.f8994a = jVar;
        bVar.invalidateSelf();
    }

    public void setShowMotionSpec(c.d.a.d.c.g gVar) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Y = gVar;
        }
    }

    public void setShowMotionSpecResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.Y = c.d.a.d.c.g.b(bVar.i0, i2);
        }
    }

    @Override // android.widget.TextView
    public void setSingleLine(boolean z) {
        if (!z) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setSingleLine(z);
    }

    @Override // android.widget.TextView
    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null) {
            return;
        }
        if (charSequence == null) {
            charSequence = "";
        }
        super.setText(bVar.H0 ? null : charSequence, bufferType);
        c.d.a.d.l.b bVar2 = this.f9859g;
        if (bVar2 != null) {
            bVar2.l0(charSequence);
        }
    }

    @Override // android.widget.TextView
    public void setTextAppearance(int i2) {
        super.setTextAppearance(i2);
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.o0.b(new c.d.a.d.u.b(bVar.i0, i2), bVar.i0);
        }
        k();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.o0.b(new c.d.a.d.u.b(bVar.i0, i2), bVar.i0);
        }
        k();
    }

    public void setTextAppearance(c.d.a.d.u.b bVar) {
        c.d.a.d.l.b bVar2 = this.f9859g;
        if (bVar2 != null) {
            bVar2.o0.b(bVar, bVar2.i0);
        }
        k();
    }

    public void setTextAppearanceResource(int i2) {
        setTextAppearance(getContext(), i2);
    }

    public void setTextEndPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.e0 == f2) {
            return;
        }
        bVar.e0 = f2;
        bVar.invalidateSelf();
        bVar.K();
    }

    public void setTextEndPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.m0(bVar.i0.getResources().getDimension(i2));
        }
    }

    public void setTextStartPadding(float f2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar == null || bVar.d0 == f2) {
            return;
        }
        bVar.d0 = f2;
        bVar.invalidateSelf();
        bVar.K();
    }

    public void setTextStartPaddingResource(int i2) {
        c.d.a.d.l.b bVar = this.f9859g;
        if (bVar != null) {
            bVar.n0(bVar.i0.getResources().getDimension(i2));
        }
    }
}