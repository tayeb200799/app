package com.google.android.material.button;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import androidx.appcompat.widget.AppCompatButton;
import b.h.k.q;
import c.d.a.d.r.k;
import c.d.a.d.x.g;
import c.d.a.d.x.j;
import c.d.a.d.x.n;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\button\MaterialButton.smali */
public class MaterialButton extends AppCompatButton implements Checkable, n {
    public static final int[] s = {R.attr.state_checkable};
    public static final int[] t = {R.attr.state_checked};

    /* renamed from: f, reason: collision with root package name */
    public final c.d.a.d.i.a f9837f;

    /* renamed from: g, reason: collision with root package name */
    public final LinkedHashSet<a> f9838g;

    /* renamed from: h, reason: collision with root package name */
    public b f9839h;

    /* renamed from: i, reason: collision with root package name */
    public PorterDuff.Mode f9840i;

    /* renamed from: j, reason: collision with root package name */
    public ColorStateList f9841j;
    public Drawable k;
    public int l;
    public int m;
    public int n;
    public int o;
    public boolean p;
    public boolean q;
    public int r;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\button\MaterialButton$a.smali */
    public interface a {
        void a(MaterialButton materialButton, boolean z);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\button\MaterialButton$b.smali */
    public interface b {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\button\MaterialButton$c.smali */
    public static class c extends b.j.a.a {
        public static final Parcelable.Creator<c> CREATOR = new a();

        /* renamed from: f, reason: collision with root package name */
        public boolean f9842f;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\button\MaterialButton$c$a.smali */
        public static class a implements Parcelable.ClassLoaderCreator<c> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new c(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public c createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new c(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new c[i2];
            }
        }

        public c(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                c.class.getClassLoader();
            }
            this.f9842f = parcel.readInt() == 1;
        }

        public c(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // b.j.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.f1843d, i2);
            parcel.writeInt(this.f9842f ? 1 : 0);
        }
    }

    public MaterialButton(Context context, AttributeSet attributeSet) {
        super(c.d.a.d.c0.a.a.a(context, attributeSet, 2130969190, 2131952305), attributeSet, 2130969190);
        this.f9838g = new LinkedHashSet<>();
        this.p = false;
        this.q = false;
        Context context2 = getContext();
        TypedArray d2 = k.d(context2, attributeSet, c.d.a.d.b.r, 2130969190, 2131952305, new int[0]);
        this.o = d2.getDimensionPixelSize(12, 0);
        this.f9840i = c.d.a.d.a.R(d2.getInt(15, -1), PorterDuff.Mode.SRC_IN);
        this.f9841j = c.d.a.d.a.C(getContext(), d2, 14);
        this.k = c.d.a.d.a.F(getContext(), d2, 10);
        this.r = d2.getInteger(11, 1);
        this.l = d2.getDimensionPixelSize(13, 0);
        c.d.a.d.i.a aVar = new c.d.a.d.i.a(this, j.b(context2, attributeSet, 2130969190, 2131952305, new c.d.a.d.x.a(0)).a());
        this.f9837f = aVar;
        aVar.f8693c = d2.getDimensionPixelOffset(1, 0);
        aVar.f8694d = d2.getDimensionPixelOffset(2, 0);
        aVar.f8695e = d2.getDimensionPixelOffset(3, 0);
        aVar.f8696f = d2.getDimensionPixelOffset(4, 0);
        if (d2.hasValue(8)) {
            int dimensionPixelSize = d2.getDimensionPixelSize(8, -1);
            aVar.f8697g = dimensionPixelSize;
            aVar.e(aVar.f8692b.e(dimensionPixelSize));
            aVar.p = true;
        }
        aVar.f8698h = d2.getDimensionPixelSize(20, 0);
        aVar.f8699i = c.d.a.d.a.R(d2.getInt(7, -1), PorterDuff.Mode.SRC_IN);
        aVar.f8700j = c.d.a.d.a.C(aVar.f8691a.getContext(), d2, 6);
        aVar.k = c.d.a.d.a.C(aVar.f8691a.getContext(), d2, 19);
        aVar.l = c.d.a.d.a.C(aVar.f8691a.getContext(), d2, 16);
        aVar.q = d2.getBoolean(5, false);
        aVar.s = d2.getDimensionPixelSize(9, 0);
        MaterialButton materialButton = aVar.f8691a;
        AtomicInteger atomicInteger = q.f1738a;
        int paddingStart = materialButton.getPaddingStart();
        int paddingTop = aVar.f8691a.getPaddingTop();
        int paddingEnd = aVar.f8691a.getPaddingEnd();
        int paddingBottom = aVar.f8691a.getPaddingBottom();
        if (d2.hasValue(0)) {
            aVar.o = true;
            aVar.f8691a.setSupportBackgroundTintList(aVar.f8700j);
            aVar.f8691a.setSupportBackgroundTintMode(aVar.f8699i);
        } else {
            aVar.g();
        }
        aVar.f8691a.setPaddingRelative(paddingStart + aVar.f8693c, paddingTop + aVar.f8695e, paddingEnd + aVar.f8694d, paddingBottom + aVar.f8696f);
        d2.recycle();
        setCompoundDrawablePadding(this.o);
        g(this.k != null);
    }

    private String getA11yClassName() {
        return (a() ? CompoundButton.class : Button.class).getName();
    }

    private int getTextHeight() {
        TextPaint paint = getPaint();
        String charSequence = getText().toString();
        if (getTransformationMethod() != null) {
            charSequence = getTransformationMethod().getTransformation(charSequence, this).toString();
        }
        Rect rect = new Rect();
        paint.getTextBounds(charSequence, 0, charSequence.length(), rect);
        return Math.min(rect.height(), getLayout().getHeight());
    }

    private int getTextWidth() {
        TextPaint paint = getPaint();
        String charSequence = getText().toString();
        if (getTransformationMethod() != null) {
            charSequence = getTransformationMethod().getTransformation(charSequence, this).toString();
        }
        return Math.min((int) paint.measureText(charSequence), getLayout().getEllipsizedWidth());
    }

    public boolean a() {
        c.d.a.d.i.a aVar = this.f9837f;
        return aVar != null && aVar.q;
    }

    public final boolean b() {
        int i2 = this.r;
        return i2 == 3 || i2 == 4;
    }

    public final boolean c() {
        int i2 = this.r;
        return i2 == 1 || i2 == 2;
    }

    public final boolean d() {
        int i2 = this.r;
        return i2 == 16 || i2 == 32;
    }

    public final boolean e() {
        c.d.a.d.i.a aVar = this.f9837f;
        return (aVar == null || aVar.o) ? false : true;
    }

    public final void f() {
        if (c()) {
            setCompoundDrawablesRelative(this.k, null, null, null);
        } else if (b()) {
            setCompoundDrawablesRelative(null, null, this.k, null);
        } else if (d()) {
            setCompoundDrawablesRelative(null, this.k, null, null);
        }
    }

    public final void g(boolean z) {
        Drawable drawable = this.k;
        if (drawable != null) {
            Drawable mutate = b.h.a.X(drawable).mutate();
            this.k = mutate;
            mutate.setTintList(this.f9841j);
            PorterDuff.Mode mode = this.f9840i;
            if (mode != null) {
                this.k.setTintMode(mode);
            }
            int i2 = this.l;
            if (i2 == 0) {
                i2 = this.k.getIntrinsicWidth();
            }
            int i3 = this.l;
            if (i3 == 0) {
                i3 = this.k.getIntrinsicHeight();
            }
            Drawable drawable2 = this.k;
            int i4 = this.m;
            int i5 = this.n;
            drawable2.setBounds(i4, i5, i2 + i4, i3 + i5);
        }
        if (z) {
            f();
            return;
        }
        Drawable[] compoundDrawablesRelative = getCompoundDrawablesRelative();
        boolean z2 = false;
        Drawable drawable3 = compoundDrawablesRelative[0];
        Drawable drawable4 = compoundDrawablesRelative[1];
        Drawable drawable5 = compoundDrawablesRelative[2];
        if ((c() && drawable3 != this.k) || ((b() && drawable5 != this.k) || (d() && drawable4 != this.k))) {
            z2 = true;
        }
        if (z2) {
            f();
        }
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (e()) {
            return this.f9837f.f8697g;
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.k;
    }

    public int getIconGravity() {
        return this.r;
    }

    public int getIconPadding() {
        return this.o;
    }

    public int getIconSize() {
        return this.l;
    }

    public ColorStateList getIconTint() {
        return this.f9841j;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f9840i;
    }

    public int getInsetBottom() {
        return this.f9837f.f8696f;
    }

    public int getInsetTop() {
        return this.f9837f.f8695e;
    }

    public ColorStateList getRippleColor() {
        if (e()) {
            return this.f9837f.l;
        }
        return null;
    }

    public j getShapeAppearanceModel() {
        if (e()) {
            return this.f9837f.f8692b;
        }
        throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
    }

    public ColorStateList getStrokeColor() {
        if (e()) {
            return this.f9837f.k;
        }
        return null;
    }

    public int getStrokeWidth() {
        if (e()) {
            return this.f9837f.f8698h;
        }
        return 0;
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public ColorStateList getSupportBackgroundTintList() {
        return e() ? this.f9837f.f8700j : super.getSupportBackgroundTintList();
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return e() ? this.f9837f.f8699i : super.getSupportBackgroundTintMode();
    }

    public final void h(int i2, int i3) {
        if (this.k == null || getLayout() == null) {
            return;
        }
        if (!c() && !b()) {
            if (d()) {
                this.m = 0;
                if (this.r == 16) {
                    this.n = 0;
                    g(false);
                    return;
                }
                int i4 = this.l;
                if (i4 == 0) {
                    i4 = this.k.getIntrinsicHeight();
                }
                int textHeight = (((((i3 - getTextHeight()) - getPaddingTop()) - i4) - this.o) - getPaddingBottom()) / 2;
                if (this.n != textHeight) {
                    this.n = textHeight;
                    g(false);
                    return;
                }
                return;
            }
            return;
        }
        this.n = 0;
        int i5 = this.r;
        if (i5 == 1 || i5 == 3) {
            this.m = 0;
            g(false);
            return;
        }
        int i6 = this.l;
        if (i6 == 0) {
            i6 = this.k.getIntrinsicWidth();
        }
        int textWidth = i2 - getTextWidth();
        AtomicInteger atomicInteger = q.f1738a;
        int paddingEnd = ((((textWidth - getPaddingEnd()) - i6) - this.o) - getPaddingStart()) / 2;
        if ((getLayoutDirection() == 1) != (this.r == 4)) {
            paddingEnd = -paddingEnd;
        }
        if (this.m != paddingEnd) {
            this.m = paddingEnd;
            g(false);
        }
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.p;
    }

    @Override // android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (e()) {
            c.d.a.d.a.f0(this, this.f9837f.b());
        }
    }

    @Override // android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 2);
        if (a()) {
            Button.mergeDrawableStates(onCreateDrawableState, s);
        }
        if (isChecked()) {
            Button.mergeDrawableStates(onCreateDrawableState, t);
        }
        return onCreateDrawableState;
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(isChecked());
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        accessibilityNodeInfo.setCheckable(a());
        accessibilityNodeInfo.setChecked(isChecked());
        accessibilityNodeInfo.setClickable(isClickable());
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.widget.TextView, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        c.d.a.d.i.a aVar;
        super.onLayout(z, i2, i3, i4, i5);
        if (Build.VERSION.SDK_INT != 21 || (aVar = this.f9837f) == null) {
            return;
        }
        int i6 = i5 - i3;
        int i7 = i4 - i2;
        Drawable drawable = aVar.m;
        if (drawable != null) {
            drawable.setBounds(aVar.f8693c, aVar.f8695e, i7 - aVar.f8694d, i6 - aVar.f8696f);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.onRestoreInstanceState(cVar.f1843d);
        setChecked(cVar.f9842f);
    }

    @Override // android.widget.TextView, android.view.View
    public Parcelable onSaveInstanceState() {
        c cVar = new c(super.onSaveInstanceState());
        cVar.f9842f = this.p;
        return cVar;
    }

    @Override // android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        h(i2, i3);
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        h(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.view.View
    public boolean performClick() {
        toggle();
        return super.performClick();
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        if (!e()) {
            super.setBackgroundColor(i2);
            return;
        }
        c.d.a.d.i.a aVar = this.f9837f;
        if (aVar.b() != null) {
            aVar.b().setTint(i2);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (!e()) {
            super.setBackgroundDrawable(drawable);
            return;
        }
        if (drawable == getBackground()) {
            getBackground().setState(drawable.getState());
            return;
        }
        Log.w("MaterialButton", "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled");
        c.d.a.d.i.a aVar = this.f9837f;
        aVar.o = true;
        aVar.f8691a.setSupportBackgroundTintList(aVar.f8700j);
        aVar.f8691a.setSupportBackgroundTintMode(aVar.f8699i);
        super.setBackgroundDrawable(drawable);
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void setBackgroundResource(int i2) {
        setBackgroundDrawable(i2 != 0 ? b.b.d.a.a.b(getContext(), i2) : null);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z) {
        if (e()) {
            this.f9837f.q = z;
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z) {
        if (a() && isEnabled() && this.p != z) {
            this.p = z;
            refreshDrawableState();
            if (this.q) {
                return;
            }
            this.q = true;
            Iterator<a> it = this.f9838g.iterator();
            while (it.hasNext()) {
                it.next().a(this, this.p);
            }
            this.q = false;
        }
    }

    public void setCornerRadius(int i2) {
        if (e()) {
            c.d.a.d.i.a aVar = this.f9837f;
            if (aVar.p && aVar.f8697g == i2) {
                return;
            }
            aVar.f8697g = i2;
            aVar.p = true;
            aVar.e(aVar.f8692b.e(i2));
        }
    }

    public void setCornerRadiusResource(int i2) {
        if (e()) {
            setCornerRadius(getResources().getDimensionPixelSize(i2));
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        if (e()) {
            g b2 = this.f9837f.b();
            g.b bVar = b2.f8986d;
            if (bVar.o != f2) {
                bVar.o = f2;
                b2.y();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.k != drawable) {
            this.k = drawable;
            g(true);
            h(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconGravity(int i2) {
        if (this.r != i2) {
            this.r = i2;
            h(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconPadding(int i2) {
        if (this.o != i2) {
            this.o = i2;
            setCompoundDrawablePadding(i2);
        }
    }

    public void setIconResource(int i2) {
        setIcon(i2 != 0 ? b.b.d.a.a.b(getContext(), i2) : null);
    }

    public void setIconSize(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("iconSize cannot be less than 0");
        }
        if (this.l != i2) {
            this.l = i2;
            g(true);
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.f9841j != colorStateList) {
            this.f9841j = colorStateList;
            g(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.f9840i != mode) {
            this.f9840i = mode;
            g(false);
        }
    }

    public void setIconTintResource(int i2) {
        setIconTint(b.b.d.a.a.a(getContext(), i2));
    }

    public void setInsetBottom(int i2) {
        c.d.a.d.i.a aVar = this.f9837f;
        aVar.f(aVar.f8695e, i2);
    }

    public void setInsetTop(int i2) {
        c.d.a.d.i.a aVar = this.f9837f;
        aVar.f(i2, aVar.f8696f);
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOnPressedChangeListenerInternal(b bVar) {
        this.f9839h = bVar;
    }

    @Override // android.view.View
    public void setPressed(boolean z) {
        b bVar = this.f9839h;
        if (bVar != null) {
            MaterialButtonToggleGroup.this.invalidate();
        }
        super.setPressed(z);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (e()) {
            c.d.a.d.i.a aVar = this.f9837f;
            if (aVar.l != colorStateList) {
                aVar.l = colorStateList;
                if (aVar.f8691a.getBackground() instanceof RippleDrawable) {
                    ((RippleDrawable) aVar.f8691a.getBackground()).setColor(c.d.a.d.v.a.b(colorStateList));
                }
            }
        }
    }

    public void setRippleColorResource(int i2) {
        if (e()) {
            setRippleColor(b.b.d.a.a.a(getContext(), i2));
        }
    }

    @Override // c.d.a.d.x.n
    public void setShapeAppearanceModel(j jVar) {
        if (!e()) {
            throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
        }
        this.f9837f.e(jVar);
    }

    public void setShouldDrawSurfaceColorStroke(boolean z) {
        if (e()) {
            c.d.a.d.i.a aVar = this.f9837f;
            aVar.n = z;
            aVar.h();
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (e()) {
            c.d.a.d.i.a aVar = this.f9837f;
            if (aVar.k != colorStateList) {
                aVar.k = colorStateList;
                aVar.h();
            }
        }
    }

    public void setStrokeColorResource(int i2) {
        if (e()) {
            setStrokeColor(b.b.d.a.a.a(getContext(), i2));
        }
    }

    public void setStrokeWidth(int i2) {
        if (e()) {
            c.d.a.d.i.a aVar = this.f9837f;
            if (aVar.f8698h != i2) {
                aVar.f8698h = i2;
                aVar.h();
            }
        }
    }

    public void setStrokeWidthResource(int i2) {
        if (e()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i2));
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (!e()) {
            super.setSupportBackgroundTintList(colorStateList);
            return;
        }
        c.d.a.d.i.a aVar = this.f9837f;
        if (aVar.f8700j != colorStateList) {
            aVar.f8700j = colorStateList;
            if (aVar.b() != null) {
                aVar.b().setTintList(aVar.f8700j);
            }
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (!e()) {
            super.setSupportBackgroundTintMode(mode);
            return;
        }
        c.d.a.d.i.a aVar = this.f9837f;
        if (aVar.f8699i != mode) {
            aVar.f8699i = mode;
            if (aVar.b() == null || aVar.f8699i == null) {
                return;
            }
            aVar.b().setTintMode(aVar.f8699i);
        }
    }

    @Override // android.widget.Checkable
    public void toggle() {
        setChecked(!this.p);
    }
}