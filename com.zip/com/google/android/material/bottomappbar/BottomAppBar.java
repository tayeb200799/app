package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import b.h.k.q;
import c.d.a.d.g.b;
import c.d.a.d.g.c;
import c.d.a.d.g.d;
import c.d.a.d.g.f;
import c.d.a.d.g.g;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomappbar\BottomAppBar.smali */
public class BottomAppBar extends Toolbar implements CoordinatorLayout.b {
    public static final /* synthetic */ int c0 = 0;
    public Animator Q;
    public Animator R;
    public int S;
    public int T;
    public boolean U;
    public int V;
    public int W;
    public boolean a0;
    public Behavior b0;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomappbar\BottomAppBar$Behavior.smali */
    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* renamed from: e, reason: collision with root package name */
        public final Rect f9807e;

        /* renamed from: f, reason: collision with root package name */
        public WeakReference<BottomAppBar> f9808f;

        /* renamed from: g, reason: collision with root package name */
        public int f9809g;

        /* renamed from: h, reason: collision with root package name */
        public final View.OnLayoutChangeListener f9810h;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomappbar\BottomAppBar$Behavior$a.smali */
        public class a implements View.OnLayoutChangeListener {
            public a() {
            }

            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
                BottomAppBar bottomAppBar = Behavior.this.f9808f.get();
                if (bottomAppBar == null || !(view instanceof FloatingActionButton)) {
                    view.removeOnLayoutChangeListener(this);
                    return;
                }
                FloatingActionButton floatingActionButton = (FloatingActionButton) view;
                Rect rect = Behavior.this.f9807e;
                rect.set(0, 0, floatingActionButton.getMeasuredWidth(), floatingActionButton.getMeasuredHeight());
                floatingActionButton.l(rect);
                int height = Behavior.this.f9807e.height();
                bottomAppBar.H(height);
                CoordinatorLayout.f fVar = (CoordinatorLayout.f) view.getLayoutParams();
                if (Behavior.this.f9809g == 0) {
                    ((ViewGroup.MarginLayoutParams) fVar).bottomMargin = bottomAppBar.getBottomInset() + (bottomAppBar.getResources().getDimensionPixelOffset(2131165384) - ((floatingActionButton.getMeasuredHeight() - height) / 2));
                    ((ViewGroup.MarginLayoutParams) fVar).leftMargin = bottomAppBar.getLeftInset();
                    ((ViewGroup.MarginLayoutParams) fVar).rightMargin = bottomAppBar.getRightInset();
                    if (c.d.a.d.a.M(floatingActionButton)) {
                        ((ViewGroup.MarginLayoutParams) fVar).leftMargin += 0;
                    } else {
                        ((ViewGroup.MarginLayoutParams) fVar).rightMargin += 0;
                    }
                }
            }
        }

        public Behavior() {
            this.f9810h = new a();
            this.f9807e = new Rect();
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f9810h = new a();
            this.f9807e = new Rect();
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public boolean k(CoordinatorLayout coordinatorLayout, View view, int i2) {
            BottomAppBar bottomAppBar = (BottomAppBar) view;
            this.f9808f = new WeakReference<>(bottomAppBar);
            int i3 = BottomAppBar.c0;
            View C = bottomAppBar.C();
            if (C != null) {
                AtomicInteger atomicInteger = q.f1738a;
                if (!C.isLaidOut()) {
                    CoordinatorLayout.f fVar = (CoordinatorLayout.f) C.getLayoutParams();
                    fVar.f278d = 49;
                    this.f9809g = ((ViewGroup.MarginLayoutParams) fVar).bottomMargin;
                    if (C instanceof FloatingActionButton) {
                        FloatingActionButton floatingActionButton = (FloatingActionButton) C;
                        floatingActionButton.addOnLayoutChangeListener(this.f9810h);
                        floatingActionButton.d(null);
                        floatingActionButton.e(new f(bottomAppBar));
                        floatingActionButton.f(null);
                    }
                    bottomAppBar.G();
                    throw null;
                }
            }
            coordinatorLayout.s(bottomAppBar, i2);
            this.f9789a = bottomAppBar.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) bottomAppBar.getLayoutParams()).bottomMargin;
            return false;
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public boolean x(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
            if (((BottomAppBar) view).getHideOnScroll()) {
                if (i2 == 2) {
                    return true;
                }
            }
            return false;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomappbar\BottomAppBar$a.smali */
    public static class a extends b.j.a.a {
        public static final Parcelable.Creator<a> CREATOR = new C0149a();

        /* renamed from: f, reason: collision with root package name */
        public int f9812f;

        /* renamed from: g, reason: collision with root package name */
        public boolean f9813g;

        /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$a$a, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\bottomappbar\BottomAppBar$a$a.smali */
        public static class C0149a implements Parcelable.ClassLoaderCreator<a> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new a(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public a createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new a(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new a[i2];
            }
        }

        public a(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f9812f = parcel.readInt();
            this.f9813g = parcel.readInt() != 0;
        }

        public a(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // b.j.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.f1843d, i2);
            parcel.writeInt(this.f9812f);
            parcel.writeInt(this.f9813g ? 1 : 0);
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getBottomInset() {
        return 0;
    }

    private float getFabTranslationX() {
        return E(this.S);
    }

    private float getFabTranslationY() {
        return -getTopEdgeTreatment().f8677g;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getLeftInset() {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getRightInset() {
        return 0;
    }

    private g getTopEdgeTreatment() {
        throw null;
    }

    public static void w(BottomAppBar bottomAppBar) {
        bottomAppBar.V--;
    }

    public void A(int i2) {
        FloatingActionButton B = B();
        if (B == null || B.j()) {
            return;
        }
        this.V++;
        B.i(new b(this, i2), true);
    }

    public final FloatingActionButton B() {
        View C = C();
        if (C instanceof FloatingActionButton) {
            return (FloatingActionButton) C;
        }
        return null;
    }

    public final View C() {
        if (!(getParent() instanceof CoordinatorLayout)) {
            return null;
        }
        for (View view : ((CoordinatorLayout) getParent()).f(this)) {
            if ((view instanceof FloatingActionButton) || (view instanceof ExtendedFloatingActionButton)) {
                return view;
            }
        }
        return null;
    }

    public int D(ActionMenuView actionMenuView, int i2, boolean z) {
        if (i2 != 1 || !z) {
            return 0;
        }
        boolean M = c.d.a.d.a.M(this);
        int measuredWidth = M ? getMeasuredWidth() : 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if ((childAt.getLayoutParams() instanceof Toolbar.e) && (((Toolbar.e) childAt.getLayoutParams()).f596a & 8388615) == 8388611) {
                measuredWidth = M ? Math.min(measuredWidth, childAt.getLeft()) : Math.max(measuredWidth, childAt.getRight());
            }
        }
        return measuredWidth - ((M ? actionMenuView.getRight() : actionMenuView.getLeft()) + 0);
    }

    public final float E(int i2) {
        boolean M = c.d.a.d.a.M(this);
        if (i2 == 1) {
            return ((getMeasuredWidth() / 2) + 0) * (M ? -1 : 1);
        }
        return 0.0f;
    }

    public final boolean F() {
        FloatingActionButton B = B();
        return B != null && B.k();
    }

    public final void G() {
        getTopEdgeTreatment().f8678h = getFabTranslationX();
        C();
        if (this.a0) {
            F();
        }
        throw null;
    }

    public boolean H(int i2) {
        float f2 = i2;
        if (f2 == getTopEdgeTreatment().f8676f) {
            return false;
        }
        getTopEdgeTreatment().f8676f = f2;
        throw null;
    }

    public ColorStateList getBackgroundTint() {
        throw null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public Behavior getBehavior() {
        if (this.b0 == null) {
            this.b0 = new Behavior();
        }
        return this.b0;
    }

    public float getCradleVerticalOffset() {
        return getTopEdgeTreatment().f8677g;
    }

    public int getFabAlignmentMode() {
        return this.S;
    }

    public int getFabAnimationMode() {
        return this.T;
    }

    public float getFabCradleMargin() {
        return getTopEdgeTreatment().f8675e;
    }

    public float getFabCradleRoundedCornerRadius() {
        return getTopEdgeTreatment().f8674d;
    }

    public boolean getHideOnScroll() {
        return this.U;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        throw null;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        if (z) {
            Animator animator = this.R;
            if (animator != null) {
                animator.cancel();
            }
            Animator animator2 = this.Q;
            if (animator2 != null) {
                animator2.cancel();
            }
            G();
            throw null;
        }
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView == null || this.R != null) {
            return;
        }
        actionMenuView.setAlpha(1.0f);
        if (F()) {
            actionMenuView.setTranslationX(D(actionMenuView, this.S, this.a0));
        } else {
            actionMenuView.setTranslationX(D(actionMenuView, 0, false));
        }
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof a)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        a aVar = (a) parcelable;
        super.onRestoreInstanceState(aVar.f1843d);
        this.S = aVar.f9812f;
        this.a0 = aVar.f9813g;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public Parcelable onSaveInstanceState() {
        a aVar = new a(super.onSaveInstanceState());
        aVar.f9812f = this.S;
        aVar.f9813g = this.a0;
        return aVar;
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        throw null;
    }

    public void setCradleVerticalOffset(float f2) {
        if (f2 != getCradleVerticalOffset()) {
            g topEdgeTreatment = getTopEdgeTreatment();
            Objects.requireNonNull(topEdgeTreatment);
            if (f2 < 0.0f) {
                throw new IllegalArgumentException("cradleVerticalOffset must be positive.");
            }
            topEdgeTreatment.f8677g = f2;
            throw null;
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        throw null;
    }

    public void setFabAlignmentMode(int i2) {
        int i3;
        this.W = 0;
        boolean z = this.a0;
        AtomicInteger atomicInteger = q.f1738a;
        if (isLaidOut()) {
            Animator animator = this.R;
            if (animator != null) {
                animator.cancel();
            }
            ArrayList arrayList = new ArrayList();
            if (F()) {
                i3 = i2;
            } else {
                z = false;
                i3 = 0;
            }
            ActionMenuView actionMenuView = getActionMenuView();
            if (actionMenuView != null) {
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(actionMenuView, "alpha", 1.0f);
                if (Math.abs(actionMenuView.getTranslationX() - D(actionMenuView, i3, z)) > 1.0f) {
                    ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(actionMenuView, "alpha", 0.0f);
                    ofFloat2.addListener(new d(this, actionMenuView, i3, z));
                    AnimatorSet animatorSet = new AnimatorSet();
                    animatorSet.setDuration(150L);
                    animatorSet.playSequentially(ofFloat2, ofFloat);
                    arrayList.add(animatorSet);
                } else if (actionMenuView.getAlpha() < 1.0f) {
                    arrayList.add(ofFloat);
                }
            }
            AnimatorSet animatorSet2 = new AnimatorSet();
            animatorSet2.playTogether(arrayList);
            this.R = animatorSet2;
            animatorSet2.addListener(new c(this));
            this.R.start();
        } else {
            int i4 = this.W;
            if (i4 != 0) {
                this.W = 0;
                getMenu().clear();
                n(i4);
            }
        }
        if (this.S != i2 && isLaidOut()) {
            Animator animator2 = this.Q;
            if (animator2 != null) {
                animator2.cancel();
            }
            ArrayList arrayList2 = new ArrayList();
            if (this.T == 1) {
                ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(B(), "translationX", E(i2));
                ofFloat3.setDuration(300L);
                arrayList2.add(ofFloat3);
            } else {
                A(i2);
            }
            AnimatorSet animatorSet3 = new AnimatorSet();
            animatorSet3.playTogether(arrayList2);
            this.Q = animatorSet3;
            animatorSet3.addListener(new c.d.a.d.g.a(this));
            this.Q.start();
        }
        this.S = i2;
    }

    public void setFabAnimationMode(int i2) {
        this.T = i2;
    }

    public void setFabCradleMargin(float f2) {
        if (f2 == getFabCradleMargin()) {
            return;
        }
        getTopEdgeTreatment().f8675e = f2;
        throw null;
    }

    public void setFabCradleRoundedCornerRadius(float f2) {
        if (f2 == getFabCradleRoundedCornerRadius()) {
            return;
        }
        getTopEdgeTreatment().f8674d = f2;
        throw null;
    }

    public void setHideOnScroll(boolean z) {
        this.U = z;
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setSubtitle(CharSequence charSequence) {
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setTitle(CharSequence charSequence) {
    }
}