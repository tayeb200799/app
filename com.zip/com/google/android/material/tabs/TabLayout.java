package com.google.android.material.tabs;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.StateSet;
import android.view.LayoutInflater;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewpager.widget.ViewPager;
import b.h.k.l;
import b.h.k.q;
import b.h.k.y.b;
import c.d.a.d.e.a;
import c.d.a.d.r.k;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

@ViewPager.d
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout.smali */
public class TabLayout extends HorizontalScrollView {
    public static final b.h.j.d<g> T = new b.h.j.f(16);
    public int A;
    public int B;
    public int C;
    public boolean D;
    public boolean E;
    public int F;
    public boolean G;
    public c.d.a.d.a0.b H;
    public c I;
    public final ArrayList<c> J;
    public c K;
    public ValueAnimator L;
    public ViewPager M;
    public b.b0.a.a N;
    public DataSetObserver O;
    public h P;
    public b Q;
    public boolean R;
    public final b.h.j.d<i> S;

    /* renamed from: d */
    public final ArrayList<g> f9898d;

    /* renamed from: e */
    public g f9899e;

    /* renamed from: f */
    public final f f9900f;

    /* renamed from: g */
    public int f9901g;

    /* renamed from: h */
    public int f9902h;

    /* renamed from: i */
    public int f9903i;

    /* renamed from: j */
    public int f9904j;
    public int k;
    public ColorStateList l;
    public ColorStateList m;
    public ColorStateList n;
    public Drawable o;
    public int p;
    public PorterDuff.Mode q;
    public float r;
    public float s;
    public final int t;
    public int u;
    public final int v;
    public final int w;
    public final int x;
    public int y;
    public int z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$a.smali */
    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TabLayout.this.scrollTo(((Integer) valueAnimator.getAnimatedValue()).intValue(), 0);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$b.smali */
    public class b implements ViewPager.h {

        /* renamed from: a */
        public boolean f9906a;

        public b() {
        }

        @Override // androidx.viewpager.widget.ViewPager.h
        public void a(ViewPager viewPager, b.b0.a.a aVar, b.b0.a.a aVar2) {
            TabLayout tabLayout = TabLayout.this;
            if (tabLayout.M == viewPager) {
                tabLayout.l(aVar2, this.f9906a);
            }
        }
    }

    @Deprecated
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$c.smali */
    public interface c<T extends g> {
        void i(T t);

        void o(T t);

        void r(T t);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$d.smali */
    public interface d extends c<g> {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$e.smali */
    public class e extends DataSetObserver {
        public e() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            TabLayout.this.i();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            TabLayout.this.i();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$f.smali */
    public class f extends LinearLayout {

        /* renamed from: d */
        public ValueAnimator f9909d;

        /* renamed from: e */
        public int f9910e;

        /* renamed from: f */
        public float f9911f;

        /* renamed from: g */
        public int f9912g;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$f$a.smali */
        public class a implements ValueAnimator.AnimatorUpdateListener {

            /* renamed from: a */
            public final /* synthetic */ View f9914a;

            /* renamed from: b */
            public final /* synthetic */ View f9915b;

            public a(View view, View view2) {
                this.f9914a = view;
                this.f9915b = view2;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                f.this.c(this.f9914a, this.f9915b, valueAnimator.getAnimatedFraction());
            }
        }

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$f$b.smali */
        public class b extends AnimatorListenerAdapter {

            /* renamed from: a */
            public final /* synthetic */ int f9917a;

            public b(int i2) {
                this.f9917a = i2;
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                f.this.f9910e = this.f9917a;
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationStart(Animator animator) {
                f.this.f9910e = this.f9917a;
            }
        }

        public f(Context context) {
            super(context);
            this.f9910e = -1;
            this.f9912g = -1;
            setWillNotDraw(false);
        }

        public final void a() {
            View childAt = getChildAt(this.f9910e);
            TabLayout tabLayout = TabLayout.this;
            c.d.a.d.a0.b bVar = tabLayout.H;
            Drawable drawable = tabLayout.o;
            Objects.requireNonNull(bVar);
            RectF a2 = c.d.a.d.a0.b.a(tabLayout, childAt);
            drawable.setBounds((int) a2.left, drawable.getBounds().top, (int) a2.right, drawable.getBounds().bottom);
        }

        public void b(int i2) {
            Rect bounds = TabLayout.this.o.getBounds();
            TabLayout.this.o.setBounds(bounds.left, 0, bounds.right, i2);
            requestLayout();
        }

        public final void c(View view, View view2, float f2) {
            if (view != null && view.getWidth() > 0) {
                TabLayout tabLayout = TabLayout.this;
                tabLayout.H.b(tabLayout, view, view2, f2, tabLayout.o);
            } else {
                Drawable drawable = TabLayout.this.o;
                drawable.setBounds(-1, drawable.getBounds().top, -1, TabLayout.this.o.getBounds().bottom);
            }
            AtomicInteger atomicInteger = q.f1738a;
            postInvalidateOnAnimation();
        }

        public final void d(boolean z, int i2, int i3) {
            View childAt = getChildAt(this.f9910e);
            View childAt2 = getChildAt(i2);
            if (childAt2 == null) {
                a();
                return;
            }
            a aVar = new a(childAt, childAt2);
            if (!z) {
                this.f9909d.removeAllUpdateListeners();
                this.f9909d.addUpdateListener(aVar);
                return;
            }
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f9909d = valueAnimator;
            valueAnimator.setInterpolator(c.d.a.d.c.a.f8579b);
            valueAnimator.setDuration(i3);
            valueAnimator.setFloatValues(0.0f, 1.0f);
            valueAnimator.addUpdateListener(aVar);
            valueAnimator.addListener(new b(i2));
            valueAnimator.start();
        }

        @Override // android.view.View
        public void draw(Canvas canvas) {
            int height = TabLayout.this.o.getBounds().height();
            if (height < 0) {
                height = TabLayout.this.o.getIntrinsicHeight();
            }
            int i2 = TabLayout.this.B;
            int i3 = 0;
            if (i2 == 0) {
                i3 = getHeight() - height;
                height = getHeight();
            } else if (i2 == 1) {
                i3 = (getHeight() - height) / 2;
                height = (getHeight() + height) / 2;
            } else if (i2 != 2) {
                height = i2 != 3 ? 0 : getHeight();
            }
            if (TabLayout.this.o.getBounds().width() > 0) {
                Rect bounds = TabLayout.this.o.getBounds();
                TabLayout.this.o.setBounds(bounds.left, i3, bounds.right, height);
                TabLayout tabLayout = TabLayout.this;
                Drawable drawable = tabLayout.o;
                if (tabLayout.p != 0) {
                    drawable = b.h.a.X(drawable);
                    if (Build.VERSION.SDK_INT == 21) {
                        drawable.setColorFilter(TabLayout.this.p, PorterDuff.Mode.SRC_IN);
                    } else {
                        drawable.setTint(TabLayout.this.p);
                    }
                }
                drawable.draw(canvas);
            }
            super.draw(canvas);
        }

        @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
        public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
            super.onLayout(z, i2, i3, i4, i5);
            ValueAnimator valueAnimator = this.f9909d;
            if (valueAnimator == null || !valueAnimator.isRunning()) {
                a();
            } else {
                d(false, this.f9910e, -1);
            }
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (View.MeasureSpec.getMode(i2) != 1073741824) {
                return;
            }
            TabLayout tabLayout = TabLayout.this;
            boolean z = true;
            if (tabLayout.z == 1 || tabLayout.C == 2) {
                int childCount = getChildCount();
                int i4 = 0;
                for (int i5 = 0; i5 < childCount; i5++) {
                    View childAt = getChildAt(i5);
                    if (childAt.getVisibility() == 0) {
                        i4 = Math.max(i4, childAt.getMeasuredWidth());
                    }
                }
                if (i4 <= 0) {
                    return;
                }
                if (i4 * childCount <= getMeasuredWidth() - (((int) c.d.a.d.a.s(getContext(), 16)) * 2)) {
                    boolean z2 = false;
                    for (int i6 = 0; i6 < childCount; i6++) {
                        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getChildAt(i6).getLayoutParams();
                        if (layoutParams.width != i4 || layoutParams.weight != 0.0f) {
                            layoutParams.width = i4;
                            layoutParams.weight = 0.0f;
                            z2 = true;
                        }
                    }
                    z = z2;
                } else {
                    TabLayout tabLayout2 = TabLayout.this;
                    tabLayout2.z = 0;
                    tabLayout2.q(false);
                }
                if (z) {
                    super.onMeasure(i2, i3);
                }
            }
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onRtlPropertiesChanged(int i2) {
            super.onRtlPropertiesChanged(i2);
            if (Build.VERSION.SDK_INT >= 23 || this.f9912g == i2) {
                return;
            }
            requestLayout();
            this.f9912g = i2;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$g.smali */
    public static class g {

        /* renamed from: a */
        public Object f9919a;

        /* renamed from: b */
        public Drawable f9920b;

        /* renamed from: c */
        public CharSequence f9921c;

        /* renamed from: d */
        public CharSequence f9922d;

        /* renamed from: f */
        public View f9924f;

        /* renamed from: g */
        public TabLayout f9925g;

        /* renamed from: h */
        public i f9926h;

        /* renamed from: e */
        public int f9923e = -1;

        /* renamed from: i */
        public int f9927i = -1;

        public void a() {
            TabLayout tabLayout = this.f9925g;
            if (tabLayout == null) {
                throw new IllegalArgumentException("Tab not attached to a TabLayout");
            }
            tabLayout.k(this, true);
        }

        public g b(int i2) {
            TabLayout tabLayout = this.f9925g;
            if (tabLayout == null) {
                throw new IllegalArgumentException("Tab not attached to a TabLayout");
            }
            c(b.b.d.a.a.b(tabLayout.getContext(), i2));
            return this;
        }

        public g c(Drawable drawable) {
            this.f9920b = drawable;
            TabLayout tabLayout = this.f9925g;
            if (tabLayout.z == 1 || tabLayout.C == 2) {
                tabLayout.q(true);
            }
            e();
            return this;
        }

        public g d(CharSequence charSequence) {
            if (TextUtils.isEmpty(this.f9922d) && !TextUtils.isEmpty(charSequence)) {
                this.f9926h.setContentDescription(charSequence);
            }
            this.f9921c = charSequence;
            e();
            return this;
        }

        public void e() {
            i iVar = this.f9926h;
            if (iVar != null) {
                iVar.f();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$h.smali */
    public static class h implements ViewPager.i {

        /* renamed from: d */
        public final WeakReference<TabLayout> f9928d;

        /* renamed from: e */
        public int f9929e;

        /* renamed from: f */
        public int f9930f;

        public h(TabLayout tabLayout) {
            this.f9928d = new WeakReference<>(tabLayout);
        }

        @Override // androidx.viewpager.widget.ViewPager.i
        public void b(int i2, float f2, int i3) {
            TabLayout tabLayout = this.f9928d.get();
            if (tabLayout != null) {
                int i4 = this.f9930f;
                tabLayout.m(i2, f2, i4 != 2 || this.f9929e == 1, (i4 == 2 && this.f9929e == 0) ? false : true);
            }
        }

        @Override // androidx.viewpager.widget.ViewPager.i
        public void f(int i2) {
            this.f9929e = this.f9930f;
            this.f9930f = i2;
        }

        @Override // androidx.viewpager.widget.ViewPager.i
        public void g(int i2) {
            TabLayout tabLayout = this.f9928d.get();
            if (tabLayout == null || tabLayout.getSelectedTabPosition() == i2 || i2 >= tabLayout.getTabCount()) {
                return;
            }
            int i3 = this.f9930f;
            tabLayout.k(tabLayout.g(i2), i3 == 0 || (i3 == 2 && this.f9929e == 0));
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$i.smali */
    public final class i extends LinearLayout {
        public static final /* synthetic */ int o = 0;

        /* renamed from: d */
        public g f9931d;

        /* renamed from: e */
        public TextView f9932e;

        /* renamed from: f */
        public ImageView f9933f;

        /* renamed from: g */
        public View f9934g;

        /* renamed from: h */
        public c.d.a.d.e.a f9935h;

        /* renamed from: i */
        public View f9936i;

        /* renamed from: j */
        public TextView f9937j;
        public ImageView k;
        public Drawable l;
        public int m;

        public i(Context context) {
            super(context);
            this.m = 2;
            g(context);
            int i2 = TabLayout.this.f9901g;
            int i3 = TabLayout.this.f9902h;
            int i4 = TabLayout.this.f9903i;
            int i5 = TabLayout.this.f9904j;
            AtomicInteger atomicInteger = q.f1738a;
            setPaddingRelative(i2, i3, i4, i5);
            setGravity(17);
            setOrientation(!TabLayout.this.D ? 1 : 0);
            setClickable(true);
            Context context2 = getContext();
            int i6 = Build.VERSION.SDK_INT;
            l lVar = i6 >= 24 ? new l(PointerIcon.getSystemIcon(context2, 1002)) : new l(null);
            if (i6 >= 24) {
                setPointerIcon((PointerIcon) lVar.f1737a);
            }
        }

        private c.d.a.d.e.a getBadge() {
            return this.f9935h;
        }

        private c.d.a.d.e.a getOrCreateBadge() {
            if (this.f9935h == null) {
                Context context = getContext();
                c.d.a.d.e.a aVar = new c.d.a.d.e.a(context);
                int[] iArr = c.d.a.d.b.f8500c;
                k.a(context, null, 2130968651, 2131952296);
                k.b(context, null, iArr, 2130968651, 2131952296, new int[0]);
                TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, iArr, 2130968651, 2131952296);
                int i2 = obtainStyledAttributes.getInt(4, 4);
                a.C0125a c0125a = aVar.k;
                if (c0125a.f8651h != i2) {
                    c0125a.f8651h = i2;
                    aVar.n = ((int) Math.pow(10.0d, i2 - 1.0d)) - 1;
                    aVar.f8642f.f8876d = true;
                    aVar.g();
                    aVar.invalidateSelf();
                }
                if (obtainStyledAttributes.hasValue(5)) {
                    int max = Math.max(0, obtainStyledAttributes.getInt(5, 0));
                    a.C0125a c0125a2 = aVar.k;
                    if (c0125a2.f8650g != max) {
                        c0125a2.f8650g = max;
                        aVar.f8642f.f8876d = true;
                        aVar.g();
                        aVar.invalidateSelf();
                    }
                }
                int defaultColor = c.d.a.d.a.C(context, obtainStyledAttributes, 0).getDefaultColor();
                aVar.k.f8647d = defaultColor;
                ColorStateList valueOf = ColorStateList.valueOf(defaultColor);
                c.d.a.d.x.g gVar = aVar.f8641e;
                if (gVar.f8986d.f8997d != valueOf) {
                    gVar.q(valueOf);
                    aVar.invalidateSelf();
                }
                if (obtainStyledAttributes.hasValue(2)) {
                    int defaultColor2 = c.d.a.d.a.C(context, obtainStyledAttributes, 2).getDefaultColor();
                    aVar.k.f8648e = defaultColor2;
                    if (aVar.f8642f.f8873a.getColor() != defaultColor2) {
                        aVar.f8642f.f8873a.setColor(defaultColor2);
                        aVar.invalidateSelf();
                    }
                }
                int i3 = obtainStyledAttributes.getInt(1, 8388661);
                a.C0125a c0125a3 = aVar.k;
                if (c0125a3.l != i3) {
                    c0125a3.l = i3;
                    WeakReference<View> weakReference = aVar.r;
                    if (weakReference != null && weakReference.get() != null) {
                        View view = aVar.r.get();
                        WeakReference<FrameLayout> weakReference2 = aVar.s;
                        aVar.f(view, weakReference2 != null ? weakReference2.get() : null);
                    }
                }
                aVar.k.n = obtainStyledAttributes.getDimensionPixelOffset(3, 0);
                aVar.g();
                aVar.k.o = obtainStyledAttributes.getDimensionPixelOffset(6, 0);
                aVar.g();
                obtainStyledAttributes.recycle();
                this.f9935h = aVar;
            }
            d();
            c.d.a.d.e.a aVar2 = this.f9935h;
            if (aVar2 != null) {
                return aVar2;
            }
            throw new IllegalStateException("Unable to create badge");
        }

        public final boolean a() {
            return this.f9935h != null;
        }

        public final void b(View view) {
            if (a() && view != null) {
                setClipChildren(false);
                setClipToPadding(false);
                ViewGroup viewGroup = (ViewGroup) getParent();
                if (viewGroup != null) {
                    viewGroup.setClipChildren(false);
                    viewGroup.setClipToPadding(false);
                }
                c.d.a.d.e.a aVar = this.f9935h;
                Rect rect = new Rect();
                view.getDrawingRect(rect);
                aVar.setBounds(rect);
                aVar.f(view, null);
                if (aVar.c() != null) {
                    aVar.c().setForeground(aVar);
                } else {
                    view.getOverlay().add(aVar);
                }
                this.f9934g = view;
            }
        }

        public final void c() {
            if (a()) {
                setClipChildren(true);
                setClipToPadding(true);
                ViewGroup viewGroup = (ViewGroup) getParent();
                if (viewGroup != null) {
                    viewGroup.setClipChildren(true);
                    viewGroup.setClipToPadding(true);
                }
                View view = this.f9934g;
                if (view != null) {
                    c.d.a.d.e.a aVar = this.f9935h;
                    if (aVar != null) {
                        if (aVar.c() != null) {
                            aVar.c().setForeground(null);
                        } else {
                            view.getOverlay().remove(aVar);
                        }
                    }
                    this.f9934g = null;
                }
            }
        }

        public final void d() {
            g gVar;
            g gVar2;
            if (a()) {
                if (this.f9936i != null) {
                    c();
                    return;
                }
                ImageView imageView = this.f9933f;
                if (imageView != null && (gVar2 = this.f9931d) != null && gVar2.f9920b != null) {
                    if (this.f9934g == imageView) {
                        e(imageView);
                        return;
                    } else {
                        c();
                        b(this.f9933f);
                        return;
                    }
                }
                if (this.f9932e == null || (gVar = this.f9931d) == null) {
                    c();
                    return;
                }
                Objects.requireNonNull(gVar);
                View view = this.f9934g;
                TextView textView = this.f9932e;
                if (view == textView) {
                    e(textView);
                } else {
                    c();
                    b(this.f9932e);
                }
            }
        }

        @Override // android.view.ViewGroup, android.view.View
        public void drawableStateChanged() {
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            Drawable drawable = this.l;
            boolean z = false;
            if (drawable != null && drawable.isStateful()) {
                z = false | this.l.setState(drawableState);
            }
            if (z) {
                invalidate();
                TabLayout.this.invalidate();
            }
        }

        public final void e(View view) {
            if (a() && view == this.f9934g) {
                c.d.a.d.e.a aVar = this.f9935h;
                Rect rect = new Rect();
                view.getDrawingRect(rect);
                aVar.setBounds(rect);
                aVar.f(view, null);
            }
        }

        public final void f() {
            Drawable drawable;
            g gVar = this.f9931d;
            Drawable drawable2 = null;
            View view = gVar != null ? gVar.f9924f : null;
            if (view != null) {
                ViewParent parent = view.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(view);
                    }
                    addView(view);
                }
                this.f9936i = view;
                TextView textView = this.f9932e;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.f9933f;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.f9933f.setImageDrawable(null);
                }
                TextView textView2 = (TextView) view.findViewById(R.id.text1);
                this.f9937j = textView2;
                if (textView2 != null) {
                    this.m = textView2.getMaxLines();
                }
                this.k = (ImageView) view.findViewById(R.id.icon);
            } else {
                View view2 = this.f9936i;
                if (view2 != null) {
                    removeView(view2);
                    this.f9936i = null;
                }
                this.f9937j = null;
                this.k = null;
            }
            boolean z = false;
            if (this.f9936i == null) {
                if (this.f9933f == null) {
                    ImageView imageView2 = (ImageView) LayoutInflater.from(getContext()).inflate(2131558446, (ViewGroup) this, false);
                    this.f9933f = imageView2;
                    addView(imageView2, 0);
                }
                if (gVar != null && (drawable = gVar.f9920b) != null) {
                    drawable2 = b.h.a.X(drawable).mutate();
                }
                if (drawable2 != null) {
                    drawable2.setTintList(TabLayout.this.m);
                    PorterDuff.Mode mode = TabLayout.this.q;
                    if (mode != null) {
                        drawable2.setTintMode(mode);
                    }
                }
                if (this.f9932e == null) {
                    TextView textView3 = (TextView) LayoutInflater.from(getContext()).inflate(2131558447, (ViewGroup) this, false);
                    this.f9932e = textView3;
                    addView(textView3);
                    this.m = this.f9932e.getMaxLines();
                }
                b.h.a.O(this.f9932e, TabLayout.this.k);
                ColorStateList colorStateList = TabLayout.this.l;
                if (colorStateList != null) {
                    this.f9932e.setTextColor(colorStateList);
                }
                h(this.f9932e, this.f9933f);
                d();
                ImageView imageView3 = this.f9933f;
                if (imageView3 != null) {
                    imageView3.addOnLayoutChangeListener(new c.d.a.d.a0.d(this, imageView3));
                }
                TextView textView4 = this.f9932e;
                if (textView4 != null) {
                    textView4.addOnLayoutChangeListener(new c.d.a.d.a0.d(this, textView4));
                }
            } else {
                TextView textView5 = this.f9937j;
                if (textView5 != null || this.k != null) {
                    h(textView5, this.k);
                }
            }
            if (gVar != null && !TextUtils.isEmpty(gVar.f9922d)) {
                setContentDescription(gVar.f9922d);
            }
            if (gVar != null) {
                TabLayout tabLayout = gVar.f9925g;
                if (tabLayout == null) {
                    throw new IllegalArgumentException("Tab not attached to a TabLayout");
                }
                if (tabLayout.getSelectedTabPosition() == gVar.f9923e) {
                    z = true;
                }
            }
            setSelected(z);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r3v5, types: [android.graphics.drawable.RippleDrawable] */
        /* JADX WARN: Type inference failed for: r7v0, types: [android.view.View, android.widget.LinearLayout, com.google.android.material.tabs.TabLayout$i] */
        public final void g(Context context) {
            int i2 = TabLayout.this.t;
            if (i2 != 0) {
                Drawable b2 = b.b.d.a.a.b(context, i2);
                this.l = b2;
                if (b2 != null && b2.isStateful()) {
                    this.l.setState(getDrawableState());
                }
            } else {
                this.l = null;
            }
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(0);
            if (TabLayout.this.n != null) {
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setCornerRadius(1.0E-5f);
                gradientDrawable2.setColor(-1);
                ColorStateList colorStateList = TabLayout.this.n;
                ColorStateList colorStateList2 = new ColorStateList(new int[][]{c.d.a.d.v.a.f8971i, StateSet.NOTHING}, new int[]{c.d.a.d.v.a.a(colorStateList, c.d.a.d.v.a.f8967e), c.d.a.d.v.a.a(colorStateList, c.d.a.d.v.a.f8963a)});
                boolean z = TabLayout.this.G;
                if (z) {
                    gradientDrawable = null;
                }
                gradientDrawable = new RippleDrawable(colorStateList2, gradientDrawable, z ? null : gradientDrawable2);
            }
            AtomicInteger atomicInteger = q.f1738a;
            setBackground(gradientDrawable);
            TabLayout.this.invalidate();
        }

        public int getContentHeight() {
            View[] viewArr = {this.f9932e, this.f9933f, this.f9936i};
            int i2 = 0;
            int i3 = 0;
            boolean z = false;
            for (int i4 = 0; i4 < 3; i4++) {
                View view = viewArr[i4];
                if (view != null && view.getVisibility() == 0) {
                    i3 = z ? Math.min(i3, view.getTop()) : view.getTop();
                    i2 = z ? Math.max(i2, view.getBottom()) : view.getBottom();
                    z = true;
                }
            }
            return i2 - i3;
        }

        public int getContentWidth() {
            View[] viewArr = {this.f9932e, this.f9933f, this.f9936i};
            int i2 = 0;
            int i3 = 0;
            boolean z = false;
            for (int i4 = 0; i4 < 3; i4++) {
                View view = viewArr[i4];
                if (view != null && view.getVisibility() == 0) {
                    i3 = z ? Math.min(i3, view.getLeft()) : view.getLeft();
                    i2 = z ? Math.max(i2, view.getRight()) : view.getRight();
                    z = true;
                }
            }
            return i2 - i3;
        }

        public g getTab() {
            return this.f9931d;
        }

        public final void h(TextView textView, ImageView imageView) {
            Drawable drawable;
            g gVar = this.f9931d;
            Drawable mutate = (gVar == null || (drawable = gVar.f9920b) == null) ? null : b.h.a.X(drawable).mutate();
            g gVar2 = this.f9931d;
            CharSequence charSequence = gVar2 != null ? gVar2.f9921c : null;
            if (imageView != null) {
                if (mutate != null) {
                    imageView.setImageDrawable(mutate);
                    imageView.setVisibility(0);
                    setVisibility(0);
                } else {
                    imageView.setVisibility(8);
                    imageView.setImageDrawable(null);
                }
            }
            boolean z = !TextUtils.isEmpty(charSequence);
            if (textView != null) {
                if (z) {
                    textView.setText(charSequence);
                    Objects.requireNonNull(this.f9931d);
                    textView.setVisibility(0);
                    setVisibility(0);
                } else {
                    textView.setVisibility(8);
                    textView.setText((CharSequence) null);
                }
            }
            if (imageView != null) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) imageView.getLayoutParams();
                int s = (z && imageView.getVisibility() == 0) ? (int) c.d.a.d.a.s(getContext(), 8) : 0;
                if (TabLayout.this.D) {
                    if (s != marginLayoutParams.getMarginEnd()) {
                        marginLayoutParams.setMarginEnd(s);
                        marginLayoutParams.bottomMargin = 0;
                        imageView.setLayoutParams(marginLayoutParams);
                        imageView.requestLayout();
                    }
                } else if (s != marginLayoutParams.bottomMargin) {
                    marginLayoutParams.bottomMargin = s;
                    marginLayoutParams.setMarginEnd(0);
                    imageView.setLayoutParams(marginLayoutParams);
                    imageView.requestLayout();
                }
            }
            g gVar3 = this.f9931d;
            CharSequence charSequence2 = gVar3 != null ? gVar3.f9922d : null;
            if (!z) {
                charSequence = charSequence2;
            }
            b.b.a.c(this, charSequence);
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            Context context;
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            c.d.a.d.e.a aVar = this.f9935h;
            if (aVar != null && aVar.isVisible()) {
                CharSequence contentDescription = getContentDescription();
                StringBuilder sb = new StringBuilder();
                sb.append((Object) contentDescription);
                sb.append(", ");
                c.d.a.d.e.a aVar2 = this.f9935h;
                Object obj = null;
                if (aVar2.isVisible()) {
                    if (!aVar2.e()) {
                        obj = aVar2.k.f8652i;
                    } else if (aVar2.k.f8653j > 0 && (context = aVar2.f8640d.get()) != null) {
                        int d2 = aVar2.d();
                        int i2 = aVar2.n;
                        obj = d2 <= i2 ? context.getResources().getQuantityString(aVar2.k.f8653j, aVar2.d(), Integer.valueOf(aVar2.d())) : context.getString(aVar2.k.k, Integer.valueOf(i2));
                    }
                }
                sb.append(obj);
                accessibilityNodeInfo.setContentDescription(sb.toString());
            }
            accessibilityNodeInfo.setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo) b.c.a(0, 1, this.f9931d.f9923e, 1, false, isSelected()).f1804a);
            if (isSelected()) {
                accessibilityNodeInfo.setClickable(false);
                accessibilityNodeInfo.removeAction((AccessibilityNodeInfo.AccessibilityAction) b.a.f1793e.f1799a);
            }
            accessibilityNodeInfo.getExtras().putCharSequence("AccessibilityNodeInfo.roleDescription", getResources().getString(2131886404));
        }

        /* JADX WARN: Code restructure failed: missing block: B:27:0x0094, code lost:
        
            if (((r0 / r2.getPaint().getTextSize()) * r2.getLineWidth(0)) > ((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight())) goto L70;
         */
        @Override // android.widget.LinearLayout, android.view.View
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void onMeasure(int r8, int r9) {
            /*
                r7 = this;
                int r0 = android.view.View.MeasureSpec.getSize(r8)
                int r1 = android.view.View.MeasureSpec.getMode(r8)
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                int r2 = r2.getTabMaxWidth()
                if (r2 <= 0) goto L1e
                if (r1 == 0) goto L14
                if (r0 <= r2) goto L1e
            L14:
                com.google.android.material.tabs.TabLayout r8 = com.google.android.material.tabs.TabLayout.this
                int r8 = r8.u
                r0 = -2147483648(0xffffffff80000000, float:-0.0)
                int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r0)
            L1e:
                super.onMeasure(r8, r9)
                android.widget.TextView r0 = r7.f9932e
                if (r0 == 0) goto La6
                com.google.android.material.tabs.TabLayout r0 = com.google.android.material.tabs.TabLayout.this
                float r0 = r0.r
                int r1 = r7.m
                android.widget.ImageView r2 = r7.f9933f
                r3 = 1
                if (r2 == 0) goto L38
                int r2 = r2.getVisibility()
                if (r2 != 0) goto L38
                r1 = 1
                goto L46
            L38:
                android.widget.TextView r2 = r7.f9932e
                if (r2 == 0) goto L46
                int r2 = r2.getLineCount()
                if (r2 <= r3) goto L46
                com.google.android.material.tabs.TabLayout r0 = com.google.android.material.tabs.TabLayout.this
                float r0 = r0.s
            L46:
                android.widget.TextView r2 = r7.f9932e
                float r2 = r2.getTextSize()
                android.widget.TextView r4 = r7.f9932e
                int r4 = r4.getLineCount()
                android.widget.TextView r5 = r7.f9932e
                int r5 = r5.getMaxLines()
                int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
                if (r2 != 0) goto L60
                if (r5 < 0) goto La6
                if (r1 == r5) goto La6
            L60:
                com.google.android.material.tabs.TabLayout r5 = com.google.android.material.tabs.TabLayout.this
                int r5 = r5.C
                r6 = 0
                if (r5 != r3) goto L97
                if (r2 <= 0) goto L97
                if (r4 != r3) goto L97
                android.widget.TextView r2 = r7.f9932e
                android.text.Layout r2 = r2.getLayout()
                if (r2 == 0) goto L96
                float r4 = r2.getLineWidth(r6)
                android.text.TextPaint r2 = r2.getPaint()
                float r2 = r2.getTextSize()
                float r2 = r0 / r2
                float r2 = r2 * r4
                int r4 = r7.getMeasuredWidth()
                int r5 = r7.getPaddingLeft()
                int r4 = r4 - r5
                int r5 = r7.getPaddingRight()
                int r4 = r4 - r5
                float r4 = (float) r4
                int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r2 <= 0) goto L97
            L96:
                r3 = 0
            L97:
                if (r3 == 0) goto La6
                android.widget.TextView r2 = r7.f9932e
                r2.setTextSize(r6, r0)
                android.widget.TextView r0 = r7.f9932e
                r0.setMaxLines(r1)
                super.onMeasure(r8, r9)
            La6:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.i.onMeasure(int, int):void");
        }

        @Override // android.view.View
        public boolean performClick() {
            boolean performClick = super.performClick();
            if (this.f9931d == null) {
                return performClick;
            }
            if (!performClick) {
                playSoundEffect(0);
            }
            this.f9931d.a();
            return true;
        }

        @Override // android.view.View
        public void setSelected(boolean z) {
            if (isSelected() != z) {
            }
            super.setSelected(z);
            TextView textView = this.f9932e;
            if (textView != null) {
                textView.setSelected(z);
            }
            ImageView imageView = this.f9933f;
            if (imageView != null) {
                imageView.setSelected(z);
            }
            View view = this.f9936i;
            if (view != null) {
                view.setSelected(z);
            }
        }

        public void setTab(g gVar) {
            if (gVar != this.f9931d) {
                this.f9931d = gVar;
                f();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\material\tabs\TabLayout$j.smali */
    public static class j implements d {

        /* renamed from: d */
        public final ViewPager f9938d;

        public j(ViewPager viewPager) {
            this.f9938d = viewPager;
        }

        @Override // com.google.android.material.tabs.TabLayout.c
        public void i(g gVar) {
        }

        @Override // com.google.android.material.tabs.TabLayout.c
        public void o(g gVar) {
        }

        @Override // com.google.android.material.tabs.TabLayout.c
        public void r(g gVar) {
            this.f9938d.setCurrentItem(gVar.f9923e);
        }
    }

    public TabLayout(Context context, AttributeSet attributeSet) {
        super(c.d.a.d.c0.a.a.a(context, attributeSet, 2130969462, 2131952282), attributeSet, 2130969462);
        this.f9898d = new ArrayList<>();
        this.o = new GradientDrawable();
        this.p = 0;
        this.u = Integer.MAX_VALUE;
        this.J = new ArrayList<>();
        this.S = new b.h.j.e(12);
        Context context2 = getContext();
        setHorizontalScrollBarEnabled(false);
        f fVar = new f(context2);
        this.f9900f = fVar;
        super.addView(fVar, 0, new FrameLayout.LayoutParams(-2, -1));
        TypedArray d2 = k.d(context2, attributeSet, c.d.a.d.b.G, 2130969462, 2131952282, 23);
        if (getBackground() instanceof ColorDrawable) {
            ColorDrawable colorDrawable = (ColorDrawable) getBackground();
            c.d.a.d.x.g gVar = new c.d.a.d.x.g();
            gVar.q(ColorStateList.valueOf(colorDrawable.getColor()));
            gVar.f8986d.f8995b = new c.d.a.d.o.a(context2);
            gVar.y();
            AtomicInteger atomicInteger = q.f1738a;
            gVar.p(getElevation());
            setBackground(gVar);
        }
        setSelectedTabIndicator(c.d.a.d.a.F(context2, d2, 5));
        setSelectedTabIndicatorColor(d2.getColor(8, 0));
        fVar.b(d2.getDimensionPixelSize(11, -1));
        setSelectedTabIndicatorGravity(d2.getInt(10, 0));
        setTabIndicatorFullWidth(d2.getBoolean(9, true));
        setTabIndicatorAnimationMode(d2.getInt(7, 0));
        int dimensionPixelSize = d2.getDimensionPixelSize(16, 0);
        this.f9904j = dimensionPixelSize;
        this.f9903i = dimensionPixelSize;
        this.f9902h = dimensionPixelSize;
        this.f9901g = dimensionPixelSize;
        this.f9901g = d2.getDimensionPixelSize(19, dimensionPixelSize);
        this.f9902h = d2.getDimensionPixelSize(20, this.f9902h);
        this.f9903i = d2.getDimensionPixelSize(18, this.f9903i);
        this.f9904j = d2.getDimensionPixelSize(17, this.f9904j);
        int resourceId = d2.getResourceId(23, 2131952041);
        this.k = resourceId;
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(resourceId, b.b.b.x);
        try {
            this.r = obtainStyledAttributes.getDimensionPixelSize(0, 0);
            this.l = c.d.a.d.a.C(context2, obtainStyledAttributes, 3);
            obtainStyledAttributes.recycle();
            if (d2.hasValue(24)) {
                this.l = c.d.a.d.a.C(context2, d2, 24);
            }
            if (d2.hasValue(22)) {
                this.l = new ColorStateList(new int[][]{HorizontalScrollView.SELECTED_STATE_SET, HorizontalScrollView.EMPTY_STATE_SET}, new int[]{d2.getColor(22, 0), this.l.getDefaultColor()});
            }
            this.m = c.d.a.d.a.C(context2, d2, 3);
            this.q = c.d.a.d.a.R(d2.getInt(4, -1), null);
            this.n = c.d.a.d.a.C(context2, d2, 21);
            this.A = d2.getInt(6, 300);
            this.v = d2.getDimensionPixelSize(14, -1);
            this.w = d2.getDimensionPixelSize(13, -1);
            this.t = d2.getResourceId(0, 0);
            this.y = d2.getDimensionPixelSize(1, 0);
            this.C = d2.getInt(15, 1);
            this.z = d2.getInt(2, 0);
            this.D = d2.getBoolean(12, false);
            this.G = d2.getBoolean(25, false);
            d2.recycle();
            Resources resources = getResources();
            this.s = resources.getDimensionPixelSize(2131165323);
            this.x = resources.getDimensionPixelSize(2131165321);
            d();
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    private int getDefaultHeight() {
        int size = this.f9898d.size();
        boolean z = false;
        int i2 = 0;
        while (true) {
            if (i2 < size) {
                g gVar = this.f9898d.get(i2);
                if (gVar != null && gVar.f9920b != null && !TextUtils.isEmpty(gVar.f9921c)) {
                    z = true;
                    break;
                }
                i2++;
            } else {
                break;
            }
        }
        return (!z || this.D) ? 48 : 72;
    }

    private int getTabMinWidth() {
        int i2 = this.v;
        if (i2 != -1) {
            return i2;
        }
        int i3 = this.C;
        if (i3 == 0 || i3 == 2) {
            return this.x;
        }
        return 0;
    }

    private int getTabScrollRange() {
        return Math.max(0, ((this.f9900f.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
    }

    private void setSelectedTabView(int i2) {
        int childCount = this.f9900f.getChildCount();
        if (i2 < childCount) {
            int i3 = 0;
            while (i3 < childCount) {
                View childAt = this.f9900f.getChildAt(i3);
                boolean z = true;
                childAt.setSelected(i3 == i2);
                if (i3 != i2) {
                    z = false;
                }
                childAt.setActivated(z);
                i3++;
            }
        }
    }

    public void a(g gVar, boolean z) {
        int size = this.f9898d.size();
        if (gVar.f9925g != this) {
            throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
        }
        gVar.f9923e = size;
        this.f9898d.add(size, gVar);
        int size2 = this.f9898d.size();
        while (true) {
            size++;
            if (size >= size2) {
                break;
            } else {
                this.f9898d.get(size).f9923e = size;
            }
        }
        i iVar = gVar.f9926h;
        iVar.setSelected(false);
        iVar.setActivated(false);
        f fVar = this.f9900f;
        int i2 = gVar.f9923e;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
        p(layoutParams);
        fVar.addView(iVar, i2, layoutParams);
        if (z) {
            gVar.a();
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public void addView(View view) {
        b(view);
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public void addView(View view, int i2) {
        b(view);
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        b(view);
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup, android.view.ViewManager
    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        b(view);
    }

    public final void b(View view) {
        if (!(view instanceof c.d.a.d.a0.c)) {
            throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
        }
        c.d.a.d.a0.c cVar = (c.d.a.d.a0.c) view;
        g h2 = h();
        Objects.requireNonNull(cVar);
        if (!TextUtils.isEmpty(cVar.getContentDescription())) {
            h2.f9922d = cVar.getContentDescription();
            h2.e();
        }
        a(h2, this.f9898d.isEmpty());
    }

    public final void c(int i2) {
        boolean z;
        if (i2 == -1) {
            return;
        }
        if (getWindowToken() != null) {
            AtomicInteger atomicInteger = q.f1738a;
            if (isLaidOut()) {
                f fVar = this.f9900f;
                int childCount = fVar.getChildCount();
                int i3 = 0;
                while (true) {
                    if (i3 >= childCount) {
                        z = false;
                        break;
                    } else {
                        if (fVar.getChildAt(i3).getWidth() <= 0) {
                            z = true;
                            break;
                        }
                        i3++;
                    }
                }
                if (!z) {
                    int scrollX = getScrollX();
                    int e2 = e(i2, 0.0f);
                    if (scrollX != e2) {
                        f();
                        this.L.setIntValues(scrollX, e2);
                        this.L.start();
                    }
                    f fVar2 = this.f9900f;
                    int i4 = this.A;
                    ValueAnimator valueAnimator = fVar2.f9909d;
                    if (valueAnimator != null && valueAnimator.isRunning()) {
                        fVar2.f9909d.cancel();
                    }
                    fVar2.d(true, i2, i4);
                    return;
                }
            }
        }
        m(i2, 0.0f, true, true);
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x003c, code lost:
    
        if (r0 != 2) goto L52;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void d() {
        /*
            r5 = this;
            int r0 = r5.C
            r1 = 2
            r2 = 0
            if (r0 == 0) goto Lb
            if (r0 != r1) goto L9
            goto Lb
        L9:
            r0 = 0
            goto L14
        Lb:
            int r0 = r5.y
            int r3 = r5.f9901g
            int r0 = r0 - r3
            int r0 = java.lang.Math.max(r2, r0)
        L14:
            com.google.android.material.tabs.TabLayout$f r3 = r5.f9900f
            java.util.concurrent.atomic.AtomicInteger r4 = b.h.k.q.f1738a
            r3.setPaddingRelative(r0, r2, r2, r2)
            int r0 = r5.C
            java.lang.String r2 = "TabLayout"
            r3 = 1
            if (r0 == 0) goto L36
            if (r0 == r3) goto L27
            if (r0 == r1) goto L27
            goto L52
        L27:
            int r0 = r5.z
            if (r0 != r1) goto L30
            java.lang.String r0 = "GRAVITY_START is not supported with the current tab mode, GRAVITY_CENTER will be used instead"
            android.util.Log.w(r2, r0)
        L30:
            com.google.android.material.tabs.TabLayout$f r0 = r5.f9900f
            r0.setGravity(r3)
            goto L52
        L36:
            int r0 = r5.z
            if (r0 == 0) goto L45
            if (r0 == r3) goto L3f
            if (r0 == r1) goto L4a
            goto L52
        L3f:
            com.google.android.material.tabs.TabLayout$f r0 = r5.f9900f
            r0.setGravity(r3)
            goto L52
        L45:
            java.lang.String r0 = "MODE_SCROLLABLE + GRAVITY_FILL is not supported, GRAVITY_START will be used instead"
            android.util.Log.w(r2, r0)
        L4a:
            com.google.android.material.tabs.TabLayout$f r0 = r5.f9900f
            r1 = 8388611(0x800003, float:1.1754948E-38)
            r0.setGravity(r1)
        L52:
            r5.q(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.d():void");
    }

    public final int e(int i2, float f2) {
        int i3 = this.C;
        if (i3 != 0 && i3 != 2) {
            return 0;
        }
        View childAt = this.f9900f.getChildAt(i2);
        int i4 = i2 + 1;
        View childAt2 = i4 < this.f9900f.getChildCount() ? this.f9900f.getChildAt(i4) : null;
        int width = childAt != null ? childAt.getWidth() : 0;
        int width2 = childAt2 != null ? childAt2.getWidth() : 0;
        int left = ((width / 2) + childAt.getLeft()) - (getWidth() / 2);
        int i5 = (int) ((width + width2) * 0.5f * f2);
        AtomicInteger atomicInteger = q.f1738a;
        return getLayoutDirection() == 0 ? left + i5 : left - i5;
    }

    public final void f() {
        if (this.L == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.L = valueAnimator;
            valueAnimator.setInterpolator(c.d.a.d.c.a.f8579b);
            this.L.setDuration(this.A);
            this.L.addUpdateListener(new a());
        }
    }

    public g g(int i2) {
        if (i2 < 0 || i2 >= getTabCount()) {
            return null;
        }
        return this.f9898d.get(i2);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    public int getSelectedTabPosition() {
        g gVar = this.f9899e;
        if (gVar != null) {
            return gVar.f9923e;
        }
        return -1;
    }

    public int getTabCount() {
        return this.f9898d.size();
    }

    public int getTabGravity() {
        return this.z;
    }

    public ColorStateList getTabIconTint() {
        return this.m;
    }

    public int getTabIndicatorAnimationMode() {
        return this.F;
    }

    public int getTabIndicatorGravity() {
        return this.B;
    }

    public int getTabMaxWidth() {
        return this.u;
    }

    public int getTabMode() {
        return this.C;
    }

    public ColorStateList getTabRippleColor() {
        return this.n;
    }

    public Drawable getTabSelectedIndicator() {
        return this.o;
    }

    public ColorStateList getTabTextColors() {
        return this.l;
    }

    public g h() {
        g b2 = T.b();
        if (b2 == null) {
            b2 = new g();
        }
        b2.f9925g = this;
        b.h.j.d<i> dVar = this.S;
        i b3 = dVar != null ? dVar.b() : null;
        if (b3 == null) {
            b3 = new i(getContext());
        }
        b3.setTab(b2);
        b3.setFocusable(true);
        b3.setMinimumWidth(getTabMinWidth());
        if (TextUtils.isEmpty(b2.f9922d)) {
            b3.setContentDescription(b2.f9921c);
        } else {
            b3.setContentDescription(b2.f9922d);
        }
        b2.f9926h = b3;
        int i2 = b2.f9927i;
        if (i2 != -1) {
            b3.setId(i2);
        }
        return b2;
    }

    public void i() {
        int currentItem;
        j();
        b.b0.a.a aVar = this.N;
        if (aVar != null) {
            int count = aVar.getCount();
            for (int i2 = 0; i2 < count; i2++) {
                g h2 = h();
                h2.d(this.N.f(i2));
                a(h2, false);
            }
            ViewPager viewPager = this.M;
            if (viewPager == null || count <= 0 || (currentItem = viewPager.getCurrentItem()) == getSelectedTabPosition() || currentItem >= getTabCount()) {
                return;
            }
            k(g(currentItem), true);
        }
    }

    public void j() {
        int childCount = this.f9900f.getChildCount();
        while (true) {
            childCount--;
            if (childCount < 0) {
                break;
            }
            i iVar = (i) this.f9900f.getChildAt(childCount);
            this.f9900f.removeViewAt(childCount);
            if (iVar != null) {
                iVar.setTab(null);
                iVar.setSelected(false);
                this.S.a(iVar);
            }
            requestLayout();
        }
        Iterator<g> it = this.f9898d.iterator();
        while (it.hasNext()) {
            g next = it.next();
            it.remove();
            next.f9925g = null;
            next.f9926h = null;
            next.f9919a = null;
            next.f9920b = null;
            next.f9927i = -1;
            next.f9921c = null;
            next.f9922d = null;
            next.f9923e = -1;
            next.f9924f = null;
            T.a(next);
        }
        this.f9899e = null;
    }

    public void k(g gVar, boolean z) {
        g gVar2 = this.f9899e;
        if (gVar2 == gVar) {
            if (gVar2 != null) {
                for (int size = this.J.size() - 1; size >= 0; size--) {
                    this.J.get(size).i(gVar);
                }
                c(gVar.f9923e);
                return;
            }
            return;
        }
        int i2 = gVar != null ? gVar.f9923e : -1;
        if (z) {
            if ((gVar2 == null || gVar2.f9923e == -1) && i2 != -1) {
                m(i2, 0.0f, true, true);
            } else {
                c(i2);
            }
            if (i2 != -1) {
                setSelectedTabView(i2);
            }
        }
        this.f9899e = gVar;
        if (gVar2 != null) {
            for (int size2 = this.J.size() - 1; size2 >= 0; size2--) {
                this.J.get(size2).o(gVar2);
            }
        }
        if (gVar != null) {
            for (int size3 = this.J.size() - 1; size3 >= 0; size3--) {
                this.J.get(size3).r(gVar);
            }
        }
    }

    public void l(b.b0.a.a aVar, boolean z) {
        DataSetObserver dataSetObserver;
        b.b0.a.a aVar2 = this.N;
        if (aVar2 != null && (dataSetObserver = this.O) != null) {
            aVar2.f1114a.unregisterObserver(dataSetObserver);
        }
        this.N = aVar;
        if (z && aVar != null) {
            if (this.O == null) {
                this.O = new e();
            }
            aVar.f1114a.registerObserver(this.O);
        }
        i();
    }

    public void m(int i2, float f2, boolean z, boolean z2) {
        int round = Math.round(i2 + f2);
        if (round < 0 || round >= this.f9900f.getChildCount()) {
            return;
        }
        if (z2) {
            f fVar = this.f9900f;
            ValueAnimator valueAnimator = fVar.f9909d;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                fVar.f9909d.cancel();
            }
            fVar.f9910e = i2;
            fVar.f9911f = f2;
            fVar.c(fVar.getChildAt(i2), fVar.getChildAt(fVar.f9910e + 1), fVar.f9911f);
        }
        ValueAnimator valueAnimator2 = this.L;
        if (valueAnimator2 != null && valueAnimator2.isRunning()) {
            this.L.cancel();
        }
        scrollTo(e(i2, f2), 0);
        if (z) {
            setSelectedTabView(round);
        }
    }

    public final void n(ViewPager viewPager, boolean z, boolean z2) {
        List<ViewPager.h> list;
        List<ViewPager.i> list2;
        ViewPager viewPager2 = this.M;
        if (viewPager2 != null) {
            h hVar = this.P;
            if (hVar != null && (list2 = viewPager2.U) != null) {
                list2.remove(hVar);
            }
            b bVar = this.Q;
            if (bVar != null && (list = this.M.W) != null) {
                list.remove(bVar);
            }
        }
        c cVar = this.K;
        if (cVar != null) {
            this.J.remove(cVar);
            this.K = null;
        }
        if (viewPager != null) {
            this.M = viewPager;
            if (this.P == null) {
                this.P = new h(this);
            }
            h hVar2 = this.P;
            hVar2.f9930f = 0;
            hVar2.f9929e = 0;
            viewPager.b(hVar2);
            j jVar = new j(viewPager);
            this.K = jVar;
            if (!this.J.contains(jVar)) {
                this.J.add(jVar);
            }
            b.b0.a.a adapter = viewPager.getAdapter();
            if (adapter != null) {
                l(adapter, z);
            }
            if (this.Q == null) {
                this.Q = new b();
            }
            b bVar2 = this.Q;
            bVar2.f9906a = z;
            if (viewPager.W == null) {
                viewPager.W = new ArrayList();
            }
            viewPager.W.add(bVar2);
            m(viewPager.getCurrentItem(), 0.0f, true, true);
        } else {
            this.M = null;
            l(null, false);
        }
        this.R = z2;
    }

    public final void o() {
        int size = this.f9898d.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f9898d.get(i2).e();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof c.d.a.d.x.g) {
            c.d.a.d.a.f0(this, (c.d.a.d.x.g) background);
        }
        if (this.M == null) {
            ViewParent parent = getParent();
            if (parent instanceof ViewPager) {
                n((ViewPager) parent, true, true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.R) {
            setupWithViewPager(null);
            this.R = false;
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        i iVar;
        Drawable drawable;
        for (int i2 = 0; i2 < this.f9900f.getChildCount(); i2++) {
            View childAt = this.f9900f.getChildAt(i2);
            if ((childAt instanceof i) && (drawable = (iVar = (i) childAt).l) != null) {
                drawable.setBounds(iVar.getLeft(), iVar.getTop(), iVar.getRight(), iVar.getBottom());
                iVar.l.draw(canvas);
            }
        }
        super.onDraw(canvas);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) b.C0033b.a(1, getTabCount(), false, 1).f1803a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0073, code lost:
    
        if (r0 != 2) goto L71;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x007e, code lost:
    
        if (r7.getMeasuredWidth() != getMeasuredWidth()) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0080, code lost:
    
        r4 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x008a, code lost:
    
        if (r7.getMeasuredWidth() < getMeasuredWidth()) goto L67;
     */
    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r7, int r8) {
        /*
            r6 = this;
            android.content.Context r0 = r6.getContext()
            int r1 = r6.getDefaultHeight()
            float r0 = c.d.a.d.a.s(r0, r1)
            int r0 = java.lang.Math.round(r0)
            int r1 = android.view.View.MeasureSpec.getMode(r8)
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1073741824(0x40000000, float:2.0)
            r4 = 0
            r5 = 1
            if (r1 == r2) goto L2e
            if (r1 == 0) goto L1f
            goto L41
        L1f:
            int r8 = r6.getPaddingTop()
            int r8 = r8 + r0
            int r0 = r6.getPaddingBottom()
            int r0 = r0 + r8
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3)
            goto L41
        L2e:
            int r1 = r6.getChildCount()
            if (r1 != r5) goto L41
            int r1 = android.view.View.MeasureSpec.getSize(r8)
            if (r1 < r0) goto L41
            android.view.View r1 = r6.getChildAt(r4)
            r1.setMinimumHeight(r0)
        L41:
            int r0 = android.view.View.MeasureSpec.getSize(r7)
            int r1 = android.view.View.MeasureSpec.getMode(r7)
            if (r1 == 0) goto L5f
            int r1 = r6.w
            if (r1 <= 0) goto L50
            goto L5d
        L50:
            float r0 = (float) r0
            android.content.Context r1 = r6.getContext()
            r2 = 56
            float r1 = c.d.a.d.a.s(r1, r2)
            float r0 = r0 - r1
            int r1 = (int) r0
        L5d:
            r6.u = r1
        L5f:
            super.onMeasure(r7, r8)
            int r7 = r6.getChildCount()
            if (r7 != r5) goto Lad
            android.view.View r7 = r6.getChildAt(r4)
            int r0 = r6.C
            if (r0 == 0) goto L82
            if (r0 == r5) goto L76
            r1 = 2
            if (r0 == r1) goto L82
            goto L8d
        L76:
            int r0 = r7.getMeasuredWidth()
            int r1 = r6.getMeasuredWidth()
            if (r0 == r1) goto L8d
        L80:
            r4 = 1
            goto L8d
        L82:
            int r0 = r7.getMeasuredWidth()
            int r1 = r6.getMeasuredWidth()
            if (r0 >= r1) goto L8d
            goto L80
        L8d:
            if (r4 == 0) goto Lad
            int r0 = r6.getPaddingTop()
            int r1 = r6.getPaddingBottom()
            int r1 = r1 + r0
            android.view.ViewGroup$LayoutParams r0 = r7.getLayoutParams()
            int r0 = r0.height
            int r8 = android.widget.HorizontalScrollView.getChildMeasureSpec(r8, r1, r0)
            int r0 = r6.getMeasuredWidth()
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3)
            r7.measure(r0, r8)
        Lad:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.onMeasure(int, int):void");
    }

    public final void p(LinearLayout.LayoutParams layoutParams) {
        if (this.C == 1 && this.z == 0) {
            layoutParams.width = 0;
            layoutParams.weight = 1.0f;
        } else {
            layoutParams.width = -2;
            layoutParams.weight = 0.0f;
        }
    }

    public void q(boolean z) {
        for (int i2 = 0; i2 < this.f9900f.getChildCount(); i2++) {
            View childAt = this.f9900f.getChildAt(i2);
            childAt.setMinimumWidth(getTabMinWidth());
            p((LinearLayout.LayoutParams) childAt.getLayoutParams());
            if (z) {
                childAt.requestLayout();
            }
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        c.d.a.d.a.e0(this, f2);
    }

    public void setInlineLabel(boolean z) {
        if (this.D != z) {
            this.D = z;
            for (int i2 = 0; i2 < this.f9900f.getChildCount(); i2++) {
                View childAt = this.f9900f.getChildAt(i2);
                if (childAt instanceof i) {
                    i iVar = (i) childAt;
                    iVar.setOrientation(!TabLayout.this.D ? 1 : 0);
                    TextView textView = iVar.f9937j;
                    if (textView == null && iVar.k == null) {
                        iVar.h(iVar.f9932e, iVar.f9933f);
                    } else {
                        iVar.h(textView, iVar.k);
                    }
                }
            }
            d();
        }
    }

    public void setInlineLabelResource(int i2) {
        setInlineLabel(getResources().getBoolean(i2));
    }

    @Deprecated
    public void setOnTabSelectedListener(c cVar) {
        c cVar2 = this.I;
        if (cVar2 != null) {
            this.J.remove(cVar2);
        }
        this.I = cVar;
        if (cVar == null || this.J.contains(cVar)) {
            return;
        }
        this.J.add(cVar);
    }

    @Deprecated
    public void setOnTabSelectedListener(d dVar) {
        setOnTabSelectedListener((c) dVar);
    }

    public void setScrollAnimatorListener(Animator.AnimatorListener animatorListener) {
        f();
        this.L.addListener(animatorListener);
    }

    public void setSelectedTabIndicator(int i2) {
        if (i2 != 0) {
            setSelectedTabIndicator(b.b.d.a.a.b(getContext(), i2));
        } else {
            setSelectedTabIndicator((Drawable) null);
        }
    }

    public void setSelectedTabIndicator(Drawable drawable) {
        if (this.o != drawable) {
            if (drawable == null) {
                drawable = new GradientDrawable();
            }
            this.o = drawable;
        }
    }

    public void setSelectedTabIndicatorColor(int i2) {
        this.p = i2;
    }

    public void setSelectedTabIndicatorGravity(int i2) {
        if (this.B != i2) {
            this.B = i2;
            f fVar = this.f9900f;
            AtomicInteger atomicInteger = q.f1738a;
            fVar.postInvalidateOnAnimation();
        }
    }

    @Deprecated
    public void setSelectedTabIndicatorHeight(int i2) {
        this.f9900f.b(i2);
    }

    public void setTabGravity(int i2) {
        if (this.z != i2) {
            this.z = i2;
            d();
        }
    }

    public void setTabIconTint(ColorStateList colorStateList) {
        if (this.m != colorStateList) {
            this.m = colorStateList;
            o();
        }
    }

    public void setTabIconTintResource(int i2) {
        setTabIconTint(b.b.d.a.a.a(getContext(), i2));
    }

    public void setTabIndicatorAnimationMode(int i2) {
        this.F = i2;
        if (i2 == 0) {
            this.H = new c.d.a.d.a0.b();
        } else {
            if (i2 == 1) {
                this.H = new c.d.a.d.a0.a();
                return;
            }
            throw new IllegalArgumentException(i2 + " is not a valid TabIndicatorAnimationMode");
        }
    }

    public void setTabIndicatorFullWidth(boolean z) {
        this.E = z;
        f fVar = this.f9900f;
        AtomicInteger atomicInteger = q.f1738a;
        fVar.postInvalidateOnAnimation();
    }

    public void setTabMode(int i2) {
        if (i2 != this.C) {
            this.C = i2;
            d();
        }
    }

    public void setTabRippleColor(ColorStateList colorStateList) {
        if (this.n != colorStateList) {
            this.n = colorStateList;
            for (int i2 = 0; i2 < this.f9900f.getChildCount(); i2++) {
                View childAt = this.f9900f.getChildAt(i2);
                if (childAt instanceof i) {
                    Context context = getContext();
                    int i3 = i.o;
                    ((i) childAt).g(context);
                }
            }
        }
    }

    public void setTabRippleColorResource(int i2) {
        setTabRippleColor(b.b.d.a.a.a(getContext(), i2));
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.l != colorStateList) {
            this.l = colorStateList;
            o();
        }
    }

    @Deprecated
    public void setTabsFromPagerAdapter(b.b0.a.a aVar) {
        l(aVar, false);
    }

    public void setUnboundedRipple(boolean z) {
        if (this.G != z) {
            this.G = z;
            for (int i2 = 0; i2 < this.f9900f.getChildCount(); i2++) {
                View childAt = this.f9900f.getChildAt(i2);
                if (childAt instanceof i) {
                    Context context = getContext();
                    int i3 = i.o;
                    ((i) childAt).g(context);
                }
            }
        }
    }

    public void setUnboundedRippleResource(int i2) {
        setUnboundedRipple(getResources().getBoolean(i2));
    }

    public void setupWithViewPager(ViewPager viewPager) {
        n(viewPager, true, false);
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return getTabScrollRange() > 0;
    }
}