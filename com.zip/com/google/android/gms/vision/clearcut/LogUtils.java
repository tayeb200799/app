package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.Keep;
import c.d.a.c.b.a;
import c.d.a.c.e.q.c;
import c.d.a.c.i.j.d0;
import c.d.a.c.i.j.g0;
import c.d.a.c.i.j.h0;
import c.d.a.c.i.j.k2;
import c.d.a.c.i.j.l0;
import c.d.a.c.i.j.m0;
import c.d.a.c.i.j.v5;
import c.d.a.c.i.j.y;
import java.util.ArrayList;
import java.util.List;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\vision\clearcut\LogUtils.smali */
public class LogUtils {
    public static m0 zza(long j2, int i2, String str, String str2, List<l0> list, v5 v5Var) {
        g0.a q = g0.q();
        d0.b q2 = d0.q();
        if (q2.f8153f) {
            q2.l();
            q2.f8153f = false;
        }
        d0.t((d0) q2.f8152e, str2);
        if (q2.f8153f) {
            q2.l();
            q2.f8153f = false;
        }
        d0.r((d0) q2.f8152e, j2);
        long j3 = i2;
        if (q2.f8153f) {
            q2.l();
            q2.f8153f = false;
        }
        d0.v((d0) q2.f8152e, j3);
        if (q2.f8153f) {
            q2.l();
            q2.f8153f = false;
        }
        d0.s((d0) q2.f8152e, list);
        ArrayList arrayList = new ArrayList();
        arrayList.add((d0) ((k2) q2.n()));
        if (q.f8153f) {
            q.l();
            q.f8153f = false;
        }
        g0.s((g0) q.f8152e, arrayList);
        h0.b q3 = h0.q();
        long j4 = v5Var.f8242e;
        if (q3.f8153f) {
            q3.l();
            q3.f8153f = false;
        }
        h0.t((h0) q3.f8152e, j4);
        long j5 = v5Var.f8241d;
        if (q3.f8153f) {
            q3.l();
            q3.f8153f = false;
        }
        h0.r((h0) q3.f8152e, j5);
        long j6 = v5Var.f8243f;
        if (q3.f8153f) {
            q3.l();
            q3.f8153f = false;
        }
        h0.u((h0) q3.f8152e, j6);
        long j7 = v5Var.f8244g;
        if (q3.f8153f) {
            q3.l();
            q3.f8153f = false;
        }
        h0.v((h0) q3.f8152e, j7);
        h0 h0Var = (h0) ((k2) q3.n());
        if (q.f8153f) {
            q.l();
            q.f8153f = false;
        }
        g0.r((g0) q.f8152e, h0Var);
        g0 g0Var = (g0) ((k2) q.n());
        m0.a q4 = m0.q();
        if (q4.f8153f) {
            q4.l();
            q4.f8153f = false;
        }
        m0.r((m0) q4.f8152e, g0Var);
        return (m0) ((k2) q4.n());
    }

    public static y zza(Context context) {
        y.a q = y.q();
        String packageName = context.getPackageName();
        if (q.f8153f) {
            q.l();
            q.f8153f = false;
        }
        y.r((y) q.f8152e, packageName);
        String zzb = zzb(context);
        if (zzb != null) {
            if (q.f8153f) {
                q.l();
                q.f8153f = false;
            }
            y.t((y) q.f8152e, zzb);
        }
        return (y) ((k2) q.n());
    }

    private static String zzb(Context context) {
        try {
            return c.a(context).b(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e2) {
            a.x(e2, "Unable to find calling package info for %s", context.getPackageName());
            return null;
        }
    }
}