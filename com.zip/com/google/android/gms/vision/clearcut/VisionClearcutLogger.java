package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.util.Log;
import androidx.annotation.Keep;
import androidx.annotation.RecentlyNonNull;
import c.d.a.c.c.a;
import c.d.a.c.c.a.C0113a;
import c.d.a.c.i.j.h2;
import c.d.a.c.i.j.m0;
import c.d.a.c.i.j.r1;
import c.d.a.c.i.j.u;
import c.d.a.c.i.j.w1;
import java.io.IOException;
import java.util.Objects;
import java.util.logging.Logger;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\vision\clearcut\VisionClearcutLogger.smali */
public class VisionClearcutLogger {
    private final a zza;
    private boolean zzb = true;

    public VisionClearcutLogger(@RecentlyNonNull Context context) {
        this.zza = new a(context, "VISION", null);
    }

    public final void zza(int i2, m0 m0Var) {
        Objects.requireNonNull(m0Var);
        try {
            int g2 = m0Var.g();
            byte[] bArr = new byte[g2];
            Logger logger = r1.f8211b;
            r1.a aVar = new r1.a(bArr, g2);
            m0Var.e(aVar);
            if (aVar.a() != 0) {
                throw new IllegalStateException("Did not write as much data as expected.");
            }
            if (i2 < 0 || i2 > 3) {
                Object[] objArr = {Integer.valueOf(i2)};
                if (Log.isLoggable("Vision", 4)) {
                    Log.i("Vision", String.format("Illegal event code: %d", objArr));
                    return;
                }
                return;
            }
            try {
                if (this.zzb) {
                    a aVar2 = this.zza;
                    Objects.requireNonNull(aVar2);
                    a.C0113a c0113a = aVar2.new C0113a(bArr, null);
                    c0113a.f7251e.f7922h = i2;
                    c0113a.a();
                    return;
                }
                m0.a q = m0.q();
                try {
                    w1 w1Var = w1.f8256c;
                    if (w1Var == null) {
                        synchronized (w1.class) {
                            w1Var = w1.f8256c;
                            if (w1Var == null) {
                                w1Var = h2.b(w1.class);
                                w1.f8256c = w1Var;
                            }
                        }
                    }
                    q.i(bArr, 0, g2, w1Var);
                    Object[] objArr2 = {q.toString()};
                    if (Log.isLoggable("Vision", 6)) {
                        Log.e("Vision", String.format("Would have logged:\n%s", objArr2));
                    }
                } catch (Exception e2) {
                    c.d.a.c.b.a.x(e2, "Parsing error", new Object[0]);
                }
            } catch (Exception e3) {
                u.f8228a.a(e3);
                c.d.a.c.b.a.x(e3, "Failed to log", new Object[0]);
            }
        } catch (IOException e4) {
            String name = m0.class.getName();
            StringBuilder l = c.a.a.a.a.l(name.length() + 62 + 10, "Serializing ", name, " to a ", "byte array");
            l.append(" threw an IOException (should never happen).");
            throw new RuntimeException(l.toString(), e4);
        }
    }
}