package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.util.Log;
import androidx.annotation.Keep;
import androidx.annotation.RecentlyNonNull;
import c.d.a.c.i.j.m0;
import c.d.a.c.n.e.a;
import c.d.a.c.n.e.b;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\vision\clearcut\DynamiteClearcutLogger.smali */
public class DynamiteClearcutLogger {
    private static final ExecutorService zza;
    private b zzb = new b();
    private VisionClearcutLogger zzc;

    static {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(2, 2, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), Executors.defaultThreadFactory());
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        zza = Executors.unconfigurableExecutorService(threadPoolExecutor);
    }

    public DynamiteClearcutLogger(@RecentlyNonNull Context context) {
        this.zzc = new VisionClearcutLogger(context);
    }

    public final void zza(int i2, m0 m0Var) {
        boolean z;
        if (i2 == 3) {
            b bVar = this.zzb;
            synchronized (bVar.f8488b) {
                long currentTimeMillis = System.currentTimeMillis();
                if (bVar.f8489c + bVar.f8487a > currentTimeMillis) {
                    z = false;
                } else {
                    bVar.f8489c = currentTimeMillis;
                    z = true;
                }
            }
            if (!z) {
                Object[] objArr = new Object[0];
                if (Log.isLoggable("Vision", 2)) {
                    Log.v("Vision", String.format("Skipping image analysis log due to rate limiting", objArr));
                    return;
                }
                return;
            }
        }
        zza.execute(new a(this, i2, m0Var));
    }
}