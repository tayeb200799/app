package com.google.android.gms.vision.clearcut;

import android.os.Bundle;
import androidx.annotation.Keep;
import androidx.annotation.RecentlyNonNull;
import c.d.a.c.e.a;
import c.d.a.c.e.j.d;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\vision\clearcut\LoggingConnectionCallbacks.smali */
public class LoggingConnectionCallbacks implements d.a, d.b {
    public void onConnected(@RecentlyNonNull Bundle bundle) {
        throw new NoSuchMethodError();
    }

    @Override // c.d.a.c.e.j.k.k
    public void onConnectionFailed(@RecentlyNonNull a aVar) {
        throw new NoSuchMethodError();
    }

    public void onConnectionSuspended(int i2) {
        throw new NoSuchMethodError();
    }
}