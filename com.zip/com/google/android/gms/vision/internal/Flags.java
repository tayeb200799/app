package com.google.android.gms.vision.internal;

import androidx.annotation.Keep;
import c.d.a.c.h.a;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\vision\internal\Flags.smali */
public class Flags {
    private static final a<Boolean> zza = new a.C0118a(0, "vision:product_barcode_value_logging_enabled", Boolean.TRUE);

    private Flags() {
    }
}