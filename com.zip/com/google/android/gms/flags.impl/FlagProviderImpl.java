package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Log;
import c.d.a.c.b.a;
import c.d.a.c.h.d.b;
import c.d.a.c.h.d.c;
import c.d.a.c.h.d.d;
import c.d.a.c.h.d.e;
import c.d.a.c.h.g;
import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\flags\impl\FlagProviderImpl.smali */
public class FlagProviderImpl extends g {

    /* renamed from: a, reason: collision with root package name */
    public boolean f9774a = false;

    /* renamed from: b, reason: collision with root package name */
    public SharedPreferences f9775b;

    @Override // c.d.a.c.h.f
    public boolean getBooleanFlagValue(String str, boolean z, int i2) {
        if (!this.f9774a) {
            return z;
        }
        SharedPreferences sharedPreferences = this.f9775b;
        Boolean valueOf = Boolean.valueOf(z);
        try {
            valueOf = (Boolean) a.t0(new c.d.a.c.h.d.a(sharedPreferences, str, valueOf));
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
        }
        return valueOf.booleanValue();
    }

    @Override // c.d.a.c.h.f
    public int getIntFlagValue(String str, int i2, int i3) {
        if (!this.f9774a) {
            return i2;
        }
        SharedPreferences sharedPreferences = this.f9775b;
        Integer valueOf = Integer.valueOf(i2);
        try {
            valueOf = (Integer) a.t0(new b(sharedPreferences, str, valueOf));
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
        }
        return valueOf.intValue();
    }

    @Override // c.d.a.c.h.f
    public long getLongFlagValue(String str, long j2, int i2) {
        if (!this.f9774a) {
            return j2;
        }
        SharedPreferences sharedPreferences = this.f9775b;
        Long valueOf = Long.valueOf(j2);
        try {
            valueOf = (Long) a.t0(new c(sharedPreferences, str, valueOf));
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
        }
        return valueOf.longValue();
    }

    @Override // c.d.a.c.h.f
    public String getStringFlagValue(String str, String str2, int i2) {
        if (!this.f9774a) {
            return str2;
        }
        try {
            return (String) a.t0(new d(this.f9775b, str, str2));
        } catch (Exception e2) {
            String valueOf = String.valueOf(e2.getMessage());
            Log.w("FlagDataUtils", valueOf.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf) : new String("Flag value not available, returning default: "));
            return str2;
        }
    }

    @Override // c.d.a.c.h.f
    public void init(c.d.a.c.f.a aVar) {
        Context context = (Context) c.d.a.c.f.b.p0(aVar);
        if (this.f9774a) {
            return;
        }
        try {
            this.f9775b = e.a(context.createPackageContext("com.google.android.gms", 0));
            this.f9774a = true;
        } catch (PackageManager.NameNotFoundException unused) {
        } catch (Exception e2) {
            String valueOf = String.valueOf(e2.getMessage());
            Log.w("FlagProviderImpl", valueOf.length() != 0 ? "Could not retrieve sdk flags, continuing with defaults: ".concat(valueOf) : new String("Could not retrieve sdk flags, continuing with defaults: "));
        }
    }
}