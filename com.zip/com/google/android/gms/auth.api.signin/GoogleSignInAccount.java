package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import c.d.a.c.a.a.b.b;
import c.d.a.c.e.m.r.a;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\auth\api\signin\GoogleSignInAccount.smali */
public class GoogleSignInAccount extends a implements ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new b();

    /* renamed from: d, reason: collision with root package name */
    public final int f9725d;

    /* renamed from: e, reason: collision with root package name */
    public String f9726e;

    /* renamed from: f, reason: collision with root package name */
    public String f9727f;

    /* renamed from: g, reason: collision with root package name */
    public String f9728g;

    /* renamed from: h, reason: collision with root package name */
    public String f9729h;

    /* renamed from: i, reason: collision with root package name */
    public Uri f9730i;

    /* renamed from: j, reason: collision with root package name */
    public String f9731j;
    public long k;
    public String l;
    public List<Scope> m;
    public String n;
    public String o;
    public Set<Scope> p = new HashSet();

    public GoogleSignInAccount(int i2, String str, String str2, String str3, String str4, Uri uri, String str5, long j2, String str6, List<Scope> list, String str7, String str8) {
        this.f9725d = i2;
        this.f9726e = str;
        this.f9727f = str2;
        this.f9728g = str3;
        this.f9729h = str4;
        this.f9730i = uri;
        this.f9731j = str5;
        this.k = j2;
        this.l = str6;
        this.m = list;
        this.n = str7;
        this.o = str8;
    }

    public static GoogleSignInAccount j0(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        String optString = jSONObject.optString("photoUrl");
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i2 = 0; i2 < length; i2++) {
            hashSet.add(new Scope(jSONArray.getString(i2)));
        }
        String optString2 = jSONObject.optString("id");
        String optString3 = jSONObject.has("tokenId") ? jSONObject.optString("tokenId") : null;
        String optString4 = jSONObject.has("email") ? jSONObject.optString("email") : null;
        String optString5 = jSONObject.has("displayName") ? jSONObject.optString("displayName") : null;
        String optString6 = jSONObject.has("givenName") ? jSONObject.optString("givenName") : null;
        String optString7 = jSONObject.has("familyName") ? jSONObject.optString("familyName") : null;
        Long valueOf = Long.valueOf(parseLong);
        String string = jSONObject.getString("obfuscatedIdentifier");
        long longValue = valueOf.longValue();
        c.d.a.c.b.a.g(string);
        GoogleSignInAccount googleSignInAccount = new GoogleSignInAccount(3, optString2, optString3, optString4, optString5, parse, null, longValue, string, new ArrayList(hashSet), optString6, optString7);
        googleSignInAccount.f9731j = jSONObject.has("serverAuthCode") ? jSONObject.optString("serverAuthCode") : null;
        return googleSignInAccount;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GoogleSignInAccount)) {
            return false;
        }
        GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) obj;
        return googleSignInAccount.l.equals(this.l) && googleSignInAccount.i0().equals(i0());
    }

    public int hashCode() {
        return i0().hashCode() + ((this.l.hashCode() + 527) * 31);
    }

    public Set<Scope> i0() {
        HashSet hashSet = new HashSet(this.m);
        hashSet.addAll(this.p);
        return hashSet;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        int g0 = c.d.a.c.b.a.g0(parcel, 20293);
        int i3 = this.f9725d;
        parcel.writeInt(262145);
        parcel.writeInt(i3);
        c.d.a.c.b.a.U(parcel, 2, this.f9726e, false);
        c.d.a.c.b.a.U(parcel, 3, this.f9727f, false);
        c.d.a.c.b.a.U(parcel, 4, this.f9728g, false);
        c.d.a.c.b.a.U(parcel, 5, this.f9729h, false);
        c.d.a.c.b.a.T(parcel, 6, this.f9730i, i2, false);
        c.d.a.c.b.a.U(parcel, 7, this.f9731j, false);
        long j2 = this.k;
        parcel.writeInt(524296);
        parcel.writeLong(j2);
        c.d.a.c.b.a.U(parcel, 9, this.l, false);
        c.d.a.c.b.a.X(parcel, 10, this.m, false);
        c.d.a.c.b.a.U(parcel, 11, this.n, false);
        c.d.a.c.b.a.U(parcel, 12, this.o, false);
        c.d.a.c.b.a.K0(parcel, g0);
    }
}