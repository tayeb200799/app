package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import c.d.a.c.e.m.r.a;
import com.google.android.gms.common.annotation.KeepName;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

@KeepName
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\data\DataHolder.smali */
public final class DataHolder extends a implements Closeable {
    public static final Parcelable.Creator<DataHolder> CREATOR = new c.d.a.c.e.k.a();

    /* renamed from: d, reason: collision with root package name */
    public final int f9754d;

    /* renamed from: e, reason: collision with root package name */
    public final String[] f9755e;

    /* renamed from: f, reason: collision with root package name */
    public Bundle f9756f;

    /* renamed from: g, reason: collision with root package name */
    public final CursorWindow[] f9757g;

    /* renamed from: h, reason: collision with root package name */
    public final int f9758h;

    /* renamed from: i, reason: collision with root package name */
    public final Bundle f9759i;

    /* renamed from: j, reason: collision with root package name */
    public int[] f9760j;
    public boolean k = false;
    public boolean l = true;

    static {
        Objects.requireNonNull(new String[0], "null reference");
        new ArrayList();
        new HashMap();
    }

    public DataHolder(int i2, String[] strArr, CursorWindow[] cursorWindowArr, int i3, Bundle bundle) {
        this.f9754d = i2;
        this.f9755e = strArr;
        this.f9757g = cursorWindowArr;
        this.f9758h = i3;
        this.f9759i = bundle;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        synchronized (this) {
            if (!this.k) {
                this.k = true;
                int i2 = 0;
                while (true) {
                    CursorWindow[] cursorWindowArr = this.f9757g;
                    if (i2 >= cursorWindowArr.length) {
                        break;
                    }
                    cursorWindowArr[i2].close();
                    i2++;
                }
            }
        }
    }

    public final void finalize() {
        boolean z;
        try {
            if (this.l && this.f9757g.length > 0) {
                synchronized (this) {
                    z = this.k;
                }
                if (!z) {
                    close();
                    String obj = toString();
                    StringBuilder sb = new StringBuilder(String.valueOf(obj).length() + 178);
                    sb.append("Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: ");
                    sb.append(obj);
                    sb.append(")");
                    Log.e("DataBuffer", sb.toString());
                }
            }
        } finally {
            super.finalize();
        }
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        int g0 = c.d.a.c.b.a.g0(parcel, 20293);
        c.d.a.c.b.a.V(parcel, 1, this.f9755e, false);
        c.d.a.c.b.a.W(parcel, 2, this.f9757g, i2, false);
        int i3 = this.f9758h;
        parcel.writeInt(262147);
        parcel.writeInt(i3);
        c.d.a.c.b.a.P(parcel, 4, this.f9759i, false);
        int i4 = this.f9754d;
        parcel.writeInt(263144);
        parcel.writeInt(i4);
        c.d.a.c.b.a.K0(parcel, g0);
        if ((i2 & 1) != 0) {
            close();
        }
    }
}