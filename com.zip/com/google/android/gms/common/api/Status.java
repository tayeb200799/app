package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import c.d.a.c.e.j.h;
import c.d.a.c.e.j.n;
import c.d.a.c.e.m.l;
import c.d.a.c.e.m.r.a;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.util.Arrays;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\api\Status.smali */
public final class Status extends a implements h, ReflectedParcelable {

    /* renamed from: d, reason: collision with root package name */
    public final int f9738d;

    /* renamed from: e, reason: collision with root package name */
    public final int f9739e;

    /* renamed from: f, reason: collision with root package name */
    public final String f9740f;

    /* renamed from: g, reason: collision with root package name */
    public final PendingIntent f9741g;

    /* renamed from: h, reason: collision with root package name */
    public final c.d.a.c.e.a f9742h;

    /* renamed from: i, reason: collision with root package name */
    public static final Status f9736i = new Status(0, null);

    /* renamed from: j, reason: collision with root package name */
    public static final Status f9737j = new Status(15, null);
    public static final Status k = new Status(16, null);
    public static final Parcelable.Creator<Status> CREATOR = new n();

    public Status(int i2, int i3, String str, PendingIntent pendingIntent, c.d.a.c.e.a aVar) {
        this.f9738d = i2;
        this.f9739e = i3;
        this.f9740f = str;
        this.f9741g = pendingIntent;
        this.f9742h = aVar;
    }

    public Status(int i2, String str) {
        this.f9738d = 1;
        this.f9739e = i2;
        this.f9740f = str;
        this.f9741g = null;
        this.f9742h = null;
    }

    public Status(int i2, String str, PendingIntent pendingIntent) {
        this.f9738d = 1;
        this.f9739e = i2;
        this.f9740f = str;
        this.f9741g = null;
        this.f9742h = null;
    }

    @Override // c.d.a.c.e.j.h
    public Status a() {
        return this;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f9738d == status.f9738d && this.f9739e == status.f9739e && c.d.a.c.b.a.z(this.f9740f, status.f9740f) && c.d.a.c.b.a.z(this.f9741g, status.f9741g) && c.d.a.c.b.a.z(this.f9742h, status.f9742h);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f9738d), Integer.valueOf(this.f9739e), this.f9740f, this.f9741g, this.f9742h});
    }

    public String toString() {
        l lVar = new l(this);
        String str = this.f9740f;
        if (str == null) {
            int i2 = this.f9739e;
            switch (i2) {
                case -1:
                    str = "SUCCESS_CACHE";
                    break;
                case 0:
                    str = "SUCCESS";
                    break;
                case 1:
                case 9:
                case 11:
                case 12:
                default:
                    str = c.a.a.a.a.w(32, "unknown status code: ", i2);
                    break;
                case 2:
                    str = "SERVICE_VERSION_UPDATE_REQUIRED";
                    break;
                case ModuleDescriptor.MODULE_VERSION /* 3 */:
                    str = "SERVICE_DISABLED";
                    break;
                case 4:
                    str = "SIGN_IN_REQUIRED";
                    break;
                case 5:
                    str = "INVALID_ACCOUNT";
                    break;
                case 6:
                    str = "RESOLUTION_REQUIRED";
                    break;
                case 7:
                    str = "NETWORK_ERROR";
                    break;
                case 8:
                    str = "INTERNAL_ERROR";
                    break;
                case 10:
                    str = "DEVELOPER_ERROR";
                    break;
                case 13:
                    str = "ERROR";
                    break;
                case 14:
                    str = "INTERRUPTED";
                    break;
                case 15:
                    str = "TIMEOUT";
                    break;
                case 16:
                    str = "CANCELED";
                    break;
                case 17:
                    str = "API_NOT_CONNECTED";
                    break;
                case 18:
                    str = "DEAD_CLIENT";
                    break;
                case 19:
                    str = "REMOTE_EXCEPTION";
                    break;
                case 20:
                    str = "CONNECTION_SUSPENDED_DURING_CALL";
                    break;
                case 21:
                    str = "RECONNECTION_TIMED_OUT_DURING_UPDATE";
                    break;
                case 22:
                    str = "RECONNECTION_TIMED_OUT";
                    break;
            }
        }
        lVar.a("statusCode", str);
        lVar.a("resolution", this.f9741g);
        return lVar.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        int g0 = c.d.a.c.b.a.g0(parcel, 20293);
        int i3 = this.f9739e;
        parcel.writeInt(262145);
        parcel.writeInt(i3);
        c.d.a.c.b.a.U(parcel, 2, this.f9740f, false);
        c.d.a.c.b.a.T(parcel, 3, this.f9741g, i2, false);
        c.d.a.c.b.a.T(parcel, 4, this.f9742h, i2, false);
        int i4 = this.f9738d;
        parcel.writeInt(263144);
        parcel.writeInt(i4);
        c.d.a.c.b.a.K0(parcel, g0);
    }
}