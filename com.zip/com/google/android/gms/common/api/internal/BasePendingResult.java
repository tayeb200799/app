package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import c.d.a.c.e.j.d;
import c.d.a.c.e.j.e;
import c.d.a.c.e.j.h;
import c.d.a.c.e.j.i;
import c.d.a.c.e.j.k.a1;
import c.d.a.c.e.j.k.b1;
import c.d.a.c.i.b.f;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

@KeepName
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\api\internal\BasePendingResult.smali */
public abstract class BasePendingResult<R extends h> extends e<R> {
    public static final ThreadLocal<Boolean> k = new a1();

    /* renamed from: a, reason: collision with root package name */
    public final Object f9743a;

    /* renamed from: b, reason: collision with root package name */
    public final a<R> f9744b;

    /* renamed from: c, reason: collision with root package name */
    public final CountDownLatch f9745c;

    /* renamed from: d, reason: collision with root package name */
    public final ArrayList<e.a> f9746d;

    /* renamed from: e, reason: collision with root package name */
    public final AtomicReference<Object> f9747e;

    /* renamed from: f, reason: collision with root package name */
    public R f9748f;

    /* renamed from: g, reason: collision with root package name */
    public Status f9749g;

    /* renamed from: h, reason: collision with root package name */
    public volatile boolean f9750h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f9751i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f9752j;

    @KeepName
    public b1 mResultGuardian;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\api\internal\BasePendingResult$a.smali */
    public static class a<R extends h> extends f {
        public a(Looper looper) {
            super(looper);
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.os.Handler
        public final void handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 1) {
                Pair pair = (Pair) message.obj;
                i iVar = (i) pair.first;
                h hVar = (h) pair.second;
                try {
                    iVar.a(hVar);
                    return;
                } catch (RuntimeException e2) {
                    BasePendingResult.f(hVar);
                    throw e2;
                }
            }
            if (i2 == 2) {
                ((BasePendingResult) message.obj).b(Status.f9737j);
                return;
            }
            StringBuilder sb = new StringBuilder(45);
            sb.append("Don't know how to handle message: ");
            sb.append(i2);
            Log.wtf("BasePendingResult", sb.toString(), new Exception());
        }
    }

    @Deprecated
    public BasePendingResult() {
        this.f9743a = new Object();
        this.f9745c = new CountDownLatch(1);
        this.f9746d = new ArrayList<>();
        this.f9747e = new AtomicReference<>();
        this.f9752j = false;
        this.f9744b = new a<>(Looper.getMainLooper());
        new WeakReference(null);
    }

    public BasePendingResult(d dVar) {
        this.f9743a = new Object();
        this.f9745c = new CountDownLatch(1);
        this.f9746d = new ArrayList<>();
        this.f9747e = new AtomicReference<>();
        this.f9752j = false;
        this.f9744b = new a<>(dVar != null ? dVar.a() : Looper.getMainLooper());
        new WeakReference(dVar);
    }

    public static void f(h hVar) {
        if (hVar instanceof c.d.a.c.e.j.f) {
            try {
                ((c.d.a.c.e.j.f) hVar).a();
            } catch (RuntimeException e2) {
                String valueOf = String.valueOf(hVar);
                valueOf.length();
                Log.w("BasePendingResult", "Unable to release ".concat(valueOf), e2);
            }
        }
    }

    public abstract R a(Status status);

    @Deprecated
    public final void b(Status status) {
        synchronized (this.f9743a) {
            if (!c()) {
                d(a(status));
                this.f9751i = true;
            }
        }
    }

    public final boolean c() {
        return this.f9745c.getCount() == 0;
    }

    public final void d(R r) {
        synchronized (this.f9743a) {
            if (this.f9751i) {
                f(r);
                return;
            }
            c();
            c.d.a.c.b.a.l(!c(), "Results have already been set");
            c.d.a.c.b.a.l(!this.f9750h, "Result has already been consumed");
            e(r);
        }
    }

    public final void e(R r) {
        this.f9748f = r;
        this.f9749g = r.a();
        this.f9745c.countDown();
        if (this.f9748f instanceof c.d.a.c.e.j.f) {
            this.mResultGuardian = new b1(this);
        }
        ArrayList<e.a> arrayList = this.f9746d;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            arrayList.get(i2).a(this.f9749g);
        }
        this.f9746d.clear();
    }
}