package com.google.android.gms.common.api.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Keep;
import c.d.a.c.e.j.k.g;
import c.d.a.c.e.j.k.h;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\api\internal\LifecycleCallback.smali */
public class LifecycleCallback {

    /* renamed from: d, reason: collision with root package name */
    public final h f9753d;

    public LifecycleCallback(h hVar) {
        this.f9753d = hVar;
    }

    @Keep
    private static h getChimeraLifecycleFragmentImpl(g gVar) {
        throw new IllegalStateException("Method not available in SDK.");
    }

    public void a() {
    }

    public Activity b() {
        Activity m = this.f9753d.m();
        Objects.requireNonNull(m, "null reference");
        return m;
    }

    public void c(int i2, int i3, Intent intent) {
    }

    public void d(Bundle bundle) {
    }

    public void e() {
    }

    public void f(Bundle bundle) {
    }

    public void g() {
    }

    public void h() {
    }
}