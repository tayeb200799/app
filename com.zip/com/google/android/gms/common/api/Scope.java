package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import c.d.a.c.e.j.m;
import c.d.a.c.e.m.r.a;
import com.google.android.gms.common.internal.ReflectedParcelable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\api\Scope.smali */
public final class Scope extends a implements ReflectedParcelable {
    public static final Parcelable.Creator<Scope> CREATOR = new m();

    /* renamed from: d, reason: collision with root package name */
    public final int f9734d;

    /* renamed from: e, reason: collision with root package name */
    public final String f9735e;

    public Scope(int i2, String str) {
        c.d.a.c.b.a.h(str, "scopeUri must not be null or empty");
        this.f9734d = i2;
        this.f9735e = str;
    }

    public Scope(String str) {
        c.d.a.c.b.a.h(str, "scopeUri must not be null or empty");
        this.f9734d = 1;
        this.f9735e = str;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Scope) {
            return this.f9735e.equals(((Scope) obj).f9735e);
        }
        return false;
    }

    public int hashCode() {
        return this.f9735e.hashCode();
    }

    public String toString() {
        return this.f9735e;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        int g0 = c.d.a.c.b.a.g0(parcel, 20293);
        int i3 = this.f9734d;
        parcel.writeInt(262145);
        parcel.writeInt(i3);
        c.d.a.c.b.a.U(parcel, 2, this.f9735e, false);
        c.d.a.c.b.a.K0(parcel, g0);
    }
}