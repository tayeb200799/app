package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import c.d.a.c.e.a;
import c.d.a.c.e.d;
import c.d.a.c.e.j.k.f;
import com.google.android.gms.common.annotation.KeepName;
import java.util.Objects;

@KeepName
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\api\GoogleApiActivity.smali */
public class GoogleApiActivity extends Activity implements DialogInterface.OnCancelListener {

    /* renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ int f9732e = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f9733d = 0;

    @Override // android.app.Activity
    public final void onActivityResult(int i2, int i3, Intent intent) {
        super.onActivityResult(i2, i3, intent);
        if (i2 == 1) {
            boolean booleanExtra = getIntent().getBooleanExtra("notify_manager", true);
            this.f9733d = 0;
            setResult(i3, intent);
            if (booleanExtra) {
                f g2 = f.g(this);
                if (i3 == -1) {
                    Handler handler = g2.q;
                    handler.sendMessage(handler.obtainMessage(3));
                } else if (i3 == 0) {
                    g2.h(new a(13, null), getIntent().getIntExtra("failing_client_id", -1));
                }
            }
        } else if (i2 == 2) {
            this.f9733d = 0;
            setResult(i3, intent);
        }
        finish();
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        this.f9733d = 0;
        setResult(0);
        finish();
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.f9733d = bundle.getInt("resolution");
        }
        if (this.f9733d != 1) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                Log.e("GoogleApiActivity", "Activity started without extras");
                finish();
                return;
            }
            PendingIntent pendingIntent = (PendingIntent) extras.get("pending_intent");
            Integer num = (Integer) extras.get("error_code");
            if (pendingIntent == null && num == null) {
                Log.e("GoogleApiActivity", "Activity started without resolution");
                finish();
                return;
            }
            if (pendingIntent == null) {
                Objects.requireNonNull(num, "null reference");
                int intValue = num.intValue();
                Object obj = d.f7336b;
                d.f7337c.f(this, intValue, 2, this);
                this.f9733d = 1;
                return;
            }
            try {
                startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
                this.f9733d = 1;
            } catch (ActivityNotFoundException e2) {
                if (extras.getBoolean("notify_manager", true)) {
                    f.g(this).h(new a(22, null), getIntent().getIntExtra("failing_client_id", -1));
                } else {
                    String obj2 = pendingIntent.toString();
                    StringBuilder sb = new StringBuilder(obj2.length() + 36);
                    sb.append("Activity not found while launching ");
                    sb.append(obj2);
                    sb.append(".");
                    String sb2 = sb.toString();
                    if (Build.FINGERPRINT.contains("generic")) {
                        sb2 = sb2.concat(" This may occur when resolving Google Play services connection issues on emulators with Google APIs but not Google Play Store.");
                    }
                    Log.e("GoogleApiActivity", sb2, e2);
                }
                this.f9733d = 1;
                finish();
            } catch (IntentSender.SendIntentException e3) {
                Log.e("GoogleApiActivity", "Failed to launch pendingIntent", e3);
                finish();
            }
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("resolution", this.f9733d);
        super.onSaveInstanceState(bundle);
    }
}