package com.google.android.gms.common;

import com.google.android.gms.common.annotation.KeepName;

@KeepName
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\GooglePlayServicesManifestException.smali */
public class GooglePlayServicesManifestException extends IllegalStateException {
    public GooglePlayServicesManifestException(int i2, String str) {
        super(str);
    }
}