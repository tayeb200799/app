package com.google.android.gms.common.internal;

import android.os.Parcelable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\common\internal\ReflectedParcelable.smali */
public interface ReflectedParcelable extends Parcelable {
}