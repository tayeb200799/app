package com.google.android.gms.dynamite;

import android.content.Context;
import android.database.Cursor;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import c.d.a.c.g.d;
import c.d.a.c.g.e;
import c.d.a.c.g.f;
import c.d.a.c.g.g;
import c.d.a.c.g.i;
import c.d.a.c.g.j;
import c.d.a.c.g.k;
import c.d.a.c.g.l;
import com.google.android.gms.common.util.DynamiteApi;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import javax.annotation.concurrent.GuardedBy;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\DynamiteModule.smali */
public final class DynamiteModule {

    /* renamed from: d, reason: collision with root package name */
    @GuardedBy("DynamiteModule.class")
    public static Boolean f9763d = null;

    /* renamed from: e, reason: collision with root package name */
    @GuardedBy("DynamiteModule.class")
    public static String f9764e = null;

    /* renamed from: f, reason: collision with root package name */
    @GuardedBy("DynamiteModule.class")
    public static boolean f9765f = false;

    /* renamed from: g, reason: collision with root package name */
    @GuardedBy("DynamiteModule.class")
    public static int f9766g = -1;

    @GuardedBy("DynamiteModule.class")
    public static k k;

    @GuardedBy("DynamiteModule.class")
    public static l l;

    /* renamed from: a, reason: collision with root package name */
    public final Context f9770a;

    /* renamed from: h, reason: collision with root package name */
    public static final ThreadLocal<i> f9767h = new ThreadLocal<>();

    /* renamed from: i, reason: collision with root package name */
    public static final ThreadLocal<Long> f9768i = new d();

    /* renamed from: j, reason: collision with root package name */
    public static final b.a f9769j = new e();

    /* renamed from: b, reason: collision with root package name */
    public static final b f9761b = new f();

    /* renamed from: c, reason: collision with root package name */
    public static final b f9762c = new g();

    @DynamiteApi
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\DynamiteModule$DynamiteLoaderClassLoader.smali */
    public static class DynamiteLoaderClassLoader {

        @GuardedBy("DynamiteLoaderClassLoader.class")
        public static ClassLoader sClassLoader;
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\DynamiteModule$a.smali */
    public static class a extends Exception {
        public /* synthetic */ a(String str) {
            super(str);
        }

        public /* synthetic */ a(String str, Throwable th) {
            super(str, th);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\DynamiteModule$b.smali */
    public interface b {

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\DynamiteModule$b$a.smali */
        public interface a {
            int a(Context context, String str);

            int b(Context context, String str, boolean z);
        }

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$b, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\DynamiteModule$b$b.smali */
        public static class C0147b {

            /* renamed from: a, reason: collision with root package name */
            public int f9771a = 0;

            /* renamed from: b, reason: collision with root package name */
            public int f9772b = 0;

            /* renamed from: c, reason: collision with root package name */
            public int f9773c = 0;
        }

        C0147b a(Context context, String str, a aVar);
    }

    public DynamiteModule(Context context) {
        Objects.requireNonNull(context, "null reference");
        this.f9770a = context;
    }

    public static DynamiteModule b(Context context, b bVar, String str) {
        Boolean bool;
        c.d.a.c.f.a p0;
        DynamiteModule dynamiteModule;
        l lVar;
        Boolean valueOf;
        c.d.a.c.f.a p02;
        ThreadLocal<i> threadLocal = f9767h;
        i iVar = threadLocal.get();
        i iVar2 = new i(null);
        threadLocal.set(iVar2);
        ThreadLocal<Long> threadLocal2 = f9768i;
        long longValue = threadLocal2.get().longValue();
        try {
            threadLocal2.set(Long.valueOf(SystemClock.elapsedRealtime()));
            b.C0147b a2 = bVar.a(context, str, f9769j);
            int i2 = a2.f9771a;
            int i3 = a2.f9772b;
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 68 + String.valueOf(str).length());
            sb.append("Considering local module ");
            sb.append(str);
            sb.append(":");
            sb.append(i2);
            sb.append(" and remote module ");
            sb.append(str);
            sb.append(":");
            sb.append(i3);
            Log.i("DynamiteModule", sb.toString());
            int i4 = a2.f9773c;
            if (i4 != 0) {
                if (i4 == -1) {
                    if (a2.f9771a != 0) {
                        i4 = -1;
                    }
                }
                if (i4 != 1 || a2.f9772b != 0) {
                    if (i4 == -1) {
                        DynamiteModule d2 = d(context, str);
                        if (longValue == 0) {
                            threadLocal2.remove();
                        } else {
                            threadLocal2.set(Long.valueOf(longValue));
                        }
                        Cursor cursor = iVar2.f7630a;
                        if (cursor != null) {
                            cursor.close();
                        }
                        threadLocal.set(iVar);
                        return d2;
                    }
                    if (i4 != 1) {
                        StringBuilder sb2 = new StringBuilder(47);
                        sb2.append("VersionPolicy returned invalid code:");
                        sb2.append(i4);
                        throw new a(sb2.toString());
                    }
                    try {
                        int i5 = a2.f9772b;
                        try {
                            synchronized (DynamiteModule.class) {
                                bool = f9763d;
                            }
                            if (bool == null) {
                                throw new a("Failed to determine which loading route to use.");
                            }
                            if (bool.booleanValue()) {
                                StringBuilder sb3 = new StringBuilder(String.valueOf(str).length() + 51);
                                sb3.append("Selected remote version of ");
                                sb3.append(str);
                                sb3.append(", version >= ");
                                sb3.append(i5);
                                Log.i("DynamiteModule", sb3.toString());
                                synchronized (DynamiteModule.class) {
                                    lVar = l;
                                }
                                if (lVar == null) {
                                    throw new a("DynamiteLoaderV2 was not cached.");
                                }
                                i iVar3 = threadLocal.get();
                                if (iVar3 == null || iVar3.f7630a == null) {
                                    throw new a("No result cursor");
                                }
                                Context applicationContext = context.getApplicationContext();
                                Cursor cursor2 = iVar3.f7630a;
                                new c.d.a.c.f.b(null);
                                synchronized (DynamiteModule.class) {
                                    valueOf = Boolean.valueOf(f9766g >= 2);
                                }
                                if (valueOf.booleanValue()) {
                                    Log.v("DynamiteModule", "Dynamite loader version >= 2, using loadModule2NoCrashUtils");
                                    p02 = lVar.q0(new c.d.a.c.f.b(applicationContext), str, i5, new c.d.a.c.f.b(cursor2));
                                } else {
                                    Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to loadModule2");
                                    p02 = lVar.p0(new c.d.a.c.f.b(applicationContext), str, i5, new c.d.a.c.f.b(cursor2));
                                }
                                Context context2 = (Context) c.d.a.c.f.b.p0(p02);
                                if (context2 == null) {
                                    throw new a("Failed to get module context");
                                }
                                dynamiteModule = new DynamiteModule(context2);
                            } else {
                                StringBuilder sb4 = new StringBuilder(String.valueOf(str).length() + 51);
                                sb4.append("Selected remote version of ");
                                sb4.append(str);
                                sb4.append(", version >= ");
                                sb4.append(i5);
                                Log.i("DynamiteModule", sb4.toString());
                                k g2 = g(context);
                                if (g2 == null) {
                                    throw new a("Failed to create IDynamiteLoader.");
                                }
                                Parcel n0 = g2.n0(6, g2.o0());
                                int readInt = n0.readInt();
                                n0.recycle();
                                if (readInt >= 3) {
                                    i iVar4 = threadLocal.get();
                                    if (iVar4 == null) {
                                        throw new a("No cached result cursor holder");
                                    }
                                    p0 = g2.q0(new c.d.a.c.f.b(context), str, i5, new c.d.a.c.f.b(iVar4.f7630a));
                                } else if (readInt == 2) {
                                    Log.w("DynamiteModule", "IDynamite loader version = 2");
                                    p0 = g2.r0(new c.d.a.c.f.b(context), str, i5);
                                } else {
                                    Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to createModuleContext");
                                    p0 = g2.p0(new c.d.a.c.f.b(context), str, i5);
                                }
                                if (c.d.a.c.f.b.p0(p0) == null) {
                                    throw new a("Failed to load remote module.");
                                }
                                dynamiteModule = new DynamiteModule((Context) c.d.a.c.f.b.p0(p0));
                            }
                            if (longValue == 0) {
                                threadLocal2.remove();
                            } else {
                                threadLocal2.set(Long.valueOf(longValue));
                            }
                            Cursor cursor3 = iVar2.f7630a;
                            if (cursor3 != null) {
                                cursor3.close();
                            }
                            threadLocal.set(iVar);
                            return dynamiteModule;
                        } catch (RemoteException e2) {
                            throw new a("Failed to load remote module.", e2);
                        } catch (a e3) {
                            throw e3;
                        } catch (Throwable th) {
                            try {
                                Objects.requireNonNull(context, "null reference");
                            } catch (Exception e4) {
                                Log.e("CrashUtils", "Error adding exception to DropBox!", e4);
                            }
                            throw new a("Failed to load remote module.", th);
                        }
                    } catch (a e5) {
                        String valueOf2 = String.valueOf(e5.getMessage());
                        Log.w("DynamiteModule", valueOf2.length() != 0 ? "Failed to load remote module: ".concat(valueOf2) : new String("Failed to load remote module: "));
                        int i6 = a2.f9771a;
                        if (i6 == 0 || bVar.a(context, str, new j(i6)).f9773c != -1) {
                            throw new a("Remote load failed. No local fallback found.", e5);
                        }
                        DynamiteModule d3 = d(context, str);
                        if (longValue == 0) {
                            f9768i.remove();
                        } else {
                            f9768i.set(Long.valueOf(longValue));
                        }
                        Cursor cursor4 = iVar2.f7630a;
                        if (cursor4 != null) {
                            cursor4.close();
                        }
                        f9767h.set(iVar);
                        return d3;
                    }
                }
            }
            int i7 = a2.f9771a;
            int i8 = a2.f9772b;
            StringBuilder sb5 = new StringBuilder(String.valueOf(str).length() + 92);
            sb5.append("No acceptable module ");
            sb5.append(str);
            sb5.append(" found. Local version is ");
            sb5.append(i7);
            sb5.append(" and remote version is ");
            sb5.append(i8);
            sb5.append(".");
            throw new a(sb5.toString());
        } catch (Throwable th2) {
            if (longValue == 0) {
                f9768i.remove();
            } else {
                f9768i.set(Long.valueOf(longValue));
            }
            Cursor cursor5 = iVar2.f7630a;
            if (cursor5 != null) {
                cursor5.close();
            }
            f9767h.set(iVar);
            throw th2;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x0087, code lost:
    
        if (f(r10) != false) goto L33;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int c(android.content.Context r10, java.lang.String r11, boolean r12) {
        /*
            r0 = 0
            java.lang.ThreadLocal<java.lang.Long> r1 = com.google.android.gms.dynamite.DynamiteModule.f9768i     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.Object r1 = r1.get()     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.Long r1 = (java.lang.Long) r1     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            long r1 = r1.longValue()     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            android.content.ContentResolver r3 = r10.getContentResolver()     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.String r10 = "api_force_staging"
            java.lang.String r4 = "api"
            r9 = 1
            if (r9 == r12) goto L19
            r10 = r4
        L19:
            android.net.Uri$Builder r12 = new android.net.Uri$Builder     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            r12.<init>()     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.String r4 = "content"
            android.net.Uri$Builder r12 = r12.scheme(r4)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.String r4 = "com.google.android.gms.chimera"
            android.net.Uri$Builder r12 = r12.authority(r4)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            android.net.Uri$Builder r10 = r12.path(r10)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            android.net.Uri$Builder r10 = r10.appendPath(r11)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.String r11 = "requestStartTime"
            java.lang.String r12 = java.lang.String.valueOf(r1)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            android.net.Uri$Builder r10 = r10.appendQueryParameter(r11, r12)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            android.net.Uri r4 = r10.build()     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            android.database.Cursor r10 = r3.query(r4, r5, r6, r7, r8)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            if (r10 == 0) goto La2
            boolean r11 = r10.moveToFirst()     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            if (r11 == 0) goto La2
            r11 = 0
            int r12 = r10.getInt(r11)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            if (r12 <= 0) goto L8d
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r1 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r1)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            r2 = 2
            java.lang.String r2 = r10.getString(r2)     // Catch: java.lang.Throwable -> L8a
            com.google.android.gms.dynamite.DynamiteModule.f9764e = r2     // Catch: java.lang.Throwable -> L8a
            java.lang.String r2 = "loaderVersion"
            int r2 = r10.getColumnIndex(r2)     // Catch: java.lang.Throwable -> L8a
            if (r2 < 0) goto L6f
            int r2 = r10.getInt(r2)     // Catch: java.lang.Throwable -> L8a
            com.google.android.gms.dynamite.DynamiteModule.f9766g = r2     // Catch: java.lang.Throwable -> L8a
        L6f:
            java.lang.String r2 = "disableStandaloneDynamiteLoader"
            int r2 = r10.getColumnIndex(r2)     // Catch: java.lang.Throwable -> L8a
            if (r2 < 0) goto L82
            int r2 = r10.getInt(r2)     // Catch: java.lang.Throwable -> L8a
            if (r2 == 0) goto L7e
            goto L7f
        L7e:
            r9 = 0
        L7f:
            com.google.android.gms.dynamite.DynamiteModule.f9765f = r9     // Catch: java.lang.Throwable -> L8a
            r11 = r9
        L82:
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L8a
            boolean r1 = f(r10)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            if (r1 == 0) goto L8d
            goto L8e
        L8a:
            r11 = move-exception
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L8a
            throw r11     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
        L8d:
            r0 = r10
        L8e:
            if (r11 != 0) goto L96
            if (r0 == 0) goto L95
            r0.close()
        L95:
            return r12
        L96:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            java.lang.String r11 = "forcing fallback to container DynamiteLoader impl"
            r10.<init>(r11)     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
            throw r10     // Catch: java.lang.Throwable -> L9e java.lang.Exception -> La0
        L9e:
            r10 = move-exception
            goto Lc6
        La0:
            r10 = move-exception
            goto Lb8
        La2:
            java.lang.String r11 = "DynamiteModule"
            java.lang.String r12 = "Failed to retrieve remote module version."
            android.util.Log.w(r11, r12)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            com.google.android.gms.dynamite.DynamiteModule$a r11 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            java.lang.String r12 = "Failed to connect to dynamite module ContentResolver."
            r11.<init>(r12)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
            throw r11     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lb5
        Lb1:
            r11 = move-exception
            r0 = r10
            r10 = r11
            goto Lc6
        Lb5:
            r11 = move-exception
            r0 = r10
            r10 = r11
        Lb8:
            boolean r11 = r10 instanceof com.google.android.gms.dynamite.DynamiteModule.a     // Catch: java.lang.Throwable -> L9e
            if (r11 == 0) goto Lbe
            throw r10     // Catch: java.lang.Throwable -> L9e
        Lbe:
            com.google.android.gms.dynamite.DynamiteModule$a r11 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch: java.lang.Throwable -> L9e
            java.lang.String r12 = "V2 version check failed"
            r11.<init>(r12, r10)     // Catch: java.lang.Throwable -> L9e
            throw r11     // Catch: java.lang.Throwable -> L9e
        Lc6:
            if (r0 == 0) goto Lcb
            r0.close()
        Lcb:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.c(android.content.Context, java.lang.String, boolean):int");
    }

    public static DynamiteModule d(Context context, String str) {
        String valueOf = String.valueOf(str);
        Log.i("DynamiteModule", valueOf.length() != 0 ? "Selected local version of ".concat(valueOf) : new String("Selected local version of "));
        return new DynamiteModule(context.getApplicationContext());
    }

    @GuardedBy("DynamiteModule.class")
    public static void e(ClassLoader classLoader) {
        l lVar;
        try {
            IBinder iBinder = (IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(new Class[0]).newInstance(new Object[0]);
            if (iBinder == null) {
                lVar = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
                lVar = queryLocalInterface instanceof l ? (l) queryLocalInterface : new l(iBinder);
            }
            l = lVar;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e2) {
            throw new a("Failed to instantiate dynamite loader", e2);
        }
    }

    public static boolean f(Cursor cursor) {
        i iVar = f9767h.get();
        if (iVar == null || iVar.f7630a != null) {
            return false;
        }
        iVar.f7630a = cursor;
        return true;
    }

    public static k g(Context context) {
        k kVar;
        synchronized (DynamiteModule.class) {
            k kVar2 = k;
            if (kVar2 != null) {
                return kVar2;
            }
            try {
                IBinder iBinder = (IBinder) context.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance();
                if (iBinder == null) {
                    kVar = null;
                } else {
                    IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoader");
                    kVar = queryLocalInterface instanceof k ? (k) queryLocalInterface : new k(iBinder);
                }
                if (kVar != null) {
                    k = kVar;
                    return kVar;
                }
            } catch (Exception e2) {
                String valueOf = String.valueOf(e2.getMessage());
                Log.e("DynamiteModule", valueOf.length() != 0 ? "Failed to load IDynamiteLoader from GmsCore: ".concat(valueOf) : new String("Failed to load IDynamiteLoader from GmsCore: "));
            }
            return null;
        }
    }

    public IBinder a(String str) {
        try {
            return (IBinder) this.f9770a.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e2) {
            throw new a(str.length() != 0 ? "Failed to instantiate module class: ".concat(str) : new String("Failed to instantiate module class: "), e2);
        }
    }
}