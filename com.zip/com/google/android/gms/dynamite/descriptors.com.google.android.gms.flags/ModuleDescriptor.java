package com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\android\gms\dynamite\descriptors\com\google\android\gms\flags\ModuleDescriptor.smali */
public class ModuleDescriptor {
    public static final String MODULE_ID = "com.google.android.gms.flags";
    public static final int MODULE_VERSION = 3;
}