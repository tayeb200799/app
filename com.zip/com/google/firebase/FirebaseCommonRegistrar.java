package com.google.firebase;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import c.d.a.d.a;
import c.d.c.k.d0;
import c.d.c.k.m;
import c.d.c.k.n;
import c.d.c.k.o;
import c.d.c.k.p;
import c.d.c.k.u;
import c.d.c.p.d;
import c.d.c.p.e;
import c.d.c.v.f;
import c.d.c.v.g;
import c.d.c.v.h;
import com.google.firebase.FirebaseCommonRegistrar;
import f.b;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\FirebaseCommonRegistrar.smali */
public class FirebaseCommonRegistrar implements p {
    public static String a(String str) {
        return str.replace(' ', '_').replace('/', '_');
    }

    @Override // c.d.c.k.p
    public List<m<?>> getComponents() {
        String str;
        ArrayList arrayList = new ArrayList();
        m.b a2 = m.a(h.class);
        a2.a(new u(f.class, 2, 0));
        a2.c(new o() { // from class: c.d.c.v.a
            @Override // c.d.c.k.o
            public final Object a(n nVar) {
                Set b2 = ((d0) nVar).b(f.class);
                e eVar = e.f9637b;
                if (eVar == null) {
                    synchronized (e.class) {
                        eVar = e.f9637b;
                        if (eVar == null) {
                            eVar = new e();
                            e.f9637b = eVar;
                        }
                    }
                }
                return new d(b2, eVar);
            }
        });
        arrayList.add(a2.b());
        int i2 = d.f9350b;
        m.b a3 = m.a(c.d.c.p.f.class);
        a3.a(new u(Context.class, 1, 0));
        a3.a(new u(e.class, 2, 0));
        a3.c(new o() { // from class: c.d.c.p.c
            @Override // c.d.c.k.o
            public final Object a(n nVar) {
                d0 d0Var = (d0) nVar;
                return new d((Context) d0Var.a(Context.class), d0Var.b(e.class));
            }
        });
        arrayList.add(a3.b());
        arrayList.add(a.n("fire-android", String.valueOf(Build.VERSION.SDK_INT)));
        arrayList.add(a.n("fire-core", "20.0.0"));
        arrayList.add(a.n("device-name", a(Build.PRODUCT)));
        arrayList.add(a.n("device-model", a(Build.DEVICE)));
        arrayList.add(a.n("device-brand", a(Build.BRAND)));
        arrayList.add(a.z("android-target-sdk", new g() { // from class: c.d.c.c
            @Override // c.d.c.v.g
            public final String a(Object obj) {
                ApplicationInfo applicationInfo = ((Context) obj).getApplicationInfo();
                return applicationInfo != null ? String.valueOf(applicationInfo.targetSdkVersion) : "";
            }
        }));
        arrayList.add(a.z("android-min-sdk", new g() { // from class: c.d.c.d
            @Override // c.d.c.v.g
            public final String a(Object obj) {
                ApplicationInfo applicationInfo = ((Context) obj).getApplicationInfo();
                return (applicationInfo == null || Build.VERSION.SDK_INT < 24) ? "" : String.valueOf(applicationInfo.minSdkVersion);
            }
        }));
        arrayList.add(a.z("android-platform", new g() { // from class: c.d.c.e
            @Override // c.d.c.v.g
            public final String a(Object obj) {
                Context context = (Context) obj;
                int i3 = Build.VERSION.SDK_INT;
                return context.getPackageManager().hasSystemFeature("android.hardware.type.television") ? "tv" : context.getPackageManager().hasSystemFeature("android.hardware.type.watch") ? "watch" : (i3 < 23 || !context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) ? (i3 < 26 || !context.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) ? "" : "embedded" : "auto";
            }
        }));
        arrayList.add(a.z("android-installer", new g() { // from class: c.d.c.b
            @Override // c.d.c.v.g
            public final String a(Object obj) {
                Context context = (Context) obj;
                String installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
                return installerPackageName != null ? FirebaseCommonRegistrar.a(installerPackageName) : "";
            }
        }));
        try {
            str = b.f10020h.toString();
        } catch (NoClassDefFoundError unused) {
            str = null;
        }
        if (str != null) {
            arrayList.add(a.n("kotlin", str));
        }
        return arrayList;
    }
}