package com.google.firebase.datatransport;

import android.content.Context;
import androidx.annotation.Keep;
import c.d.a.a.b;
import c.d.a.a.g;
import c.d.a.a.i.c;
import c.d.a.a.j.c;
import c.d.a.a.j.e;
import c.d.a.a.j.j;
import c.d.a.a.j.k;
import c.d.c.k.d0;
import c.d.c.k.m;
import c.d.c.k.n;
import c.d.c.k.o;
import c.d.c.k.p;
import c.d.c.k.u;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\datatransport\TransportRegistrar.smali */
public class TransportRegistrar implements p {
    @Override // c.d.c.k.p
    public List<m<?>> getComponents() {
        m.b a2 = m.a(g.class);
        a2.a(new u(Context.class, 1, 0));
        a2.c(new o() { // from class: c.d.c.l.a
            @Override // c.d.c.k.o
            public final Object a(n nVar) {
                Set singleton;
                c.d.a.a.j.n.b((Context) ((d0) nVar).a(Context.class));
                c.d.a.a.j.n a3 = c.d.a.a.j.n.a();
                c cVar = c.f4257g;
                Objects.requireNonNull(a3);
                if (cVar instanceof e) {
                    Objects.requireNonNull(cVar);
                    singleton = Collections.unmodifiableSet(c.f4256f);
                } else {
                    singleton = Collections.singleton(new b("proto"));
                }
                j.a a4 = j.a();
                Objects.requireNonNull(cVar);
                a4.b("cct");
                c.b bVar = (c.b) a4;
                bVar.f4385b = cVar.b();
                return new k(singleton, bVar.a(), a3);
            }
        });
        return Collections.singletonList(a2.b());
    }
}