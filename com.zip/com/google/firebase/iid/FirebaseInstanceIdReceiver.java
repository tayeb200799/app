package com.google.firebase.iid;

import c.d.a.c.d.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\iid\FirebaseInstanceIdReceiver.smali */
public final class FirebaseInstanceIdReceiver extends a {
}