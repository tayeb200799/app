package com.google.firebase.messaging;

import androidx.annotation.Keep;
import c.d.c.g;
import c.d.c.k.m;
import c.d.c.k.n;
import c.d.c.k.o;
import c.d.c.k.p;
import c.d.c.k.u;
import c.d.c.o.d;
import c.d.c.p.f;
import c.d.c.q.a.a;
import c.d.c.v.h;
import com.google.firebase.messaging.FirebaseMessagingRegistrar;
import java.util.Arrays;
import java.util.List;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\messaging\FirebaseMessagingRegistrar.smali */
public class FirebaseMessagingRegistrar implements p {
    public static /* synthetic */ FirebaseMessaging lambda$getComponents$0(n nVar) {
        return new FirebaseMessaging((g) nVar.a(g.class), (a) nVar.a(a.class), nVar.c(h.class), nVar.c(f.class), (c.d.c.s.h) nVar.a(c.d.c.s.h.class), (c.d.a.a.g) nVar.a(c.d.a.a.g.class), (d) nVar.a(d.class));
    }

    @Override // c.d.c.k.p
    @Keep
    public List<m<?>> getComponents() {
        m[] mVarArr = new m[2];
        m.b a2 = m.a(FirebaseMessaging.class);
        a2.a(new u(g.class, 1, 0));
        a2.a(new u(a.class, 0, 0));
        a2.a(new u(h.class, 0, 1));
        a2.a(new u(f.class, 0, 1));
        a2.a(new u(c.d.a.a.g.class, 0, 0));
        a2.a(new u(c.d.c.s.h.class, 1, 0));
        a2.a(new u(d.class, 1, 0));
        a2.c(new o() { // from class: c.d.c.u.w
            @Override // c.d.c.k.o
            public final Object a(c.d.c.k.n nVar) {
                return FirebaseMessagingRegistrar.lambda$getComponents$0(nVar);
            }
        });
        if (!(a2.f9302c == 0)) {
            throw new IllegalStateException("Instantiation type has already been set.");
        }
        a2.f9302c = 1;
        mVarArr[0] = a2.b();
        mVarArr[1] = c.d.a.d.a.n("fire-fcm", "23.0.0");
        return Arrays.asList(mVarArr);
    }
}