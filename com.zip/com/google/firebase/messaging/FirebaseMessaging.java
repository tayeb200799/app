package com.google.firebase.messaging;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.Keep;
import c.d.a.a.g;
import c.d.a.c.m.i;
import c.d.a.c.m.j;
import c.d.c.f;
import c.d.c.o.b;
import c.d.c.o.d;
import c.d.c.q.a.a;
import c.d.c.s.h;
import c.d.c.u.d0;
import c.d.c.u.j0;
import c.d.c.u.n;
import c.d.c.u.o0;
import c.d.c.u.p0;
import c.d.c.u.t0;
import c.d.c.u.z;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.concurrent.GuardedBy;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\messaging\FirebaseMessaging.smali */
public class FirebaseMessaging {
    public static final long m = TimeUnit.HOURS.toSeconds(8);

    @GuardedBy("FirebaseMessaging.class")
    public static o0 n;

    @SuppressLint({"FirebaseUnknownNullness"})
    public static g o;

    @GuardedBy("FirebaseMessaging.class")
    public static ScheduledExecutorService p;

    /* renamed from: a, reason: collision with root package name */
    public final c.d.c.g f9995a;

    /* renamed from: b, reason: collision with root package name */
    public final c.d.c.q.a.a f9996b;

    /* renamed from: c, reason: collision with root package name */
    public final h f9997c;

    /* renamed from: d, reason: collision with root package name */
    public final Context f9998d;

    /* renamed from: e, reason: collision with root package name */
    public final z f9999e;

    /* renamed from: f, reason: collision with root package name */
    public final j0 f10000f;

    /* renamed from: g, reason: collision with root package name */
    public final a f10001g;

    /* renamed from: h, reason: collision with root package name */
    public final Executor f10002h;

    /* renamed from: i, reason: collision with root package name */
    public final i<t0> f10003i;

    /* renamed from: j, reason: collision with root package name */
    public final d0 f10004j;

    @GuardedBy("this")
    public boolean k;
    public final Application.ActivityLifecycleCallbacks l;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\messaging\FirebaseMessaging$a.smali */
    public class a {

        /* renamed from: a, reason: collision with root package name */
        public final d f10005a;

        /* renamed from: b, reason: collision with root package name */
        @GuardedBy("this")
        public boolean f10006b;

        /* renamed from: c, reason: collision with root package name */
        @GuardedBy("this")
        public b<f> f10007c;

        /* renamed from: d, reason: collision with root package name */
        @GuardedBy("this")
        public Boolean f10008d;

        public a(d dVar) {
            this.f10005a = dVar;
        }

        public synchronized void a() {
            if (this.f10006b) {
                return;
            }
            Boolean c2 = c();
            this.f10008d = c2;
            if (c2 == null) {
                b<f> bVar = new b() { // from class: c.d.c.u.v
                    @Override // c.d.c.o.b
                    public final void a(c.d.c.o.a aVar) {
                        FirebaseMessaging.a aVar2 = FirebaseMessaging.a.this;
                        if (aVar2.b()) {
                            FirebaseMessaging firebaseMessaging = FirebaseMessaging.this;
                            o0 o0Var = FirebaseMessaging.n;
                            firebaseMessaging.i();
                        }
                    }
                };
                this.f10007c = bVar;
                this.f10005a.a(f.class, bVar);
            }
            this.f10006b = true;
        }

        public synchronized boolean b() {
            boolean z;
            boolean z2;
            a();
            Boolean bool = this.f10008d;
            if (bool != null) {
                z2 = bool.booleanValue();
            } else {
                c.d.c.g gVar = FirebaseMessaging.this.f9995a;
                gVar.a();
                c.d.c.t.a a2 = gVar.f9254g.a();
                synchronized (a2) {
                    z = a2.f9455d;
                }
                z2 = z;
            }
            return z2;
        }

        public final Boolean c() {
            ApplicationInfo applicationInfo;
            Bundle bundle;
            c.d.c.g gVar = FirebaseMessaging.this.f9995a;
            gVar.a();
            Context context = gVar.f9248a;
            SharedPreferences sharedPreferences = context.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("auto_init")) {
                return Boolean.valueOf(sharedPreferences.getBoolean("auto_init", false));
            }
            try {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128)) == null || (bundle = applicationInfo.metaData) == null || !bundle.containsKey("firebase_messaging_auto_init_enabled")) {
                    return null;
                }
                return Boolean.valueOf(applicationInfo.metaData.getBoolean("firebase_messaging_auto_init_enabled"));
            } catch (PackageManager.NameNotFoundException unused) {
                return null;
            }
        }
    }

    public FirebaseMessaging(c.d.c.g gVar, c.d.c.q.a.a aVar, c.d.c.r.b<c.d.c.v.h> bVar, c.d.c.r.b<c.d.c.p.f> bVar2, h hVar, g gVar2, d dVar) {
        gVar.a();
        final d0 d0Var = new d0(gVar.f9248a);
        final z zVar = new z(gVar, d0Var, bVar, bVar2, hVar);
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor(new c.d.a.c.e.p.g.a("Firebase-Messaging-Task"));
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, new c.d.a.c.e.p.g.a("Firebase-Messaging-Init"));
        this.k = false;
        o = gVar2;
        this.f9995a = gVar;
        this.f9996b = aVar;
        this.f9997c = hVar;
        this.f10001g = new a(dVar);
        gVar.a();
        final Context context = gVar.f9248a;
        this.f9998d = context;
        n nVar = new n();
        this.l = nVar;
        this.f10004j = d0Var;
        this.f9999e = zVar;
        this.f10000f = new j0(newSingleThreadExecutor);
        this.f10002h = scheduledThreadPoolExecutor;
        gVar.a();
        Context context2 = gVar.f9248a;
        if (context2 instanceof Application) {
            ((Application) context2).registerActivityLifecycleCallbacks(nVar);
        } else {
            String valueOf = String.valueOf(context2);
            c.a.a.a.a.v(new StringBuilder(valueOf.length() + 125), "Context ", valueOf, " was not an application, can't register for lifecycle callbacks. Some notification events may be dropped as a result.", "FirebaseMessaging");
        }
        if (aVar != null) {
            aVar.b(new a.InterfaceC0142a(this) { // from class: c.d.c.u.s
            });
        }
        scheduledThreadPoolExecutor.execute(new Runnable() { // from class: c.d.c.u.t
            @Override // java.lang.Runnable
            public final void run() {
                FirebaseMessaging firebaseMessaging = FirebaseMessaging.this;
                if (firebaseMessaging.f10001g.b()) {
                    firebaseMessaging.i();
                }
            }
        });
        final ScheduledThreadPoolExecutor scheduledThreadPoolExecutor2 = new ScheduledThreadPoolExecutor(1, new c.d.a.c.e.p.g.a("Firebase-Messaging-Topics-Io"));
        int i2 = t0.f9594j;
        i<t0> c2 = c.d.a.c.b.a.c(scheduledThreadPoolExecutor2, new Callable() { // from class: c.d.c.u.s0
            @Override // java.util.concurrent.Callable
            public final Object call() {
                r0 r0Var;
                Context context3 = context;
                ScheduledExecutorService scheduledExecutorService = scheduledThreadPoolExecutor2;
                FirebaseMessaging firebaseMessaging = this;
                d0 d0Var2 = d0Var;
                z zVar2 = zVar;
                synchronized (r0.class) {
                    WeakReference<r0> weakReference = r0.f9583d;
                    r0Var = weakReference != null ? weakReference.get() : null;
                    if (r0Var == null) {
                        r0 r0Var2 = new r0(context3.getSharedPreferences("com.google.android.gms.appid", 0), scheduledExecutorService);
                        synchronized (r0Var2) {
                            r0Var2.f9585b = n0.a(r0Var2.f9584a, "topic_operation_queue", r0Var2.f9586c);
                        }
                        r0.f9583d = new WeakReference<>(r0Var2);
                        r0Var = r0Var2;
                    }
                }
                return new t0(firebaseMessaging, d0Var2, r0Var, zVar2, context3, scheduledExecutorService);
            }
        });
        this.f10003i = c2;
        c2.d(scheduledThreadPoolExecutor, new c.d.a.c.m.f() { // from class: c.d.c.u.o
            @Override // c.d.a.c.m.f
            public final void c(Object obj) {
                boolean z;
                t0 t0Var = (t0) obj;
                if (FirebaseMessaging.this.f10001g.b()) {
                    if (t0Var.f9602h.a() != null) {
                        synchronized (t0Var) {
                            z = t0Var.f9601g;
                        }
                        if (z) {
                            return;
                        }
                        t0Var.g(0L);
                    }
                }
            }
        });
        scheduledThreadPoolExecutor.execute(new Runnable() { // from class: c.d.c.u.u
            /* JADX WARN: Removed duplicated region for block: B:19:0x004d  */
            /* JADX WARN: Removed duplicated region for block: B:21:0x0050  */
            /* JADX WARN: Removed duplicated region for block: B:24:0x0055  */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public final void run() {
                /*
                    r7 = this;
                    com.google.firebase.messaging.FirebaseMessaging r0 = com.google.firebase.messaging.FirebaseMessaging.this
                    android.content.Context r0 = r0.f9998d
                    android.content.Context r1 = r0.getApplicationContext()
                    if (r1 == 0) goto Lb
                    goto Lc
                Lb:
                    r1 = r0
                Lc:
                    r2 = 0
                    java.lang.String r3 = "com.google.firebase.messaging"
                    android.content.SharedPreferences r1 = r1.getSharedPreferences(r3, r2)
                    java.lang.String r3 = "proxy_notification_initialized"
                    boolean r1 = r1.getBoolean(r3, r2)
                    if (r1 == 0) goto L1c
                    goto L62
                L1c:
                    java.lang.String r1 = "firebase_messaging_notification_delegation_enabled"
                    r3 = 1
                    android.content.Context r4 = r0.getApplicationContext()     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    android.content.pm.PackageManager r5 = r4.getPackageManager()     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    if (r5 == 0) goto L46
                    java.lang.String r4 = r4.getPackageName()     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    r6 = 128(0x80, float:1.8E-43)
                    android.content.pm.ApplicationInfo r4 = r5.getApplicationInfo(r4, r6)     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    if (r4 == 0) goto L46
                    android.os.Bundle r5 = r4.metaData     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    if (r5 == 0) goto L46
                    boolean r5 = r5.containsKey(r1)     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    if (r5 == 0) goto L46
                    android.os.Bundle r4 = r4.metaData     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    boolean r1 = r4.getBoolean(r1)     // Catch: android.content.pm.PackageManager.NameNotFoundException -> L46
                    goto L47
                L46:
                    r1 = 1
                L47:
                    int r4 = android.os.Build.VERSION.SDK_INT
                    r5 = 29
                    if (r4 < r5) goto L4e
                    r2 = 1
                L4e:
                    if (r2 != 0) goto L55
                    r0 = 0
                    c.d.a.c.b.a.B(r0)
                    goto L62
                L55:
                    c.d.a.c.m.j r2 = new c.d.a.c.m.j
                    r2.<init>()
                    c.d.c.u.f0 r3 = new c.d.c.u.f0
                    r3.<init>()
                    r3.run()
                L62:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: c.d.c.u.u.run():void");
            }
        });
    }

    public static synchronized FirebaseMessaging c() {
        FirebaseMessaging firebaseMessaging;
        synchronized (FirebaseMessaging.class) {
            firebaseMessaging = getInstance(c.d.c.g.b());
        }
        return firebaseMessaging;
    }

    public static synchronized o0 d(Context context) {
        o0 o0Var;
        synchronized (FirebaseMessaging.class) {
            if (n == null) {
                n = new o0(context);
            }
            o0Var = n;
        }
        return o0Var;
    }

    @Keep
    public static synchronized FirebaseMessaging getInstance(c.d.c.g gVar) {
        FirebaseMessaging firebaseMessaging;
        synchronized (FirebaseMessaging.class) {
            gVar.a();
            firebaseMessaging = (FirebaseMessaging) gVar.f9251d.a(FirebaseMessaging.class);
            c.d.a.c.b.a.j(firebaseMessaging, "Firebase Messaging component is not present");
        }
        return firebaseMessaging;
    }

    public String a() {
        i<String> iVar;
        c.d.c.q.a.a aVar = this.f9996b;
        if (aVar != null) {
            try {
                return (String) c.d.a.c.b.a.a(aVar.a());
            } catch (InterruptedException | ExecutionException e2) {
                throw new IOException(e2);
            }
        }
        final o0.a g2 = g();
        if (!k(g2)) {
            return g2.f9566a;
        }
        final String b2 = d0.b(this.f9995a);
        final j0 j0Var = this.f10000f;
        synchronized (j0Var) {
            iVar = j0Var.f9544b.get(b2);
            if (iVar == null) {
                if (Log.isLoggable("FirebaseMessaging", 3)) {
                    String valueOf = String.valueOf(b2);
                    Log.d("FirebaseMessaging", valueOf.length() != 0 ? "Making new request for: ".concat(valueOf) : new String("Making new request for: "));
                }
                z zVar = this.f9999e;
                iVar = zVar.a(zVar.c(d0.b(zVar.f9623a), "*", new Bundle())).m(new Executor() { // from class: c.d.c.u.q
                    @Override // java.util.concurrent.Executor
                    public final void execute(Runnable runnable) {
                        runnable.run();
                    }
                }, new c.d.a.c.m.h() { // from class: c.d.c.u.r
                    @Override // c.d.a.c.m.h
                    public final c.d.a.c.m.i a(Object obj) {
                        FirebaseMessaging firebaseMessaging = FirebaseMessaging.this;
                        String str = b2;
                        o0.a aVar2 = g2;
                        String str2 = (String) obj;
                        o0 d2 = FirebaseMessaging.d(firebaseMessaging.f9998d);
                        String e3 = firebaseMessaging.e();
                        String a2 = firebaseMessaging.f10004j.a();
                        synchronized (d2) {
                            String a3 = o0.a.a(str2, a2, System.currentTimeMillis());
                            if (a3 != null) {
                                SharedPreferences.Editor edit = d2.f9564a.edit();
                                edit.putString(d2.a(e3, str), a3);
                                edit.commit();
                            }
                        }
                        if (aVar2 == null || !str2.equals(aVar2.f9566a)) {
                            c.d.c.g gVar = firebaseMessaging.f9995a;
                            gVar.a();
                            if ("[DEFAULT]".equals(gVar.f9249b)) {
                                if (Log.isLoggable("FirebaseMessaging", 3)) {
                                    c.d.c.g gVar2 = firebaseMessaging.f9995a;
                                    gVar2.a();
                                    String valueOf2 = String.valueOf(gVar2.f9249b);
                                    Log.d("FirebaseMessaging", valueOf2.length() != 0 ? "Invoking onNewToken for app: ".concat(valueOf2) : new String("Invoking onNewToken for app: "));
                                }
                                Intent intent = new Intent("com.google.firebase.messaging.NEW_TOKEN");
                                intent.putExtra("token", str2);
                                new m(firebaseMessaging.f9998d).b(intent);
                            }
                        }
                        return c.d.a.c.b.a.B(str2);
                    }
                }).f(j0Var.f9543a, new c.d.a.c.m.a() { // from class: c.d.c.u.i0
                    @Override // c.d.a.c.m.a
                    public final Object a(c.d.a.c.m.i iVar2) {
                        j0 j0Var2 = j0.this;
                        String str = b2;
                        synchronized (j0Var2) {
                            j0Var2.f9544b.remove(str);
                        }
                        return iVar2;
                    }
                });
                j0Var.f9544b.put(b2, iVar);
            } else if (Log.isLoggable("FirebaseMessaging", 3)) {
                String valueOf2 = String.valueOf(b2);
                Log.d("FirebaseMessaging", valueOf2.length() != 0 ? "Joining ongoing request for: ".concat(valueOf2) : new String("Joining ongoing request for: "));
            }
        }
        try {
            return (String) c.d.a.c.b.a.a(iVar);
        } catch (InterruptedException | ExecutionException e3) {
            throw new IOException(e3);
        }
    }

    public void b(Runnable runnable, long j2) {
        synchronized (FirebaseMessaging.class) {
            if (p == null) {
                p = new ScheduledThreadPoolExecutor(1, new c.d.a.c.e.p.g.a("TAG"));
            }
            p.schedule(runnable, j2, TimeUnit.SECONDS);
        }
    }

    public final String e() {
        c.d.c.g gVar = this.f9995a;
        gVar.a();
        return "[DEFAULT]".equals(gVar.f9249b) ? "" : this.f9995a.c();
    }

    public i<String> f() {
        c.d.c.q.a.a aVar = this.f9996b;
        if (aVar != null) {
            return aVar.a();
        }
        final j jVar = new j();
        this.f10002h.execute(new Runnable() { // from class: c.d.c.u.p
            @Override // java.lang.Runnable
            public final void run() {
                FirebaseMessaging firebaseMessaging = FirebaseMessaging.this;
                c.d.a.c.m.j jVar2 = jVar;
                Objects.requireNonNull(firebaseMessaging);
                try {
                    jVar2.f8355a.o(firebaseMessaging.a());
                } catch (Exception e2) {
                    jVar2.f8355a.n(e2);
                }
            }
        });
        return jVar.f8355a;
    }

    public o0.a g() {
        o0.a b2;
        o0 d2 = d(this.f9998d);
        String e2 = e();
        String b3 = d0.b(this.f9995a);
        synchronized (d2) {
            b2 = o0.a.b(d2.f9564a.getString(d2.a(e2, b3), null));
        }
        return b2;
    }

    public synchronized void h(boolean z) {
        this.k = z;
    }

    public final void i() {
        c.d.c.q.a.a aVar = this.f9996b;
        if (aVar != null) {
            aVar.c();
        } else if (k(g())) {
            synchronized (this) {
                if (!this.k) {
                    j(0L);
                }
            }
        }
    }

    public synchronized void j(long j2) {
        b(new p0(this, Math.min(Math.max(30L, j2 + j2), m)), j2);
        this.k = true;
    }

    public boolean k(o0.a aVar) {
        if (aVar != null) {
            if (!(System.currentTimeMillis() > aVar.f9568c + o0.a.f9565d || !this.f10004j.a().equals(aVar.f9567b))) {
                return false;
            }
        }
        return true;
    }
}