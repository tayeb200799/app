package com.google.firebase.installations;

import androidx.annotation.Keep;
import c.d.a.d.a;
import c.d.c.g;
import c.d.c.k.d0;
import c.d.c.k.m;
import c.d.c.k.o;
import c.d.c.k.p;
import c.d.c.k.u;
import c.d.c.p.f;
import c.d.c.s.h;
import java.util.Arrays;
import java.util.List;

@Keep
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\com\google\firebase\installations\FirebaseInstallationsRegistrar.smali */
public class FirebaseInstallationsRegistrar implements p {
    @Override // c.d.c.k.p
    public List<m<?>> getComponents() {
        m.b a2 = m.a(h.class);
        a2.a(new u(g.class, 1, 0));
        a2.a(new u(f.class, 0, 1));
        a2.a(new u(c.d.c.v.h.class, 0, 1));
        a2.c(new o() { // from class: c.d.c.s.d
            @Override // c.d.c.k.o
            public final Object a(c.d.c.k.n nVar) {
                d0 d0Var = (d0) nVar;
                return new g((c.d.c.g) d0Var.a(c.d.c.g.class), d0Var.c(c.d.c.v.h.class), d0Var.c(c.d.c.p.f.class));
            }
        });
        return Arrays.asList(a2.b(), a.n("fire-installations", "17.0.0"));
    }
}