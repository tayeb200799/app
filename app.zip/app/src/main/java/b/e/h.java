package b.e;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\e\h.smali */
public class h<K, V> {

    /* renamed from: g, reason: collision with root package name */
    public static Object[] f1194g;

    /* renamed from: h, reason: collision with root package name */
    public static int f1195h;

    /* renamed from: i, reason: collision with root package name */
    public static Object[] f1196i;

    /* renamed from: j, reason: collision with root package name */
    public static int f1197j;

    /* renamed from: d, reason: collision with root package name */
    public int[] f1198d;

    /* renamed from: e, reason: collision with root package name */
    public Object[] f1199e;

    /* renamed from: f, reason: collision with root package name */
    public int f1200f;

    public h() {
        this.f1198d = d.f1164a;
        this.f1199e = d.f1166c;
        this.f1200f = 0;
    }

    public h(int i2) {
        if (i2 == 0) {
            this.f1198d = d.f1164a;
            this.f1199e = d.f1166c;
        } else {
            a(i2);
        }
        this.f1200f = 0;
    }

    public static void c(int[] iArr, Object[] objArr, int i2) {
        if (iArr.length == 8) {
            synchronized (h.class) {
                if (f1197j < 10) {
                    objArr[0] = f1196i;
                    objArr[1] = iArr;
                    for (int i3 = (i2 << 1) - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f1196i = objArr;
                    f1197j++;
                }
            }
            return;
        }
        if (iArr.length == 4) {
            synchronized (h.class) {
                if (f1195h < 10) {
                    objArr[0] = f1194g;
                    objArr[1] = iArr;
                    for (int i4 = (i2 << 1) - 1; i4 >= 2; i4--) {
                        objArr[i4] = null;
                    }
                    f1194g = objArr;
                    f1195h++;
                }
            }
        }
    }

    public final void a(int i2) {
        if (i2 == 8) {
            synchronized (h.class) {
                Object[] objArr = f1196i;
                if (objArr != null) {
                    this.f1199e = objArr;
                    f1196i = (Object[]) objArr[0];
                    this.f1198d = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f1197j--;
                    return;
                }
            }
        } else if (i2 == 4) {
            synchronized (h.class) {
                Object[] objArr2 = f1194g;
                if (objArr2 != null) {
                    this.f1199e = objArr2;
                    f1194g = (Object[]) objArr2[0];
                    this.f1198d = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f1195h--;
                    return;
                }
            }
        }
        this.f1198d = new int[i2];
        this.f1199e = new Object[i2 << 1];
    }

    public void b(int i2) {
        int i3 = this.f1200f;
        int[] iArr = this.f1198d;
        if (iArr.length < i2) {
            Object[] objArr = this.f1199e;
            a(i2);
            if (this.f1200f > 0) {
                System.arraycopy(iArr, 0, this.f1198d, 0, i3);
                System.arraycopy(objArr, 0, this.f1199e, 0, i3 << 1);
            }
            c(iArr, objArr, i3);
        }
        if (this.f1200f != i3) {
            throw new ConcurrentModificationException();
        }
    }

    public void clear() {
        int i2 = this.f1200f;
        if (i2 > 0) {
            int[] iArr = this.f1198d;
            Object[] objArr = this.f1199e;
            this.f1198d = d.f1164a;
            this.f1199e = d.f1166c;
            this.f1200f = 0;
            c(iArr, objArr, i2);
        }
        if (this.f1200f > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object obj) {
        return e(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return g(obj) >= 0;
    }

    public int d(Object obj, int i2) {
        int i3 = this.f1200f;
        if (i3 == 0) {
            return -1;
        }
        try {
            int a2 = d.a(this.f1198d, i3, i2);
            if (a2 < 0 || obj.equals(this.f1199e[a2 << 1])) {
                return a2;
            }
            int i4 = a2 + 1;
            while (i4 < i3 && this.f1198d[i4] == i2) {
                if (obj.equals(this.f1199e[i4 << 1])) {
                    return i4;
                }
                i4++;
            }
            for (int i5 = a2 - 1; i5 >= 0 && this.f1198d[i5] == i2; i5--) {
                if (obj.equals(this.f1199e[i5 << 1])) {
                    return i5;
                }
            }
            return ~i4;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public int e(Object obj) {
        return obj == null ? f() : d(obj, obj.hashCode());
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof h) {
            h hVar = (h) obj;
            if (this.f1200f != hVar.f1200f) {
                return false;
            }
            for (int i2 = 0; i2 < this.f1200f; i2++) {
                try {
                    K h2 = h(i2);
                    V l = l(i2);
                    Object obj2 = hVar.get(h2);
                    if (l == null) {
                        if (obj2 != null || !hVar.containsKey(h2)) {
                            return false;
                        }
                    } else if (!l.equals(obj2)) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (this.f1200f != map.size()) {
                return false;
            }
            for (int i3 = 0; i3 < this.f1200f; i3++) {
                try {
                    K h3 = h(i3);
                    V l2 = l(i3);
                    Object obj3 = map.get(h3);
                    if (l2 == null) {
                        if (obj3 != null || !map.containsKey(h3)) {
                            return false;
                        }
                    } else if (!l2.equals(obj3)) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    public int f() {
        int i2 = this.f1200f;
        if (i2 == 0) {
            return -1;
        }
        try {
            int a2 = d.a(this.f1198d, i2, 0);
            if (a2 < 0 || this.f1199e[a2 << 1] == null) {
                return a2;
            }
            int i3 = a2 + 1;
            while (i3 < i2 && this.f1198d[i3] == 0) {
                if (this.f1199e[i3 << 1] == null) {
                    return i3;
                }
                i3++;
            }
            for (int i4 = a2 - 1; i4 >= 0 && this.f1198d[i4] == 0; i4--) {
                if (this.f1199e[i4 << 1] == null) {
                    return i4;
                }
            }
            return ~i3;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public int g(Object obj) {
        int i2 = this.f1200f * 2;
        Object[] objArr = this.f1199e;
        if (obj == null) {
            for (int i3 = 1; i3 < i2; i3 += 2) {
                if (objArr[i3] == null) {
                    return i3 >> 1;
                }
            }
            return -1;
        }
        for (int i4 = 1; i4 < i2; i4 += 2) {
            if (obj.equals(objArr[i4])) {
                return i4 >> 1;
            }
        }
        return -1;
    }

    public V get(Object obj) {
        return getOrDefault(obj, null);
    }

    public V getOrDefault(Object obj, V v) {
        int e2 = e(obj);
        return e2 >= 0 ? (V) this.f1199e[(e2 << 1) + 1] : v;
    }

    public K h(int i2) {
        return (K) this.f1199e[i2 << 1];
    }

    public int hashCode() {
        int[] iArr = this.f1198d;
        Object[] objArr = this.f1199e;
        int i2 = this.f1200f;
        int i3 = 1;
        int i4 = 0;
        int i5 = 0;
        while (i4 < i2) {
            Object obj = objArr[i3];
            i5 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i4];
            i4++;
            i3 += 2;
        }
        return i5;
    }

    public void i(h<? extends K, ? extends V> hVar) {
        int i2 = hVar.f1200f;
        b(this.f1200f + i2);
        if (this.f1200f != 0) {
            for (int i3 = 0; i3 < i2; i3++) {
                put(hVar.h(i3), hVar.l(i3));
            }
        } else if (i2 > 0) {
            System.arraycopy(hVar.f1198d, 0, this.f1198d, 0, i2);
            System.arraycopy(hVar.f1199e, 0, this.f1199e, 0, i2 << 1);
            this.f1200f = i2;
        }
    }

    public boolean isEmpty() {
        return this.f1200f <= 0;
    }

    public V j(int i2) {
        Object[] objArr = this.f1199e;
        int i3 = i2 << 1;
        V v = (V) objArr[i3 + 1];
        int i4 = this.f1200f;
        int i5 = 0;
        if (i4 <= 1) {
            c(this.f1198d, objArr, i4);
            this.f1198d = d.f1164a;
            this.f1199e = d.f1166c;
        } else {
            int i6 = i4 - 1;
            int[] iArr = this.f1198d;
            if (iArr.length <= 8 || i4 >= iArr.length / 3) {
                if (i2 < i6) {
                    int i7 = i2 + 1;
                    int i8 = i6 - i2;
                    System.arraycopy(iArr, i7, iArr, i2, i8);
                    Object[] objArr2 = this.f1199e;
                    System.arraycopy(objArr2, i7 << 1, objArr2, i3, i8 << 1);
                }
                Object[] objArr3 = this.f1199e;
                int i9 = i6 << 1;
                objArr3[i9] = null;
                objArr3[i9 + 1] = null;
            } else {
                a(i4 > 8 ? i4 + (i4 >> 1) : 8);
                if (i4 != this.f1200f) {
                    throw new ConcurrentModificationException();
                }
                if (i2 > 0) {
                    System.arraycopy(iArr, 0, this.f1198d, 0, i2);
                    System.arraycopy(objArr, 0, this.f1199e, 0, i3);
                }
                if (i2 < i6) {
                    int i10 = i2 + 1;
                    int i11 = i6 - i2;
                    System.arraycopy(iArr, i10, this.f1198d, i2, i11);
                    System.arraycopy(objArr, i10 << 1, this.f1199e, i3, i11 << 1);
                }
            }
            i5 = i6;
        }
        if (i4 != this.f1200f) {
            throw new ConcurrentModificationException();
        }
        this.f1200f = i5;
        return v;
    }

    public V k(int i2, V v) {
        int i3 = (i2 << 1) + 1;
        Object[] objArr = this.f1199e;
        V v2 = (V) objArr[i3];
        objArr[i3] = v;
        return v2;
    }

    public V l(int i2) {
        return (V) this.f1199e[(i2 << 1) + 1];
    }

    public V put(K k, V v) {
        int i2;
        int d2;
        int i3 = this.f1200f;
        if (k == null) {
            d2 = f();
            i2 = 0;
        } else {
            int hashCode = k.hashCode();
            i2 = hashCode;
            d2 = d(k, hashCode);
        }
        if (d2 >= 0) {
            int i4 = (d2 << 1) + 1;
            Object[] objArr = this.f1199e;
            V v2 = (V) objArr[i4];
            objArr[i4] = v;
            return v2;
        }
        int i5 = ~d2;
        int[] iArr = this.f1198d;
        if (i3 >= iArr.length) {
            int i6 = 4;
            if (i3 >= 8) {
                i6 = (i3 >> 1) + i3;
            } else if (i3 >= 4) {
                i6 = 8;
            }
            Object[] objArr2 = this.f1199e;
            a(i6);
            if (i3 != this.f1200f) {
                throw new ConcurrentModificationException();
            }
            int[] iArr2 = this.f1198d;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr2, 0, this.f1199e, 0, objArr2.length);
            }
            c(iArr, objArr2, i3);
        }
        if (i5 < i3) {
            int[] iArr3 = this.f1198d;
            int i7 = i5 + 1;
            System.arraycopy(iArr3, i5, iArr3, i7, i3 - i5);
            Object[] objArr3 = this.f1199e;
            System.arraycopy(objArr3, i5 << 1, objArr3, i7 << 1, (this.f1200f - i5) << 1);
        }
        int i8 = this.f1200f;
        if (i3 == i8) {
            int[] iArr4 = this.f1198d;
            if (i5 < iArr4.length) {
                iArr4[i5] = i2;
                Object[] objArr4 = this.f1199e;
                int i9 = i5 << 1;
                objArr4[i9] = k;
                objArr4[i9 + 1] = v;
                this.f1200f = i8 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V orDefault = getOrDefault(k, null);
        return orDefault == null ? put(k, v) : orDefault;
    }

    public V remove(Object obj) {
        int e2 = e(obj);
        if (e2 >= 0) {
            return j(e2);
        }
        return null;
    }

    public boolean remove(Object obj, Object obj2) {
        int e2 = e(obj);
        if (e2 < 0) {
            return false;
        }
        V l = l(e2);
        if (obj2 != l && (obj2 == null || !obj2.equals(l))) {
            return false;
        }
        j(e2);
        return true;
    }

    public V replace(K k, V v) {
        int e2 = e(k);
        if (e2 >= 0) {
            return k(e2, v);
        }
        return null;
    }

    public boolean replace(K k, V v, V v2) {
        int e2 = e(k);
        if (e2 < 0) {
            return false;
        }
        V l = l(e2);
        if (l != v && (v == null || !v.equals(l))) {
            return false;
        }
        k(e2, v2);
        return true;
    }

    public int size() {
        return this.f1200f;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1200f * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.f1200f; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            K h2 = h(i2);
            if (h2 != this) {
                sb.append(h2);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            V l = l(i2);
            if (l != this) {
                sb.append(l);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
