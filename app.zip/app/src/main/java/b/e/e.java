package b.e;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\e\e.smali */
public class e<E> implements Cloneable {

    /* renamed from: h, reason: collision with root package name */
    public static final Object f1167h = new Object();

    /* renamed from: d, reason: collision with root package name */
    public boolean f1168d = false;

    /* renamed from: e, reason: collision with root package name */
    public long[] f1169e;

    /* renamed from: f, reason: collision with root package name */
    public Object[] f1170f;

    /* renamed from: g, reason: collision with root package name */
    public int f1171g;

    public e() {
        int f2 = d.f(10);
        this.f1169e = new long[f2];
        this.f1170f = new Object[f2];
    }

    public void b(long j2, E e2) {
        int i2 = this.f1171g;
        if (i2 != 0 && j2 <= this.f1169e[i2 - 1]) {
            h(j2, e2);
            return;
        }
        if (this.f1168d && i2 >= this.f1169e.length) {
            e();
        }
        int i3 = this.f1171g;
        if (i3 >= this.f1169e.length) {
            int f2 = d.f(i3 + 1);
            long[] jArr = new long[f2];
            Object[] objArr = new Object[f2];
            long[] jArr2 = this.f1169e;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr2 = this.f1170f;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.f1169e = jArr;
            this.f1170f = objArr;
        }
        this.f1169e[i3] = j2;
        this.f1170f[i3] = e2;
        this.f1171g = i3 + 1;
    }

    public void c() {
        int i2 = this.f1171g;
        Object[] objArr = this.f1170f;
        for (int i3 = 0; i3 < i2; i3++) {
            objArr[i3] = null;
        }
        this.f1171g = 0;
        this.f1168d = false;
    }

    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public e<E> clone() {
        try {
            e<E> eVar = (e) super.clone();
            eVar.f1169e = (long[]) this.f1169e.clone();
            eVar.f1170f = (Object[]) this.f1170f.clone();
            return eVar;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public final void e() {
        int i2 = this.f1171g;
        long[] jArr = this.f1169e;
        Object[] objArr = this.f1170f;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != f1167h) {
                if (i4 != i3) {
                    jArr[i3] = jArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.f1168d = false;
        this.f1171g = i3;
    }

    public E f(long j2) {
        return g(j2, null);
    }

    public E g(long j2, E e2) {
        int b2 = d.b(this.f1169e, this.f1171g, j2);
        if (b2 >= 0) {
            Object[] objArr = this.f1170f;
            if (objArr[b2] != f1167h) {
                return (E) objArr[b2];
            }
        }
        return e2;
    }

    public void h(long j2, E e2) {
        int b2 = d.b(this.f1169e, this.f1171g, j2);
        if (b2 >= 0) {
            this.f1170f[b2] = e2;
            return;
        }
        int i2 = ~b2;
        int i3 = this.f1171g;
        if (i2 < i3) {
            Object[] objArr = this.f1170f;
            if (objArr[i2] == f1167h) {
                this.f1169e[i2] = j2;
                objArr[i2] = e2;
                return;
            }
        }
        if (this.f1168d && i3 >= this.f1169e.length) {
            e();
            i2 = ~d.b(this.f1169e, this.f1171g, j2);
        }
        int i4 = this.f1171g;
        if (i4 >= this.f1169e.length) {
            int f2 = d.f(i4 + 1);
            long[] jArr = new long[f2];
            Object[] objArr2 = new Object[f2];
            long[] jArr2 = this.f1169e;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f1170f;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f1169e = jArr;
            this.f1170f = objArr2;
        }
        int i5 = this.f1171g;
        if (i5 - i2 != 0) {
            long[] jArr3 = this.f1169e;
            int i6 = i2 + 1;
            System.arraycopy(jArr3, i2, jArr3, i6, i5 - i2);
            Object[] objArr4 = this.f1170f;
            System.arraycopy(objArr4, i2, objArr4, i6, this.f1171g - i2);
        }
        this.f1169e[i2] = j2;
        this.f1170f[i2] = e2;
        this.f1171g++;
    }

    public int i() {
        if (this.f1168d) {
            e();
        }
        return this.f1171g;
    }

    public E k(int i2) {
        if (this.f1168d) {
            e();
        }
        return (E) this.f1170f[i2];
    }

    public String toString() {
        if (i() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1171g * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.f1171g; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            if (this.f1168d) {
                e();
            }
            sb.append(this.f1169e[i2]);
            sb.append('=');
            E k = k(i2);
            if (k != this) {
                sb.append(k);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
