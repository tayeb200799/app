package b.f.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\c.smali */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public e<b> f1218a = new e<>(256);

    /* renamed from: b, reason: collision with root package name */
    public e<b> f1219b = new e<>(256);

    /* renamed from: c, reason: collision with root package name */
    public e<g> f1220c = new e<>(256);

    /* renamed from: d, reason: collision with root package name */
    public g[] f1221d = new g[32];
}
