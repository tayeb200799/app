package b.p;

import android.app.Application;
import java.lang.reflect.InvocationTargetException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\y.smali */
public class y {

    /* renamed from: a, reason: collision with root package name */
    public final b f2164a;

    /* renamed from: b, reason: collision with root package name */
    public final z f2165b;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\y$a.smali */
    public static class a extends d {

        /* renamed from: b, reason: collision with root package name */
        public static a f2166b;

        /* renamed from: a, reason: collision with root package name */
        public Application f2167a;

        public a(Application application) {
            this.f2167a = application;
        }

        @Override // b.p.y.d, b.p.y.b
        public <T extends x> T a(Class<T> cls) {
            if (!b.p.a.class.isAssignableFrom(cls)) {
                return (T) super.a(cls);
            }
            try {
                return cls.getConstructor(Application.class).newInstance(this.f2167a);
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            } catch (NoSuchMethodException e4) {
                throw new RuntimeException("Cannot create an instance of " + cls, e4);
            } catch (InvocationTargetException e5) {
                throw new RuntimeException("Cannot create an instance of " + cls, e5);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\y$b.smali */
    public interface b {
        <T extends x> T a(Class<T> cls);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\y$c.smali */
    public static abstract class c extends e implements b {
        public <T extends x> T a(Class<T> cls) {
            throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
        }

        public abstract <T extends x> T c(String str, Class<T> cls);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\y$d.smali */
    public static class d implements b {
        @Override // b.p.y.b
        public <T extends x> T a(Class<T> cls) {
            try {
                return cls.newInstance();
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\y$e.smali */
    public static class e {
        public void b(x xVar) {
        }
    }

    public y(a0 a0Var) {
        this(a0Var.q(), ((f) a0Var).l());
    }

    public y(z zVar, b bVar) {
        this.f2164a = bVar;
        this.f2165b = zVar;
    }

    public <T extends x> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        String f2 = c.a.a.a.a.f("androidx.lifecycle.ViewModelProvider.DefaultKey:", canonicalName);
        T t = (T) this.f2165b.f2168a.get(f2);
        if (cls.isInstance(t)) {
            Object obj = this.f2164a;
            if (obj instanceof e) {
                ((e) obj).b(t);
            }
        } else {
            b bVar = this.f2164a;
            t = (T) (bVar instanceof c ? ((c) bVar).c(f2, cls) : bVar.a(cls));
            x put = this.f2165b.f2168a.put(f2, t);
            if (put != null) {
                put.d();
            }
        }
        return t;
    }
}
