package b.p;

import android.os.Handler;
import b.p.g;
import b.p.u;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\s.smali */
public class s implements k {
    public static final s l = new s();

    /* renamed from: h, reason: collision with root package name */
    public Handler f2141h;

    /* renamed from: d, reason: collision with root package name */
    public int f2137d = 0;

    /* renamed from: e, reason: collision with root package name */
    public int f2138e = 0;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2139f = true;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2140g = true;

    /* renamed from: i, reason: collision with root package name */
    public final l f2142i = new l(this);

    /* renamed from: j, reason: collision with root package name */
    public Runnable f2143j = new a();
    public u.a k = new b();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\s$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            s sVar = s.this;
            if (sVar.f2138e == 0) {
                sVar.f2139f = true;
                sVar.f2142i.d(g.a.ON_PAUSE);
            }
            s sVar2 = s.this;
            if (sVar2.f2137d == 0 && sVar2.f2139f) {
                sVar2.f2142i.d(g.a.ON_STOP);
                sVar2.f2140g = true;
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\s$b.smali */
    public class b implements u.a {
        public b() {
        }
    }

    @Override // b.p.k
    public g a() {
        return this.f2142i;
    }

    public void b() {
        int i2 = this.f2138e + 1;
        this.f2138e = i2;
        if (i2 == 1) {
            if (!this.f2139f) {
                this.f2141h.removeCallbacks(this.f2143j);
            } else {
                this.f2142i.d(g.a.ON_RESUME);
                this.f2139f = false;
            }
        }
    }

    public void e() {
        int i2 = this.f2137d + 1;
        this.f2137d = i2;
        if (i2 == 1 && this.f2140g) {
            this.f2142i.d(g.a.ON_START);
            this.f2140g = false;
        }
    }
}
