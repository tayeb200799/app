package b.p;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\x.smali */
public abstract class x {

    /* renamed from: a, reason: collision with root package name */
    public final Map<String, Object> f2162a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public volatile boolean f2163b = false;

    public void d() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <T> T e(String str, T t) {
        Object obj;
        synchronized (this.f2162a) {
            obj = this.f2162a.get(str);
            if (obj == 0) {
                this.f2162a.put(str, t);
            }
        }
        if (obj != 0) {
            t = obj;
        }
        if (this.f2163b && (t instanceof Closeable)) {
            try {
                ((Closeable) t).close();
            } catch (IOException e2) {
                throw new RuntimeException(e2);
            }
        }
        return t;
    }
}
