package b.p;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\z.smali */
public class z {

    /* renamed from: a, reason: collision with root package name */
    public final HashMap<String, x> f2168a = new HashMap<>();

    public final void a() {
        for (x xVar : this.f2168a.values()) {
            xVar.f2163b = true;
            Map<String, Object> map = xVar.f2162a;
            if (map != null) {
                synchronized (map) {
                    for (Object obj : xVar.f2162a.values()) {
                        if (obj instanceof Closeable) {
                            try {
                                ((Closeable) obj).close();
                            } catch (IOException e2) {
                                throw new RuntimeException(e2);
                            }
                        }
                    }
                }
            }
            xVar.d();
        }
        this.f2168a.clear();
    }
}
