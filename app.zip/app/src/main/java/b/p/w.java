package b.p;

import android.annotation.SuppressLint;
import android.app.Application;
import android.os.Bundle;
import androidx.lifecycle.SavedStateHandleController;
import b.p.y;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\w.smali */
public final class w extends y.c {

    /* renamed from: f, reason: collision with root package name */
    public static final Class<?>[] f2155f = {Application.class, v.class};

    /* renamed from: g, reason: collision with root package name */
    public static final Class<?>[] f2156g = {v.class};

    /* renamed from: a, reason: collision with root package name */
    public final Application f2157a;

    /* renamed from: b, reason: collision with root package name */
    public final y.a f2158b;

    /* renamed from: c, reason: collision with root package name */
    public final Bundle f2159c;

    /* renamed from: d, reason: collision with root package name */
    public final g f2160d;

    /* renamed from: e, reason: collision with root package name */
    public final b.v.a f2161e;

    @SuppressLint({"LambdaLast"})
    public w(Application application, b.v.c cVar, Bundle bundle) {
        this.f2161e = cVar.d();
        this.f2160d = cVar.a();
        this.f2159c = bundle;
        this.f2157a = application;
        if (y.a.f2166b == null) {
            y.a.f2166b = new y.a(application);
        }
        this.f2158b = y.a.f2166b;
    }

    public static <T> Constructor<T> d(Class<T> cls, Class<?>[] clsArr) {
        for (Object obj : cls.getConstructors()) {
            Constructor<T> constructor = (Constructor<T>) obj;
            if (Arrays.equals(clsArr, constructor.getParameterTypes())) {
                return constructor;
            }
        }
        return null;
    }

    @Override // b.p.y.c, b.p.y.b
    public <T extends x> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return (T) c(canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Override // b.p.y.e
    public void b(x xVar) {
        SavedStateHandleController.h(xVar, this.f2161e, this.f2160d);
    }

    @Override // b.p.y.c
    public <T extends x> T c(String str, Class<T> cls) {
        v vVar;
        boolean isAssignableFrom = a.class.isAssignableFrom(cls);
        Constructor d2 = isAssignableFrom ? d(cls, f2155f) : d(cls, f2156g);
        if (d2 == null) {
            return (T) this.f2158b.a(cls);
        }
        b.v.a aVar = this.f2161e;
        g gVar = this.f2160d;
        Bundle bundle = this.f2159c;
        Bundle a2 = aVar.a(str);
        int i2 = v.f2151c;
        if (a2 == null && bundle == null) {
            vVar = new v();
        } else {
            HashMap hashMap = new HashMap();
            if (bundle != null) {
                for (String str2 : bundle.keySet()) {
                    hashMap.put(str2, bundle.get(str2));
                }
            }
            if (a2 == null) {
                vVar = new v(hashMap);
            } else {
                ArrayList parcelableArrayList = a2.getParcelableArrayList("keys");
                ArrayList parcelableArrayList2 = a2.getParcelableArrayList("values");
                if (parcelableArrayList == null || parcelableArrayList2 == null || parcelableArrayList.size() != parcelableArrayList2.size()) {
                    throw new IllegalStateException("Invalid bundle passed as restored state");
                }
                for (int i3 = 0; i3 < parcelableArrayList.size(); i3++) {
                    hashMap.put((String) parcelableArrayList.get(i3), parcelableArrayList2.get(i3));
                }
                vVar = new v(hashMap);
            }
        }
        SavedStateHandleController savedStateHandleController = new SavedStateHandleController(str, vVar);
        savedStateHandleController.i(aVar, gVar);
        SavedStateHandleController.j(aVar, gVar);
        try {
            T t = isAssignableFrom ? (T) d2.newInstance(this.f2157a, savedStateHandleController.f358c) : (T) d2.newInstance(savedStateHandleController.f358c);
            t.e("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
            return t;
        } catch (IllegalAccessException e2) {
            throw new RuntimeException("Failed to access " + cls, e2);
        } catch (InstantiationException e3) {
            throw new RuntimeException("A " + cls + " cannot be instantiated.", e3);
        } catch (InvocationTargetException e4) {
            throw new RuntimeException("An exception happened in constructor of " + cls, e4.getCause());
        }
    }
}
