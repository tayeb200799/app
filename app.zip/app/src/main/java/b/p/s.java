package b.p;

import android.os.Handler;
import b.p.g;
import b.p.u;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\s.smali */
public class s implements k {
    public static final s l = new s();

    /* renamed from: h, reason: collision with root package name */
    public Handler f2144h;

    /* renamed from: d, reason: collision with root package name */
    public int f2140d = 0;

    /* renamed from: e, reason: collision with root package name */
    public int f2141e = 0;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2142f = true;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2143g = true;

    /* renamed from: i, reason: collision with root package name */
    public final l f2145i = new l(this);

    /* renamed from: j, reason: collision with root package name */
    public Runnable f2146j = new a();
    public u.a k = new b();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\s$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            s sVar = s.this;
            if (sVar.f2141e == 0) {
                sVar.f2142f = true;
                sVar.f2145i.d(g.a.ON_PAUSE);
            }
            s sVar2 = s.this;
            if (sVar2.f2140d == 0 && sVar2.f2142f) {
                sVar2.f2145i.d(g.a.ON_STOP);
                sVar2.f2143g = true;
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\s$b.smali */
    public class b implements u.a {
        public b() {
        }
    }

    @Override // b.p.k
    public g a() {
        return this.f2145i;
    }

    public void b() {
        int i2 = this.f2141e + 1;
        this.f2141e = i2;
        if (i2 == 1) {
            if (!this.f2142f) {
                this.f2144h.removeCallbacks(this.f2146j);
            } else {
                this.f2145i.d(g.a.ON_RESUME);
                this.f2142f = false;
            }
        }
    }

    public void e() {
        int i2 = this.f2140d + 1;
        this.f2140d = i2;
        if (i2 == 1 && this.f2143g) {
            this.f2145i.d(g.a.ON_START);
            this.f2143g = false;
        }
    }
}
