package b.p;

import androidx.lifecycle.LiveData;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\p.smali */
public class p<T> extends LiveData<T> {
    @Override // androidx.lifecycle.LiveData
    public void i(T t) {
        LiveData.a("setValue");
        this.f343f++;
        this.f341d = t;
        c(null);
    }

    public void j(T t) {
        boolean z;
        synchronized (this.f338a) {
            z = this.f342e == LiveData.f337j;
            this.f342e = t;
        }
        if (z) {
            b.c.a.a.a.d().f1123a.c(this.f346i);
        }
    }
}
