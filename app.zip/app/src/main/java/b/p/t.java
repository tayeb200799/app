package b.p;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import b.p.g;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\t.smali */
public class t extends c {
    public final /* synthetic */ s this$0;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\t$a.smali */
    public class a extends c {
        public a() {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            t.this.this$0.b();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            t.this.this$0.e();
        }
    }

    public t(s sVar) {
        this.this$0 = sVar;
    }

    @Override // b.p.c, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        if (Build.VERSION.SDK_INT < 29) {
            int i2 = u.f2149e;
            ((u) activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag")).f2150d = this.this$0.k;
        }
    }

    @Override // b.p.c, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        s sVar = this.this$0;
        int i2 = sVar.f2141e - 1;
        sVar.f2141e = i2;
        if (i2 == 0) {
            sVar.f2144h.postDelayed(sVar.f2146j, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        activity.registerActivityLifecycleCallbacks(new a());
    }

    @Override // b.p.c, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        s sVar = this.this$0;
        int i2 = sVar.f2140d - 1;
        sVar.f2140d = i2;
        if (i2 == 0 && sVar.f2142f) {
            sVar.f2145i.d(g.a.ON_STOP);
            sVar.f2143g = true;
        }
    }
}
