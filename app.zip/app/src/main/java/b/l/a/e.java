package b.l.a;

import b.l.a.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\e.smali */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public double f1894a;

    /* renamed from: b, reason: collision with root package name */
    public double f1895b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1896c;

    /* renamed from: d, reason: collision with root package name */
    public double f1897d;

    /* renamed from: e, reason: collision with root package name */
    public double f1898e;

    /* renamed from: f, reason: collision with root package name */
    public double f1899f;

    /* renamed from: g, reason: collision with root package name */
    public double f1900g;

    /* renamed from: h, reason: collision with root package name */
    public double f1901h;

    /* renamed from: i, reason: collision with root package name */
    public double f1902i;

    /* renamed from: j, reason: collision with root package name */
    public final b.h f1903j;

    public e() {
        this.f1894a = Math.sqrt(1500.0d);
        this.f1895b = 0.5d;
        this.f1896c = false;
        this.f1902i = Double.MAX_VALUE;
        this.f1903j = new b.h();
    }

    public e(float f2) {
        this.f1894a = Math.sqrt(1500.0d);
        this.f1895b = 0.5d;
        this.f1896c = false;
        this.f1902i = Double.MAX_VALUE;
        this.f1903j = new b.h();
        this.f1902i = f2;
    }

    public e a(float f2) {
        if (f2 <= 0.0f) {
            throw new IllegalArgumentException("Spring stiffness constant must be positive.");
        }
        this.f1894a = Math.sqrt(f2);
        this.f1896c = false;
        return this;
    }

    public b.h b(double d2, double d3, long j2) {
        double cos;
        double d4;
        if (!this.f1896c) {
            if (this.f1902i == Double.MAX_VALUE) {
                throw new IllegalStateException("Error: Final position of the spring must be set before the animation starts");
            }
            double d5 = this.f1895b;
            if (d5 > 1.0d) {
                double d6 = this.f1894a;
                this.f1899f = (Math.sqrt((d5 * d5) - 1.0d) * d6) + ((-d5) * d6);
                double d7 = this.f1895b;
                double d8 = this.f1894a;
                this.f1900g = ((-d7) * d8) - (Math.sqrt((d7 * d7) - 1.0d) * d8);
            } else if (d5 >= 0.0d && d5 < 1.0d) {
                this.f1901h = Math.sqrt(1.0d - (d5 * d5)) * this.f1894a;
            }
            this.f1896c = true;
        }
        double d9 = j2 / 1000.0d;
        double d10 = d2 - this.f1902i;
        double d11 = this.f1895b;
        if (d11 > 1.0d) {
            double d12 = this.f1900g;
            double d13 = this.f1899f;
            double d14 = d10 - (((d12 * d10) - d3) / (d12 - d13));
            double d15 = ((d10 * d12) - d3) / (d12 - d13);
            d4 = (Math.pow(2.718281828459045d, this.f1899f * d9) * d15) + (Math.pow(2.718281828459045d, d12 * d9) * d14);
            double d16 = this.f1900g;
            double pow = Math.pow(2.718281828459045d, d16 * d9) * d14 * d16;
            double d17 = this.f1899f;
            cos = (Math.pow(2.718281828459045d, d17 * d9) * d15 * d17) + pow;
        } else if (d11 == 1.0d) {
            double d18 = this.f1894a;
            double d19 = (d18 * d10) + d3;
            double d20 = (d19 * d9) + d10;
            double pow2 = Math.pow(2.718281828459045d, (-d18) * d9) * d20;
            double pow3 = Math.pow(2.718281828459045d, (-this.f1894a) * d9) * d20;
            double d21 = this.f1894a;
            cos = (Math.pow(2.718281828459045d, (-d21) * d9) * d19) + (pow3 * (-d21));
            d4 = pow2;
        } else {
            double d22 = 1.0d / this.f1901h;
            double d23 = this.f1894a;
            double d24 = ((d11 * d23 * d10) + d3) * d22;
            double sin = ((Math.sin(this.f1901h * d9) * d24) + (Math.cos(this.f1901h * d9) * d10)) * Math.pow(2.718281828459045d, (-d11) * d23 * d9);
            double d25 = this.f1894a;
            double d26 = this.f1895b;
            double d27 = (-d25) * sin * d26;
            double pow4 = Math.pow(2.718281828459045d, (-d26) * d25 * d9);
            double d28 = this.f1901h;
            double sin2 = Math.sin(d28 * d9) * (-d28) * d10;
            double d29 = this.f1901h;
            cos = (((Math.cos(d29 * d9) * d24 * d29) + sin2) * pow4) + d27;
            d4 = sin;
        }
        b.h hVar = this.f1903j;
        hVar.f1892a = (float) (d4 + this.f1902i);
        hVar.f1893b = (float) cos;
        return hVar;
    }
}
