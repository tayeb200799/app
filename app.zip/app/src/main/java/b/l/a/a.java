package b.l.a;

import android.view.Choreographer;
import b.e.h;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\a.smali */
public class a {

    /* renamed from: g, reason: collision with root package name */
    public static final ThreadLocal<a> f1870g = new ThreadLocal<>();

    /* renamed from: d, reason: collision with root package name */
    public c f1874d;

    /* renamed from: a, reason: collision with root package name */
    public final h<b, Long> f1871a = new h<>();

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList<b> f1872b = new ArrayList<>();

    /* renamed from: c, reason: collision with root package name */
    public final C0039a f1873c = new C0039a();

    /* renamed from: e, reason: collision with root package name */
    public long f1875e = 0;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1876f = false;

    /* renamed from: b.l.a.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\a$a.smali */
    public class C0039a {
        public C0039a() {
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x0043  */
        /* JADX WARN: Removed duplicated region for block: B:16:0x0046 A[SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void a() {
            /*
                r11 = this;
                b.l.a.a r0 = b.l.a.a.this
                long r1 = android.os.SystemClock.uptimeMillis()
                r0.f1875e = r1
                b.l.a.a r0 = b.l.a.a.this
                long r1 = r0.f1875e
                long r3 = android.os.SystemClock.uptimeMillis()
                r5 = 0
                r6 = 0
            L12:
                java.util.ArrayList<b.l.a.a$b> r7 = r0.f1872b
                int r7 = r7.size()
                if (r6 >= r7) goto L49
                java.util.ArrayList<b.l.a.a$b> r7 = r0.f1872b
                java.lang.Object r7 = r7.get(r6)
                b.l.a.a$b r7 = (b.l.a.a.b) r7
                if (r7 != 0) goto L25
                goto L46
            L25:
                b.e.h<b.l.a.a$b, java.lang.Long> r8 = r0.f1871a
                r9 = 0
                java.lang.Object r8 = r8.getOrDefault(r7, r9)
                java.lang.Long r8 = (java.lang.Long) r8
                if (r8 != 0) goto L31
                goto L3e
            L31:
                long r8 = r8.longValue()
                int r10 = (r8 > r3 ? 1 : (r8 == r3 ? 0 : -1))
                if (r10 >= 0) goto L40
                b.e.h<b.l.a.a$b, java.lang.Long> r8 = r0.f1871a
                r8.remove(r7)
            L3e:
                r8 = 1
                goto L41
            L40:
                r8 = 0
            L41:
                if (r8 == 0) goto L46
                r7.a(r1)
            L46:
                int r6 = r6 + 1
                goto L12
            L49:
                boolean r1 = r0.f1876f
                if (r1 == 0) goto L67
                java.util.ArrayList<b.l.a.a$b> r1 = r0.f1872b
                int r1 = r1.size()
            L53:
                int r1 = r1 + (-1)
                if (r1 < 0) goto L65
                java.util.ArrayList<b.l.a.a$b> r2 = r0.f1872b
                java.lang.Object r2 = r2.get(r1)
                if (r2 != 0) goto L53
                java.util.ArrayList<b.l.a.a$b> r2 = r0.f1872b
                r2.remove(r1)
                goto L53
            L65:
                r0.f1876f = r5
            L67:
                b.l.a.a r0 = b.l.a.a.this
                java.util.ArrayList<b.l.a.a$b> r0 = r0.f1872b
                int r0 = r0.size()
                if (r0 <= 0) goto L8b
                b.l.a.a r0 = b.l.a.a.this
                b.l.a.a$c r1 = r0.f1874d
                if (r1 != 0) goto L80
                b.l.a.a$d r1 = new b.l.a.a$d
                b.l.a.a$a r2 = r0.f1873c
                r1.<init>(r2)
                r0.f1874d = r1
            L80:
                b.l.a.a$c r0 = r0.f1874d
                b.l.a.a$d r0 = (b.l.a.a.d) r0
                android.view.Choreographer r1 = r0.f1879b
                android.view.Choreographer$FrameCallback r0 = r0.f1880c
                r1.postFrameCallback(r0)
            L8b:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: b.l.a.a.C0039a.a():void");
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\a$b.smali */
    public interface b {
        boolean a(long j2);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\a$c.smali */
    public static abstract class c {

        /* renamed from: a, reason: collision with root package name */
        public final C0039a f1878a;

        public c(C0039a c0039a) {
            this.f1878a = c0039a;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\a$d.smali */
    public static class d extends c {

        /* renamed from: b, reason: collision with root package name */
        public final Choreographer f1879b;

        /* renamed from: c, reason: collision with root package name */
        public final Choreographer.FrameCallback f1880c;

        /* renamed from: b.l.a.a$d$a, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\a$d$a.smali */
        public class ChoreographerFrameCallbackC0040a implements Choreographer.FrameCallback {
            public ChoreographerFrameCallbackC0040a() {
            }

            @Override // android.view.Choreographer.FrameCallback
            public void doFrame(long j2) {
                d.this.f1878a.a();
            }
        }

        public d(C0039a c0039a) {
            super(c0039a);
            this.f1879b = Choreographer.getInstance();
            this.f1880c = new ChoreographerFrameCallbackC0040a();
        }
    }

    public static a a() {
        ThreadLocal<a> threadLocal = f1870g;
        if (threadLocal.get() == null) {
            threadLocal.set(new a());
        }
        return threadLocal.get();
    }
}
