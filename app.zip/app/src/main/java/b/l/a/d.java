package b.l.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\d.smali */
public final class d extends b<d> {
    public e r;
    public float s;

    public <K> d(K k, c<K> cVar) {
        super(k, cVar);
        this.r = null;
        this.s = Float.MAX_VALUE;
    }
}
