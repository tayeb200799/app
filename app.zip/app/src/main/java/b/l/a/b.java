package b.l.a;

import android.os.Looper;
import android.util.AndroidRuntimeException;
import android.view.View;
import b.l.a.a;
import b.l.a.b;
import java.util.ArrayList;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b.smali */
public abstract class b<T extends b<T>> implements a.b {
    public static final k l = new c("scaleX");
    public static final k m = new d("scaleY");
    public static final k n = new e("rotation");
    public static final k o = new f("rotationX");
    public static final k p = new g("rotationY");
    public static final k q = new a("alpha");

    /* renamed from: d, reason: collision with root package name */
    public final Object f1885d;

    /* renamed from: e, reason: collision with root package name */
    public final b.l.a.c f1886e;

    /* renamed from: i, reason: collision with root package name */
    public float f1890i;

    /* renamed from: a, reason: collision with root package name */
    public float f1882a = 0.0f;

    /* renamed from: b, reason: collision with root package name */
    public float f1883b = Float.MAX_VALUE;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1884c = false;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1887f = false;

    /* renamed from: g, reason: collision with root package name */
    public float f1888g = -3.4028235E38f;

    /* renamed from: h, reason: collision with root package name */
    public long f1889h = 0;

    /* renamed from: j, reason: collision with root package name */
    public final ArrayList<i> f1891j = new ArrayList<>();
    public final ArrayList<j> k = new ArrayList<>();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$a.smali */
    public static class a extends k {
        public a(String str) {
            super(str, null);
        }

        @Override // b.l.a.c
        public float a(View view) {
            return view.getAlpha();
        }

        @Override // b.l.a.c
        public void b(View view, float f2) {
            view.setAlpha(f2);
        }
    }

    /* renamed from: b.l.a.b$b, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$b.smali */
    public static class C0041b extends k {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$c.smali */
    public static class c extends k {
        public c(String str) {
            super(str, null);
        }

        @Override // b.l.a.c
        public float a(View view) {
            return view.getScaleX();
        }

        @Override // b.l.a.c
        public void b(View view, float f2) {
            view.setScaleX(f2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$d.smali */
    public static class d extends k {
        public d(String str) {
            super(str, null);
        }

        @Override // b.l.a.c
        public float a(View view) {
            return view.getScaleY();
        }

        @Override // b.l.a.c
        public void b(View view, float f2) {
            view.setScaleY(f2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$e.smali */
    public static class e extends k {
        public e(String str) {
            super(str, null);
        }

        @Override // b.l.a.c
        public float a(View view) {
            return view.getRotation();
        }

        @Override // b.l.a.c
        public void b(View view, float f2) {
            view.setRotation(f2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$f.smali */
    public static class f extends k {
        public f(String str) {
            super(str, null);
        }

        @Override // b.l.a.c
        public float a(View view) {
            return view.getRotationX();
        }

        @Override // b.l.a.c
        public void b(View view, float f2) {
            view.setRotationX(f2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$g.smali */
    public static class g extends k {
        public g(String str) {
            super(str, null);
        }

        @Override // b.l.a.c
        public float a(View view) {
            return view.getRotationY();
        }

        @Override // b.l.a.c
        public void b(View view, float f2) {
            view.setRotationY(f2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$h.smali */
    public static class h {

        /* renamed from: a, reason: collision with root package name */
        public float f1892a;

        /* renamed from: b, reason: collision with root package name */
        public float f1893b;
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$i.smali */
    public interface i {
        void a(b bVar, boolean z, float f2, float f3);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$j.smali */
    public interface j {
        void a(b bVar, float f2, float f3);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\b$k.smali */
    public static abstract class k extends b.l.a.c<View> {
        public k(String str, C0041b c0041b) {
            super(str);
        }
    }

    public <K> b(K k2, b.l.a.c<K> cVar) {
        this.f1885d = k2;
        this.f1886e = cVar;
        if (cVar == n || cVar == o || cVar == p) {
            this.f1890i = 0.1f;
            return;
        }
        if (cVar == q) {
            this.f1890i = 0.00390625f;
        } else if (cVar == l || cVar == m) {
            this.f1890i = 0.00390625f;
        } else {
            this.f1890i = 1.0f;
        }
    }

    public static <T> void d(ArrayList<T> arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (arrayList.get(size) == null) {
                arrayList.remove(size);
            }
        }
    }

    @Override // b.l.a.a.b
    public boolean a(long j2) {
        long j3 = this.f1889h;
        if (j3 == 0) {
            this.f1889h = j2;
            e(this.f1883b);
            return false;
        }
        long j4 = j2 - j3;
        this.f1889h = j2;
        b.l.a.d dVar = (b.l.a.d) this;
        if (dVar.s != Float.MAX_VALUE) {
            b.l.a.e eVar = dVar.r;
            double d2 = eVar.f1902i;
            long j5 = j4 / 2;
            h b2 = eVar.b(dVar.f1883b, dVar.f1882a, j5);
            b.l.a.e eVar2 = dVar.r;
            eVar2.f1902i = dVar.s;
            dVar.s = Float.MAX_VALUE;
            h b3 = eVar2.b(b2.f1892a, b2.f1893b, j5);
            dVar.f1883b = b3.f1892a;
            dVar.f1882a = b3.f1893b;
        } else {
            h b4 = dVar.r.b(dVar.f1883b, dVar.f1882a, j4);
            dVar.f1883b = b4.f1892a;
            dVar.f1882a = b4.f1893b;
        }
        float max = Math.max(dVar.f1883b, dVar.f1888g);
        dVar.f1883b = max;
        float min = Math.min(max, Float.MAX_VALUE);
        dVar.f1883b = min;
        float f2 = dVar.f1882a;
        b.l.a.e eVar3 = dVar.r;
        Objects.requireNonNull(eVar3);
        double abs = Math.abs(f2);
        boolean z = true;
        if (abs < eVar3.f1898e && ((double) Math.abs(min - ((float) eVar3.f1902i))) < eVar3.f1897d) {
            dVar.f1883b = (float) dVar.r.f1902i;
            dVar.f1882a = 0.0f;
        } else {
            z = false;
        }
        float min2 = Math.min(this.f1883b, Float.MAX_VALUE);
        this.f1883b = min2;
        float max2 = Math.max(min2, this.f1888g);
        this.f1883b = max2;
        e(max2);
        if (z) {
            c(false);
        }
        return z;
    }

    public void b() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new AndroidRuntimeException("Animations may only be canceled on the main thread");
        }
        if (this.f1887f) {
            c(true);
        }
    }

    public final void c(boolean z) {
        this.f1887f = false;
        b.l.a.a a2 = b.l.a.a.a();
        a2.f1871a.remove(this);
        int indexOf = a2.f1872b.indexOf(this);
        if (indexOf >= 0) {
            a2.f1872b.set(indexOf, null);
            a2.f1876f = true;
        }
        this.f1889h = 0L;
        this.f1884c = false;
        for (int i2 = 0; i2 < this.f1891j.size(); i2++) {
            if (this.f1891j.get(i2) != null) {
                this.f1891j.get(i2).a(this, z, this.f1883b, this.f1882a);
            }
        }
        d(this.f1891j);
    }

    public void e(float f2) {
        this.f1886e.b(this.f1885d, f2);
        for (int i2 = 0; i2 < this.k.size(); i2++) {
            if (this.k.get(i2) != null) {
                this.k.get(i2).a(this, this.f1883b, this.f1882a);
            }
        }
        d(this.k);
    }
}
