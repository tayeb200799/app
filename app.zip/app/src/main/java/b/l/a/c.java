package b.l.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\l\a\c.smali */
public abstract class c<T> {
    public c(String str) {
    }

    public abstract float a(T t);

    public abstract void b(T t, float f2);
}
