package b.b.d.a;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.SparseArray;
import android.util.TypedValue;
import b.b.i.l0;
import java.util.WeakHashMap;

@SuppressLint({"RestrictedAPI"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\d\a\a.smali */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final ThreadLocal<TypedValue> f690a = new ThreadLocal<>();

    /* renamed from: b, reason: collision with root package name */
    public static final WeakHashMap<Context, SparseArray<C0011a>> f691b = new WeakHashMap<>(0);

    /* renamed from: c, reason: collision with root package name */
    public static final Object f692c = new Object();

    /* renamed from: b.b.d.a.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\d\a\a$a.smali */
    public static class C0011a {

        /* renamed from: a, reason: collision with root package name */
        public final ColorStateList f693a;

        /* renamed from: b, reason: collision with root package name */
        public final Configuration f694b;

        public C0011a(ColorStateList colorStateList, Configuration configuration) {
            this.f693a = colorStateList;
            this.f694b = configuration;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00b5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static android.content.res.ColorStateList a(android.content.Context r12, int r13) {
        /*
            Method dump skipped, instructions count: 363
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.d.a.a.a(android.content.Context, int):android.content.res.ColorStateList");
    }

    public static Drawable b(Context context, int i2) {
        return l0.d().f(context, i2);
    }
}
