package b.b.i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import b.b.i.l0;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\i.smali */
public final class i {

    /* renamed from: b, reason: collision with root package name */
    public static final PorterDuff.Mode f955b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    public static i f956c;

    /* renamed from: a, reason: collision with root package name */
    public l0 f957a;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\i$a.smali */
    public class a implements l0.e {

        /* renamed from: a, reason: collision with root package name */
        public final int[] f958a = {2131230815, 2131230813, 2131230732};

        /* renamed from: b, reason: collision with root package name */
        public final int[] f959b = {2131230756, 2131230797, 2131230763, 2131230758, 2131230759, 2131230762, 2131230761};

        /* renamed from: c, reason: collision with root package name */
        public final int[] f960c = {2131230812, 2131230814, 2131230749, 2131230805, 2131230806, 2131230808, 2131230810, 2131230807, 2131230809, 2131230811};

        /* renamed from: d, reason: collision with root package name */
        public final int[] f961d = {2131230787, 2131230747, 2131230786};

        /* renamed from: e, reason: collision with root package name */
        public final int[] f962e = {2131230803, 2131230816};

        /* renamed from: f, reason: collision with root package name */
        public final int[] f963f = {2131230735, 2131230741, 2131230736, 2131230742};

        public final boolean a(int[] iArr, int i2) {
            for (int i3 : iArr) {
                if (i3 == i2) {
                    return true;
                }
            }
            return false;
        }

        public final ColorStateList b(Context context, int i2) {
            int c2 = q0.c(context, 2130968807);
            return new ColorStateList(new int[][]{q0.f1020b, q0.f1022d, q0.f1021c, q0.f1024f}, new int[]{q0.b(context, 2130968805), b.h.e.a.a(c2, i2), b.h.e.a.a(c2, i2), i2});
        }

        public ColorStateList c(Context context, int i2) {
            if (i2 == 2131230752) {
                return b.b.d.a.a.a(context, 2131099669);
            }
            if (i2 == 2131230802) {
                return b.b.d.a.a.a(context, 2131099672);
            }
            if (i2 == 2131230801) {
                int[][] iArr = new int[3][];
                int[] iArr2 = new int[3];
                ColorStateList d2 = q0.d(context, 2130968824);
                if (d2 == null || !d2.isStateful()) {
                    iArr[0] = q0.f1020b;
                    iArr2[0] = q0.b(context, 2130968824);
                    iArr[1] = q0.f1023e;
                    iArr2[1] = q0.c(context, 2130968806);
                    iArr[2] = q0.f1024f;
                    iArr2[2] = q0.c(context, 2130968824);
                } else {
                    iArr[0] = q0.f1020b;
                    iArr2[0] = d2.getColorForState(iArr[0], 0);
                    iArr[1] = q0.f1023e;
                    iArr2[1] = q0.c(context, 2130968806);
                    iArr[2] = q0.f1024f;
                    iArr2[2] = d2.getDefaultColor();
                }
                return new ColorStateList(iArr, iArr2);
            }
            if (i2 == 2131230740) {
                return b(context, q0.c(context, 2130968805));
            }
            if (i2 == 2131230734) {
                return b(context, 0);
            }
            if (i2 == 2131230739) {
                return b(context, q0.c(context, 2130968803));
            }
            if (i2 == 2131230799 || i2 == 2131230800) {
                return b.b.d.a.a.a(context, 2131099671);
            }
            if (a(this.f959b, i2)) {
                return q0.d(context, 2130968808);
            }
            if (a(this.f962e, i2)) {
                return b.b.d.a.a.a(context, 2131099668);
            }
            if (a(this.f963f, i2)) {
                return b.b.d.a.a.a(context, 2131099667);
            }
            if (i2 == 2131230796) {
                return b.b.d.a.a.a(context, 2131099670);
            }
            return null;
        }

        public final void d(Drawable drawable, int i2, PorterDuff.Mode mode) {
            if (z.a(drawable)) {
                drawable = drawable.mutate();
            }
            if (mode == null) {
                mode = i.f955b;
            }
            drawable.setColorFilter(i.c(i2, mode));
        }
    }

    public static synchronized i a() {
        i iVar;
        synchronized (i.class) {
            if (f956c == null) {
                e();
            }
            iVar = f956c;
        }
        return iVar;
    }

    public static synchronized PorterDuffColorFilter c(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter h2;
        synchronized (i.class) {
            h2 = l0.h(i2, mode);
        }
        return h2;
    }

    public static synchronized void e() {
        synchronized (i.class) {
            if (f956c == null) {
                i iVar = new i();
                f956c = iVar;
                iVar.f957a = l0.d();
                l0 l0Var = f956c.f957a;
                a aVar = new a();
                synchronized (l0Var) {
                    l0Var.f985g = aVar;
                }
            }
        }
    }

    public static void f(Drawable drawable, t0 t0Var, int[] iArr) {
        PorterDuff.Mode mode = l0.f976h;
        if (z.a(drawable) && drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        boolean z = t0Var.f1050d;
        if (z || t0Var.f1049c) {
            PorterDuffColorFilter porterDuffColorFilter = null;
            ColorStateList colorStateList = z ? t0Var.f1047a : null;
            PorterDuff.Mode mode2 = t0Var.f1049c ? t0Var.f1048b : l0.f976h;
            if (colorStateList != null && mode2 != null) {
                porterDuffColorFilter = l0.h(colorStateList.getColorForState(iArr, 0), mode2);
            }
            drawable.setColorFilter(porterDuffColorFilter);
        } else {
            drawable.clearColorFilter();
        }
        if (Build.VERSION.SDK_INT <= 23) {
            drawable.invalidateSelf();
        }
    }

    public synchronized Drawable b(Context context, int i2) {
        return this.f957a.f(context, i2);
    }

    public synchronized ColorStateList d(Context context, int i2) {
        return this.f957a.i(context, i2);
    }
}
