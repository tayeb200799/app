package b.b.i;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.AlertController;
import b.b.c.g;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s.smali */
public class s extends Spinner {
    public static final int[] l = {R.attr.spinnerMode};

    /* renamed from: d, reason: collision with root package name */
    public final b.b.i.e f1028d;

    /* renamed from: e, reason: collision with root package name */
    public final Context f1029e;

    /* renamed from: f, reason: collision with root package name */
    public c0 f1030f;

    /* renamed from: g, reason: collision with root package name */
    public SpinnerAdapter f1031g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f1032h;

    /* renamed from: i, reason: collision with root package name */
    public f f1033i;

    /* renamed from: j, reason: collision with root package name */
    public int f1034j;
    public final Rect k;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$a.smali */
    public class a implements ViewTreeObserver.OnGlobalLayoutListener {
        public a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!s.this.getInternalPopup().b()) {
                s.this.b();
            }
            ViewTreeObserver viewTreeObserver = s.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$b.smali */
    public class b implements f, DialogInterface.OnClickListener {

        /* renamed from: d, reason: collision with root package name */
        public b.b.c.g f1036d;

        /* renamed from: e, reason: collision with root package name */
        public ListAdapter f1037e;

        /* renamed from: f, reason: collision with root package name */
        public CharSequence f1038f;

        public b() {
        }

        @Override // b.b.i.s.f
        public int a() {
            return 0;
        }

        @Override // b.b.i.s.f
        public boolean b() {
            b.b.c.g gVar = this.f1036d;
            if (gVar != null) {
                return gVar.isShowing();
            }
            return false;
        }

        @Override // b.b.i.s.f
        public void dismiss() {
            b.b.c.g gVar = this.f1036d;
            if (gVar != null) {
                gVar.dismiss();
                this.f1036d = null;
            }
        }

        @Override // b.b.i.s.f
        public Drawable f() {
            return null;
        }

        @Override // b.b.i.s.f
        public void h(CharSequence charSequence) {
            this.f1038f = charSequence;
        }

        @Override // b.b.i.s.f
        public void i(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        @Override // b.b.i.s.f
        public void j(int i2) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        @Override // b.b.i.s.f
        public void k(int i2) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }

        @Override // b.b.i.s.f
        public void l(int i2) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        @Override // b.b.i.s.f
        public void m(int i2, int i3) {
            if (this.f1037e == null) {
                return;
            }
            g.a aVar = new g.a(s.this.getPopupContext());
            CharSequence charSequence = this.f1038f;
            if (charSequence != null) {
                aVar.f612a.f110d = charSequence;
            }
            ListAdapter listAdapter = this.f1037e;
            int selectedItemPosition = s.this.getSelectedItemPosition();
            AlertController.b bVar = aVar.f612a;
            bVar.f113g = listAdapter;
            bVar.f114h = this;
            bVar.f116j = selectedItemPosition;
            bVar.f115i = true;
            b.b.c.g a2 = aVar.a();
            this.f1036d = a2;
            ListView listView = a2.f611f.f100g;
            listView.setTextDirection(i2);
            listView.setTextAlignment(i3);
            this.f1036d.show();
        }

        @Override // b.b.i.s.f
        public int n() {
            return 0;
        }

        @Override // b.b.i.s.f
        public CharSequence o() {
            return this.f1038f;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            s.this.setSelection(i2);
            if (s.this.getOnItemClickListener() != null) {
                s.this.performItemClick(null, i2, this.f1037e.getItemId(i2));
            }
            b.b.c.g gVar = this.f1036d;
            if (gVar != null) {
                gVar.dismiss();
                this.f1036d = null;
            }
        }

        @Override // b.b.i.s.f
        public void p(ListAdapter listAdapter) {
            this.f1037e = listAdapter;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$c.smali */
    public static class c implements ListAdapter, SpinnerAdapter {

        /* renamed from: d, reason: collision with root package name */
        public SpinnerAdapter f1040d;

        /* renamed from: e, reason: collision with root package name */
        public ListAdapter f1041e;

        public c(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.f1040d = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f1041e = (ListAdapter) spinnerAdapter;
            }
            if (theme != null) {
                if (Build.VERSION.SDK_INT >= 23 && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                    ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                    if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                        themedSpinnerAdapter.setDropDownViewTheme(theme);
                        return;
                    }
                    return;
                }
                if (spinnerAdapter instanceof r0) {
                    r0 r0Var = (r0) spinnerAdapter;
                    if (r0Var.getDropDownViewTheme() == null) {
                        r0Var.setDropDownViewTheme(theme);
                    }
                }
            }
        }

        @Override // android.widget.ListAdapter
        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f1041e;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        @Override // android.widget.Adapter
        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        @Override // android.widget.SpinnerAdapter
        public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i2, view, viewGroup);
        }

        @Override // android.widget.Adapter
        public Object getItem(int i2) {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i2);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter == null) {
                return -1L;
            }
            return spinnerAdapter.getItemId(i2);
        }

        @Override // android.widget.Adapter
        public int getItemViewType(int i2) {
            return 0;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i2, view, viewGroup);
        }

        @Override // android.widget.Adapter
        public int getViewTypeCount() {
            return 1;
        }

        @Override // android.widget.Adapter
        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        @Override // android.widget.Adapter
        public boolean isEmpty() {
            return getCount() == 0;
        }

        @Override // android.widget.ListAdapter
        public boolean isEnabled(int i2) {
            ListAdapter listAdapter = this.f1041e;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i2);
            }
            return true;
        }

        @Override // android.widget.Adapter
        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        @Override // android.widget.Adapter
        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1040d;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$d.smali */
    public class d extends f0 implements f {
        public CharSequence G;
        public ListAdapter H;
        public final Rect I;
        public int J;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$d$a.smali */
        public class a implements AdapterView.OnItemClickListener {
            public a(s sVar) {
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
                s.this.setSelection(i2);
                if (s.this.getOnItemClickListener() != null) {
                    d dVar = d.this;
                    s.this.performItemClick(view, i2, dVar.H.getItemId(i2));
                }
                d.this.dismiss();
            }
        }

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$d$b.smali */
        public class b implements ViewTreeObserver.OnGlobalLayoutListener {
            public b() {
            }

            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                d dVar = d.this;
                s sVar = s.this;
                Objects.requireNonNull(dVar);
                AtomicInteger atomicInteger = b.h.k.q.f1741a;
                if (!(sVar.isAttachedToWindow() && sVar.getGlobalVisibleRect(dVar.I))) {
                    d.this.dismiss();
                } else {
                    d.this.t();
                    d.this.d();
                }
            }
        }

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$d$c.smali */
        public class c implements PopupWindow.OnDismissListener {

            /* renamed from: d, reason: collision with root package name */
            public final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f1044d;

            public c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f1044d = onGlobalLayoutListener;
            }

            @Override // android.widget.PopupWindow.OnDismissListener
            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = s.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.f1044d);
                }
            }
        }

        public d(Context context, AttributeSet attributeSet, int i2) {
            super(context, attributeSet, i2, 0);
            this.I = new Rect();
            this.s = s.this;
            s(true);
            this.q = 0;
            this.t = new a(s.this);
        }

        @Override // b.b.i.s.f
        public void h(CharSequence charSequence) {
            this.G = charSequence;
        }

        @Override // b.b.i.s.f
        public void k(int i2) {
            this.J = i2;
        }

        @Override // b.b.i.s.f
        public void m(int i2, int i3) {
            ViewTreeObserver viewTreeObserver;
            boolean b2 = b();
            t();
            this.C.setInputMethodMode(2);
            d();
            a0 a0Var = this.f939f;
            a0Var.setChoiceMode(1);
            a0Var.setTextDirection(i2);
            a0Var.setTextAlignment(i3);
            int selectedItemPosition = s.this.getSelectedItemPosition();
            a0 a0Var2 = this.f939f;
            if (b() && a0Var2 != null) {
                a0Var2.setListSelectionHidden(false);
                a0Var2.setSelection(selectedItemPosition);
                if (a0Var2.getChoiceMode() != 0) {
                    a0Var2.setItemChecked(selectedItemPosition, true);
                }
            }
            if (b2 || (viewTreeObserver = s.this.getViewTreeObserver()) == null) {
                return;
            }
            b bVar = new b();
            viewTreeObserver.addOnGlobalLayoutListener(bVar);
            this.C.setOnDismissListener(new c(bVar));
        }

        @Override // b.b.i.s.f
        public CharSequence o() {
            return this.G;
        }

        @Override // b.b.i.f0, b.b.i.s.f
        public void p(ListAdapter listAdapter) {
            super.p(listAdapter);
            this.H = listAdapter;
        }

        public void t() {
            Drawable f2 = f();
            int i2 = 0;
            if (f2 != null) {
                f2.getPadding(s.this.k);
                i2 = b1.b(s.this) ? s.this.k.right : -s.this.k.left;
            } else {
                Rect rect = s.this.k;
                rect.right = 0;
                rect.left = 0;
            }
            int paddingLeft = s.this.getPaddingLeft();
            int paddingRight = s.this.getPaddingRight();
            int width = s.this.getWidth();
            s sVar = s.this;
            int i3 = sVar.f1034j;
            if (i3 == -2) {
                int a2 = sVar.a((SpinnerAdapter) this.H, f());
                int i4 = s.this.getContext().getResources().getDisplayMetrics().widthPixels;
                Rect rect2 = s.this.k;
                int i5 = (i4 - rect2.left) - rect2.right;
                if (a2 > i5) {
                    a2 = i5;
                }
                r(Math.max(a2, (width - paddingLeft) - paddingRight));
            } else if (i3 == -1) {
                r((width - paddingLeft) - paddingRight);
            } else {
                r(i3);
            }
            this.f942i = b1.b(s.this) ? (((width - paddingRight) - this.f941h) - this.J) + i2 : paddingLeft + this.J + i2;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$e.smali */
    public static class e extends View.BaseSavedState {
        public static final Parcelable.Creator<e> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public boolean f1046d;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$e$a.smali */
        public class a implements Parcelable.Creator<e> {
            @Override // android.os.Parcelable.Creator
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public e[] newArray(int i2) {
                return new e[i2];
            }
        }

        public e(Parcel parcel) {
            super(parcel);
            this.f1046d = parcel.readByte() != 0;
        }

        public e(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeByte(this.f1046d ? (byte) 1 : (byte) 0);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s$f.smali */
    public interface f {
        int a();

        boolean b();

        void dismiss();

        Drawable f();

        void h(CharSequence charSequence);

        void i(Drawable drawable);

        void j(int i2);

        void k(int i2);

        void l(int i2);

        void m(int i2, int i3);

        int n();

        CharSequence o();

        void p(ListAdapter listAdapter);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0056, code lost:
    
        if (r5 == null) goto L23;
     */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00d0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public s(android.content.Context r10, android.util.AttributeSet r11, int r12) {
        /*
            r9 = this;
            int[] r0 = b.b.b.v
            r9.<init>(r10, r11, r12)
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r9.k = r1
            android.content.Context r1 = r9.getContext()
            b.b.i.q0.a(r9, r1)
            r1 = 0
            android.content.res.TypedArray r2 = r10.obtainStyledAttributes(r11, r0, r12, r1)
            b.b.i.e r3 = new b.b.i.e
            r3.<init>(r9)
            r9.f1028d = r3
            r3 = 4
            int r3 = r2.getResourceId(r3, r1)
            if (r3 == 0) goto L2e
            b.b.h.c r4 = new b.b.h.c
            r4.<init>(r10, r3)
            r9.f1029e = r4
            goto L30
        L2e:
            r9.f1029e = r10
        L30:
            r3 = 0
            r4 = -1
            int[] r5 = b.b.i.s.l     // Catch: java.lang.Throwable -> L49 java.lang.Exception -> L4c
            android.content.res.TypedArray r5 = r10.obtainStyledAttributes(r11, r5, r12, r1)     // Catch: java.lang.Throwable -> L49 java.lang.Exception -> L4c
            boolean r6 = r5.hasValue(r1)     // Catch: java.lang.Throwable -> L43 java.lang.Exception -> L47
            if (r6 == 0) goto L58
            int r4 = r5.getInt(r1, r1)     // Catch: java.lang.Throwable -> L43 java.lang.Exception -> L47
            goto L58
        L43:
            r10 = move-exception
            r3 = r5
            goto Lce
        L47:
            r6 = move-exception
            goto L4f
        L49:
            r10 = move-exception
            goto Lce
        L4c:
            r5 = move-exception
            r6 = r5
            r5 = r3
        L4f:
            java.lang.String r7 = "AppCompatSpinner"
            java.lang.String r8 = "Could not read android:spinnerMode"
            android.util.Log.i(r7, r8, r6)     // Catch: java.lang.Throwable -> L43
            if (r5 == 0) goto L5b
        L58:
            r5.recycle()
        L5b:
            r5 = 2
            r6 = 1
            if (r4 == 0) goto L95
            if (r4 == r6) goto L62
            goto La3
        L62:
            b.b.i.s$d r4 = new b.b.i.s$d
            android.content.Context r7 = r9.f1029e
            r4.<init>(r7, r11, r12)
            android.content.Context r7 = r9.f1029e
            b.b.i.v0 r0 = b.b.i.v0.q(r7, r11, r0, r12, r1)
            r7 = 3
            r8 = -2
            int r7 = r0.k(r7, r8)
            r9.f1034j = r7
            android.graphics.drawable.Drawable r7 = r0.g(r6)
            android.widget.PopupWindow r8 = r4.C
            r8.setBackgroundDrawable(r7)
            java.lang.String r5 = r2.getString(r5)
            r4.G = r5
            android.content.res.TypedArray r0 = r0.f1079b
            r0.recycle()
            r9.f1033i = r4
            b.b.i.r r0 = new b.b.i.r
            r0.<init>(r9, r9, r4)
            r9.f1030f = r0
            goto La3
        L95:
            b.b.i.s$b r0 = new b.b.i.s$b
            r0.<init>()
            r9.f1033i = r0
            java.lang.String r4 = r2.getString(r5)
            r0.h(r4)
        La3:
            java.lang.CharSequence[] r0 = r2.getTextArray(r1)
            if (r0 == 0) goto Lba
            android.widget.ArrayAdapter r1 = new android.widget.ArrayAdapter
            r4 = 17367048(0x1090008, float:2.5162948E-38)
            r1.<init>(r10, r4, r0)
            r10 = 2131558605(0x7f0d00cd, float:1.874253E38)
            r1.setDropDownViewResource(r10)
            r9.setAdapter(r1)
        Lba:
            r2.recycle()
            r9.f1032h = r6
            android.widget.SpinnerAdapter r10 = r9.f1031g
            if (r10 == 0) goto Lc8
            r9.setAdapter(r10)
            r9.f1031g = r3
        Lc8:
            b.b.i.e r10 = r9.f1028d
            r10.d(r11, r12)
            return
        Lce:
            if (r3 == 0) goto Ld3
            r3.recycle()
        Ld3:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.i.s.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i2 = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i3 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i2) {
                view = null;
                i2 = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i3 = Math.max(i3, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i3;
        }
        drawable.getPadding(this.k);
        Rect rect = this.k;
        return i3 + rect.left + rect.right;
    }

    public void b() {
        this.f1033i.m(getTextDirection(), getTextAlignment());
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            eVar.a();
        }
    }

    @Override // android.widget.Spinner
    public int getDropDownHorizontalOffset() {
        f fVar = this.f1033i;
        return fVar != null ? fVar.a() : super.getDropDownHorizontalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownVerticalOffset() {
        f fVar = this.f1033i;
        return fVar != null ? fVar.n() : super.getDropDownVerticalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownWidth() {
        return this.f1033i != null ? this.f1034j : super.getDropDownWidth();
    }

    public final f getInternalPopup() {
        return this.f1033i;
    }

    @Override // android.widget.Spinner
    public Drawable getPopupBackground() {
        f fVar = this.f1033i;
        return fVar != null ? fVar.f() : super.getPopupBackground();
    }

    @Override // android.widget.Spinner
    public Context getPopupContext() {
        return this.f1029e;
    }

    @Override // android.widget.Spinner
    public CharSequence getPrompt() {
        f fVar = this.f1033i;
        return fVar != null ? fVar.o() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    @Override // android.widget.Spinner, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        f fVar = this.f1033i;
        if (fVar == null || !fVar.b()) {
            return;
        }
        this.f1033i.dismiss();
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f1033i == null || View.MeasureSpec.getMode(i2) != Integer.MIN_VALUE) {
            return;
        }
        setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i2)), getMeasuredHeight());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        e eVar = (e) parcelable;
        super.onRestoreInstanceState(eVar.getSuperState());
        if (!eVar.f1046d || (viewTreeObserver = getViewTreeObserver()) == null) {
            return;
        }
        viewTreeObserver.addOnGlobalLayoutListener(new a());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public Parcelable onSaveInstanceState() {
        e eVar = new e(super.onSaveInstanceState());
        f fVar = this.f1033i;
        eVar.f1046d = fVar != null && fVar.b();
        return eVar;
    }

    @Override // android.widget.Spinner, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        c0 c0Var = this.f1030f;
        if (c0Var == null || !c0Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.widget.Spinner, android.view.View
    public boolean performClick() {
        f fVar = this.f1033i;
        if (fVar == null) {
            return super.performClick();
        }
        if (fVar.b()) {
            return true;
        }
        b();
        return true;
    }

    @Override // android.widget.AdapterView
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f1032h) {
            this.f1031g = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f1033i != null) {
            Context context = this.f1029e;
            if (context == null) {
                context = getContext();
            }
            this.f1033i.p(new c(spinnerAdapter, context.getTheme()));
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            eVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            eVar.f(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownHorizontalOffset(int i2) {
        f fVar = this.f1033i;
        if (fVar == null) {
            super.setDropDownHorizontalOffset(i2);
        } else {
            fVar.k(i2);
            this.f1033i.l(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownVerticalOffset(int i2) {
        f fVar = this.f1033i;
        if (fVar != null) {
            fVar.j(i2);
        } else {
            super.setDropDownVerticalOffset(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownWidth(int i2) {
        if (this.f1033i != null) {
            this.f1034j = i2;
        } else {
            super.setDropDownWidth(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundDrawable(Drawable drawable) {
        f fVar = this.f1033i;
        if (fVar != null) {
            fVar.i(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundResource(int i2) {
        setPopupBackgroundDrawable(b.b.d.a.a.b(getPopupContext(), i2));
    }

    @Override // android.widget.Spinner
    public void setPrompt(CharSequence charSequence) {
        f fVar = this.f1033i;
        if (fVar != null) {
            fVar.h(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            eVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        b.b.i.e eVar = this.f1028d;
        if (eVar != null) {
            eVar.i(mode);
        }
    }
}
