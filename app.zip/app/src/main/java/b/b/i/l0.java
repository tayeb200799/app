package b.b.i;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import b.b.i.i;
import b.h.d.a;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0.smali */
public final class l0 {

    /* renamed from: i, reason: collision with root package name */
    public static l0 f979i;

    /* renamed from: a, reason: collision with root package name */
    public WeakHashMap<Context, b.e.i<ColorStateList>> f981a;

    /* renamed from: b, reason: collision with root package name */
    public b.e.h<String, d> f982b;

    /* renamed from: c, reason: collision with root package name */
    public b.e.i<String> f983c;

    /* renamed from: d, reason: collision with root package name */
    public final WeakHashMap<Context, b.e.e<WeakReference<Drawable.ConstantState>>> f984d = new WeakHashMap<>(0);

    /* renamed from: e, reason: collision with root package name */
    public TypedValue f985e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f986f;

    /* renamed from: g, reason: collision with root package name */
    public e f987g;

    /* renamed from: h, reason: collision with root package name */
    public static final PorterDuff.Mode f978h = PorterDuff.Mode.SRC_IN;

    /* renamed from: j, reason: collision with root package name */
    public static final c f980j = new c(6);

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0$a.smali */
    public static class a implements d {
        @Override // b.b.i.l0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.b.e.a.a.g(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e2);
                return null;
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0$b.smali */
    public static class b implements d {
        @Override // b.b.i.l0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                Resources resources = context.getResources();
                b.z.a.a.c cVar = new b.z.a.a.c(context, null, null);
                cVar.inflate(resources, xmlPullParser, attributeSet, theme);
                return cVar;
            } catch (Exception e2) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e2);
                return null;
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0$c.smali */
    public static class c extends b.e.f<Integer, PorterDuffColorFilter> {
        public c(int i2) {
            super(i2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0$d.smali */
    public interface d {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0$e.smali */
    public interface e {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\l0$f.smali */
    public static class f implements d {
        @Override // b.b.i.l0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.z.a.a.g.a(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e2);
                return null;
            }
        }
    }

    public static synchronized l0 d() {
        l0 l0Var;
        synchronized (l0.class) {
            if (f979i == null) {
                l0 l0Var2 = new l0();
                f979i = l0Var2;
                if (Build.VERSION.SDK_INT < 24) {
                    l0Var2.a("vector", new f());
                    l0Var2.a("animated-vector", new b());
                    l0Var2.a("animated-selector", new a());
                }
            }
            l0Var = f979i;
        }
        return l0Var;
    }

    public static synchronized PorterDuffColorFilter h(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter a2;
        synchronized (l0.class) {
            c cVar = f980j;
            Objects.requireNonNull(cVar);
            int i3 = (i2 + 31) * 31;
            a2 = cVar.a(Integer.valueOf(mode.hashCode() + i3));
            if (a2 == null) {
                a2 = new PorterDuffColorFilter(i2, mode);
                Objects.requireNonNull(cVar);
                cVar.b(Integer.valueOf(mode.hashCode() + i3), a2);
            }
        }
        return a2;
    }

    public final void a(String str, d dVar) {
        if (this.f982b == null) {
            this.f982b = new b.e.h<>();
        }
        this.f982b.put(str, dVar);
    }

    public final synchronized boolean b(Context context, long j2, Drawable drawable) {
        Drawable.ConstantState constantState = drawable.getConstantState();
        if (constantState == null) {
            return false;
        }
        b.e.e<WeakReference<Drawable.ConstantState>> eVar = this.f984d.get(context);
        if (eVar == null) {
            eVar = new b.e.e<>();
            this.f984d.put(context, eVar);
        }
        eVar.h(j2, new WeakReference<>(constantState));
        return true;
    }

    public final Drawable c(Context context, int i2) {
        if (this.f985e == null) {
            this.f985e = new TypedValue();
        }
        TypedValue typedValue = this.f985e;
        context.getResources().getValue(i2, typedValue, true);
        long j2 = (typedValue.assetCookie << 32) | typedValue.data;
        Drawable e2 = e(context, j2);
        if (e2 != null) {
            return e2;
        }
        e eVar = this.f987g;
        LayerDrawable layerDrawable = null;
        if (eVar != null) {
            if (i2 == 2131230748) {
                layerDrawable = new LayerDrawable(new Drawable[]{f(context, 2131230747), f(context, 2131230749)});
            }
        }
        if (layerDrawable != null) {
            layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
            b(context, j2, layerDrawable);
        }
        return layerDrawable;
    }

    public final synchronized Drawable e(Context context, long j2) {
        b.e.e<WeakReference<Drawable.ConstantState>> eVar = this.f984d.get(context);
        if (eVar == null) {
            return null;
        }
        WeakReference<Drawable.ConstantState> g2 = eVar.g(j2, null);
        if (g2 != null) {
            Drawable.ConstantState constantState = g2.get();
            if (constantState != null) {
                return constantState.newDrawable(context.getResources());
            }
            int b2 = b.e.d.b(eVar.f1169e, eVar.f1171g, j2);
            if (b2 >= 0) {
                Object[] objArr = eVar.f1170f;
                Object obj = objArr[b2];
                Object obj2 = b.e.e.f1167h;
                if (obj != obj2) {
                    objArr[b2] = obj2;
                    eVar.f1168d = true;
                }
            }
        }
        return null;
    }

    public synchronized Drawable f(Context context, int i2) {
        return g(context, i2, false);
    }

    public synchronized Drawable g(Context context, int i2, boolean z) {
        Drawable j2;
        if (!this.f986f) {
            boolean z2 = true;
            this.f986f = true;
            Drawable f2 = f(context, 2131230817);
            if (f2 != null) {
                if (!(f2 instanceof b.z.a.a.g) && !"android.graphics.drawable.VectorDrawable".equals(f2.getClass().getName())) {
                    z2 = false;
                }
            }
            this.f986f = false;
            throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
        }
        j2 = j(context, i2);
        if (j2 == null) {
            j2 = c(context, i2);
        }
        if (j2 == null) {
            Object obj = b.h.d.a.f1570a;
            j2 = a.b.b(context, i2);
        }
        if (j2 != null) {
            j2 = k(context, i2, z, j2);
        }
        if (j2 != null) {
            z.b(j2);
        }
        return j2;
    }

    public synchronized ColorStateList i(Context context, int i2) {
        ColorStateList f2;
        b.e.i<ColorStateList> iVar;
        WeakHashMap<Context, b.e.i<ColorStateList>> weakHashMap = this.f981a;
        f2 = (weakHashMap == null || (iVar = weakHashMap.get(context)) == null) ? null : iVar.f(i2, null);
        if (f2 == null) {
            e eVar = this.f987g;
            ColorStateList c2 = eVar != null ? ((i.a) eVar).c(context, i2) : null;
            if (c2 != null) {
                if (this.f981a == null) {
                    this.f981a = new WeakHashMap<>();
                }
                b.e.i<ColorStateList> iVar2 = this.f981a.get(context);
                if (iVar2 == null) {
                    iVar2 = new b.e.i<>(10);
                    this.f981a.put(context, iVar2);
                }
                iVar2.b(i2, c2);
            }
            f2 = c2;
        }
        return f2;
    }

    public final Drawable j(Context context, int i2) {
        int next;
        b.e.h<String, d> hVar = this.f982b;
        if (hVar == null || hVar.isEmpty()) {
            return null;
        }
        b.e.i<String> iVar = this.f983c;
        if (iVar != null) {
            String f2 = iVar.f(i2, null);
            if ("appcompat_skip_skip".equals(f2) || (f2 != null && this.f982b.getOrDefault(f2, null) == null)) {
                return null;
            }
        } else {
            this.f983c = new b.e.i<>(10);
        }
        if (this.f985e == null) {
            this.f985e = new TypedValue();
        }
        TypedValue typedValue = this.f985e;
        Resources resources = context.getResources();
        resources.getValue(i2, typedValue, true);
        long j2 = (typedValue.assetCookie << 32) | typedValue.data;
        Drawable e2 = e(context, j2);
        if (e2 != null) {
            return e2;
        }
        CharSequence charSequence = typedValue.string;
        if (charSequence != null && charSequence.toString().endsWith(".xml")) {
            try {
                XmlResourceParser xml = resources.getXml(i2);
                AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
                do {
                    next = xml.next();
                    if (next == 2) {
                        break;
                    }
                } while (next != 1);
                if (next != 2) {
                    throw new XmlPullParserException("No start tag found");
                }
                String name = xml.getName();
                this.f983c.b(i2, name);
                d dVar = this.f982b.get(name);
                if (dVar != null) {
                    e2 = dVar.a(context, xml, asAttributeSet, context.getTheme());
                }
                if (e2 != null) {
                    e2.setChangingConfigurations(typedValue.changingConfigurations);
                    b(context, j2, e2);
                }
            } catch (Exception e3) {
                Log.e("ResourceManagerInternal", "Exception while inflating drawable", e3);
            }
        }
        if (e2 == null) {
            this.f983c.b(i2, "appcompat_skip_skip");
        }
        return e2;
    }

    public final Drawable k(Context context, int i2, boolean z, Drawable drawable) {
        ColorStateList i3 = i(context, i2);
        PorterDuff.Mode mode = null;
        if (i3 != null) {
            if (z.a(drawable)) {
                drawable = drawable.mutate();
            }
            Drawable X = b.h.a.X(drawable);
            X.setTintList(i3);
            e eVar = this.f987g;
            if (eVar != null) {
                if (i2 == 2131230801) {
                    mode = PorterDuff.Mode.MULTIPLY;
                }
            }
            if (mode == null) {
                return X;
            }
            X.setTintMode(mode);
            return X;
        }
        e eVar2 = this.f987g;
        if (eVar2 != null) {
            i.a aVar = (i.a) eVar2;
            Objects.requireNonNull(aVar);
            boolean z2 = true;
            if (i2 == 2131230798) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable findDrawableByLayerId = layerDrawable.findDrawableByLayerId(R.id.background);
                int c2 = q0.c(context, 2130968808);
                PorterDuff.Mode mode2 = i.f957b;
                aVar.d(findDrawableByLayerId, c2, mode2);
                aVar.d(layerDrawable.findDrawableByLayerId(R.id.secondaryProgress), q0.c(context, 2130968808), mode2);
                aVar.d(layerDrawable.findDrawableByLayerId(R.id.progress), q0.c(context, 2130968806), mode2);
            } else if (i2 == 2131230789 || i2 == 2131230788 || i2 == 2131230790) {
                LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
                Drawable findDrawableByLayerId2 = layerDrawable2.findDrawableByLayerId(R.id.background);
                int b2 = q0.b(context, 2130968808);
                PorterDuff.Mode mode3 = i.f957b;
                aVar.d(findDrawableByLayerId2, b2, mode3);
                aVar.d(layerDrawable2.findDrawableByLayerId(R.id.secondaryProgress), q0.c(context, 2130968806), mode3);
                aVar.d(layerDrawable2.findDrawableByLayerId(R.id.progress), q0.c(context, 2130968806), mode3);
            } else {
                z2 = false;
            }
            if (z2) {
                return drawable;
            }
        }
        if (l(context, i2, drawable) || !z) {
            return drawable;
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0052  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean l(android.content.Context r8, int r9, android.graphics.drawable.Drawable r10) {
        /*
            r7 = this;
            b.b.i.l0$e r0 = r7.f987g
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L72
            b.b.i.i$a r0 = (b.b.i.i.a) r0
            java.util.Objects.requireNonNull(r0)
            android.graphics.PorterDuff$Mode r3 = b.b.i.i.f957b
            int[] r4 = r0.f960a
            boolean r4 = r0.a(r4, r9)
            r5 = 16842801(0x1010031, float:2.3693695E-38)
            r6 = -1
            if (r4 == 0) goto L1d
            r5 = 2130968808(0x7f0400e8, float:1.754628E38)
            goto L49
        L1d:
            int[] r4 = r0.f962c
            boolean r4 = r0.a(r4, r9)
            if (r4 == 0) goto L29
            r5 = 2130968806(0x7f0400e6, float:1.7546276E38)
            goto L49
        L29:
            int[] r4 = r0.f963d
            boolean r0 = r0.a(r4, r9)
            if (r0 == 0) goto L34
            android.graphics.PorterDuff$Mode r3 = android.graphics.PorterDuff.Mode.MULTIPLY
            goto L49
        L34:
            r0 = 2131230775(0x7f080037, float:1.8077612E38)
            if (r9 != r0) goto L44
            r9 = 16842800(0x1010030, float:2.3693693E-38)
            r0 = 1109603123(0x42233333, float:40.8)
            int r0 = java.lang.Math.round(r0)
            goto L4b
        L44:
            r0 = 2131230751(0x7f08001f, float:1.8077564E38)
            if (r9 != r0) goto L4d
        L49:
            r9 = r5
            r0 = -1
        L4b:
            r4 = 1
            goto L50
        L4d:
            r9 = 0
            r0 = -1
            r4 = 0
        L50:
            if (r4 == 0) goto L6e
            boolean r4 = b.b.i.z.a(r10)
            if (r4 == 0) goto L5c
            android.graphics.drawable.Drawable r10 = r10.mutate()
        L5c:
            int r8 = b.b.i.q0.c(r8, r9)
            android.graphics.PorterDuffColorFilter r8 = b.b.i.i.c(r8, r3)
            r10.setColorFilter(r8)
            if (r0 == r6) goto L6c
            r10.setAlpha(r0)
        L6c:
            r8 = 1
            goto L6f
        L6e:
            r8 = 0
        L6f:
            if (r8 == 0) goto L72
            goto L73
        L72:
            r1 = 0
        L73:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.i.l0.l(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
    }
}
