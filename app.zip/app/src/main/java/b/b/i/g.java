package b.b.i;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.lang.reflect.Method;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\h0.smali */
public class h0 extends f0 implements g0 {
    public static Method H;
    public g0 G;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\h0$a.smali */
    public static class a extends a0 {
        public final int q;
        public final int r;
        public g0 s;
        public MenuItem t;

        public a(Context context, boolean z) {
            super(context, z);
            if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
                this.q = 21;
                this.r = 22;
            } else {
                this.q = 22;
                this.r = 21;
            }
        }

        @Override // b.b.i.a0, android.view.View
        public boolean onHoverEvent(MotionEvent motionEvent) {
            int i2;
            b.b.h.i.f fVar;
            int pointToPosition;
            int i3;
            if (this.s != null) {
                ListAdapter adapter = getAdapter();
                if (adapter instanceof HeaderViewListAdapter) {
                    HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                    i2 = headerViewListAdapter.getHeadersCount();
                    fVar = (b.b.h.i.f) headerViewListAdapter.getWrappedAdapter();
                } else {
                    i2 = 0;
                    fVar = (b.b.h.i.f) adapter;
                }
                b.b.h.i.i iVar = null;
                if (motionEvent.getAction() != 10 && (pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) != -1 && (i3 = pointToPosition - i2) >= 0 && i3 < fVar.getCount()) {
                    iVar = fVar.getItem(i3);
                }
                MenuItem menuItem = this.t;
                if (menuItem != iVar) {
                    b.b.h.i.g gVar = fVar.f815d;
                    if (menuItem != null) {
                        this.s.e(gVar, menuItem);
                    }
                    this.t = iVar;
                    if (iVar != null) {
                        this.s.c(gVar, iVar);
                    }
                }
            }
            return super.onHoverEvent(motionEvent);
        }

        @Override // android.widget.ListView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
        public boolean onKeyDown(int i2, KeyEvent keyEvent) {
            ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
            if (listMenuItemView != null && i2 == this.q) {
                if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                    performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
                }
                return true;
            }
            if (listMenuItemView == null || i2 != this.r) {
                return super.onKeyDown(i2, keyEvent);
            }
            setSelection(-1);
            ((b.b.h.i.f) getAdapter()).f815d.c(false);
            return true;
        }

        public void setHoverListener(g0 g0Var) {
            this.s = g0Var;
        }

        @Override // b.b.i.a0, android.widget.AbsListView
        public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
            super.setSelector(drawable);
        }
    }

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                H = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public h0(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, null, i2, i3);
    }

    @Override // b.b.i.g0
    public void c(b.b.h.i.g gVar, MenuItem menuItem) {
        g0 g0Var = this.G;
        if (g0Var != null) {
            g0Var.c(gVar, menuItem);
        }
    }

    @Override // b.b.i.g0
    public void e(b.b.h.i.g gVar, MenuItem menuItem) {
        g0 g0Var = this.G;
        if (g0Var != null) {
            g0Var.e(gVar, menuItem);
        }
    }

    @Override // b.b.i.f0
    public a0 q(Context context, boolean z) {
        a aVar = new a(context, z);
        aVar.setHoverListener(this);
        return aVar;
    }
}
