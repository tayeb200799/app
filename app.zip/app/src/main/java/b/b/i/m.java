package b.b.i;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\n0.smali */
public class n0 {

    /* renamed from: a, reason: collision with root package name */
    public int f992a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f993b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f994c = Integer.MIN_VALUE;

    /* renamed from: d, reason: collision with root package name */
    public int f995d = Integer.MIN_VALUE;

    /* renamed from: e, reason: collision with root package name */
    public int f996e = 0;

    /* renamed from: f, reason: collision with root package name */
    public int f997f = 0;

    /* renamed from: g, reason: collision with root package name */
    public boolean f998g = false;

    /* renamed from: h, reason: collision with root package name */
    public boolean f999h = false;

    public void a(int i2, int i3) {
        this.f994c = i2;
        this.f995d = i3;
        this.f999h = true;
        if (this.f998g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f992a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f993b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f992a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f993b = i3;
        }
    }
}
