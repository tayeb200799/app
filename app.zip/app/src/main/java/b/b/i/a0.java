package b.b.i;

import android.content.res.Resources;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\a1.smali */
public class a1 extends Resources {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f896a = 0;
}
