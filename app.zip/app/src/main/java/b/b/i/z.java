package b.c.a.a;

import java.util.concurrent.Executor;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\a\a.smali */
public class a extends c {

    /* renamed from: c, reason: collision with root package name */
    public static volatile a f1118c;

    /* renamed from: d, reason: collision with root package name */
    public static final Executor f1119d = new ExecutorC0018a();

    /* renamed from: a, reason: collision with root package name */
    public c f1120a;

    /* renamed from: b, reason: collision with root package name */
    public c f1121b;

    /* renamed from: b.c.a.a.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\a\a$a.smali */
    public static class ExecutorC0018a implements Executor {
        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            a.d().f1120a.a(runnable);
        }
    }

    public a() {
        b bVar = new b();
        this.f1121b = bVar;
        this.f1120a = bVar;
    }

    public static a d() {
        if (f1118c != null) {
            return f1118c;
        }
        synchronized (a.class) {
            if (f1118c == null) {
                f1118c = new a();
            }
        }
        return f1118c;
    }

    @Override // b.c.a.a.c
    public void a(Runnable runnable) {
        this.f1120a.a(runnable);
    }

    @Override // b.c.a.a.c
    public boolean b() {
        return this.f1120a.b();
    }

    @Override // b.c.a.a.c
    public void c(Runnable runnable) {
        this.f1120a.c(runnable);
    }
}
