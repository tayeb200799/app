package b.b.i;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\z0.smali */
public class z0 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1110a;

    /* renamed from: b, reason: collision with root package name */
    public final View f1111b;

    /* renamed from: c, reason: collision with root package name */
    public final TextView f1112c;

    /* renamed from: d, reason: collision with root package name */
    public final WindowManager.LayoutParams f1113d;

    /* renamed from: e, reason: collision with root package name */
    public final Rect f1114e;

    /* renamed from: f, reason: collision with root package name */
    public final int[] f1115f;

    /* renamed from: g, reason: collision with root package name */
    public final int[] f1116g;

    public z0(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f1113d = layoutParams;
        this.f1114e = new Rect();
        this.f1115f = new int[2];
        this.f1116g = new int[2];
        this.f1110a = context;
        View inflate = LayoutInflater.from(context).inflate(2131558427, (ViewGroup) null);
        this.f1111b = inflate;
        this.f1112c = (TextView) inflate.findViewById(2131362284);
        layoutParams.setTitle(z0.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = 2131951622;
        layoutParams.flags = 24;
    }

    public void a() {
        if (this.f1111b.getParent() != null) {
            ((WindowManager) this.f1110a.getSystemService("window")).removeView(this.f1111b);
        }
    }
}
