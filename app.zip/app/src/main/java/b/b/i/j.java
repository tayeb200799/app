package b.b.i;

import android.content.Context;
import android.view.View;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\k0.smali */
public class k0 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f972a;

    /* renamed from: b, reason: collision with root package name */
    public final b.b.h.i.g f973b;

    /* renamed from: c, reason: collision with root package name */
    public final b.b.h.i.l f974c;

    /* renamed from: d, reason: collision with root package name */
    public a f975d;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\k0$a.smali */
    public interface a {
    }

    public k0(Context context, View view) {
        this.f972a = context;
        b.b.h.i.g gVar = new b.b.h.i.g(context);
        this.f973b = gVar;
        gVar.f825e = new i0(this);
        b.b.h.i.l lVar = new b.b.h.i.l(context, gVar, view, false, 2130969304, 0);
        this.f974c = lVar;
        lVar.f862g = 0;
        lVar.k = new j0(this);
    }
}
