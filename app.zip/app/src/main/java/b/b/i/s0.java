package b.b.i;

import android.content.Context;
import android.content.ContextWrapper;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\s0.smali */
public class s0 extends ContextWrapper {

    /* renamed from: a, reason: collision with root package name */
    public static final Object f1047a = new Object();

    public static Context a(Context context) {
        if (!(context instanceof s0) && !(context.getResources() instanceof u0)) {
            context.getResources();
            int i2 = a1.f898a;
        }
        return context;
    }
}
