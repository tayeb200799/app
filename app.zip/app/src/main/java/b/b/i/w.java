package b.b.i;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.ToggleButton;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\w.smali */
public class w extends ToggleButton {

    /* renamed from: d, reason: collision with root package name */
    public final u f1081d;

    public w(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyleToggle);
        q0.a(this, getContext());
        u uVar = new u(this);
        this.f1081d = uVar;
        uVar.e(attributeSet, R.attr.buttonStyleToggle);
    }
}
