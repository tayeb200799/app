package b.b.i;

import android.widget.PopupWindow;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\j0.smali */
public class j0 implements PopupWindow.OnDismissListener {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ k0 f970d;

    public j0(k0 k0Var) {
        this.f970d = k0Var;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        Objects.requireNonNull(this.f970d);
    }
}
