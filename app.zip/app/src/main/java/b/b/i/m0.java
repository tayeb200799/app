package b.b.i;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RatingBar;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\o.smali */
public class o extends RatingBar {

    /* renamed from: d, reason: collision with root package name */
    public final m f1000d;

    public o(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969325);
        q0.a(this, getContext());
        m mVar = new m(this);
        this.f1000d = mVar;
        mVar.a(attributeSet, 2130969325);
    }

    @Override // android.widget.RatingBar, android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public synchronized void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        Bitmap bitmap = this.f1000d.f988b;
        if (bitmap != null) {
            setMeasuredDimension(View.resolveSizeAndState(bitmap.getWidth() * getNumStars(), i2, 0), getMeasuredHeight());
        }
    }
}
