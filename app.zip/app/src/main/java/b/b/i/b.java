package b.b.i;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatImageView;
import b.b.h.i.g;
import b.b.h.i.m;
import b.b.h.i.n;
import java.util.ArrayList;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c.smali */
public class c extends b.b.h.i.b {
    public final f A;
    public d l;
    public Drawable m;
    public boolean n;
    public boolean o;
    public boolean p;
    public int q;
    public int r;
    public int s;
    public boolean t;
    public int u;
    public final SparseBooleanArray v;
    public e w;
    public a x;
    public RunnableC0017c y;
    public b z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$a.smali */
    public class a extends b.b.h.i.l {
        public a(Context context, b.b.h.i.r rVar, View view) {
            super(context, rVar, view, false, 2130968608, 0);
            if (!rVar.A.g()) {
                View view2 = c.this.l;
                this.f861f = view2 == null ? (View) c.this.k : view2;
            }
            e(c.this.A);
        }

        @Override // b.b.h.i.l
        public void c() {
            c cVar = c.this;
            cVar.x = null;
            Objects.requireNonNull(cVar);
            super.c();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$b.smali */
    public class b extends ActionMenuItemView.b {
        public b() {
        }
    }

    /* renamed from: b.b.i.c$c, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$c.smali */
    public class RunnableC0017c implements Runnable {

        /* renamed from: d, reason: collision with root package name */
        public e f900d;

        public RunnableC0017c(e eVar) {
            this.f900d = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            g.a aVar;
            b.b.h.i.g gVar = c.this.f783f;
            if (gVar != null && (aVar = gVar.f825e) != null) {
                aVar.b(gVar);
            }
            View view = (View) c.this.k;
            if (view != null && view.getWindowToken() != null && this.f900d.g()) {
                c.this.w = this.f900d;
            }
            c.this.y = null;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$d.smali */
    public class d extends AppCompatImageView implements ActionMenuView.a {

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$d$a.smali */
        public class a extends c0 {
            public a(View view, c cVar) {
                super(view);
            }

            @Override // b.b.i.c0
            public b.b.h.i.p b() {
                e eVar = c.this.w;
                if (eVar == null) {
                    return null;
                }
                return eVar.a();
            }

            @Override // b.b.i.c0
            public boolean c() {
                c.this.n();
                return true;
            }

            @Override // b.b.i.c0
            public boolean d() {
                c cVar = c.this;
                if (cVar.y != null) {
                    return false;
                }
                cVar.g();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, 2130968607);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            b.b.a.c(this, getContentDescription());
            setOnTouchListener(new a(this, c.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            c.this.n();
            return true;
        }

        @Override // android.widget.ImageView
        public boolean setFrame(int i2, int i3, int i4, int i5) {
            boolean frame = super.setFrame(i2, i3, i4, i5);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                background.setHotspotBounds(paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$e.smali */
    public class e extends b.b.h.i.l {
        public e(Context context, b.b.h.i.g gVar, View view, boolean z) {
            super(context, gVar, view, z, 2130968608, 0);
            this.f862g = 8388613;
            e(c.this.A);
        }

        @Override // b.b.h.i.l
        public void c() {
            b.b.h.i.g gVar = c.this.f783f;
            if (gVar != null) {
                gVar.c(true);
            }
            c.this.w = null;
            super.c();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\c$f.smali */
    public class f implements m.a {
        public f() {
        }

        @Override // b.b.h.i.m.a
        public void a(b.b.h.i.g gVar, boolean z) {
            if (gVar instanceof b.b.h.i.r) {
                gVar.k().c(false);
            }
            m.a aVar = c.this.f785h;
            if (aVar != null) {
                aVar.a(gVar, z);
            }
        }

        @Override // b.b.h.i.m.a
        public boolean b(b.b.h.i.g gVar) {
            c cVar = c.this;
            if (gVar == cVar.f783f) {
                return false;
            }
            int i2 = ((b.b.h.i.r) gVar).A.f834a;
            m.a aVar = cVar.f785h;
            if (aVar != null) {
                return aVar.b(gVar);
            }
            return false;
        }
    }

    public c(Context context) {
        super(context, 2131558403, 2131558402);
        this.v = new SparseBooleanArray();
        this.A = new f();
    }

    @Override // b.b.h.i.m
    public void a(b.b.h.i.g gVar, boolean z) {
        b();
        m.a aVar = this.f785h;
        if (aVar != null) {
            aVar.a(gVar, z);
        }
    }

    public boolean b() {
        return g() | l();
    }

    @Override // b.b.h.i.m
    public void c(Context context, b.b.h.i.g gVar) {
        this.f782e = context;
        LayoutInflater.from(context);
        this.f783f = gVar;
        Resources resources = context.getResources();
        if (!this.p) {
            this.o = true;
        }
        int i2 = 2;
        this.q = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i2 = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i2 = 4;
        } else if (i3 >= 360) {
            i2 = 3;
        }
        this.s = i2;
        int i5 = this.q;
        if (this.o) {
            if (this.l == null) {
                d dVar = new d(this.f781d);
                this.l = dVar;
                if (this.n) {
                    dVar.setImageDrawable(this.m);
                    this.m = null;
                    this.n = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.l.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i5 -= this.l.getMeasuredWidth();
        } else {
            this.l = null;
        }
        this.r = i5;
        this.u = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r5v4, types: [b.b.h.i.n$a] */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    public View d(b.b.h.i.i iVar, View view, ViewGroup viewGroup) {
        View actionView = iVar.getActionView();
        if (actionView == null || iVar.f()) {
            ActionMenuItemView actionMenuItemView = view instanceof n.a ? (n.a) view : (n.a) this.f784g.inflate(this.f787j, viewGroup, false);
            actionMenuItemView.d(iVar, 0);
            ActionMenuItemView actionMenuItemView2 = actionMenuItemView;
            actionMenuItemView2.setItemInvoker((ActionMenuView) this.k);
            if (this.z == null) {
                this.z = new b();
            }
            actionMenuItemView2.setPopupCallback(this.z);
            actionView = actionMenuItemView;
        }
        actionView.setVisibility(iVar.C ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // b.b.h.i.m
    public boolean e(b.b.h.i.r rVar) {
        boolean z = false;
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        b.b.h.i.r rVar2 = rVar;
        while (true) {
            b.b.h.i.g gVar = rVar2.z;
            if (gVar == this.f783f) {
                break;
            }
            rVar2 = (b.b.h.i.r) gVar;
        }
        b.b.h.i.i iVar = rVar2.A;
        ViewGroup viewGroup = (ViewGroup) this.k;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i2 = 0;
            while (true) {
                if (i2 >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i2);
                if ((childAt instanceof n.a) && ((n.a) childAt).getItemData() == iVar) {
                    view = childAt;
                    break;
                }
                i2++;
            }
        }
        if (view == null) {
            return false;
        }
        int i3 = rVar.A.f834a;
        int size = rVar.size();
        int i4 = 0;
        while (true) {
            if (i4 >= size) {
                break;
            }
            MenuItem item = rVar.getItem(i4);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
            i4++;
        }
        a aVar = new a(this.f782e, rVar, view);
        this.x = aVar;
        aVar.d(z);
        if (!this.x.g()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
        m.a aVar2 = this.f785h;
        if (aVar2 != null) {
            aVar2.b(rVar);
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // b.b.h.i.m
    public void f(boolean z) {
        int i2;
        boolean z2;
        ViewGroup viewGroup = (ViewGroup) this.k;
        ArrayList<b.b.h.i.i> arrayList = null;
        boolean z3 = false;
        if (viewGroup != null) {
            b.b.h.i.g gVar = this.f783f;
            if (gVar != null) {
                gVar.i();
                ArrayList<b.b.h.i.i> l = this.f783f.l();
                int size = l.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    b.b.h.i.i iVar = l.get(i3);
                    if (iVar.g()) {
                        View childAt = viewGroup.getChildAt(i2);
                        b.b.h.i.i itemData = childAt instanceof n.a ? ((n.a) childAt).getItemData() : null;
                        View d2 = d(iVar, childAt, viewGroup);
                        if (iVar != itemData) {
                            d2.setPressed(false);
                            d2.jumpDrawablesToCurrentState();
                        }
                        if (d2 != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) d2.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(d2);
                            }
                            ((ViewGroup) this.k).addView(d2, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i2) == this.l) {
                    z2 = false;
                } else {
                    viewGroup.removeViewAt(i2);
                    z2 = true;
                }
                if (!z2) {
                    i2++;
                }
            }
        }
        ((View) this.k).requestLayout();
        b.b.h.i.g gVar2 = this.f783f;
        if (gVar2 != null) {
            gVar2.i();
            ArrayList<b.b.h.i.i> arrayList2 = gVar2.f829i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                b.h.k.b bVar = arrayList2.get(i4).A;
            }
        }
        b.b.h.i.g gVar3 = this.f783f;
        if (gVar3 != null) {
            gVar3.i();
            arrayList = gVar3.f830j;
        }
        if (this.o && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z3 = !arrayList.get(0).C;
            } else if (size3 > 0) {
                z3 = true;
            }
        }
        if (z3) {
            if (this.l == null) {
                this.l = new d(this.f781d);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.l.getParent();
            if (viewGroup3 != this.k) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.l);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.k;
                d dVar = this.l;
                ActionMenuView.c generateDefaultLayoutParams = actionMenuView.generateDefaultLayoutParams();
                generateDefaultLayoutParams.f148c = true;
                actionMenuView.addView(dVar, generateDefaultLayoutParams);
            }
        } else {
            d dVar2 = this.l;
            if (dVar2 != null) {
                Object parent = dVar2.getParent();
                Object obj = this.k;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.l);
                }
            }
        }
        ((ActionMenuView) this.k).setOverflowReserved(this.o);
    }

    public boolean g() {
        Object obj;
        RunnableC0017c runnableC0017c = this.y;
        if (runnableC0017c != null && (obj = this.k) != null) {
            ((View) obj).removeCallbacks(runnableC0017c);
            this.y = null;
            return true;
        }
        e eVar = this.w;
        if (eVar == null) {
            return false;
        }
        if (eVar.b()) {
            eVar.f865j.dismiss();
        }
        return true;
    }

    @Override // b.b.h.i.m
    public boolean h() {
        ArrayList<b.b.h.i.i> arrayList;
        int i2;
        int i3;
        boolean z;
        b.b.h.i.g gVar = this.f783f;
        if (gVar != null) {
            arrayList = gVar.l();
            i2 = arrayList.size();
        } else {
            arrayList = null;
            i2 = 0;
        }
        int i4 = this.s;
        int i5 = this.r;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.k;
        int i6 = 0;
        boolean z2 = false;
        int i7 = 0;
        int i8 = 0;
        while (true) {
            i3 = 2;
            z = true;
            if (i6 >= i2) {
                break;
            }
            b.b.h.i.i iVar = arrayList.get(i6);
            int i9 = iVar.y;
            if ((i9 & 2) == 2) {
                i8++;
            } else if ((i9 & 1) == 1) {
                i7++;
            } else {
                z2 = true;
            }
            if (this.t && iVar.C) {
                i4 = 0;
            }
            i6++;
        }
        if (this.o && (z2 || i7 + i8 > i4)) {
            i4--;
        }
        int i10 = i4 - i8;
        SparseBooleanArray sparseBooleanArray = this.v;
        sparseBooleanArray.clear();
        int i11 = 0;
        int i12 = 0;
        while (i11 < i2) {
            b.b.h.i.i iVar2 = arrayList.get(i11);
            int i13 = iVar2.y;
            if ((i13 & 2) == i3) {
                View d2 = d(iVar2, null, viewGroup);
                d2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = d2.getMeasuredWidth();
                i5 -= measuredWidth;
                if (i12 == 0) {
                    i12 = measuredWidth;
                }
                int i14 = iVar2.f835b;
                if (i14 != 0) {
                    sparseBooleanArray.put(i14, z);
                }
                iVar2.k(z);
            } else if ((i13 & 1) == z) {
                int i15 = iVar2.f835b;
                boolean z3 = sparseBooleanArray.get(i15);
                boolean z4 = (i10 > 0 || z3) && i5 > 0;
                if (z4) {
                    View d3 = d(iVar2, null, viewGroup);
                    d3.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = d3.getMeasuredWidth();
                    i5 -= measuredWidth2;
                    if (i12 == 0) {
                        i12 = measuredWidth2;
                    }
                    z4 &= i5 + i12 > 0;
                }
                if (z4 && i15 != 0) {
                    sparseBooleanArray.put(i15, true);
                } else if (z3) {
                    sparseBooleanArray.put(i15, false);
                    for (int i16 = 0; i16 < i11; i16++) {
                        b.b.h.i.i iVar3 = arrayList.get(i16);
                        if (iVar3.f835b == i15) {
                            if (iVar3.g()) {
                                i10++;
                            }
                            iVar3.k(false);
                        }
                    }
                }
                if (z4) {
                    i10--;
                }
                iVar2.k(z4);
            } else {
                iVar2.k(false);
                i11++;
                i3 = 2;
                z = true;
            }
            i11++;
            i3 = 2;
            z = true;
        }
        return true;
    }

    public boolean l() {
        a aVar = this.x;
        if (aVar == null) {
            return false;
        }
        if (!aVar.b()) {
            return true;
        }
        aVar.f865j.dismiss();
        return true;
    }

    public boolean m() {
        e eVar = this.w;
        return eVar != null && eVar.b();
    }

    public boolean n() {
        b.b.h.i.g gVar;
        if (!this.o || m() || (gVar = this.f783f) == null || this.k == null || this.y != null) {
            return false;
        }
        gVar.i();
        if (gVar.f830j.isEmpty()) {
            return false;
        }
        RunnableC0017c runnableC0017c = new RunnableC0017c(new e(this.f782e, this.f783f, this.l, true));
        this.y = runnableC0017c;
        ((View) this.k).post(runnableC0017c);
        return true;
    }
}
