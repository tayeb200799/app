package b.b.i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\q.smali */
public class q extends m {

    /* renamed from: d, reason: collision with root package name */
    public final SeekBar f1013d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f1014e;

    /* renamed from: f, reason: collision with root package name */
    public ColorStateList f1015f;

    /* renamed from: g, reason: collision with root package name */
    public PorterDuff.Mode f1016g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1017h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f1018i;

    public q(SeekBar seekBar) {
        super(seekBar);
        this.f1015f = null;
        this.f1016g = null;
        this.f1017h = false;
        this.f1018i = false;
        this.f1013d = seekBar;
    }

    @Override // b.b.i.m
    public void a(AttributeSet attributeSet, int i2) {
        super.a(attributeSet, i2);
        Context context = this.f1013d.getContext();
        int[] iArr = b.b.b.f592g;
        v0 q = v0.q(context, attributeSet, iArr, i2, 0);
        SeekBar seekBar = this.f1013d;
        b.h.k.q.s(seekBar, seekBar.getContext(), iArr, attributeSet, q.f1076b, i2, 0);
        Drawable h2 = q.h(0);
        if (h2 != null) {
            this.f1013d.setThumb(h2);
        }
        Drawable g2 = q.g(1);
        Drawable drawable = this.f1014e;
        if (drawable != null) {
            drawable.setCallback(null);
        }
        this.f1014e = g2;
        if (g2 != null) {
            g2.setCallback(this.f1013d);
            SeekBar seekBar2 = this.f1013d;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            b.h.a.K(g2, seekBar2.getLayoutDirection());
            if (g2.isStateful()) {
                g2.setState(this.f1013d.getDrawableState());
            }
            c();
        }
        this.f1013d.invalidate();
        if (q.o(3)) {
            this.f1016g = z.d(q.j(3, -1), this.f1016g);
            this.f1018i = true;
        }
        if (q.o(2)) {
            this.f1015f = q.c(2);
            this.f1017h = true;
        }
        q.f1076b.recycle();
        c();
    }

    public final void c() {
        Drawable drawable = this.f1014e;
        if (drawable != null) {
            if (this.f1017h || this.f1018i) {
                Drawable X = b.h.a.X(drawable.mutate());
                this.f1014e = X;
                if (this.f1017h) {
                    X.setTintList(this.f1015f);
                }
                if (this.f1018i) {
                    this.f1014e.setTintMode(this.f1016g);
                }
                if (this.f1014e.isStateful()) {
                    this.f1014e.setState(this.f1013d.getDrawableState());
                }
            }
        }
    }

    public void d(Canvas canvas) {
        if (this.f1014e != null) {
            int max = this.f1013d.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f1014e.getIntrinsicWidth();
                int intrinsicHeight = this.f1014e.getIntrinsicHeight();
                int i2 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i3 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f1014e.setBounds(-i2, -i3, i2, i3);
                float width = ((this.f1013d.getWidth() - this.f1013d.getPaddingLeft()) - this.f1013d.getPaddingRight()) / max;
                int save = canvas.save();
                canvas.translate(this.f1013d.getPaddingLeft(), this.f1013d.getHeight() / 2);
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f1014e.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }
}
