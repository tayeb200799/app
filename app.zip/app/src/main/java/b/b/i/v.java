package b.b.i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import b.h.d.b.h;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\v0.smali */
public class v0 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1075a;

    /* renamed from: b, reason: collision with root package name */
    public final TypedArray f1076b;

    /* renamed from: c, reason: collision with root package name */
    public TypedValue f1077c;

    public v0(Context context, TypedArray typedArray) {
        this.f1075a = context;
        this.f1076b = typedArray;
    }

    public static v0 p(Context context, AttributeSet attributeSet, int[] iArr) {
        return new v0(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    public static v0 q(Context context, AttributeSet attributeSet, int[] iArr, int i2, int i3) {
        return new v0(context, context.obtainStyledAttributes(attributeSet, iArr, i2, i3));
    }

    public boolean a(int i2, boolean z) {
        return this.f1076b.getBoolean(i2, z);
    }

    public int b(int i2, int i3) {
        return this.f1076b.getColor(i2, i3);
    }

    public ColorStateList c(int i2) {
        int resourceId;
        ColorStateList a2;
        return (!this.f1076b.hasValue(i2) || (resourceId = this.f1076b.getResourceId(i2, 0)) == 0 || (a2 = b.b.d.a.a.a(this.f1075a, resourceId)) == null) ? this.f1076b.getColorStateList(i2) : a2;
    }

    public float d(int i2, float f2) {
        return this.f1076b.getDimension(i2, f2);
    }

    public int e(int i2, int i3) {
        return this.f1076b.getDimensionPixelOffset(i2, i3);
    }

    public int f(int i2, int i3) {
        return this.f1076b.getDimensionPixelSize(i2, i3);
    }

    public Drawable g(int i2) {
        int resourceId;
        return (!this.f1076b.hasValue(i2) || (resourceId = this.f1076b.getResourceId(i2, 0)) == 0) ? this.f1076b.getDrawable(i2) : b.b.d.a.a.b(this.f1075a, resourceId);
    }

    public Drawable h(int i2) {
        int resourceId;
        Drawable g2;
        if (!this.f1076b.hasValue(i2) || (resourceId = this.f1076b.getResourceId(i2, 0)) == 0) {
            return null;
        }
        i a2 = i.a();
        Context context = this.f1075a;
        synchronized (a2) {
            g2 = a2.f957a.g(context, resourceId, true);
        }
        return g2;
    }

    public Typeface i(int i2, int i3, h.c cVar) {
        int resourceId = this.f1076b.getResourceId(i2, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f1077c == null) {
            this.f1077c = new TypedValue();
        }
        Context context = this.f1075a;
        TypedValue typedValue = this.f1077c;
        ThreadLocal<TypedValue> threadLocal = b.h.d.b.h.f1586a;
        if (context.isRestricted()) {
            return null;
        }
        return b.h.d.b.h.b(context, resourceId, typedValue, i3, cVar, null, true, false);
    }

    public int j(int i2, int i3) {
        return this.f1076b.getInt(i2, i3);
    }

    public int k(int i2, int i3) {
        return this.f1076b.getLayoutDimension(i2, i3);
    }

    public int l(int i2, int i3) {
        return this.f1076b.getResourceId(i2, i3);
    }

    public String m(int i2) {
        return this.f1076b.getString(i2);
    }

    public CharSequence n(int i2) {
        return this.f1076b.getText(i2);
    }

    public boolean o(int i2) {
        return this.f1076b.hasValue(i2);
    }
}
