package b.b.i;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f0.smali */
public class f0 implements b.b.h.i.p {
    public static Method D;
    public static Method E;
    public static Method F;
    public Rect A;
    public boolean B;
    public PopupWindow C;

    /* renamed from: d, reason: collision with root package name */
    public Context f935d;

    /* renamed from: e, reason: collision with root package name */
    public ListAdapter f936e;

    /* renamed from: f, reason: collision with root package name */
    public a0 f937f;

    /* renamed from: i, reason: collision with root package name */
    public int f940i;

    /* renamed from: j, reason: collision with root package name */
    public int f941j;
    public boolean l;
    public boolean m;
    public boolean n;
    public DataSetObserver r;
    public View s;
    public AdapterView.OnItemClickListener t;
    public final Handler y;

    /* renamed from: g, reason: collision with root package name */
    public int f938g = -2;

    /* renamed from: h, reason: collision with root package name */
    public int f939h = -2;
    public int k = 1002;
    public int o = 0;
    public int p = Integer.MAX_VALUE;
    public int q = 0;
    public final e u = new e();
    public final d v = new d();
    public final c w = new c();
    public final a x = new a();
    public final Rect z = new Rect();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f0$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a0 a0Var = f0.this.f937f;
            if (a0Var != null) {
                a0Var.setListSelectionHidden(true);
                a0Var.requestLayout();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f0$b.smali */
    public class b extends DataSetObserver {
        public b() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            if (f0.this.b()) {
                f0.this.d();
            }
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            f0.this.dismiss();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f0$c.smali */
    public class c implements AbsListView.OnScrollListener {
        public c() {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i2, int i3, int i4) {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i2) {
            if (i2 == 1) {
                if ((f0.this.C.getInputMethodMode() == 2) || f0.this.C.getContentView() == null) {
                    return;
                }
                f0 f0Var = f0.this;
                f0Var.y.removeCallbacks(f0Var.u);
                f0.this.u.run();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f0$d.smali */
    public class d implements View.OnTouchListener {
        public d() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = f0.this.C) != null && popupWindow.isShowing() && x >= 0 && x < f0.this.C.getWidth() && y >= 0 && y < f0.this.C.getHeight()) {
                f0 f0Var = f0.this;
                f0Var.y.postDelayed(f0Var.u, 250L);
                return false;
            }
            if (action != 1) {
                return false;
            }
            f0 f0Var2 = f0.this;
            f0Var2.y.removeCallbacks(f0Var2.u);
            return false;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f0$e.smali */
    public class e implements Runnable {
        public e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a0 a0Var = f0.this.f937f;
            if (a0Var != null) {
                AtomicInteger atomicInteger = b.h.k.q.f1738a;
                if (!a0Var.isAttachedToWindow() || f0.this.f937f.getCount() <= f0.this.f937f.getChildCount()) {
                    return;
                }
                int childCount = f0.this.f937f.getChildCount();
                f0 f0Var = f0.this;
                if (childCount <= f0Var.p) {
                    f0Var.C.setInputMethodMode(2);
                    f0.this.d();
                }
            }
        }
    }

    static {
        Class cls = Boolean.TYPE;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 <= 28) {
            try {
                D = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", cls);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                F = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (i2 <= 23) {
            try {
                E = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", View.class, Integer.TYPE, cls);
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public f0(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f935d = context;
        this.y = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.b.b.o, i2, i3);
        this.f940i = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f941j = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.l = true;
        }
        obtainStyledAttributes.recycle();
        l lVar = new l(context, attributeSet, i2, i3);
        this.C = lVar;
        lVar.setInputMethodMode(1);
    }

    public int a() {
        return this.f940i;
    }

    @Override // b.b.h.i.p
    public boolean b() {
        return this.C.isShowing();
    }

    @Override // b.b.h.i.p
    public void d() {
        int i2;
        int maxAvailableHeight;
        int makeMeasureSpec;
        int paddingBottom;
        a0 a0Var;
        int i3 = Build.VERSION.SDK_INT;
        if (this.f937f == null) {
            a0 q = q(this.f935d, !this.B);
            this.f937f = q;
            q.setAdapter(this.f936e);
            this.f937f.setOnItemClickListener(this.t);
            this.f937f.setFocusable(true);
            this.f937f.setFocusableInTouchMode(true);
            this.f937f.setOnItemSelectedListener(new e0(this));
            this.f937f.setOnScrollListener(this.w);
            this.C.setContentView(this.f937f);
        }
        Drawable background = this.C.getBackground();
        if (background != null) {
            background.getPadding(this.z);
            Rect rect = this.z;
            int i4 = rect.top;
            i2 = rect.bottom + i4;
            if (!this.l) {
                this.f941j = -i4;
            }
        } else {
            this.z.setEmpty();
            i2 = 0;
        }
        boolean z = this.C.getInputMethodMode() == 2;
        View view = this.s;
        int i5 = this.f941j;
        if (i3 <= 23) {
            Method method = E;
            if (method != null) {
                try {
                    maxAvailableHeight = ((Integer) method.invoke(this.C, view, Integer.valueOf(i5), Boolean.valueOf(z))).intValue();
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
                }
            }
            maxAvailableHeight = this.C.getMaxAvailableHeight(view, i5);
        } else {
            maxAvailableHeight = this.C.getMaxAvailableHeight(view, i5, z);
        }
        if (this.f938g == -1) {
            paddingBottom = maxAvailableHeight + i2;
        } else {
            int i6 = this.f939h;
            if (i6 == -2) {
                int i7 = this.f935d.getResources().getDisplayMetrics().widthPixels;
                Rect rect2 = this.z;
                makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i7 - (rect2.left + rect2.right), Integer.MIN_VALUE);
            } else if (i6 != -1) {
                makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
            } else {
                int i8 = this.f935d.getResources().getDisplayMetrics().widthPixels;
                Rect rect3 = this.z;
                makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i8 - (rect3.left + rect3.right), 1073741824);
            }
            int a2 = this.f937f.a(makeMeasureSpec, maxAvailableHeight - 0, -1);
            paddingBottom = a2 + (a2 > 0 ? this.f937f.getPaddingBottom() + this.f937f.getPaddingTop() + i2 + 0 : 0);
        }
        boolean z2 = this.C.getInputMethodMode() == 2;
        b.h.a.S(this.C, this.k);
        if (this.C.isShowing()) {
            View view2 = this.s;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            if (view2.isAttachedToWindow()) {
                int i9 = this.f939h;
                if (i9 == -1) {
                    i9 = -1;
                } else if (i9 == -2) {
                    i9 = this.s.getWidth();
                }
                int i10 = this.f938g;
                if (i10 == -1) {
                    if (!z2) {
                        paddingBottom = -1;
                    }
                    if (z2) {
                        this.C.setWidth(this.f939h == -1 ? -1 : 0);
                        this.C.setHeight(0);
                    } else {
                        this.C.setWidth(this.f939h == -1 ? -1 : 0);
                        this.C.setHeight(-1);
                    }
                } else if (i10 != -2) {
                    paddingBottom = i10;
                }
                this.C.setOutsideTouchable(true);
                this.C.update(this.s, this.f940i, this.f941j, i9 < 0 ? -1 : i9, paddingBottom < 0 ? -1 : paddingBottom);
                return;
            }
            return;
        }
        int i11 = this.f939h;
        if (i11 == -1) {
            i11 = -1;
        } else if (i11 == -2) {
            i11 = this.s.getWidth();
        }
        int i12 = this.f938g;
        if (i12 == -1) {
            paddingBottom = -1;
        } else if (i12 != -2) {
            paddingBottom = i12;
        }
        this.C.setWidth(i11);
        this.C.setHeight(paddingBottom);
        if (i3 <= 28) {
            Method method2 = D;
            if (method2 != null) {
                try {
                    method2.invoke(this.C, Boolean.TRUE);
                } catch (Exception unused2) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            this.C.setIsClippedToScreen(true);
        }
        this.C.setOutsideTouchable(true);
        this.C.setTouchInterceptor(this.v);
        if (this.n) {
            b.h.a.M(this.C, this.m);
        }
        if (i3 <= 28) {
            Method method3 = F;
            if (method3 != null) {
                try {
                    method3.invoke(this.C, this.A);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            this.C.setEpicenterBounds(this.A);
        }
        this.C.showAsDropDown(this.s, this.f940i, this.f941j, this.o);
        this.f937f.setSelection(-1);
        if ((!this.B || this.f937f.isInTouchMode()) && (a0Var = this.f937f) != null) {
            a0Var.setListSelectionHidden(true);
            a0Var.requestLayout();
        }
        if (this.B) {
            return;
        }
        this.y.post(this.x);
    }

    @Override // b.b.h.i.p
    public void dismiss() {
        this.C.dismiss();
        this.C.setContentView(null);
        this.f937f = null;
        this.y.removeCallbacks(this.u);
    }

    public Drawable f() {
        return this.C.getBackground();
    }

    @Override // b.b.h.i.p
    public ListView g() {
        return this.f937f;
    }

    public void i(Drawable drawable) {
        this.C.setBackgroundDrawable(drawable);
    }

    public void j(int i2) {
        this.f941j = i2;
        this.l = true;
    }

    public void l(int i2) {
        this.f940i = i2;
    }

    public int n() {
        if (this.l) {
            return this.f941j;
        }
        return 0;
    }

    public void p(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.r;
        if (dataSetObserver == null) {
            this.r = new b();
        } else {
            ListAdapter listAdapter2 = this.f936e;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f936e = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.r);
        }
        a0 a0Var = this.f937f;
        if (a0Var != null) {
            a0Var.setAdapter(this.f936e);
        }
    }

    public a0 q(Context context, boolean z) {
        return new a0(context, z);
    }

    public void r(int i2) {
        Drawable background = this.C.getBackground();
        if (background == null) {
            this.f939h = i2;
            return;
        }
        background.getPadding(this.z);
        Rect rect = this.z;
        this.f939h = rect.left + rect.right + i2;
    }

    public void s(boolean z) {
        this.B = z;
        this.C.setFocusable(z);
    }
}
