package b.b.i;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\a.smali */
public abstract class a extends ViewGroup {

    /* renamed from: d, reason: collision with root package name */
    public final C0016a f879d;

    /* renamed from: e, reason: collision with root package name */
    public final Context f880e;

    /* renamed from: f, reason: collision with root package name */
    public ActionMenuView f881f;

    /* renamed from: g, reason: collision with root package name */
    public c f882g;

    /* renamed from: h, reason: collision with root package name */
    public int f883h;

    /* renamed from: i, reason: collision with root package name */
    public b.h.k.t f884i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f885j;
    public boolean k;

    /* renamed from: b.b.i.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\a$a.smali */
    public class C0016a implements b.h.k.u {

        /* renamed from: a, reason: collision with root package name */
        public boolean f886a = false;

        /* renamed from: b, reason: collision with root package name */
        public int f887b;

        public C0016a() {
        }

        @Override // b.h.k.u
        public void a(View view) {
            this.f886a = true;
        }

        @Override // b.h.k.u
        public void b(View view) {
            if (this.f886a) {
                return;
            }
            a aVar = a.this;
            aVar.f884i = null;
            a.super.setVisibility(this.f887b);
        }

        @Override // b.h.k.u
        public void c(View view) {
            a.super.setVisibility(0);
            this.f886a = false;
        }
    }

    public a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public a(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f879d = new C0016a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(2130968580, typedValue, true) || typedValue.resourceId == 0) {
            this.f880e = context;
        } else {
            this.f880e = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    public int c(View view, int i2, int i3, int i4) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE), i3);
        return Math.max(0, (i2 - view.getMeasuredWidth()) - i4);
    }

    public int d(View view, int i2, int i3, int i4, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = ((i4 - measuredHeight) / 2) + i3;
        if (z) {
            view.layout(i2 - measuredWidth, i5, i2, measuredHeight + i5);
        } else {
            view.layout(i2, i5, i2 + measuredWidth, measuredHeight + i5);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    public b.h.k.t e(int i2, long j2) {
        b.h.k.t tVar = this.f884i;
        if (tVar != null) {
            tVar.b();
        }
        if (i2 != 0) {
            b.h.k.t b2 = b.h.k.q.b(this);
            b2.a(0.0f);
            b2.c(j2);
            C0016a c0016a = this.f879d;
            a.this.f884i = b2;
            c0016a.f887b = i2;
            View view = b2.f1759a.get();
            if (view != null) {
                b2.e(view, c0016a);
            }
            return b2;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        b.h.k.t b3 = b.h.k.q.b(this);
        b3.a(1.0f);
        b3.c(j2);
        C0016a c0016a2 = this.f879d;
        a.this.f884i = b3;
        c0016a2.f887b = i2;
        View view2 = b3.f1759a.get();
        if (view2 != null) {
            b3.e(view2, c0016a2);
        }
        return b3;
    }

    public int getAnimatedVisibility() {
        return this.f884i != null ? this.f879d.f887b : getVisibility();
    }

    public int getContentHeight() {
        return this.f883h;
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(null, b.b.b.f588a, 2130968583, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(13, 0));
        obtainStyledAttributes.recycle();
        c cVar = this.f882g;
        if (cVar != null) {
            Configuration configuration2 = cVar.f784e.getResources().getConfiguration();
            int i2 = configuration2.screenWidthDp;
            int i3 = configuration2.screenHeightDp;
            cVar.s = (configuration2.smallestScreenWidthDp > 600 || i2 > 600 || (i2 > 960 && i3 > 720) || (i2 > 720 && i3 > 960)) ? 5 : (i2 >= 500 || (i2 > 640 && i3 > 480) || (i2 > 480 && i3 > 640)) ? 4 : i2 >= 360 ? 3 : 2;
            b.b.h.i.g gVar = cVar.f785f;
            if (gVar != null) {
                gVar.q(true);
            }
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.k = false;
        }
        if (!this.k) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.k = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.k = false;
        }
        return true;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f885j = false;
        }
        if (!this.f885j) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f885j = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f885j = false;
        }
        return true;
    }

    public abstract void setContentHeight(int i2);

    @Override // android.view.View
    public void setVisibility(int i2) {
        if (i2 != getVisibility()) {
            b.h.k.t tVar = this.f884i;
            if (tVar != null) {
                tVar.b();
            }
            super.setVisibility(i2);
        }
    }
}
