package b.b.i;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\p.smali */
public class p extends SeekBar {

    /* renamed from: d, reason: collision with root package name */
    public final q f1007d;

    public p(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130969363);
        q0.a(this, getContext());
        q qVar = new q(this);
        this.f1007d = qVar;
        qVar.a(attributeSet, 2130969363);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        q qVar = this.f1007d;
        Drawable drawable = qVar.f1014e;
        if (drawable != null && drawable.isStateful() && drawable.setState(qVar.f1013d.getDrawableState())) {
            qVar.f1013d.invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1007d.f1014e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1007d.d(canvas);
    }
}
