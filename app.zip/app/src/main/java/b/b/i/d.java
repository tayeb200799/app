package b.b.i;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\e.smali */
public class e {

    /* renamed from: a, reason: collision with root package name */
    public final View f925a;

    /* renamed from: d, reason: collision with root package name */
    public t0 f928d;

    /* renamed from: e, reason: collision with root package name */
    public t0 f929e;

    /* renamed from: f, reason: collision with root package name */
    public t0 f930f;

    /* renamed from: c, reason: collision with root package name */
    public int f927c = -1;

    /* renamed from: b, reason: collision with root package name */
    public final i f926b = i.a();

    public e(View view) {
        this.f925a = view;
    }

    public void a() {
        Drawable background = this.f925a.getBackground();
        if (background != null) {
            int i2 = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i2 <= 21 ? i2 == 21 : this.f928d != null) {
                if (this.f930f == null) {
                    this.f930f = new t0();
                }
                t0 t0Var = this.f930f;
                t0Var.f1047a = null;
                t0Var.f1050d = false;
                t0Var.f1048b = null;
                t0Var.f1049c = false;
                View view = this.f925a;
                AtomicInteger atomicInteger = b.h.k.q.f1738a;
                ColorStateList backgroundTintList = view.getBackgroundTintList();
                if (backgroundTintList != null) {
                    t0Var.f1050d = true;
                    t0Var.f1047a = backgroundTintList;
                }
                PorterDuff.Mode backgroundTintMode = this.f925a.getBackgroundTintMode();
                if (backgroundTintMode != null) {
                    t0Var.f1049c = true;
                    t0Var.f1048b = backgroundTintMode;
                }
                if (t0Var.f1050d || t0Var.f1049c) {
                    i.f(background, t0Var, this.f925a.getDrawableState());
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            t0 t0Var2 = this.f929e;
            if (t0Var2 != null) {
                i.f(background, t0Var2, this.f925a.getDrawableState());
                return;
            }
            t0 t0Var3 = this.f928d;
            if (t0Var3 != null) {
                i.f(background, t0Var3, this.f925a.getDrawableState());
            }
        }
    }

    public ColorStateList b() {
        t0 t0Var = this.f929e;
        if (t0Var != null) {
            return t0Var.f1047a;
        }
        return null;
    }

    public PorterDuff.Mode c() {
        t0 t0Var = this.f929e;
        if (t0Var != null) {
            return t0Var.f1048b;
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x006f A[Catch: all -> 0x0077, TryCatch #0 {all -> 0x0077, blocks: (B:3:0x001d, B:5:0x0024, B:7:0x003a, B:8:0x003d, B:10:0x0046, B:12:0x0051, B:14:0x005b, B:20:0x0069, B:22:0x006f, B:23:0x0079, B:25:0x007c, B:27:0x0083, B:29:0x0093, B:31:0x009d, B:35:0x00a8, B:37:0x00ae, B:38:0x00b5), top: B:2:0x001d }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void d(android.util.AttributeSet r11, int r12) {
        /*
            r10 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            android.view.View r1 = r10.f925a
            android.content.Context r1 = r1.getContext()
            int[] r4 = b.b.b.A
            r9 = 0
            b.b.i.v0 r1 = b.b.i.v0.q(r1, r11, r4, r12, r9)
            android.view.View r2 = r10.f925a
            android.content.Context r3 = r2.getContext()
            android.content.res.TypedArray r6 = r1.f1076b
            r8 = 0
            r5 = r11
            r7 = r12
            b.h.k.q.s(r2, r3, r4, r5, r6, r7, r8)
            boolean r11 = r1.o(r9)     // Catch: java.lang.Throwable -> L77
            r12 = -1
            if (r11 == 0) goto L3d
            int r11 = r1.l(r9, r12)     // Catch: java.lang.Throwable -> L77
            r10.f927c = r11     // Catch: java.lang.Throwable -> L77
            b.b.i.i r11 = r10.f926b     // Catch: java.lang.Throwable -> L77
            android.view.View r2 = r10.f925a     // Catch: java.lang.Throwable -> L77
            android.content.Context r2 = r2.getContext()     // Catch: java.lang.Throwable -> L77
            int r3 = r10.f927c     // Catch: java.lang.Throwable -> L77
            android.content.res.ColorStateList r11 = r11.d(r2, r3)     // Catch: java.lang.Throwable -> L77
            if (r11 == 0) goto L3d
            r10.g(r11)     // Catch: java.lang.Throwable -> L77
        L3d:
            r11 = 1
            boolean r2 = r1.o(r11)     // Catch: java.lang.Throwable -> L77
            r3 = 21
            if (r2 == 0) goto L7c
            android.view.View r2 = r10.f925a     // Catch: java.lang.Throwable -> L77
            android.content.res.ColorStateList r4 = r1.c(r11)     // Catch: java.lang.Throwable -> L77
            r2.setBackgroundTintList(r4)     // Catch: java.lang.Throwable -> L77
            if (r0 != r3) goto L7c
            android.graphics.drawable.Drawable r4 = r2.getBackground()     // Catch: java.lang.Throwable -> L77
            android.content.res.ColorStateList r5 = r2.getBackgroundTintList()     // Catch: java.lang.Throwable -> L77
            if (r5 != 0) goto L64
            android.graphics.PorterDuff$Mode r5 = r2.getBackgroundTintMode()     // Catch: java.lang.Throwable -> L77
            if (r5 == 0) goto L62
            goto L64
        L62:
            r5 = 0
            goto L65
        L64:
            r5 = 1
        L65:
            if (r4 == 0) goto L7c
            if (r5 == 0) goto L7c
            boolean r5 = r4.isStateful()     // Catch: java.lang.Throwable -> L77
            if (r5 == 0) goto L79
            int[] r5 = r2.getDrawableState()     // Catch: java.lang.Throwable -> L77
            r4.setState(r5)     // Catch: java.lang.Throwable -> L77
            goto L79
        L77:
            r11 = move-exception
            goto Lbe
        L79:
            r2.setBackground(r4)     // Catch: java.lang.Throwable -> L77
        L7c:
            r2 = 2
            boolean r4 = r1.o(r2)     // Catch: java.lang.Throwable -> L77
            if (r4 == 0) goto Lb8
            android.view.View r4 = r10.f925a     // Catch: java.lang.Throwable -> L77
            int r12 = r1.j(r2, r12)     // Catch: java.lang.Throwable -> L77
            r2 = 0
            android.graphics.PorterDuff$Mode r12 = b.b.i.z.d(r12, r2)     // Catch: java.lang.Throwable -> L77
            r4.setBackgroundTintMode(r12)     // Catch: java.lang.Throwable -> L77
            if (r0 != r3) goto Lb8
            android.graphics.drawable.Drawable r12 = r4.getBackground()     // Catch: java.lang.Throwable -> L77
            android.content.res.ColorStateList r0 = r4.getBackgroundTintList()     // Catch: java.lang.Throwable -> L77
            if (r0 != 0) goto La3
            android.graphics.PorterDuff$Mode r0 = r4.getBackgroundTintMode()     // Catch: java.lang.Throwable -> L77
            if (r0 == 0) goto La4
        La3:
            r9 = 1
        La4:
            if (r12 == 0) goto Lb8
            if (r9 == 0) goto Lb8
            boolean r11 = r12.isStateful()     // Catch: java.lang.Throwable -> L77
            if (r11 == 0) goto Lb5
            int[] r11 = r4.getDrawableState()     // Catch: java.lang.Throwable -> L77
            r12.setState(r11)     // Catch: java.lang.Throwable -> L77
        Lb5:
            r4.setBackground(r12)     // Catch: java.lang.Throwable -> L77
        Lb8:
            android.content.res.TypedArray r11 = r1.f1076b
            r11.recycle()
            return
        Lbe:
            android.content.res.TypedArray r12 = r1.f1076b
            r12.recycle()
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.i.e.d(android.util.AttributeSet, int):void");
    }

    public void e() {
        this.f927c = -1;
        g(null);
        a();
    }

    public void f(int i2) {
        this.f927c = i2;
        i iVar = this.f926b;
        g(iVar != null ? iVar.d(this.f925a.getContext(), i2) : null);
        a();
    }

    public void g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f928d == null) {
                this.f928d = new t0();
            }
            t0 t0Var = this.f928d;
            t0Var.f1047a = colorStateList;
            t0Var.f1050d = true;
        } else {
            this.f928d = null;
        }
        a();
    }

    public void h(ColorStateList colorStateList) {
        if (this.f929e == null) {
            this.f929e = new t0();
        }
        t0 t0Var = this.f929e;
        t0Var.f1047a = colorStateList;
        t0Var.f1050d = true;
        a();
    }

    public void i(PorterDuff.Mode mode) {
        if (this.f929e == null) {
            this.f929e = new t0();
        }
        t0 t0Var = this.f929e;
        t0Var.f1048b = mode;
        t0Var.f1049c = true;
        a();
    }
}
