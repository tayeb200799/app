package b.b.i;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.Toolbar.d;
import b.b.h.i.m;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\x0.smali */
public class x0 implements y {

    /* renamed from: a, reason: collision with root package name */
    public Toolbar f1081a;

    /* renamed from: b, reason: collision with root package name */
    public int f1082b;

    /* renamed from: c, reason: collision with root package name */
    public View f1083c;

    /* renamed from: d, reason: collision with root package name */
    public View f1084d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f1085e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f1086f;

    /* renamed from: g, reason: collision with root package name */
    public Drawable f1087g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1088h;

    /* renamed from: i, reason: collision with root package name */
    public CharSequence f1089i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f1090j;
    public CharSequence k;
    public Window.Callback l;
    public boolean m;
    public c n;
    public int o;
    public Drawable p;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\x0$a.smali */
    public class a extends b.h.k.v {

        /* renamed from: a, reason: collision with root package name */
        public boolean f1091a = false;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f1092b;

        public a(int i2) {
            this.f1092b = i2;
        }

        @Override // b.h.k.v, b.h.k.u
        public void a(View view) {
            this.f1091a = true;
        }

        @Override // b.h.k.u
        public void b(View view) {
            if (this.f1091a) {
                return;
            }
            x0.this.f1081a.setVisibility(this.f1092b);
        }

        @Override // b.h.k.v, b.h.k.u
        public void c(View view) {
            x0.this.f1081a.setVisibility(0);
        }
    }

    public x0(Toolbar toolbar, boolean z) {
        Drawable drawable;
        this.o = 0;
        this.f1081a = toolbar;
        this.f1089i = toolbar.getTitle();
        this.f1090j = toolbar.getSubtitle();
        this.f1088h = this.f1089i != null;
        this.f1087g = toolbar.getNavigationIcon();
        v0 q = v0.q(toolbar.getContext(), null, b.b.b.f586a, 2130968583, 0);
        int i2 = 15;
        this.p = q.g(15);
        if (z) {
            CharSequence n = q.n(27);
            if (!TextUtils.isEmpty(n)) {
                this.f1088h = true;
                this.f1089i = n;
                if ((this.f1082b & 8) != 0) {
                    this.f1081a.setTitle(n);
                }
            }
            CharSequence n2 = q.n(25);
            if (!TextUtils.isEmpty(n2)) {
                this.f1090j = n2;
                if ((this.f1082b & 8) != 0) {
                    this.f1081a.setSubtitle(n2);
                }
            }
            Drawable g2 = q.g(20);
            if (g2 != null) {
                this.f1086f = g2;
                y();
            }
            Drawable g3 = q.g(17);
            if (g3 != null) {
                this.f1085e = g3;
                y();
            }
            if (this.f1087g == null && (drawable = this.p) != null) {
                this.f1087g = drawable;
                x();
            }
            o(q.j(10, 0));
            int l = q.l(9, 0);
            if (l != 0) {
                View inflate = LayoutInflater.from(this.f1081a.getContext()).inflate(l, (ViewGroup) this.f1081a, false);
                View view = this.f1084d;
                if (view != null && (this.f1082b & 16) != 0) {
                    this.f1081a.removeView(view);
                }
                this.f1084d = inflate;
                if (inflate != null && (this.f1082b & 16) != 0) {
                    this.f1081a.addView(inflate);
                }
                o(this.f1082b | 16);
            }
            int k = q.k(13, 0);
            if (k > 0) {
                ViewGroup.LayoutParams layoutParams = this.f1081a.getLayoutParams();
                layoutParams.height = k;
                this.f1081a.setLayoutParams(layoutParams);
            }
            int e2 = q.e(7, -1);
            int e3 = q.e(3, -1);
            if (e2 >= 0 || e3 >= 0) {
                Toolbar toolbar2 = this.f1081a;
                int max = Math.max(e2, 0);
                int max2 = Math.max(e3, 0);
                toolbar2.d();
                toolbar2.w.a(max, max2);
            }
            int l2 = q.l(28, 0);
            if (l2 != 0) {
                Toolbar toolbar3 = this.f1081a;
                Context context = toolbar3.getContext();
                toolbar3.o = l2;
                TextView textView = toolbar3.f213e;
                if (textView != null) {
                    textView.setTextAppearance(context, l2);
                }
            }
            int l3 = q.l(26, 0);
            if (l3 != 0) {
                Toolbar toolbar4 = this.f1081a;
                Context context2 = toolbar4.getContext();
                toolbar4.p = l3;
                TextView textView2 = toolbar4.f214f;
                if (textView2 != null) {
                    textView2.setTextAppearance(context2, l3);
                }
            }
            int l4 = q.l(22, 0);
            if (l4 != 0) {
                this.f1081a.setPopupTheme(l4);
            }
        } else {
            if (this.f1081a.getNavigationIcon() != null) {
                this.p = this.f1081a.getNavigationIcon();
            } else {
                i2 = 11;
            }
            this.f1082b = i2;
        }
        q.f1076b.recycle();
        if (2131886081 != this.o) {
            this.o = 2131886081;
            if (TextUtils.isEmpty(this.f1081a.getNavigationContentDescription())) {
                int i3 = this.o;
                this.k = i3 != 0 ? m().getString(i3) : null;
                w();
            }
        }
        this.k = this.f1081a.getNavigationContentDescription();
        this.f1081a.setNavigationOnClickListener(new w0(this));
    }

    @Override // b.b.i.y
    public void a(Menu menu, m.a aVar) {
        b.b.h.i.i iVar;
        if (this.n == null) {
            c cVar = new c(this.f1081a.getContext());
            this.n = cVar;
            Objects.requireNonNull(cVar);
        }
        c cVar2 = this.n;
        cVar2.f785h = aVar;
        Toolbar toolbar = this.f1081a;
        b.b.h.i.g gVar = (b.b.h.i.g) menu;
        if (gVar == null && toolbar.f212d == null) {
            return;
        }
        toolbar.f();
        b.b.h.i.g gVar2 = toolbar.f212d.s;
        if (gVar2 == gVar) {
            return;
        }
        if (gVar2 != null) {
            gVar2.u(toolbar.M);
            gVar2.u(toolbar.N);
        }
        if (toolbar.N == null) {
            toolbar.N = toolbar.new d();
        }
        cVar2.t = true;
        if (gVar != null) {
            gVar.b(cVar2, toolbar.m);
            gVar.b(toolbar.N, toolbar.m);
        } else {
            cVar2.c(toolbar.m, null);
            Toolbar.d dVar = toolbar.N;
            b.b.h.i.g gVar3 = dVar.f222d;
            if (gVar3 != null && (iVar = dVar.f223e) != null) {
                gVar3.d(iVar);
            }
            dVar.f222d = null;
            cVar2.f(true);
            toolbar.N.f(true);
        }
        toolbar.f212d.setPopupTheme(toolbar.n);
        toolbar.f212d.setPresenter(cVar2);
        toolbar.M = cVar2;
    }

    @Override // b.b.i.y
    public boolean b() {
        return this.f1081a.p();
    }

    @Override // b.b.i.y
    public void c() {
        this.m = true;
    }

    @Override // b.b.i.y
    public void collapseActionView() {
        Toolbar.d dVar = this.f1081a.N;
        b.b.h.i.i iVar = dVar == null ? null : dVar.f223e;
        if (iVar != null) {
            iVar.collapseActionView();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0021 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:15:? A[RETURN, SYNTHETIC] */
    @Override // b.b.i.y
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean d() {
        /*
            r4 = this;
            androidx.appcompat.widget.Toolbar r0 = r4.f1081a
            androidx.appcompat.widget.ActionMenuView r0 = r0.f212d
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L22
            b.b.i.c r0 = r0.w
            if (r0 == 0) goto L1e
            b.b.i.c$c r3 = r0.y
            if (r3 != 0) goto L19
            boolean r0 = r0.m()
            if (r0 == 0) goto L17
            goto L19
        L17:
            r0 = 0
            goto L1a
        L19:
            r0 = 1
        L1a:
            if (r0 == 0) goto L1e
            r0 = 1
            goto L1f
        L1e:
            r0 = 0
        L1f:
            if (r0 == 0) goto L22
            r1 = 1
        L22:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.i.x0.d():boolean");
    }

    @Override // b.b.i.y
    public boolean e() {
        ActionMenuView actionMenuView = this.f1081a.f212d;
        if (actionMenuView == null) {
            return false;
        }
        c cVar = actionMenuView.w;
        return cVar != null && cVar.g();
    }

    @Override // b.b.i.y
    public boolean f() {
        return this.f1081a.v();
    }

    @Override // b.b.i.y
    public boolean g() {
        ActionMenuView actionMenuView;
        Toolbar toolbar = this.f1081a;
        return toolbar.getVisibility() == 0 && (actionMenuView = toolbar.f212d) != null && actionMenuView.v;
    }

    @Override // b.b.i.y
    public CharSequence getTitle() {
        return this.f1081a.getTitle();
    }

    @Override // b.b.i.y
    public void h() {
        c cVar;
        ActionMenuView actionMenuView = this.f1081a.f212d;
        if (actionMenuView == null || (cVar = actionMenuView.w) == null) {
            return;
        }
        cVar.b();
    }

    @Override // b.b.i.y
    public void i(int i2) {
        this.f1081a.setVisibility(i2);
    }

    @Override // b.b.i.y
    public void j(o0 o0Var) {
        View view = this.f1083c;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.f1081a;
            if (parent == toolbar) {
                toolbar.removeView(this.f1083c);
            }
        }
        this.f1083c = null;
    }

    @Override // b.b.i.y
    public ViewGroup k() {
        return this.f1081a;
    }

    @Override // b.b.i.y
    public void l(boolean z) {
    }

    @Override // b.b.i.y
    public Context m() {
        return this.f1081a.getContext();
    }

    @Override // b.b.i.y
    public boolean n() {
        Toolbar.d dVar = this.f1081a.N;
        return (dVar == null || dVar.f223e == null) ? false : true;
    }

    @Override // b.b.i.y
    public void o(int i2) {
        View view;
        int i3 = this.f1082b ^ i2;
        this.f1082b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    w();
                }
                x();
            }
            if ((i3 & 3) != 0) {
                y();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    this.f1081a.setTitle(this.f1089i);
                    this.f1081a.setSubtitle(this.f1090j);
                } else {
                    this.f1081a.setTitle((CharSequence) null);
                    this.f1081a.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) == 0 || (view = this.f1084d) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                this.f1081a.addView(view);
            } else {
                this.f1081a.removeView(view);
            }
        }
    }

    @Override // b.b.i.y
    public int p() {
        return this.f1082b;
    }

    @Override // b.b.i.y
    public void q(int i2) {
        this.f1086f = i2 != 0 ? b.b.d.a.a.b(m(), i2) : null;
        y();
    }

    @Override // b.b.i.y
    public int r() {
        return 0;
    }

    @Override // b.b.i.y
    public b.h.k.t s(int i2, long j2) {
        b.h.k.t b2 = b.h.k.q.b(this.f1081a);
        b2.a(i2 == 0 ? 1.0f : 0.0f);
        b2.c(j2);
        a aVar = new a(i2);
        View view = b2.f1756a.get();
        if (view != null) {
            b2.e(view, aVar);
        }
        return b2;
    }

    @Override // b.b.i.y
    public void setIcon(int i2) {
        this.f1085e = i2 != 0 ? b.b.d.a.a.b(m(), i2) : null;
        y();
    }

    @Override // b.b.i.y
    public void setIcon(Drawable drawable) {
        this.f1085e = drawable;
        y();
    }

    @Override // b.b.i.y
    public void setWindowCallback(Window.Callback callback) {
        this.l = callback;
    }

    @Override // b.b.i.y
    public void setWindowTitle(CharSequence charSequence) {
        if (this.f1088h) {
            return;
        }
        this.f1089i = charSequence;
        if ((this.f1082b & 8) != 0) {
            this.f1081a.setTitle(charSequence);
        }
    }

    @Override // b.b.i.y
    public void t() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // b.b.i.y
    public void u() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // b.b.i.y
    public void v(boolean z) {
        this.f1081a.setCollapsible(z);
    }

    public final void w() {
        if ((this.f1082b & 4) != 0) {
            if (TextUtils.isEmpty(this.k)) {
                this.f1081a.setNavigationContentDescription(this.o);
            } else {
                this.f1081a.setNavigationContentDescription(this.k);
            }
        }
    }

    public final void x() {
        if ((this.f1082b & 4) == 0) {
            this.f1081a.setNavigationIcon((Drawable) null);
            return;
        }
        Toolbar toolbar = this.f1081a;
        Drawable drawable = this.f1087g;
        if (drawable == null) {
            drawable = this.p;
        }
        toolbar.setNavigationIcon(drawable);
    }

    public final void y() {
        Drawable drawable;
        int i2 = this.f1082b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) != 0) {
            drawable = this.f1086f;
            if (drawable == null) {
                drawable = this.f1085e;
            }
        } else {
            drawable = this.f1085e;
        }
        this.f1081a.setLogo(drawable);
    }
}
