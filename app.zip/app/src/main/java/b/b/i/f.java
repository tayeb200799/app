package b.b.i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckBox;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\f.smali */
public class f extends CheckBox {

    /* renamed from: d, reason: collision with root package name */
    public final h f934d;

    /* renamed from: e, reason: collision with root package name */
    public final e f935e;

    /* renamed from: f, reason: collision with root package name */
    public final u f936f;

    public f(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130968732);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        s0.a(context);
        q0.a(this, getContext());
        h hVar = new h(this);
        this.f934d = hVar;
        hVar.b(attributeSet, i2);
        e eVar = new e(this);
        this.f935e = eVar;
        eVar.d(attributeSet, i2);
        u uVar = new u(this);
        this.f936f = uVar;
        uVar.e(attributeSet, i2);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f935e;
        if (eVar != null) {
            eVar.a();
        }
        u uVar = this.f936f;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        h hVar = this.f934d;
        return compoundPaddingLeft;
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f935e;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f935e;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        h hVar = this.f934d;
        if (hVar != null) {
            return hVar.f952b;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        h hVar = this.f934d;
        if (hVar != null) {
            return hVar.f953c;
        }
        return null;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        e eVar = this.f935e;
        if (eVar != null) {
            eVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        e eVar = this.f935e;
        if (eVar != null) {
            eVar.f(i2);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i2) {
        setButtonDrawable(b.b.d.a.a.b(getContext(), i2));
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        h hVar = this.f934d;
        if (hVar != null) {
            if (hVar.f956f) {
                hVar.f956f = false;
            } else {
                hVar.f956f = true;
                hVar.a();
            }
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        e eVar = this.f935e;
        if (eVar != null) {
            eVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        e eVar = this.f935e;
        if (eVar != null) {
            eVar.i(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        h hVar = this.f934d;
        if (hVar != null) {
            hVar.f952b = colorStateList;
            hVar.f954d = true;
            hVar.a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        h hVar = this.f934d;
        if (hVar != null) {
            hVar.f953c = mode;
            hVar.f955e = true;
            hVar.a();
        }
    }
}
