package b.b.i;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\n0.smali */
public class n0 {

    /* renamed from: a, reason: collision with root package name */
    public int f994a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f995b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f996c = Integer.MIN_VALUE;

    /* renamed from: d, reason: collision with root package name */
    public int f997d = Integer.MIN_VALUE;

    /* renamed from: e, reason: collision with root package name */
    public int f998e = 0;

    /* renamed from: f, reason: collision with root package name */
    public int f999f = 0;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1000g = false;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1001h = false;

    public void a(int i2, int i3) {
        this.f996c = i2;
        this.f997d = i3;
        this.f1001h = true;
        if (this.f1000g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f994a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f995b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f994a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f995b = i3;
        }
    }
}
