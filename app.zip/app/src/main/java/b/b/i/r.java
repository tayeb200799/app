package b.b.i;

import android.annotation.SuppressLint;
import android.view.View;
import b.b.i.s;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\r.smali */
public class r extends c0 {
    public final /* synthetic */ s.d m;
    public final /* synthetic */ s n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(s sVar, View view, s.d dVar) {
        super(view);
        this.n = sVar;
        this.m = dVar;
    }

    @Override // b.b.i.c0
    public b.b.h.i.p b() {
        return this.m;
    }

    @Override // b.b.i.c0
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
        if (this.n.getInternalPopup().b()) {
            return true;
        }
        this.n.b();
        return true;
    }
}
