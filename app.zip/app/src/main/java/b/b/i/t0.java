package b.b.i;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.RectF;
import android.os.Build;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatEditText;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\v.smali */
public class v {
    public static final RectF l = new RectF();
    public static ConcurrentHashMap<String, Method> m = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, Field> n = new ConcurrentHashMap<>();

    /* renamed from: a, reason: collision with root package name */
    public int f1065a = 0;

    /* renamed from: b, reason: collision with root package name */
    public boolean f1066b = false;

    /* renamed from: c, reason: collision with root package name */
    public float f1067c = -1.0f;

    /* renamed from: d, reason: collision with root package name */
    public float f1068d = -1.0f;

    /* renamed from: e, reason: collision with root package name */
    public float f1069e = -1.0f;

    /* renamed from: f, reason: collision with root package name */
    public int[] f1070f = new int[0];

    /* renamed from: g, reason: collision with root package name */
    public boolean f1071g = false;

    /* renamed from: h, reason: collision with root package name */
    public TextPaint f1072h;

    /* renamed from: i, reason: collision with root package name */
    public final TextView f1073i;

    /* renamed from: j, reason: collision with root package name */
    public final Context f1074j;
    public final c k;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\v$a.smali */
    public static class a extends c {
        @Override // b.b.i.v.c
        public void a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection((TextDirectionHeuristic) v.e(textView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\v$b.smali */
    public static class b extends a {
        @Override // b.b.i.v.a, b.b.i.v.c
        public void a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection(textView.getTextDirectionHeuristic());
        }

        @Override // b.b.i.v.c
        public boolean b(TextView textView) {
            return textView.isHorizontallyScrollable();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\v$c.smali */
    public static class c {
        public void a(StaticLayout.Builder builder, TextView textView) {
        }

        public boolean b(TextView textView) {
            return ((Boolean) v.e(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
        }
    }

    public v(TextView textView) {
        this.f1073i = textView;
        this.f1074j = textView.getContext();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 29) {
            this.k = new b();
        } else if (i2 >= 23) {
            this.k = new a();
        } else {
            this.k = new c();
        }
    }

    public static Method d(String str) {
        try {
            Method method = m.get(str);
            if (method == null && (method = TextView.class.getDeclaredMethod(str, new Class[0])) != null) {
                method.setAccessible(true);
                m.put(str, method);
            }
            return method;
        } catch (Exception e2) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e2);
            return null;
        }
    }

    public static <T> T e(Object obj, String str, T t) {
        try {
            return (T) d(str).invoke(obj, new Object[0]);
        } catch (Exception e2) {
            Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + str + "() method", e2);
            return t;
        }
    }

    public void a() {
        if (i() && this.f1065a != 0) {
            if (this.f1066b) {
                if (this.f1073i.getMeasuredHeight() <= 0 || this.f1073i.getMeasuredWidth() <= 0) {
                    return;
                }
                int measuredWidth = this.k.b(this.f1073i) ? 1048576 : (this.f1073i.getMeasuredWidth() - this.f1073i.getTotalPaddingLeft()) - this.f1073i.getTotalPaddingRight();
                int height = (this.f1073i.getHeight() - this.f1073i.getCompoundPaddingBottom()) - this.f1073i.getCompoundPaddingTop();
                if (measuredWidth <= 0 || height <= 0) {
                    return;
                }
                RectF rectF = l;
                synchronized (rectF) {
                    rectF.setEmpty();
                    rectF.right = measuredWidth;
                    rectF.bottom = height;
                    float c2 = c(rectF);
                    if (c2 != this.f1073i.getTextSize()) {
                        f(0, c2);
                    }
                }
            }
            this.f1066b = true;
        }
    }

    public final int[] b(int[] iArr) {
        int length = iArr.length;
        if (length == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i2 : iArr) {
            if (i2 > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i2)) < 0) {
                arrayList.add(Integer.valueOf(i2));
            }
        }
        if (length == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i3 = 0; i3 < size; i3++) {
            iArr2[i3] = ((Integer) arrayList.get(i3)).intValue();
        }
        return iArr2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x0104, code lost:
    
        if (r7.getLineEnd(r7.getLineCount() - 1) != r8.length()) goto L37;
     */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0125 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x011a A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int c(android.graphics.RectF r21) {
        /*
            Method dump skipped, instructions count: 313
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.i.v.c(android.graphics.RectF):int");
    }

    public void f(int i2, float f2) {
        Context context = this.f1074j;
        float applyDimension = TypedValue.applyDimension(i2, f2, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        if (applyDimension != this.f1073i.getPaint().getTextSize()) {
            this.f1073i.getPaint().setTextSize(applyDimension);
            boolean isInLayout = this.f1073i.isInLayout();
            if (this.f1073i.getLayout() != null) {
                this.f1066b = false;
                try {
                    Method d2 = d("nullLayouts");
                    if (d2 != null) {
                        d2.invoke(this.f1073i, new Object[0]);
                    }
                } catch (Exception e2) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e2);
                }
                if (isInLayout) {
                    this.f1073i.forceLayout();
                } else {
                    this.f1073i.requestLayout();
                }
                this.f1073i.invalidate();
            }
        }
    }

    public final boolean g() {
        if (i() && this.f1065a == 1) {
            if (!this.f1071g || this.f1070f.length == 0) {
                int floor = ((int) Math.floor((this.f1069e - this.f1068d) / this.f1067c)) + 1;
                int[] iArr = new int[floor];
                for (int i2 = 0; i2 < floor; i2++) {
                    iArr[i2] = Math.round((i2 * this.f1067c) + this.f1068d);
                }
                this.f1070f = b(iArr);
            }
            this.f1066b = true;
        } else {
            this.f1066b = false;
        }
        return this.f1066b;
    }

    public final boolean h() {
        boolean z = this.f1070f.length > 0;
        this.f1071g = z;
        if (z) {
            this.f1065a = 1;
            this.f1068d = r0[0];
            this.f1069e = r0[r1 - 1];
            this.f1067c = -1.0f;
        }
        return z;
    }

    public final boolean i() {
        return !(this.f1073i instanceof AppCompatEditText);
    }

    public final void j(float f2, float f3, float f4) {
        if (f2 <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f2 + "px) is less or equal to (0px)");
        }
        if (f3 <= f2) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f3 + "px) is less or equal to minimum auto-size text size (" + f2 + "px)");
        }
        if (f4 <= 0.0f) {
            throw new IllegalArgumentException("The auto-size step granularity (" + f4 + "px) is less or equal to (0px)");
        }
        this.f1065a = 1;
        this.f1068d = f2;
        this.f1069e = f3;
        this.f1067c = f4;
        this.f1071g = false;
    }
}
