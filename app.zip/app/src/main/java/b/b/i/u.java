package b.b.i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import b.h.d.b.h;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\u.smali */
public class u {

    /* renamed from: a, reason: collision with root package name */
    public final TextView f1054a;

    /* renamed from: b, reason: collision with root package name */
    public t0 f1055b;

    /* renamed from: c, reason: collision with root package name */
    public t0 f1056c;

    /* renamed from: d, reason: collision with root package name */
    public t0 f1057d;

    /* renamed from: e, reason: collision with root package name */
    public t0 f1058e;

    /* renamed from: f, reason: collision with root package name */
    public t0 f1059f;

    /* renamed from: g, reason: collision with root package name */
    public t0 f1060g;

    /* renamed from: h, reason: collision with root package name */
    public t0 f1061h;

    /* renamed from: i, reason: collision with root package name */
    public final v f1062i;

    /* renamed from: j, reason: collision with root package name */
    public int f1063j = 0;
    public int k = -1;
    public Typeface l;
    public boolean m;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\u$a.smali */
    public class a extends h.c {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f1064a;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f1065b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ WeakReference f1066c;

        public a(int i2, int i3, WeakReference weakReference) {
            this.f1064a = i2;
            this.f1065b = i3;
            this.f1066c = weakReference;
        }

        @Override // b.h.d.b.h.c
        public void d(int i2) {
        }

        @Override // b.h.d.b.h.c
        public void e(Typeface typeface) {
            int i2;
            if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f1064a) != -1) {
                typeface = Typeface.create(typeface, i2, (this.f1065b & 2) != 0);
            }
            u uVar = u.this;
            WeakReference weakReference = this.f1066c;
            if (uVar.m) {
                uVar.l = typeface;
                TextView textView = (TextView) weakReference.get();
                if (textView != null) {
                    textView.setTypeface(typeface, uVar.f1063j);
                }
            }
        }
    }

    public u(TextView textView) {
        this.f1054a = textView;
        this.f1062i = new v(textView);
    }

    public static t0 c(Context context, i iVar, int i2) {
        ColorStateList d2 = iVar.d(context, i2);
        if (d2 == null) {
            return null;
        }
        t0 t0Var = new t0();
        t0Var.f1053d = true;
        t0Var.f1050a = d2;
        return t0Var;
    }

    public final void a(Drawable drawable, t0 t0Var) {
        if (drawable == null || t0Var == null) {
            return;
        }
        i.f(drawable, t0Var, this.f1054a.getDrawableState());
    }

    public void b() {
        if (this.f1055b != null || this.f1056c != null || this.f1057d != null || this.f1058e != null) {
            Drawable[] compoundDrawables = this.f1054a.getCompoundDrawables();
            a(compoundDrawables[0], this.f1055b);
            a(compoundDrawables[1], this.f1056c);
            a(compoundDrawables[2], this.f1057d);
            a(compoundDrawables[3], this.f1058e);
        }
        if (this.f1059f == null && this.f1060g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = this.f1054a.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f1059f);
        a(compoundDrawablesRelative[2], this.f1060g);
    }

    public boolean d() {
        v vVar = this.f1062i;
        return vVar.i() && vVar.f1068a != 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0257  */
    /* JADX WARN: Removed duplicated region for block: B:105:0x0265  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0274  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x02c2  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x0301  */
    /* JADX WARN: Removed duplicated region for block: B:151:0x034a  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x035c  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x036a  */
    /* JADX WARN: Removed duplicated region for block: B:160:0x0377  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x0385  */
    /* JADX WARN: Removed duplicated region for block: B:166:0x0392  */
    /* JADX WARN: Removed duplicated region for block: B:175:0x041a  */
    /* JADX WARN: Removed duplicated region for block: B:190:0x0450  */
    /* JADX WARN: Removed duplicated region for block: B:198:0x0486  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x048d  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x0494  */
    /* JADX WARN: Removed duplicated region for block: B:205:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:229:0x03fa  */
    /* JADX WARN: Removed duplicated region for block: B:231:0x0401  */
    /* JADX WARN: Removed duplicated region for block: B:233:0x0406  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x040c  */
    /* JADX WARN: Removed duplicated region for block: B:237:0x0397  */
    /* JADX WARN: Removed duplicated region for block: B:238:0x038a  */
    /* JADX WARN: Removed duplicated region for block: B:239:0x037c  */
    /* JADX WARN: Removed duplicated region for block: B:240:0x036f  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x0361  */
    /* JADX WARN: Removed duplicated region for block: B:242:0x0351  */
    /* JADX WARN: Removed duplicated region for block: B:243:0x02fa  */
    /* JADX WARN: Removed duplicated region for block: B:246:0x0279  */
    /* JADX WARN: Removed duplicated region for block: B:247:0x026b  */
    /* JADX WARN: Removed duplicated region for block: B:248:0x025c  */
    /* JADX WARN: Removed duplicated region for block: B:255:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0247  */
    @android.annotation.SuppressLint({"NewApi"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void e(android.util.AttributeSet r28, int r29) {
        /*
            Method dump skipped, instructions count: 1178
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.i.u.e(android.util.AttributeSet, int):void");
    }

    public void f(Context context, int i2) {
        String m;
        ColorStateList c2;
        v0 v0Var = new v0(context, context.obtainStyledAttributes(i2, b.b.b.x));
        if (v0Var.o(14)) {
            this.f1054a.setAllCaps(v0Var.a(14, false));
        }
        int i3 = Build.VERSION.SDK_INT;
        if (i3 < 23 && v0Var.o(3) && (c2 = v0Var.c(3)) != null) {
            this.f1054a.setTextColor(c2);
        }
        if (v0Var.o(0) && v0Var.f(0, -1) == 0) {
            this.f1054a.setTextSize(0, 0.0f);
        }
        l(context, v0Var);
        if (i3 >= 26 && v0Var.o(13) && (m = v0Var.m(13)) != null) {
            this.f1054a.setFontVariationSettings(m);
        }
        v0Var.f1079b.recycle();
        Typeface typeface = this.l;
        if (typeface != null) {
            this.f1054a.setTypeface(typeface, this.f1063j);
        }
    }

    public void g(int i2, int i3, int i4, int i5) {
        v vVar = this.f1062i;
        if (vVar.i()) {
            DisplayMetrics displayMetrics = vVar.f1077j.getResources().getDisplayMetrics();
            vVar.j(TypedValue.applyDimension(i5, i2, displayMetrics), TypedValue.applyDimension(i5, i3, displayMetrics), TypedValue.applyDimension(i5, i4, displayMetrics));
            if (vVar.g()) {
                vVar.a();
            }
        }
    }

    public void h(int[] iArr, int i2) {
        v vVar = this.f1062i;
        if (vVar.i()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i2 == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = vVar.f1077j.getResources().getDisplayMetrics();
                    for (int i3 = 0; i3 < length; i3++) {
                        iArr2[i3] = Math.round(TypedValue.applyDimension(i2, iArr[i3], displayMetrics));
                    }
                }
                vVar.f1073f = vVar.b(iArr2);
                if (!vVar.h()) {
                    StringBuilder n = c.a.a.a.a.n("None of the preset sizes is valid: ");
                    n.append(Arrays.toString(iArr));
                    throw new IllegalArgumentException(n.toString());
                }
            } else {
                vVar.f1074g = false;
            }
            if (vVar.g()) {
                vVar.a();
            }
        }
    }

    public void i(int i2) {
        v vVar = this.f1062i;
        if (vVar.i()) {
            if (i2 == 0) {
                vVar.f1068a = 0;
                vVar.f1071d = -1.0f;
                vVar.f1072e = -1.0f;
                vVar.f1070c = -1.0f;
                vVar.f1073f = new int[0];
                vVar.f1069b = false;
                return;
            }
            if (i2 != 1) {
                throw new IllegalArgumentException(c.a.a.a.a.c("Unknown auto-size text type: ", i2));
            }
            DisplayMetrics displayMetrics = vVar.f1077j.getResources().getDisplayMetrics();
            vVar.j(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (vVar.g()) {
                vVar.a();
            }
        }
    }

    public void j(ColorStateList colorStateList) {
        if (this.f1061h == null) {
            this.f1061h = new t0();
        }
        t0 t0Var = this.f1061h;
        t0Var.f1050a = colorStateList;
        t0Var.f1053d = colorStateList != null;
        this.f1055b = t0Var;
        this.f1056c = t0Var;
        this.f1057d = t0Var;
        this.f1058e = t0Var;
        this.f1059f = t0Var;
        this.f1060g = t0Var;
    }

    public void k(PorterDuff.Mode mode) {
        if (this.f1061h == null) {
            this.f1061h = new t0();
        }
        t0 t0Var = this.f1061h;
        t0Var.f1051b = mode;
        t0Var.f1052c = mode != null;
        this.f1055b = t0Var;
        this.f1056c = t0Var;
        this.f1057d = t0Var;
        this.f1058e = t0Var;
        this.f1059f = t0Var;
        this.f1060g = t0Var;
    }

    public final void l(Context context, v0 v0Var) {
        String m;
        int i2 = Build.VERSION.SDK_INT;
        this.f1063j = v0Var.j(2, this.f1063j);
        if (i2 >= 28) {
            int j2 = v0Var.j(11, -1);
            this.k = j2;
            if (j2 != -1) {
                this.f1063j = (this.f1063j & 2) | 0;
            }
        }
        if (!v0Var.o(10) && !v0Var.o(12)) {
            if (v0Var.o(1)) {
                this.m = false;
                int j3 = v0Var.j(1, 1);
                if (j3 == 1) {
                    this.l = Typeface.SANS_SERIF;
                    return;
                } else if (j3 == 2) {
                    this.l = Typeface.SERIF;
                    return;
                } else {
                    if (j3 != 3) {
                        return;
                    }
                    this.l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.l = null;
        int i3 = v0Var.o(12) ? 12 : 10;
        int i4 = this.k;
        int i5 = this.f1063j;
        if (!context.isRestricted()) {
            try {
                Typeface i6 = v0Var.i(i3, this.f1063j, new a(i4, i5, new WeakReference(this.f1054a)));
                if (i6 != null) {
                    if (i2 < 28 || this.k == -1) {
                        this.l = i6;
                    } else {
                        this.l = Typeface.create(Typeface.create(i6, 0), this.k, (this.f1063j & 2) != 0);
                    }
                }
                this.m = this.l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.l != null || (m = v0Var.m(i3)) == null) {
            return;
        }
        if (i2 < 28 || this.k == -1) {
            this.l = Typeface.create(m, this.f1063j);
        } else {
            this.l = Typeface.create(Typeface.create(m, 0), this.k, (this.f1063j & 2) != 0);
        }
    }
}
