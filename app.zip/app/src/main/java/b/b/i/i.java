package b.b.i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\i\j.smali */
public class j {

    /* renamed from: a, reason: collision with root package name */
    public final ImageView f965a;

    /* renamed from: b, reason: collision with root package name */
    public t0 f966b;

    /* renamed from: c, reason: collision with root package name */
    public t0 f967c;

    public j(ImageView imageView) {
        this.f965a = imageView;
    }

    public void a() {
        Drawable drawable = this.f965a.getDrawable();
        if (drawable != null) {
            z.b(drawable);
        }
        if (drawable != null) {
            int i2 = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i2 <= 21 && i2 == 21) {
                if (this.f967c == null) {
                    this.f967c = new t0();
                }
                t0 t0Var = this.f967c;
                t0Var.f1047a = null;
                t0Var.f1050d = false;
                t0Var.f1048b = null;
                t0Var.f1049c = false;
                ColorStateList imageTintList = this.f965a.getImageTintList();
                if (imageTintList != null) {
                    t0Var.f1050d = true;
                    t0Var.f1047a = imageTintList;
                }
                PorterDuff.Mode imageTintMode = this.f965a.getImageTintMode();
                if (imageTintMode != null) {
                    t0Var.f1049c = true;
                    t0Var.f1048b = imageTintMode;
                }
                if (t0Var.f1050d || t0Var.f1049c) {
                    i.f(drawable, t0Var, this.f965a.getDrawableState());
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            t0 t0Var2 = this.f966b;
            if (t0Var2 != null) {
                i.f(drawable, t0Var2, this.f965a.getDrawableState());
            }
        }
    }

    public void b(AttributeSet attributeSet, int i2) {
        Drawable drawable;
        Drawable drawable2;
        int l;
        int i3 = Build.VERSION.SDK_INT;
        Context context = this.f965a.getContext();
        int[] iArr = b.b.b.f591f;
        v0 q = v0.q(context, attributeSet, iArr, i2, 0);
        ImageView imageView = this.f965a;
        b.h.k.q.s(imageView, imageView.getContext(), iArr, attributeSet, q.f1076b, i2, 0);
        try {
            Drawable drawable3 = this.f965a.getDrawable();
            if (drawable3 == null && (l = q.l(1, -1)) != -1 && (drawable3 = b.b.d.a.a.b(this.f965a.getContext(), l)) != null) {
                this.f965a.setImageDrawable(drawable3);
            }
            if (drawable3 != null) {
                z.b(drawable3);
            }
            if (q.o(2)) {
                ImageView imageView2 = this.f965a;
                imageView2.setImageTintList(q.c(2));
                if (i3 == 21 && (drawable2 = imageView2.getDrawable()) != null && imageView2.getImageTintList() != null) {
                    if (drawable2.isStateful()) {
                        drawable2.setState(imageView2.getDrawableState());
                    }
                    imageView2.setImageDrawable(drawable2);
                }
            }
            if (q.o(3)) {
                ImageView imageView3 = this.f965a;
                imageView3.setImageTintMode(z.d(q.j(3, -1), null));
                if (i3 == 21 && (drawable = imageView3.getDrawable()) != null && imageView3.getImageTintList() != null) {
                    if (drawable.isStateful()) {
                        drawable.setState(imageView3.getDrawableState());
                    }
                    imageView3.setImageDrawable(drawable);
                }
            }
            q.f1076b.recycle();
        } catch (Throwable th) {
            q.f1076b.recycle();
            throw th;
        }
    }

    public void c(int i2) {
        if (i2 != 0) {
            Drawable b2 = b.b.d.a.a.b(this.f965a.getContext(), i2);
            if (b2 != null) {
                z.b(b2);
            }
            this.f965a.setImageDrawable(b2);
        } else {
            this.f965a.setImageDrawable(null);
        }
        a();
    }

    public void d(ColorStateList colorStateList) {
        if (this.f966b == null) {
            this.f966b = new t0();
        }
        t0 t0Var = this.f966b;
        t0Var.f1047a = colorStateList;
        t0Var.f1050d = true;
        a();
    }

    public void e(PorterDuff.Mode mode) {
        if (this.f966b == null) {
            this.f966b = new t0();
        }
        t0 t0Var = this.f966b;
        t0Var.f1048b = mode;
        t0Var.f1049c = true;
        a();
    }
}
