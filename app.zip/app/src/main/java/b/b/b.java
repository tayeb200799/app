package b.b;

import android.R;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\b.smali */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f588a = {2130968639, 2130968646, 2130968647, 2130968836, 2130968837, 2130968838, 2130968839, 2130968840, 2130968841, 2130968879, 2130968896, 2130968897, 2130968922, 2130969009, 2130969016, 2130969022, 2130969024, 2130969027, 2130969046, 2130969064, 2130969181, 2130969258, 2130969305, 2130969314, 2130969315, 2130969426, 2130969429, 2130969534, 2130969544};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f589b = {R.attr.layout_gravity};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f590c = {R.attr.minWidth};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f591d = {2130968639, 2130968646, 2130968795, 2130969009, 2130969429, 2130969544};

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f592e = {R.attr.layout, 2130968697, 2130968698, 2130969170, 2130969171, 2130969254, 2130969385, 2130969387};

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f593f = {R.attr.src, 2130969405, 2130969532, 2130969533};

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f594g = {R.attr.thumb, 2130969528, 2130969529, 2130969530};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f595h = {R.attr.textAppearance, R.attr.drawableTop, R.attr.drawableBottom, R.attr.drawableLeft, R.attr.drawableRight, R.attr.drawableStart, R.attr.drawableEnd};

    /* renamed from: i, reason: collision with root package name */
    public static final int[] f596i = {R.attr.textAppearance, 2130968633, 2130968634, 2130968635, 2130968636, 2130968637, 2130968906, 2130968907, 2130968908, 2130968909, 2130968911, 2130968912, 2130968913, 2130968914, 2130968965, 2130968987, 2130968996, 2130969086, 2130969163, 2130969470, 2130969504};

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f597j = {R.attr.windowIsFloating, R.attr.windowAnimationStyle, 2130968578, 2130968579, 2130968580, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 2130968587, 2130968588, 2130968589, 2130968590, 2130968592, 2130968593, 2130968594, 2130968595, 2130968596, 2130968597, 2130968598, 2130968599, 2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 2130968608, 2130968612, 2130968613, 2130968614, 2130968615, 2130968616, 2130968632, 2130968673, 2130968690, 2130968691, 2130968692, 2130968693, 2130968694, 2130968700, 2130968701, 2130968732, 2130968741, 2130968803, 2130968804, 2130968805, 2130968806, 2130968807, 2130968808, 2130968809, 2130968816, 2130968817, 2130968824, 2130968851, 2130968893, 2130968894, 2130968895, 2130968898, 2130968900, 2130968916, 2130968917, 2130968919, 2130968920, 2130968921, 2130969022, 2130969040, 2130969166, 2130969167, 2130969168, 2130969169, 2130969172, 2130969173, 2130969174, 2130969175, 2130969176, 2130969177, 2130969178, 2130969179, 2130969180, 2130969282, 2130969283, 2130969284, 2130969304, 2130969306, 2130969323, 2130969325, 2130969326, 2130969327, 2130969361, 2130969363, 2130969364, 2130969365, 2130969397, 2130969398, 2130969437, 2130969481, 2130969483, 2130969484, 2130969485, 2130969487, 2130969488, 2130969489, 2130969490, 2130969498, 2130969499, 2130969546, 2130969547, 2130969548, 2130969549, 2130969580, 2130969596, 2130969597, 2130969598, 2130969599, 2130969600, 2130969601, 2130969602, 2130969603, 2130969604, 2130969605};
    public static final int[] k = {2130968617};
    public static final int[] l = {R.attr.button, 2130968695, 2130968702, 2130968703};
    public static final int[] m = {R.attr.gravity, R.attr.orientation, R.attr.baselineAligned, R.attr.baselineAlignedChildIndex, R.attr.weightSum, 2130968897, 2130968899, 2130969221, 2130969381};
    public static final int[] n = {R.attr.layout_gravity, R.attr.layout_width, R.attr.layout_height, R.attr.layout_weight};
    public static final int[] o = {R.attr.dropDownHorizontalOffset, R.attr.dropDownVerticalOffset};
    public static final int[] p = {R.attr.enabled, R.attr.id, R.attr.visible, R.attr.menuCategory, R.attr.orderInCategory, R.attr.checkableBehavior};
    public static final int[] q = {R.attr.icon, R.attr.enabled, R.attr.id, R.attr.checked, R.attr.visible, R.attr.menuCategory, R.attr.orderInCategory, R.attr.title, R.attr.titleCondensed, R.attr.alphabeticShortcut, R.attr.numericShortcut, R.attr.checkable, R.attr.onClick, 2130968591, 2130968609, 2130968611, 2130968619, 2130968835, 2130969033, 2130969034, 2130969264, 2130969379, 2130969551};
    public static final int[] r = {R.attr.windowAnimationStyle, R.attr.itemTextAppearance, R.attr.horizontalDivider, R.attr.verticalDivider, R.attr.headerBackground, R.attr.itemBackground, R.attr.itemIconDisabledAlpha, 2130969311, 2130969424};
    public static final int[] s = {R.attr.popupBackground, R.attr.popupAnimationStyle, 2130969273};
    public static final int[] t = {2130969275, 2130969281};
    public static final int[] u = {R.attr.focusable, R.attr.maxWidth, R.attr.inputType, R.attr.imeOptions, 2130968788, 2130968825, 2130968888, 2130969002, 2130969035, 2130969087, 2130969320, 2130969321, 2130969359, 2130969360, 2130969425, 2130969433, 2130969586};
    public static final int[] v = {R.attr.entries, R.attr.popupBackground, R.attr.prompt, R.attr.dropDownWidth, 2130969305};
    public static final int[] w = {R.attr.textOn, R.attr.textOff, R.attr.thumb, 2130969384, 2130969399, 2130969435, 2130969436, 2130969438, 2130969522, 2130969523, 2130969524, 2130969555, 2130969562, 2130969563};
    public static final int[] x = {R.attr.textSize, R.attr.typeface, R.attr.textStyle, R.attr.textColor, R.attr.textColorHint, R.attr.textColorLink, R.attr.shadowColor, R.attr.shadowDx, R.attr.shadowDy, R.attr.shadowRadius, R.attr.fontFamily, R.attr.textFontWeight, 2130968987, 2130968996, 2130969470, 2130969504};
    public static final int[] y = {R.attr.gravity, R.attr.minHeight, 2130968696, 2130968796, 2130968797, 2130968836, 2130968837, 2130968838, 2130968839, 2130968840, 2130968841, 2130969181, 2130969182, 2130969214, 2130969222, 2130969255, 2130969256, 2130969305, 2130969426, 2130969427, 2130969428, 2130969534, 2130969536, 2130969537, 2130969538, 2130969539, 2130969540, 2130969541, 2130969542, 2130969543};
    public static final int[] z = {R.attr.theme, R.attr.focusable, 2130969277, 2130969280, 2130969514};
    public static final int[] A = {R.attr.background, 2130968648, 2130968649};
    public static final int[] B = {R.attr.id, R.attr.layout, R.attr.inflatedId};
}
