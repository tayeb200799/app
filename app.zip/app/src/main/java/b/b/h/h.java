package b.b.h.i;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\c.smali */
public abstract class c {

    /* renamed from: a, reason: collision with root package name */
    public final Context f788a;

    /* renamed from: b, reason: collision with root package name */
    public b.e.h<b.h.f.a.b, MenuItem> f789b;

    /* renamed from: c, reason: collision with root package name */
    public b.e.h<b.h.f.a.c, SubMenu> f790c;

    public c(Context context) {
        this.f788a = context;
    }

    public final MenuItem c(MenuItem menuItem) {
        if (!(menuItem instanceof b.h.f.a.b)) {
            return menuItem;
        }
        b.h.f.a.b bVar = (b.h.f.a.b) menuItem;
        if (this.f789b == null) {
            this.f789b = new b.e.h<>();
        }
        MenuItem orDefault = this.f789b.getOrDefault(menuItem, null);
        if (orDefault != null) {
            return orDefault;
        }
        j jVar = new j(this.f788a, bVar);
        this.f789b.put(bVar, jVar);
        return jVar;
    }

    public final SubMenu d(SubMenu subMenu) {
        if (!(subMenu instanceof b.h.f.a.c)) {
            return subMenu;
        }
        b.h.f.a.c cVar = (b.h.f.a.c) subMenu;
        if (this.f790c == null) {
            this.f790c = new b.e.h<>();
        }
        SubMenu subMenu2 = this.f790c.get(cVar);
        if (subMenu2 != null) {
            return subMenu2;
        }
        s sVar = new s(this.f788a, cVar);
        this.f790c.put(cVar, sVar);
        return sVar;
    }
}
