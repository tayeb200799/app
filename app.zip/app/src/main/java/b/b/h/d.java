package b.b.h;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import b.b.h.i.i;
import b.b.h.i.j;
import b.b.i.v0;
import b.b.i.z;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\f.smali */
public class f extends MenuInflater {

    /* renamed from: e, reason: collision with root package name */
    public static final Class<?>[] f742e;

    /* renamed from: f, reason: collision with root package name */
    public static final Class<?>[] f743f;

    /* renamed from: a, reason: collision with root package name */
    public final Object[] f744a;

    /* renamed from: b, reason: collision with root package name */
    public final Object[] f745b;

    /* renamed from: c, reason: collision with root package name */
    public Context f746c;

    /* renamed from: d, reason: collision with root package name */
    public Object f747d;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\f$a.smali */
    public static class a implements MenuItem.OnMenuItemClickListener {

        /* renamed from: c, reason: collision with root package name */
        public static final Class<?>[] f748c = {MenuItem.class};

        /* renamed from: a, reason: collision with root package name */
        public Object f749a;

        /* renamed from: b, reason: collision with root package name */
        public Method f750b;

        public a(Object obj, String str) {
            this.f749a = obj;
            Class<?> cls = obj.getClass();
            try {
                this.f750b = cls.getMethod(str, f748c);
            } catch (Exception e2) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str + " in class " + cls.getName());
                inflateException.initCause(e2);
                throw inflateException;
            }
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.f750b.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.f750b.invoke(this.f749a, menuItem)).booleanValue();
                }
                this.f750b.invoke(this.f749a, menuItem);
                return true;
            } catch (Exception e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\f$b.smali */
    public class b {
        public b.h.k.b A;
        public CharSequence B;
        public CharSequence C;

        /* renamed from: a, reason: collision with root package name */
        public Menu f751a;

        /* renamed from: h, reason: collision with root package name */
        public boolean f758h;

        /* renamed from: i, reason: collision with root package name */
        public int f759i;

        /* renamed from: j, reason: collision with root package name */
        public int f760j;
        public CharSequence k;
        public CharSequence l;
        public int m;
        public char n;
        public int o;
        public char p;
        public int q;
        public int r;
        public boolean s;
        public boolean t;
        public boolean u;
        public int v;
        public int w;
        public String x;
        public String y;
        public String z;
        public ColorStateList D = null;
        public PorterDuff.Mode E = null;

        /* renamed from: b, reason: collision with root package name */
        public int f752b = 0;

        /* renamed from: c, reason: collision with root package name */
        public int f753c = 0;

        /* renamed from: d, reason: collision with root package name */
        public int f754d = 0;

        /* renamed from: e, reason: collision with root package name */
        public int f755e = 0;

        /* renamed from: f, reason: collision with root package name */
        public boolean f756f = true;

        /* renamed from: g, reason: collision with root package name */
        public boolean f757g = true;

        public b(Menu menu) {
            this.f751a = menu;
        }

        public SubMenu a() {
            this.f758h = true;
            SubMenu addSubMenu = this.f751a.addSubMenu(this.f752b, this.f759i, this.f760j, this.k);
            c(addSubMenu.getItem());
            return addSubMenu;
        }

        public final <T> T b(String str, Class<?>[] clsArr, Object[] objArr) {
            try {
                Constructor<?> constructor = Class.forName(str, false, f.this.f746c.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                return (T) constructor.newInstance(objArr);
            } catch (Exception e2) {
                Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
                return null;
            }
        }

        public final void c(MenuItem menuItem) {
            int i2 = Build.VERSION.SDK_INT;
            boolean z = false;
            menuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u).setCheckable(this.r >= 1).setTitleCondensed(this.l).setIcon(this.m);
            int i3 = this.v;
            if (i3 >= 0) {
                menuItem.setShowAsAction(i3);
            }
            if (this.z != null) {
                if (f.this.f746c.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                f fVar = f.this;
                if (fVar.f747d == null) {
                    fVar.f747d = fVar.a(fVar.f746c);
                }
                menuItem.setOnMenuItemClickListener(new a(fVar.f747d, this.z));
            }
            if (this.r >= 2) {
                if (menuItem instanceof i) {
                    i iVar = (i) menuItem;
                    iVar.x = (iVar.x & (-5)) | 4;
                } else if (menuItem instanceof j) {
                    j jVar = (j) menuItem;
                    try {
                        if (jVar.f846e == null) {
                            jVar.f846e = jVar.f845d.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                        }
                        jVar.f846e.invoke(jVar.f845d, Boolean.TRUE);
                    } catch (Exception e2) {
                        Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e2);
                    }
                }
            }
            String str = this.x;
            if (str != null) {
                menuItem.setActionView((View) b(str, f.f742e, f.this.f744a));
                z = true;
            }
            int i4 = this.w;
            if (i4 > 0) {
                if (z) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                } else {
                    menuItem.setActionView(i4);
                }
            }
            b.h.k.b bVar = this.A;
            if (bVar != null) {
                if (menuItem instanceof b.h.f.a.b) {
                    ((b.h.f.a.b) menuItem).a(bVar);
                } else {
                    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
                }
            }
            CharSequence charSequence = this.B;
            boolean z2 = menuItem instanceof b.h.f.a.b;
            if (z2) {
                ((b.h.f.a.b) menuItem).setContentDescription(charSequence);
            } else if (i2 >= 26) {
                menuItem.setContentDescription(charSequence);
            }
            CharSequence charSequence2 = this.C;
            if (z2) {
                ((b.h.f.a.b) menuItem).setTooltipText(charSequence2);
            } else if (i2 >= 26) {
                menuItem.setTooltipText(charSequence2);
            }
            char c2 = this.n;
            int i5 = this.o;
            if (z2) {
                ((b.h.f.a.b) menuItem).setAlphabeticShortcut(c2, i5);
            } else if (i2 >= 26) {
                menuItem.setAlphabeticShortcut(c2, i5);
            }
            char c3 = this.p;
            int i6 = this.q;
            if (z2) {
                ((b.h.f.a.b) menuItem).setNumericShortcut(c3, i6);
            } else if (i2 >= 26) {
                menuItem.setNumericShortcut(c3, i6);
            }
            PorterDuff.Mode mode = this.E;
            if (mode != null) {
                if (z2) {
                    ((b.h.f.a.b) menuItem).setIconTintMode(mode);
                } else if (i2 >= 26) {
                    menuItem.setIconTintMode(mode);
                }
            }
            ColorStateList colorStateList = this.D;
            if (colorStateList != null) {
                if (z2) {
                    ((b.h.f.a.b) menuItem).setIconTintList(colorStateList);
                } else if (i2 >= 26) {
                    menuItem.setIconTintList(colorStateList);
                }
            }
        }
    }

    static {
        Class<?>[] clsArr = {Context.class};
        f742e = clsArr;
        f743f = clsArr;
    }

    public f(Context context) {
        super(context);
        this.f746c = context;
        Object[] objArr = {context};
        this.f744a = objArr;
        this.f745b = objArr;
    }

    public final Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    public final void b(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) {
        ColorStateList colorStateList;
        b bVar = new b(menu);
        int eventType = xmlPullParser.getEventType();
        while (true) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if (!name.equals("menu")) {
                    throw new RuntimeException(c.a.a.a.a.f("Expecting menu, got ", name));
                }
                eventType = xmlPullParser.next();
            } else {
                eventType = xmlPullParser.next();
                if (eventType == 1) {
                    break;
                }
            }
        }
        boolean z = false;
        boolean z2 = false;
        String str = null;
        while (!z) {
            if (eventType == 1) {
                throw new RuntimeException("Unexpected end of document");
            }
            if (eventType != 2) {
                if (eventType == 3) {
                    String name2 = xmlPullParser.getName();
                    if (z2 && name2.equals(str)) {
                        str = null;
                        z2 = false;
                    } else if (name2.equals("group")) {
                        bVar.f752b = 0;
                        bVar.f753c = 0;
                        bVar.f754d = 0;
                        bVar.f755e = 0;
                        bVar.f756f = true;
                        bVar.f757g = true;
                    } else if (name2.equals("item")) {
                        if (!bVar.f758h) {
                            b.h.k.b bVar2 = bVar.A;
                            if (bVar2 == null || !bVar2.a()) {
                                bVar.f758h = true;
                                bVar.c(bVar.f751a.add(bVar.f752b, bVar.f759i, bVar.f760j, bVar.k));
                            } else {
                                bVar.a();
                            }
                        }
                    } else if (name2.equals("menu")) {
                        z = true;
                    }
                }
            } else if (!z2) {
                String name3 = xmlPullParser.getName();
                if (name3.equals("group")) {
                    TypedArray obtainStyledAttributes = f.this.f746c.obtainStyledAttributes(attributeSet, b.b.b.p);
                    bVar.f752b = obtainStyledAttributes.getResourceId(1, 0);
                    bVar.f753c = obtainStyledAttributes.getInt(3, 0);
                    bVar.f754d = obtainStyledAttributes.getInt(4, 0);
                    bVar.f755e = obtainStyledAttributes.getInt(5, 0);
                    bVar.f756f = obtainStyledAttributes.getBoolean(2, true);
                    bVar.f757g = obtainStyledAttributes.getBoolean(0, true);
                    obtainStyledAttributes.recycle();
                } else if (name3.equals("item")) {
                    v0 p = v0.p(f.this.f746c, attributeSet, b.b.b.q);
                    bVar.f759i = p.l(2, 0);
                    bVar.f760j = (p.j(5, bVar.f753c) & (-65536)) | (p.j(6, bVar.f754d) & 65535);
                    bVar.k = p.n(7);
                    bVar.l = p.n(8);
                    bVar.m = p.l(0, 0);
                    String m = p.m(9);
                    bVar.n = m == null ? (char) 0 : m.charAt(0);
                    bVar.o = p.j(16, 4096);
                    String m2 = p.m(10);
                    bVar.p = m2 == null ? (char) 0 : m2.charAt(0);
                    bVar.q = p.j(20, 4096);
                    if (p.o(11)) {
                        bVar.r = p.a(11, false) ? 1 : 0;
                    } else {
                        bVar.r = bVar.f755e;
                    }
                    bVar.s = p.a(3, false);
                    bVar.t = p.a(4, bVar.f756f);
                    bVar.u = p.a(1, bVar.f757g);
                    bVar.v = p.j(21, -1);
                    bVar.z = p.m(12);
                    bVar.w = p.l(13, 0);
                    bVar.x = p.m(15);
                    String m3 = p.m(14);
                    bVar.y = m3;
                    boolean z3 = m3 != null;
                    if (z3 && bVar.w == 0 && bVar.x == null) {
                        bVar.A = (b.h.k.b) bVar.b(m3, f743f, f.this.f745b);
                    } else {
                        if (z3) {
                            Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                        }
                        bVar.A = null;
                    }
                    bVar.B = p.n(17);
                    bVar.C = p.n(22);
                    if (p.o(19)) {
                        bVar.E = z.d(p.j(19, -1), bVar.E);
                        colorStateList = null;
                    } else {
                        colorStateList = null;
                        bVar.E = null;
                    }
                    if (p.o(18)) {
                        bVar.D = p.c(18);
                    } else {
                        bVar.D = colorStateList;
                    }
                    p.f1076b.recycle();
                    bVar.f758h = false;
                } else if (name3.equals("menu")) {
                    b(xmlPullParser, attributeSet, bVar.a());
                } else {
                    z2 = true;
                    str = name3;
                }
            }
            eventType = xmlPullParser.next();
        }
    }

    @Override // android.view.MenuInflater
    public void inflate(int i2, Menu menu) {
        if (!(menu instanceof b.h.f.a.a)) {
            super.inflate(i2, menu);
            return;
        }
        XmlResourceParser xmlResourceParser = null;
        try {
            try {
                try {
                    xmlResourceParser = this.f746c.getResources().getLayout(i2);
                    b(xmlResourceParser, Xml.asAttributeSet(xmlResourceParser), menu);
                    xmlResourceParser.close();
                } catch (IOException e2) {
                    throw new InflateException("Error inflating menu XML", e2);
                }
            } catch (XmlPullParserException e3) {
                throw new InflateException("Error inflating menu XML", e3);
            }
        } catch (Throwable th) {
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            throw th;
        }
    }
}
