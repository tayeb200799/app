package b.b.h.i;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import b.b.h.i.n;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\f.smali */
public class f extends BaseAdapter {

    /* renamed from: d, reason: collision with root package name */
    public g f817d;

    /* renamed from: e, reason: collision with root package name */
    public int f818e = -1;

    /* renamed from: f, reason: collision with root package name */
    public boolean f819f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f820g;

    /* renamed from: h, reason: collision with root package name */
    public final LayoutInflater f821h;

    /* renamed from: i, reason: collision with root package name */
    public final int f822i;

    public f(g gVar, LayoutInflater layoutInflater, boolean z, int i2) {
        this.f820g = z;
        this.f821h = layoutInflater;
        this.f817d = gVar;
        this.f822i = i2;
        a();
    }

    public void a() {
        g gVar = this.f817d;
        i iVar = gVar.v;
        if (iVar != null) {
            gVar.i();
            ArrayList<i> arrayList = gVar.f832j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (arrayList.get(i2) == iVar) {
                    this.f818e = i2;
                    return;
                }
            }
        }
        this.f818e = -1;
    }

    @Override // android.widget.Adapter
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public i getItem(int i2) {
        ArrayList<i> l;
        if (this.f820g) {
            g gVar = this.f817d;
            gVar.i();
            l = gVar.f832j;
        } else {
            l = this.f817d.l();
        }
        int i3 = this.f818e;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return l.get(i2);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ArrayList<i> l;
        if (this.f820g) {
            g gVar = this.f817d;
            gVar.i();
            l = gVar.f832j;
        } else {
            l = this.f817d.l();
        }
        return this.f818e < 0 ? l.size() : l.size() - 1;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f821h.inflate(this.f822i, viewGroup, false);
        }
        int i3 = getItem(i2).f837b;
        int i4 = i2 - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f817d.m() && i3 != (i4 >= 0 ? getItem(i4).f837b : i3));
        n.a aVar = (n.a) view;
        if (this.f819f) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.d(getItem(i2), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
