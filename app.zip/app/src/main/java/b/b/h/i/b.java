package b.b.h.i;

import android.content.Context;
import android.view.LayoutInflater;
import b.b.h.i.m;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\b.smali */
public abstract class b implements m {

    /* renamed from: d, reason: collision with root package name */
    public Context f783d;

    /* renamed from: e, reason: collision with root package name */
    public Context f784e;

    /* renamed from: f, reason: collision with root package name */
    public g f785f;

    /* renamed from: g, reason: collision with root package name */
    public LayoutInflater f786g;

    /* renamed from: h, reason: collision with root package name */
    public m.a f787h;

    /* renamed from: i, reason: collision with root package name */
    public int f788i;

    /* renamed from: j, reason: collision with root package name */
    public int f789j;
    public n k;

    public b(Context context, int i2, int i3) {
        this.f783d = context;
        this.f786g = LayoutInflater.from(context);
        this.f788i = i2;
        this.f789j = i3;
    }

    @Override // b.b.h.i.m
    public boolean i(g gVar, i iVar) {
        return false;
    }

    @Override // b.b.h.i.m
    public boolean j(g gVar, i iVar) {
        return false;
    }

    @Override // b.b.h.i.m
    public void k(m.a aVar) {
        this.f787h = aVar;
    }
}
