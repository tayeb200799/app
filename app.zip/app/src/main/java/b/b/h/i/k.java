package b.b.h.i;

import android.content.Context;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\m.smali */
public interface m {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\m$a.smali */
    public interface a {
        void a(g gVar, boolean z);

        boolean b(g gVar);
    }

    void a(g gVar, boolean z);

    void c(Context context, g gVar);

    boolean e(r rVar);

    void f(boolean z);

    boolean h();

    boolean i(g gVar, i iVar);

    boolean j(g gVar, i iVar);

    void k(a aVar);
}
