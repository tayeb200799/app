package b.b.h.i;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import b.b.h.i.m;
import b.b.i.g0;
import b.b.i.h0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\d.smali */
public final class d extends k implements m, View.OnKeyListener, PopupWindow.OnDismissListener {
    public m.a A;
    public ViewTreeObserver B;
    public PopupWindow.OnDismissListener C;
    public boolean D;

    /* renamed from: e, reason: collision with root package name */
    public final Context f791e;

    /* renamed from: f, reason: collision with root package name */
    public final int f792f;

    /* renamed from: g, reason: collision with root package name */
    public final int f793g;

    /* renamed from: h, reason: collision with root package name */
    public final int f794h;

    /* renamed from: i, reason: collision with root package name */
    public final boolean f795i;

    /* renamed from: j, reason: collision with root package name */
    public final Handler f796j;
    public View r;
    public View s;
    public int t;
    public boolean u;
    public boolean v;
    public int w;
    public int x;
    public boolean z;
    public final List<g> k = new ArrayList();
    public final List<C0015d> l = new ArrayList();
    public final ViewTreeObserver.OnGlobalLayoutListener m = new a();
    public final View.OnAttachStateChangeListener n = new b();
    public final g0 o = new c();
    public int p = 0;
    public int q = 0;
    public boolean y = false;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\d$a.smali */
    public class a implements ViewTreeObserver.OnGlobalLayoutListener {
        public a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!d.this.b() || d.this.l.size() <= 0 || d.this.l.get(0).f804a.B) {
                return;
            }
            View view = d.this.s;
            if (view == null || !view.isShown()) {
                d.this.dismiss();
                return;
            }
            Iterator<C0015d> it = d.this.l.iterator();
            while (it.hasNext()) {
                it.next().f804a.d();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\d$b.smali */
    public class b implements View.OnAttachStateChangeListener {
        public b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = d.this.B;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    d.this.B = view.getViewTreeObserver();
                }
                d dVar = d.this;
                dVar.B.removeGlobalOnLayoutListener(dVar.m);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\d$c.smali */
    public class c implements g0 {

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\d$c$a.smali */
        public class a implements Runnable {

            /* renamed from: d, reason: collision with root package name */
            public final /* synthetic */ C0015d f800d;

            /* renamed from: e, reason: collision with root package name */
            public final /* synthetic */ MenuItem f801e;

            /* renamed from: f, reason: collision with root package name */
            public final /* synthetic */ g f802f;

            public a(C0015d c0015d, MenuItem menuItem, g gVar) {
                this.f800d = c0015d;
                this.f801e = menuItem;
                this.f802f = gVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                C0015d c0015d = this.f800d;
                if (c0015d != null) {
                    d.this.D = true;
                    c0015d.f805b.c(false);
                    d.this.D = false;
                }
                if (this.f801e.isEnabled() && this.f801e.hasSubMenu()) {
                    this.f802f.r(this.f801e, 4);
                }
            }
        }

        public c() {
        }

        @Override // b.b.i.g0
        public void c(g gVar, MenuItem menuItem) {
            d.this.f796j.removeCallbacksAndMessages(null);
            int size = d.this.l.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    i2 = -1;
                    break;
                } else if (gVar == d.this.l.get(i2).f805b) {
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 == -1) {
                return;
            }
            int i3 = i2 + 1;
            d.this.f796j.postAtTime(new a(i3 < d.this.l.size() ? d.this.l.get(i3) : null, menuItem, gVar), gVar, SystemClock.uptimeMillis() + 200);
        }

        @Override // b.b.i.g0
        public void e(g gVar, MenuItem menuItem) {
            d.this.f796j.removeCallbacksAndMessages(gVar);
        }
    }

    /* renamed from: b.b.h.i.d$d, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\d$d.smali */
    public static class C0015d {

        /* renamed from: a, reason: collision with root package name */
        public final h0 f804a;

        /* renamed from: b, reason: collision with root package name */
        public final g f805b;

        /* renamed from: c, reason: collision with root package name */
        public final int f806c;

        public C0015d(h0 h0Var, g gVar, int i2) {
            this.f804a = h0Var;
            this.f805b = gVar;
            this.f806c = i2;
        }
    }

    public d(Context context, View view, int i2, int i3, boolean z) {
        this.f791e = context;
        this.r = view;
        this.f793g = i2;
        this.f794h = i3;
        this.f795i = z;
        AtomicInteger atomicInteger = b.h.k.q.f1738a;
        this.t = view.getLayoutDirection() != 1 ? 1 : 0;
        Resources resources = context.getResources();
        this.f792f = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(2131165207));
        this.f796j = new Handler();
    }

    @Override // b.b.h.i.m
    public void a(g gVar, boolean z) {
        int size = this.l.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (gVar == this.l.get(i2).f805b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 < 0) {
            return;
        }
        int i3 = i2 + 1;
        if (i3 < this.l.size()) {
            this.l.get(i3).f805b.c(false);
        }
        C0015d remove = this.l.remove(i2);
        remove.f805b.u(this);
        if (this.D) {
            h0 h0Var = remove.f804a;
            Objects.requireNonNull(h0Var);
            if (Build.VERSION.SDK_INT >= 23) {
                h0Var.C.setExitTransition(null);
            }
            remove.f804a.C.setAnimationStyle(0);
        }
        remove.f804a.dismiss();
        int size2 = this.l.size();
        if (size2 > 0) {
            this.t = this.l.get(size2 - 1).f806c;
        } else {
            View view = this.r;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            this.t = view.getLayoutDirection() == 1 ? 0 : 1;
        }
        if (size2 != 0) {
            if (z) {
                this.l.get(0).f805b.c(false);
                return;
            }
            return;
        }
        dismiss();
        m.a aVar = this.A;
        if (aVar != null) {
            aVar.a(gVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.B;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.B.removeGlobalOnLayoutListener(this.m);
            }
            this.B = null;
        }
        this.s.removeOnAttachStateChangeListener(this.n);
        this.C.onDismiss();
    }

    @Override // b.b.h.i.p
    public boolean b() {
        return this.l.size() > 0 && this.l.get(0).f804a.b();
    }

    @Override // b.b.h.i.p
    public void d() {
        if (b()) {
            return;
        }
        Iterator<g> it = this.k.iterator();
        while (it.hasNext()) {
            w(it.next());
        }
        this.k.clear();
        View view = this.r;
        this.s = view;
        if (view != null) {
            boolean z = this.B == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.B = viewTreeObserver;
            if (z) {
                viewTreeObserver.addOnGlobalLayoutListener(this.m);
            }
            this.s.addOnAttachStateChangeListener(this.n);
        }
    }

    @Override // b.b.h.i.p
    public void dismiss() {
        int size = this.l.size();
        if (size > 0) {
            C0015d[] c0015dArr = (C0015d[]) this.l.toArray(new C0015d[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                C0015d c0015d = c0015dArr[i2];
                if (c0015d.f804a.b()) {
                    c0015d.f804a.dismiss();
                }
            }
        }
    }

    @Override // b.b.h.i.m
    public boolean e(r rVar) {
        for (C0015d c0015d : this.l) {
            if (rVar == c0015d.f805b) {
                c0015d.f804a.f937f.requestFocus();
                return true;
            }
        }
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        rVar.b(this, this.f791e);
        if (b()) {
            w(rVar);
        } else {
            this.k.add(rVar);
        }
        m.a aVar = this.A;
        if (aVar != null) {
            aVar.b(rVar);
        }
        return true;
    }

    @Override // b.b.h.i.m
    public void f(boolean z) {
        Iterator<C0015d> it = this.l.iterator();
        while (it.hasNext()) {
            ListAdapter adapter = it.next().f804a.f937f.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((f) adapter).notifyDataSetChanged();
        }
    }

    @Override // b.b.h.i.p
    public ListView g() {
        if (this.l.isEmpty()) {
            return null;
        }
        return this.l.get(r0.size() - 1).f804a.f937f;
    }

    @Override // b.b.h.i.m
    public boolean h() {
        return false;
    }

    @Override // b.b.h.i.m
    public void k(m.a aVar) {
        this.A = aVar;
    }

    @Override // b.b.h.i.k
    public void l(g gVar) {
        gVar.b(this, this.f791e);
        if (b()) {
            w(gVar);
        } else {
            this.k.add(gVar);
        }
    }

    @Override // b.b.h.i.k
    public boolean m() {
        return false;
    }

    @Override // b.b.h.i.k
    public void o(View view) {
        if (this.r != view) {
            this.r = view;
            int i2 = this.p;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            this.q = Gravity.getAbsoluteGravity(i2, view.getLayoutDirection());
        }
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        C0015d c0015d;
        int size = this.l.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                c0015d = null;
                break;
            }
            c0015d = this.l.get(i2);
            if (!c0015d.f804a.b()) {
                break;
            } else {
                i2++;
            }
        }
        if (c0015d != null) {
            c0015d.f805b.c(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // b.b.h.i.k
    public void p(boolean z) {
        this.y = z;
    }

    @Override // b.b.h.i.k
    public void q(int i2) {
        if (this.p != i2) {
            this.p = i2;
            View view = this.r;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            this.q = Gravity.getAbsoluteGravity(i2, view.getLayoutDirection());
        }
    }

    @Override // b.b.h.i.k
    public void r(int i2) {
        this.u = true;
        this.w = i2;
    }

    @Override // b.b.h.i.k
    public void s(PopupWindow.OnDismissListener onDismissListener) {
        this.C = onDismissListener;
    }

    @Override // b.b.h.i.k
    public void t(boolean z) {
        this.z = z;
    }

    @Override // b.b.h.i.k
    public void u(int i2) {
        this.v = true;
        this.x = i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01b9  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void w(b.b.h.i.g r17) {
        /*
            Method dump skipped, instructions count: 536
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.h.i.d.w(b.b.h.i.g):void");
    }
}
