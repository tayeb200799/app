package b.b.h.i;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import b.b.h.i.m;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\l.smali */
public class l {

    /* renamed from: a, reason: collision with root package name */
    public final Context f858a;

    /* renamed from: b, reason: collision with root package name */
    public final g f859b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f860c;

    /* renamed from: d, reason: collision with root package name */
    public final int f861d;

    /* renamed from: e, reason: collision with root package name */
    public final int f862e;

    /* renamed from: f, reason: collision with root package name */
    public View f863f;

    /* renamed from: h, reason: collision with root package name */
    public boolean f865h;

    /* renamed from: i, reason: collision with root package name */
    public m.a f866i;

    /* renamed from: j, reason: collision with root package name */
    public k f867j;
    public PopupWindow.OnDismissListener k;

    /* renamed from: g, reason: collision with root package name */
    public int f864g = 8388611;
    public final PopupWindow.OnDismissListener l = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\l$a.smali */
    public class a implements PopupWindow.OnDismissListener {
        public a() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            l.this.c();
        }
    }

    public l(Context context, g gVar, View view, boolean z, int i2, int i3) {
        this.f858a = context;
        this.f859b = gVar;
        this.f863f = view;
        this.f860c = z;
        this.f861d = i2;
        this.f862e = i3;
    }

    public k a() {
        if (this.f867j == null) {
            Display defaultDisplay = ((WindowManager) this.f858a.getSystemService("window")).getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getRealSize(point);
            k dVar = Math.min(point.x, point.y) >= this.f858a.getResources().getDimensionPixelSize(2131165206) ? new d(this.f858a, this.f863f, this.f861d, this.f862e, this.f860c) : new q(this.f858a, this.f859b, this.f863f, this.f861d, this.f862e, this.f860c);
            dVar.l(this.f859b);
            dVar.s(this.l);
            dVar.o(this.f863f);
            dVar.k(this.f866i);
            dVar.p(this.f865h);
            dVar.q(this.f864g);
            this.f867j = dVar;
        }
        return this.f867j;
    }

    public boolean b() {
        k kVar = this.f867j;
        return kVar != null && kVar.b();
    }

    public void c() {
        this.f867j = null;
        PopupWindow.OnDismissListener onDismissListener = this.k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void d(boolean z) {
        this.f865h = z;
        k kVar = this.f867j;
        if (kVar != null) {
            kVar.p(z);
        }
    }

    public void e(m.a aVar) {
        this.f866i = aVar;
        k kVar = this.f867j;
        if (kVar != null) {
            kVar.k(aVar);
        }
    }

    public final void f(int i2, int i3, boolean z, boolean z2) {
        k a2 = a();
        a2.t(z2);
        if (z) {
            int i4 = this.f864g;
            View view = this.f863f;
            AtomicInteger atomicInteger = b.h.k.q.f1741a;
            if ((Gravity.getAbsoluteGravity(i4, view.getLayoutDirection()) & 7) == 5) {
                i2 -= this.f863f.getWidth();
            }
            a2.r(i2);
            a2.u(i3);
            int i5 = (int) ((this.f858a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            a2.f857d = new Rect(i2 - i5, i3 - i5, i2 + i5, i3 + i5);
        }
        a2.d();
    }

    public boolean g() {
        if (b()) {
            return true;
        }
        if (this.f863f == null) {
            return false;
        }
        f(0, 0, false, false);
        return true;
    }
}
