package b.b.h.i;

import android.widget.ListView;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\p.smali */
public interface p {
    boolean b();

    void d();

    void dismiss();

    ListView g();
}
