package b.b.h.i;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import b.b.h.i.e;
import b.b.h.i.m;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\i\h.smali */
public class h implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, m.a {

    /* renamed from: d, reason: collision with root package name */
    public g f831d;

    /* renamed from: e, reason: collision with root package name */
    public b.b.c.g f832e;

    /* renamed from: f, reason: collision with root package name */
    public e f833f;

    public h(g gVar) {
        this.f831d = gVar;
    }

    @Override // b.b.h.i.m.a
    public void a(g gVar, boolean z) {
        b.b.c.g gVar2;
        if ((z || gVar == this.f831d) && (gVar2 = this.f832e) != null) {
            gVar2.dismiss();
        }
    }

    @Override // b.b.h.i.m.a
    public boolean b(g gVar) {
        return false;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i2) {
        this.f831d.r(((e.a) this.f833f.b()).getItem(i2), 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        e eVar = this.f833f;
        g gVar = this.f831d;
        m.a aVar = eVar.f811h;
        if (aVar != null) {
            aVar.a(gVar, true);
        }
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i2 == 82 || i2 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f832e.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f832e.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f831d.c(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f831d.performShortcut(i2, keyEvent, 0);
    }
}
