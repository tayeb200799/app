package b.b.h;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import b.b.h.a;
import b.b.h.i.j;
import b.b.h.i.o;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\e.smali */
public class e extends ActionMode {

    /* renamed from: a, reason: collision with root package name */
    public final Context f738a;

    /* renamed from: b, reason: collision with root package name */
    public final b.b.h.a f739b;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\e$a.smali */
    public static class a implements a.InterfaceC0014a {

        /* renamed from: a, reason: collision with root package name */
        public final ActionMode.Callback f740a;

        /* renamed from: b, reason: collision with root package name */
        public final Context f741b;

        /* renamed from: c, reason: collision with root package name */
        public final ArrayList<e> f742c = new ArrayList<>();

        /* renamed from: d, reason: collision with root package name */
        public final b.e.h<Menu, Menu> f743d = new b.e.h<>();

        public a(Context context, ActionMode.Callback callback) {
            this.f741b = context;
            this.f740a = callback;
        }

        @Override // b.b.h.a.InterfaceC0014a
        public boolean a(b.b.h.a aVar, Menu menu) {
            return this.f740a.onPrepareActionMode(e(aVar), f(menu));
        }

        @Override // b.b.h.a.InterfaceC0014a
        public void b(b.b.h.a aVar) {
            this.f740a.onDestroyActionMode(e(aVar));
        }

        @Override // b.b.h.a.InterfaceC0014a
        public boolean c(b.b.h.a aVar, MenuItem menuItem) {
            return this.f740a.onActionItemClicked(e(aVar), new j(this.f741b, (b.h.f.a.b) menuItem));
        }

        @Override // b.b.h.a.InterfaceC0014a
        public boolean d(b.b.h.a aVar, Menu menu) {
            return this.f740a.onCreateActionMode(e(aVar), f(menu));
        }

        public ActionMode e(b.b.h.a aVar) {
            int size = this.f742c.size();
            for (int i2 = 0; i2 < size; i2++) {
                e eVar = this.f742c.get(i2);
                if (eVar != null && eVar.f739b == aVar) {
                    return eVar;
                }
            }
            e eVar2 = new e(this.f741b, aVar);
            this.f742c.add(eVar2);
            return eVar2;
        }

        public final Menu f(Menu menu) {
            Menu orDefault = this.f743d.getOrDefault(menu, null);
            if (orDefault != null) {
                return orDefault;
            }
            o oVar = new o(this.f741b, (b.h.f.a.a) menu);
            this.f743d.put(menu, oVar);
            return oVar;
        }
    }

    public e(Context context, b.b.h.a aVar) {
        this.f738a = context;
        this.f739b = aVar;
    }

    @Override // android.view.ActionMode
    public void finish() {
        this.f739b.c();
    }

    @Override // android.view.ActionMode
    public View getCustomView() {
        return this.f739b.d();
    }

    @Override // android.view.ActionMode
    public Menu getMenu() {
        return new o(this.f738a, (b.h.f.a.a) this.f739b.e());
    }

    @Override // android.view.ActionMode
    public MenuInflater getMenuInflater() {
        return this.f739b.f();
    }

    @Override // android.view.ActionMode
    public CharSequence getSubtitle() {
        return this.f739b.g();
    }

    @Override // android.view.ActionMode
    public Object getTag() {
        return this.f739b.f726d;
    }

    @Override // android.view.ActionMode
    public CharSequence getTitle() {
        return this.f739b.h();
    }

    @Override // android.view.ActionMode
    public boolean getTitleOptionalHint() {
        return this.f739b.f727e;
    }

    @Override // android.view.ActionMode
    public void invalidate() {
        this.f739b.i();
    }

    @Override // android.view.ActionMode
    public boolean isTitleOptional() {
        return this.f739b.j();
    }

    @Override // android.view.ActionMode
    public void setCustomView(View view) {
        this.f739b.k(view);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(int i2) {
        this.f739b.l(i2);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(CharSequence charSequence) {
        this.f739b.m(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTag(Object obj) {
        this.f739b.f726d = obj;
    }

    @Override // android.view.ActionMode
    public void setTitle(int i2) {
        this.f739b.n(i2);
    }

    @Override // android.view.ActionMode
    public void setTitle(CharSequence charSequence) {
        this.f739b.o(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTitleOptionalHint(boolean z) {
        this.f739b.p(z);
    }
}
