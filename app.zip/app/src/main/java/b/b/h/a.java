package b.b.h;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.LayoutInflater;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\c.smali */
public class c extends ContextWrapper {

    /* renamed from: a, reason: collision with root package name */
    public int f726a;

    /* renamed from: b, reason: collision with root package name */
    public Resources.Theme f727b;

    /* renamed from: c, reason: collision with root package name */
    public LayoutInflater f728c;

    /* renamed from: d, reason: collision with root package name */
    public Configuration f729d;

    /* renamed from: e, reason: collision with root package name */
    public Resources f730e;

    public c() {
        super(null);
    }

    public c(Context context, int i2) {
        super(context);
        this.f726a = i2;
    }

    public c(Context context, Resources.Theme theme) {
        super(context);
        this.f727b = theme;
    }

    public void a(Configuration configuration) {
        if (this.f730e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        }
        if (this.f729d != null) {
            throw new IllegalStateException("Override configuration has already been set");
        }
        this.f729d = new Configuration(configuration);
    }

    @Override // android.content.ContextWrapper
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public final void b() {
        if (this.f727b == null) {
            this.f727b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f727b.setTo(theme);
            }
        }
        this.f727b.applyStyle(this.f726a, true);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        if (this.f730e == null) {
            Configuration configuration = this.f729d;
            if (configuration == null) {
                this.f730e = super.getResources();
            } else {
                this.f730e = createConfigurationContext(configuration).getResources();
            }
        }
        return this.f730e;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f728c == null) {
            this.f728c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f728c;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f727b;
        if (theme != null) {
            return theme;
        }
        if (this.f726a == 0) {
            this.f726a = 2131952076;
        }
        b();
        return this.f727b;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public void setTheme(int i2) {
        if (this.f726a != i2) {
            this.f726a = i2;
            b();
        }
    }
}
