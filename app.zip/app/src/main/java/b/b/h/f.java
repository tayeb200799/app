package b.b.h;

import android.view.View;
import android.view.animation.Interpolator;
import b.h.k.t;
import b.h.k.u;
import b.h.k.v;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\g.smali */
public class g {

    /* renamed from: c, reason: collision with root package name */
    public Interpolator f763c;

    /* renamed from: d, reason: collision with root package name */
    public u f764d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f765e;

    /* renamed from: b, reason: collision with root package name */
    public long f762b = -1;

    /* renamed from: f, reason: collision with root package name */
    public final v f766f = new a();

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList<t> f761a = new ArrayList<>();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\h\g$a.smali */
    public class a extends v {

        /* renamed from: a, reason: collision with root package name */
        public boolean f767a = false;

        /* renamed from: b, reason: collision with root package name */
        public int f768b = 0;

        public a() {
        }

        @Override // b.h.k.u
        public void b(View view) {
            int i2 = this.f768b + 1;
            this.f768b = i2;
            if (i2 == g.this.f761a.size()) {
                u uVar = g.this.f764d;
                if (uVar != null) {
                    uVar.b(null);
                }
                this.f768b = 0;
                this.f767a = false;
                g.this.f765e = false;
            }
        }

        @Override // b.h.k.v, b.h.k.u
        public void c(View view) {
            if (this.f767a) {
                return;
            }
            this.f767a = true;
            u uVar = g.this.f764d;
            if (uVar != null) {
                uVar.c(null);
            }
        }
    }

    public void a() {
        if (this.f765e) {
            Iterator<t> it = this.f761a.iterator();
            while (it.hasNext()) {
                it.next().b();
            }
            this.f765e = false;
        }
    }

    public void b() {
        View view;
        if (this.f765e) {
            return;
        }
        Iterator<t> it = this.f761a.iterator();
        while (it.hasNext()) {
            t next = it.next();
            long j2 = this.f762b;
            if (j2 >= 0) {
                next.c(j2);
            }
            Interpolator interpolator = this.f763c;
            if (interpolator != null && (view = next.f1756a.get()) != null) {
                view.animate().setInterpolator(interpolator);
            }
            if (this.f764d != null) {
                next.d(this.f766f);
            }
            View view2 = next.f1756a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.f765e = true;
    }
}
