package b.b.f;

import android.R;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\f\a.smali */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f722a = {R.attr.dither, R.attr.visible, R.attr.variablePadding, R.attr.constantSize, R.attr.enterFadeDuration, R.attr.exitFadeDuration};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f723b = {R.attr.id, R.attr.drawable};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f724c = {R.attr.drawable, R.attr.toId, R.attr.fromId, R.attr.reversible};
}
