package b.b.c;

import android.R;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\r.smali */
public class r {

    /* renamed from: b, reason: collision with root package name */
    public static final Class<?>[] f651b = {Context.class, AttributeSet.class};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f652c = {R.attr.onClick};

    /* renamed from: d, reason: collision with root package name */
    public static final String[] f653d = {"android.widget.", "android.view.", "android.webkit."};

    /* renamed from: e, reason: collision with root package name */
    public static final b.e.h<String, Constructor<? extends View>> f654e = new b.e.h<>();

    /* renamed from: a, reason: collision with root package name */
    public final Object[] f655a = new Object[2];

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\r$a.smali */
    public static class a implements View.OnClickListener {

        /* renamed from: d, reason: collision with root package name */
        public final View f656d;

        /* renamed from: e, reason: collision with root package name */
        public final String f657e;

        /* renamed from: f, reason: collision with root package name */
        public Method f658f;

        /* renamed from: g, reason: collision with root package name */
        public Context f659g;

        public a(View view, String str) {
            this.f656d = view;
            this.f657e = str;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            String sb;
            Method method;
            if (this.f658f == null) {
                Context context = this.f656d.getContext();
                while (context != null) {
                    try {
                        if (!context.isRestricted() && (method = context.getClass().getMethod(this.f657e, View.class)) != null) {
                            this.f658f = method;
                            this.f659g = context;
                        }
                    } catch (NoSuchMethodException unused) {
                    }
                    context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
                }
                int id = this.f656d.getId();
                if (id == -1) {
                    sb = "";
                } else {
                    StringBuilder n = c.a.a.a.a.n(" with id '");
                    n.append(this.f656d.getContext().getResources().getResourceEntryName(id));
                    n.append("'");
                    sb = n.toString();
                }
                StringBuilder n2 = c.a.a.a.a.n("Could not find method ");
                n2.append(this.f657e);
                n2.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
                n2.append(this.f656d.getClass());
                n2.append(sb);
                throw new IllegalStateException(n2.toString());
            }
            try {
                this.f658f.invoke(this.f659g, view);
            } catch (IllegalAccessException e2) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
            } catch (InvocationTargetException e3) {
                throw new IllegalStateException("Could not execute method for android:onClick", e3);
            }
        }
    }

    public b.b.i.d a(Context context, AttributeSet attributeSet) {
        return new b.b.i.d(context, attributeSet);
    }

    public AppCompatButton b(Context context, AttributeSet attributeSet) {
        return new AppCompatButton(context, attributeSet);
    }

    public b.b.i.f c(Context context, AttributeSet attributeSet) {
        return new b.b.i.f(context, attributeSet);
    }

    public b.b.i.n d(Context context, AttributeSet attributeSet) {
        return new b.b.i.n(context, attributeSet, 2130969323);
    }

    public AppCompatTextView e(Context context, AttributeSet attributeSet) {
        return new AppCompatTextView(context, attributeSet);
    }

    public View f() {
        return null;
    }

    public final View g(Context context, String str, String str2) {
        String str3;
        b.e.h<String, Constructor<? extends View>> hVar = f654e;
        Constructor<? extends View> orDefault = hVar.getOrDefault(str, null);
        if (orDefault == null) {
            if (str2 != null) {
                try {
                    str3 = str2 + str;
                } catch (Exception unused) {
                    return null;
                }
            } else {
                str3 = str;
            }
            orDefault = Class.forName(str3, false, context.getClassLoader()).asSubclass(View.class).getConstructor(f651b);
            hVar.put(str, orDefault);
        }
        orDefault.setAccessible(true);
        return orDefault.newInstance(this.f655a);
    }

    public final void h(View view, String str) {
        if (view != null) {
            return;
        }
        throw new IllegalStateException(getClass().getName() + " asked to inflate view for <" + str + ">, but returned null");
    }
}
