package b.b.c;

import android.view.View;
import androidx.appcompat.app.AlertController;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\e.smali */
public class e implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ View f606d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ View f607e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ AlertController f608f;

    public e(AlertController alertController, View view, View view2) {
        this.f608f = alertController;
        this.f606d = view;
        this.f607e = view2;
    }

    @Override // java.lang.Runnable
    public void run() {
        AlertController.c(this.f608f.f100g, this.f606d, this.f607e);
    }
}
