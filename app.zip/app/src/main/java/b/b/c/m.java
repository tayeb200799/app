package b.b.c;

import android.view.View;
import b.h.k.v;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\o.smali */
public class o extends v {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k f647a;

    public o(k kVar) {
        this.f647a = kVar;
    }

    @Override // b.h.k.u
    public void b(View view) {
        this.f647a.s.setAlpha(1.0f);
        this.f647a.v.d(null);
        this.f647a.v = null;
    }

    @Override // b.h.k.v, b.h.k.u
    public void c(View view) {
        this.f647a.s.setVisibility(0);
        this.f647a.s.sendAccessibilityEvent(32);
        if (this.f647a.s.getParent() instanceof View) {
            View view2 = (View) this.f647a.s.getParent();
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            view2.requestApplyInsets();
        }
    }
}
