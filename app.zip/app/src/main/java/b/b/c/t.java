package b.b.c;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\t.smali */
public class t {

    /* renamed from: d, reason: collision with root package name */
    public static t f666d;

    /* renamed from: a, reason: collision with root package name */
    public final Context f667a;

    /* renamed from: b, reason: collision with root package name */
    public final LocationManager f668b;

    /* renamed from: c, reason: collision with root package name */
    public final a f669c = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\t$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public boolean f670a;

        /* renamed from: b, reason: collision with root package name */
        public long f671b;
    }

    public t(Context context, LocationManager locationManager) {
        this.f667a = context;
        this.f668b = locationManager;
    }

    public final Location a(String str) {
        try {
            if (this.f668b.isProviderEnabled(str)) {
                return this.f668b.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e2) {
            Log.d("TwilightManager", "Failed to get last known location", e2);
            return null;
        }
    }
}
