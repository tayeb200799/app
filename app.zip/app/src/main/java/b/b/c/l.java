package b.b.c;

import android.view.View;
import b.h.k.x;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\l.smali */
public class l implements b.h.k.j {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k f645a;

    public l(k kVar) {
        this.f645a = kVar;
    }

    @Override // b.h.k.j
    public x a(View view, x xVar) {
        int d2 = xVar.d();
        int Y = this.f645a.Y(xVar, null);
        if (d2 != Y) {
            xVar = xVar.g(xVar.b(), Y, xVar.c(), xVar.a());
        }
        return b.h.k.q.p(view, xVar);
    }
}
