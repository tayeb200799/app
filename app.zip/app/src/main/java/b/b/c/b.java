package b.b.c;

import android.view.View;
import androidx.appcompat.app.AlertController;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\e.smali */
public class e implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ View f604d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ View f605e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ AlertController f606f;

    public e(AlertController alertController, View view, View view2) {
        this.f606f = alertController;
        this.f604d = view;
        this.f605e = view2;
    }

    @Override // java.lang.Runnable
    public void run() {
        AlertController.c(this.f606f.f100g, this.f604d, this.f605e);
    }
}
