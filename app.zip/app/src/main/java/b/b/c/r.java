package b.b.c;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\t.smali */
public class t {

    /* renamed from: d, reason: collision with root package name */
    public static t f664d;

    /* renamed from: a, reason: collision with root package name */
    public final Context f665a;

    /* renamed from: b, reason: collision with root package name */
    public final LocationManager f666b;

    /* renamed from: c, reason: collision with root package name */
    public final a f667c = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\t$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public boolean f668a;

        /* renamed from: b, reason: collision with root package name */
        public long f669b;
    }

    public t(Context context, LocationManager locationManager) {
        this.f665a = context;
        this.f666b = locationManager;
    }

    public final Location a(String str) {
        try {
            if (this.f666b.isProviderEnabled(str)) {
                return this.f666b.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e2) {
            Log.d("TwilightManager", "Failed to get last known location", e2);
            return null;
        }
    }
}
