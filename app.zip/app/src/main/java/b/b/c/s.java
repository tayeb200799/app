package b.b.c;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import b.b.c.a;
import b.b.h.a;
import b.b.h.i.g;
import b.b.i.y;
import b.h.k.v;
import b.h.k.w;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\u.smali */
public class u extends b.b.c.a implements ActionBarOverlayLayout.d {

    /* renamed from: a, reason: collision with root package name */
    public Context f670a;

    /* renamed from: b, reason: collision with root package name */
    public Context f671b;

    /* renamed from: c, reason: collision with root package name */
    public ActionBarOverlayLayout f672c;

    /* renamed from: d, reason: collision with root package name */
    public ActionBarContainer f673d;

    /* renamed from: e, reason: collision with root package name */
    public y f674e;

    /* renamed from: f, reason: collision with root package name */
    public ActionBarContextView f675f;

    /* renamed from: g, reason: collision with root package name */
    public View f676g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f677h;

    /* renamed from: i, reason: collision with root package name */
    public d f678i;

    /* renamed from: j, reason: collision with root package name */
    public b.b.h.a f679j;
    public a.InterfaceC0014a k;
    public boolean l;
    public ArrayList<a.b> m;
    public boolean n;
    public int o;
    public boolean p;
    public boolean q;
    public boolean r;
    public boolean s;
    public b.b.h.g t;
    public boolean u;
    public boolean v;
    public final b.h.k.u w;
    public final b.h.k.u x;
    public final w y;
    public static final Interpolator z = new AccelerateInterpolator();
    public static final Interpolator A = new DecelerateInterpolator();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\u$a.smali */
    public class a extends v {
        public a() {
        }

        @Override // b.h.k.u
        public void b(View view) {
            View view2;
            u uVar = u.this;
            if (uVar.p && (view2 = uVar.f676g) != null) {
                view2.setTranslationY(0.0f);
                u.this.f673d.setTranslationY(0.0f);
            }
            u.this.f673d.setVisibility(8);
            u.this.f673d.setTransitioning(false);
            u uVar2 = u.this;
            uVar2.t = null;
            a.InterfaceC0014a interfaceC0014a = uVar2.k;
            if (interfaceC0014a != null) {
                interfaceC0014a.b(uVar2.f679j);
                uVar2.f679j = null;
                uVar2.k = null;
            }
            ActionBarOverlayLayout actionBarOverlayLayout = u.this.f672c;
            if (actionBarOverlayLayout != null) {
                AtomicInteger atomicInteger = b.h.k.q.f1738a;
                actionBarOverlayLayout.requestApplyInsets();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\u$b.smali */
    public class b extends v {
        public b() {
        }

        @Override // b.h.k.u
        public void b(View view) {
            u uVar = u.this;
            uVar.t = null;
            uVar.f673d.requestLayout();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\u$c.smali */
    public class c implements w {
        public c() {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\u$d.smali */
    public class d extends b.b.h.a implements g.a {

        /* renamed from: f, reason: collision with root package name */
        public final Context f683f;

        /* renamed from: g, reason: collision with root package name */
        public final b.b.h.i.g f684g;

        /* renamed from: h, reason: collision with root package name */
        public a.InterfaceC0014a f685h;

        /* renamed from: i, reason: collision with root package name */
        public WeakReference<View> f686i;

        public d(Context context, a.InterfaceC0014a interfaceC0014a) {
            this.f683f = context;
            this.f685h = interfaceC0014a;
            b.b.h.i.g gVar = new b.b.h.i.g(context);
            gVar.l = 1;
            this.f684g = gVar;
            gVar.f825e = this;
        }

        @Override // b.b.h.i.g.a
        public boolean a(b.b.h.i.g gVar, MenuItem menuItem) {
            a.InterfaceC0014a interfaceC0014a = this.f685h;
            if (interfaceC0014a != null) {
                return interfaceC0014a.c(this, menuItem);
            }
            return false;
        }

        @Override // b.b.h.i.g.a
        public void b(b.b.h.i.g gVar) {
            if (this.f685h == null) {
                return;
            }
            i();
            b.b.i.c cVar = u.this.f675f.f880g;
            if (cVar != null) {
                cVar.n();
            }
        }

        @Override // b.b.h.a
        public void c() {
            u uVar = u.this;
            if (uVar.f678i != this) {
                return;
            }
            if (!uVar.q) {
                this.f685h.b(this);
            } else {
                uVar.f679j = this;
                uVar.k = this.f685h;
            }
            this.f685h = null;
            u.this.d(false);
            ActionBarContextView actionBarContextView = u.this.f675f;
            if (actionBarContextView.n == null) {
                actionBarContextView.h();
            }
            u.this.f674e.k().sendAccessibilityEvent(32);
            u uVar2 = u.this;
            uVar2.f672c.setHideOnContentScrollEnabled(uVar2.v);
            u.this.f678i = null;
        }

        @Override // b.b.h.a
        public View d() {
            WeakReference<View> weakReference = this.f686i;
            if (weakReference != null) {
                return weakReference.get();
            }
            return null;
        }

        @Override // b.b.h.a
        public Menu e() {
            return this.f684g;
        }

        @Override // b.b.h.a
        public MenuInflater f() {
            return new b.b.h.f(this.f683f);
        }

        @Override // b.b.h.a
        public CharSequence g() {
            return u.this.f675f.getSubtitle();
        }

        @Override // b.b.h.a
        public CharSequence h() {
            return u.this.f675f.getTitle();
        }

        @Override // b.b.h.a
        public void i() {
            if (u.this.f678i != this) {
                return;
            }
            this.f684g.z();
            try {
                this.f685h.a(this, this.f684g);
            } finally {
                this.f684g.y();
            }
        }

        @Override // b.b.h.a
        public boolean j() {
            return u.this.f675f.u;
        }

        @Override // b.b.h.a
        public void k(View view) {
            u.this.f675f.setCustomView(view);
            this.f686i = new WeakReference<>(view);
        }

        @Override // b.b.h.a
        public void l(int i2) {
            u.this.f675f.setSubtitle(u.this.f670a.getResources().getString(i2));
        }

        @Override // b.b.h.a
        public void m(CharSequence charSequence) {
            u.this.f675f.setSubtitle(charSequence);
        }

        @Override // b.b.h.a
        public void n(int i2) {
            u.this.f675f.setTitle(u.this.f670a.getResources().getString(i2));
        }

        @Override // b.b.h.a
        public void o(CharSequence charSequence) {
            u.this.f675f.setTitle(charSequence);
        }

        @Override // b.b.h.a
        public void p(boolean z) {
            this.f725e = z;
            u.this.f675f.setTitleOptional(z);
        }
    }

    public u(Activity activity, boolean z2) {
        new ArrayList();
        this.m = new ArrayList<>();
        this.o = 0;
        this.p = true;
        this.s = true;
        this.w = new a();
        this.x = new b();
        this.y = new c();
        View decorView = activity.getWindow().getDecorView();
        e(decorView);
        if (z2) {
            return;
        }
        this.f676g = decorView.findViewById(R.id.content);
    }

    public u(Dialog dialog) {
        new ArrayList();
        this.m = new ArrayList<>();
        this.o = 0;
        this.p = true;
        this.s = true;
        this.w = new a();
        this.x = new b();
        this.y = new c();
        e(dialog.getWindow().getDecorView());
    }

    @Override // b.b.c.a
    public void a(boolean z2) {
        if (z2 == this.l) {
            return;
        }
        this.l = z2;
        int size = this.m.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.m.get(i2).a(z2);
        }
    }

    @Override // b.b.c.a
    public Context b() {
        if (this.f671b == null) {
            TypedValue typedValue = new TypedValue();
            this.f670a.getTheme().resolveAttribute(2130968588, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                this.f671b = new ContextThemeWrapper(this.f670a, i2);
            } else {
                this.f671b = this.f670a;
            }
        }
        return this.f671b;
    }

    @Override // b.b.c.a
    public void c(boolean z2) {
        if (this.f677h) {
            return;
        }
        int i2 = z2 ? 4 : 0;
        int p = this.f674e.p();
        this.f677h = true;
        this.f674e.o((i2 & 4) | (p & (-5)));
    }

    public void d(boolean z2) {
        b.h.k.t s;
        b.h.k.t e2;
        if (z2) {
            if (!this.r) {
                this.r = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.f672c;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.setShowingForActionMode(true);
                }
                g(false);
            }
        } else if (this.r) {
            this.r = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f672c;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setShowingForActionMode(false);
            }
            g(false);
        }
        ActionBarContainer actionBarContainer = this.f673d;
        AtomicInteger atomicInteger = b.h.k.q.f1738a;
        if (!actionBarContainer.isLaidOut()) {
            if (z2) {
                this.f674e.i(4);
                this.f675f.setVisibility(0);
                return;
            } else {
                this.f674e.i(0);
                this.f675f.setVisibility(8);
                return;
            }
        }
        if (z2) {
            e2 = this.f674e.s(4, 100L);
            s = this.f675f.e(0, 200L);
        } else {
            s = this.f674e.s(0, 200L);
            e2 = this.f675f.e(8, 100L);
        }
        b.b.h.g gVar = new b.b.h.g();
        gVar.f761a.add(e2);
        View view = e2.f1756a.get();
        long duration = view != null ? view.animate().getDuration() : 0L;
        View view2 = s.f1756a.get();
        if (view2 != null) {
            view2.animate().setStartDelay(duration);
        }
        gVar.f761a.add(s);
        gVar.b();
    }

    public final void e(View view) {
        y wrapper;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(2131362010);
        this.f672c = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        KeyEvent.Callback findViewById = view.findViewById(2131361844);
        if (findViewById instanceof y) {
            wrapper = (y) findViewById;
        } else {
            if (!(findViewById instanceof Toolbar)) {
                StringBuilder n = c.a.a.a.a.n("Can't make a decor toolbar out of ");
                n.append(findViewById != null ? findViewById.getClass().getSimpleName() : "null");
                throw new IllegalStateException(n.toString());
            }
            wrapper = ((Toolbar) findViewById).getWrapper();
        }
        this.f674e = wrapper;
        this.f675f = (ActionBarContextView) view.findViewById(2131361852);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(2131361846);
        this.f673d = actionBarContainer;
        y yVar = this.f674e;
        if (yVar == null || this.f675f == null || actionBarContainer == null) {
            throw new IllegalStateException(u.class.getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f670a = yVar.m();
        boolean z2 = (this.f674e.p() & 4) != 0;
        if (z2) {
            this.f677h = true;
        }
        Context context = this.f670a;
        this.f674e.l((context.getApplicationInfo().targetSdkVersion < 14) || z2);
        f(context.getResources().getBoolean(2131034112));
        TypedArray obtainStyledAttributes = this.f670a.obtainStyledAttributes(null, b.b.b.f586a, 2130968583, 0);
        if (obtainStyledAttributes.getBoolean(14, false)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f672c;
            if (!actionBarOverlayLayout2.k) {
                throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
            }
            this.v = true;
            actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ActionBarContainer actionBarContainer2 = this.f673d;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            actionBarContainer2.setElevation(dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    public final void f(boolean z2) {
        this.n = z2;
        if (z2) {
            this.f673d.setTabContainer(null);
            this.f674e.j(null);
        } else {
            this.f674e.j(null);
            this.f673d.setTabContainer(null);
        }
        boolean z3 = this.f674e.r() == 2;
        this.f674e.v(!this.n && z3);
        this.f672c.setHasNonEmbeddedTabs(!this.n && z3);
    }

    public final void g(boolean z2) {
        View view;
        View view2;
        View view3;
        if (!(this.r || !this.q)) {
            if (this.s) {
                this.s = false;
                b.b.h.g gVar = this.t;
                if (gVar != null) {
                    gVar.a();
                }
                if (this.o != 0 || (!this.u && !z2)) {
                    this.w.b(null);
                    return;
                }
                this.f673d.setAlpha(1.0f);
                this.f673d.setTransitioning(true);
                b.b.h.g gVar2 = new b.b.h.g();
                float f2 = -this.f673d.getHeight();
                if (z2) {
                    this.f673d.getLocationInWindow(new int[]{0, 0});
                    f2 -= r9[1];
                }
                b.h.k.t b2 = b.h.k.q.b(this.f673d);
                b2.g(f2);
                b2.f(this.y);
                if (!gVar2.f765e) {
                    gVar2.f761a.add(b2);
                }
                if (this.p && (view = this.f676g) != null) {
                    b.h.k.t b3 = b.h.k.q.b(view);
                    b3.g(f2);
                    if (!gVar2.f765e) {
                        gVar2.f761a.add(b3);
                    }
                }
                Interpolator interpolator = z;
                boolean z3 = gVar2.f765e;
                if (!z3) {
                    gVar2.f763c = interpolator;
                }
                if (!z3) {
                    gVar2.f762b = 250L;
                }
                b.h.k.u uVar = this.w;
                if (!z3) {
                    gVar2.f764d = uVar;
                }
                this.t = gVar2;
                gVar2.b();
                return;
            }
            return;
        }
        if (this.s) {
            return;
        }
        this.s = true;
        b.b.h.g gVar3 = this.t;
        if (gVar3 != null) {
            gVar3.a();
        }
        this.f673d.setVisibility(0);
        if (this.o == 0 && (this.u || z2)) {
            this.f673d.setTranslationY(0.0f);
            float f3 = -this.f673d.getHeight();
            if (z2) {
                this.f673d.getLocationInWindow(new int[]{0, 0});
                f3 -= r9[1];
            }
            this.f673d.setTranslationY(f3);
            b.b.h.g gVar4 = new b.b.h.g();
            b.h.k.t b4 = b.h.k.q.b(this.f673d);
            b4.g(0.0f);
            b4.f(this.y);
            if (!gVar4.f765e) {
                gVar4.f761a.add(b4);
            }
            if (this.p && (view3 = this.f676g) != null) {
                view3.setTranslationY(f3);
                b.h.k.t b5 = b.h.k.q.b(this.f676g);
                b5.g(0.0f);
                if (!gVar4.f765e) {
                    gVar4.f761a.add(b5);
                }
            }
            Interpolator interpolator2 = A;
            boolean z4 = gVar4.f765e;
            if (!z4) {
                gVar4.f763c = interpolator2;
            }
            if (!z4) {
                gVar4.f762b = 250L;
            }
            b.h.k.u uVar2 = this.x;
            if (!z4) {
                gVar4.f764d = uVar2;
            }
            this.t = gVar4;
            gVar4.b();
        } else {
            this.f673d.setAlpha(1.0f);
            this.f673d.setTranslationY(0.0f);
            if (this.p && (view2 = this.f676g) != null) {
                view2.setTranslationY(0.0f);
            }
            this.x.b(null);
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f672c;
        if (actionBarOverlayLayout != null) {
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            actionBarOverlayLayout.requestApplyInsets();
        }
    }
}
