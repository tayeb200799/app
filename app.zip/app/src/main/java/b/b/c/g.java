package b.b.c;

import b.b.h.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\i.smali */
public interface i {
    void g(b.b.h.a aVar);

    void j(b.b.h.a aVar);

    b.b.h.a v(a.InterfaceC0014a interfaceC0014a);
}
