package b.b.c;

import android.view.View;
import android.widget.AdapterView;
import androidx.appcompat.app.AlertController;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\f.smali */
public class f implements AdapterView.OnItemClickListener {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ AlertController f607d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ AlertController.b f608e;

    public f(AlertController.b bVar, AlertController alertController) {
        this.f608e = bVar;
        this.f607d = alertController;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
        this.f608e.f114h.onClick(this.f607d.f95b, i2);
        if (this.f608e.f115i) {
            return;
        }
        this.f607d.f95b.dismiss();
    }
}
