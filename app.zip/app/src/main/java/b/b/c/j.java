package b.b.c;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\j.smali */
public abstract class j {

    /* renamed from: d, reason: collision with root package name */
    public static int f614d = -100;

    /* renamed from: e, reason: collision with root package name */
    public static final b.e.c<WeakReference<j>> f615e = new b.e.c<>(0);

    /* renamed from: f, reason: collision with root package name */
    public static final Object f616f = new Object();

    public static void t(j jVar) {
        synchronized (f616f) {
            Iterator<WeakReference<j>> it = f615e.iterator();
            while (it.hasNext()) {
                j jVar2 = it.next().get();
                if (jVar2 == jVar || jVar2 == null) {
                    it.remove();
                }
            }
        }
    }

    public static void y(int i2) {
        if (i2 != -1 && i2 != 0 && i2 != 1 && i2 != 2 && i2 != 3) {
            Log.d("AppCompatDelegate", "setDefaultNightMode() called with an unknown mode");
            return;
        }
        if (f614d != i2) {
            f614d = i2;
            synchronized (f616f) {
                Iterator<WeakReference<j>> it = f615e.iterator();
                while (it.hasNext()) {
                    j jVar = it.next().get();
                    if (jVar != null) {
                        jVar.d();
                    }
                }
            }
        }
    }

    public abstract void A(CharSequence charSequence);

    public abstract void c(View view, ViewGroup.LayoutParams layoutParams);

    public abstract boolean d();

    public Context e(Context context) {
        return context;
    }

    public abstract <T extends View> T f(int i2);

    public int g() {
        return -100;
    }

    public abstract MenuInflater h();

    public abstract a i();

    public abstract void j();

    public abstract void k();

    public abstract void l(Configuration configuration);

    public abstract void m(Bundle bundle);

    public abstract void n();

    public abstract void o(Bundle bundle);

    public abstract void p();

    public abstract void q(Bundle bundle);

    public abstract void r();

    public abstract void s();

    public abstract boolean u(int i2);

    public abstract void v(int i2);

    public abstract void w(View view);

    public abstract void x(View view, ViewGroup.LayoutParams layoutParams);

    public void z(int i2) {
    }
}
