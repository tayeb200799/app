package b.b.c;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.Process;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import b.b.c.t;
import b.b.h.a;
import b.b.h.i.g;
import b.b.h.i.m;
import b.b.i.b1;
import b.b.i.l0;
import b.b.i.v0;
import b.b.i.x;
import b.h.k.v;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k.smali */
public class k extends b.b.c.j implements g.a, LayoutInflater.Factory2 {
    public static final b.e.h<String, Integer> c0 = new b.e.h<>();
    public static final int[] d0 = {R.attr.windowBackground};
    public static final boolean e0 = !"robolectric".equals(Build.FINGERPRINT);
    public static final boolean f0 = true;
    public boolean A;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public boolean H;
    public i[] I;
    public i J;
    public boolean K;
    public boolean L;
    public boolean M;
    public boolean N;
    public boolean O;
    public int P;
    public int Q;
    public boolean R;
    public boolean S;
    public f T;
    public f U;
    public boolean V;
    public int W;
    public boolean Y;
    public Rect Z;
    public Rect a0;
    public r b0;

    /* renamed from: g, reason: collision with root package name */
    public final Object f615g;

    /* renamed from: h, reason: collision with root package name */
    public final Context f616h;

    /* renamed from: i, reason: collision with root package name */
    public Window f617i;

    /* renamed from: j, reason: collision with root package name */
    public d f618j;
    public final b.b.c.i k;
    public b.b.c.a l;
    public MenuInflater m;
    public CharSequence n;
    public x o;
    public b p;
    public j q;
    public b.b.h.a r;
    public ActionBarContextView s;
    public PopupWindow t;
    public Runnable u;
    public boolean w;
    public ViewGroup x;
    public TextView y;
    public View z;
    public b.h.k.t v = null;
    public final Runnable X = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            k kVar = k.this;
            if ((kVar.W & 1) != 0) {
                kVar.I(0);
            }
            k kVar2 = k.this;
            if ((kVar2.W & 4096) != 0) {
                kVar2.I(108);
            }
            k kVar3 = k.this;
            kVar3.V = false;
            kVar3.W = 0;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$b.smali */
    public final class b implements m.a {
        public b() {
        }

        @Override // b.b.h.i.m.a
        public void a(b.b.h.i.g gVar, boolean z) {
            k.this.E(gVar);
        }

        @Override // b.b.h.i.m.a
        public boolean b(b.b.h.i.g gVar) {
            Window.Callback P = k.this.P();
            if (P == null) {
                return true;
            }
            P.onMenuOpened(108, gVar);
            return true;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$c.smali */
    public class c implements a.InterfaceC0014a {

        /* renamed from: a, reason: collision with root package name */
        public a.InterfaceC0014a f621a;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$c$a.smali */
        public class a extends v {
            public a() {
            }

            @Override // b.h.k.u
            public void b(View view) {
                k.this.s.setVisibility(8);
                k kVar = k.this;
                PopupWindow popupWindow = kVar.t;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (kVar.s.getParent() instanceof View) {
                    View view2 = (View) k.this.s.getParent();
                    AtomicInteger atomicInteger = b.h.k.q.f1738a;
                    view2.requestApplyInsets();
                }
                k.this.s.removeAllViews();
                k.this.v.d(null);
                k kVar2 = k.this;
                kVar2.v = null;
                ViewGroup viewGroup = kVar2.x;
                AtomicInteger atomicInteger2 = b.h.k.q.f1738a;
                viewGroup.requestApplyInsets();
            }
        }

        public c(a.InterfaceC0014a interfaceC0014a) {
            this.f621a = interfaceC0014a;
        }

        @Override // b.b.h.a.InterfaceC0014a
        public boolean a(b.b.h.a aVar, Menu menu) {
            ViewGroup viewGroup = k.this.x;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            viewGroup.requestApplyInsets();
            return this.f621a.a(aVar, menu);
        }

        @Override // b.b.h.a.InterfaceC0014a
        public void b(b.b.h.a aVar) {
            this.f621a.b(aVar);
            k kVar = k.this;
            if (kVar.t != null) {
                kVar.f617i.getDecorView().removeCallbacks(k.this.u);
            }
            k kVar2 = k.this;
            if (kVar2.s != null) {
                kVar2.J();
                k kVar3 = k.this;
                b.h.k.t b2 = b.h.k.q.b(kVar3.s);
                b2.a(0.0f);
                kVar3.v = b2;
                b.h.k.t tVar = k.this.v;
                a aVar2 = new a();
                View view = tVar.f1756a.get();
                if (view != null) {
                    tVar.e(view, aVar2);
                }
            }
            k kVar4 = k.this;
            b.b.c.i iVar = kVar4.k;
            if (iVar != null) {
                iVar.j(kVar4.r);
            }
            k kVar5 = k.this;
            kVar5.r = null;
            ViewGroup viewGroup = kVar5.x;
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            viewGroup.requestApplyInsets();
        }

        @Override // b.b.h.a.InterfaceC0014a
        public boolean c(b.b.h.a aVar, MenuItem menuItem) {
            return this.f621a.c(aVar, menuItem);
        }

        @Override // b.b.h.a.InterfaceC0014a
        public boolean d(b.b.h.a aVar, Menu menu) {
            return this.f621a.d(aVar, menu);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$d.smali */
    public class d extends b.b.h.h {
        public d(Window.Callback callback) {
            super(callback);
        }

        /* JADX WARN: Removed duplicated region for block: B:38:0x009d  */
        /* JADX WARN: Removed duplicated region for block: B:45:0x00a1  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final android.view.ActionMode a(android.view.ActionMode.Callback r11) {
            /*
                Method dump skipped, instructions count: 521
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.d.a(android.view.ActionMode$Callback):android.view.ActionMode");
        }

        @Override // android.view.Window.Callback
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return k.this.H(keyEvent) || this.f770d.dispatchKeyEvent(keyEvent);
        }

        /* JADX WARN: Code restructure failed: missing block: B:13:0x003c, code lost:
        
            if (r3 != false) goto L30;
         */
        /* JADX WARN: Code restructure failed: missing block: B:31:0x0069, code lost:
        
            if (r7 != false) goto L30;
         */
        /* JADX WARN: Removed duplicated region for block: B:16:0x0071 A[ORIG_RETURN, RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:18:? A[RETURN, SYNTHETIC] */
        @Override // android.view.Window.Callback
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public boolean dispatchKeyShortcutEvent(android.view.KeyEvent r7) {
            /*
                r6 = this;
                android.view.Window$Callback r0 = r6.f770d
                boolean r0 = r0.dispatchKeyShortcutEvent(r7)
                r1 = 1
                r2 = 0
                if (r0 != 0) goto L72
                b.b.c.k r0 = b.b.c.k.this
                int r3 = r7.getKeyCode()
                r0.Q()
                b.b.c.a r4 = r0.l
                if (r4 == 0) goto L3f
                b.b.c.u r4 = (b.b.c.u) r4
                b.b.c.u$d r4 = r4.f678i
                if (r4 != 0) goto L1e
                goto L3b
            L1e:
                b.b.h.i.g r4 = r4.f684g
                if (r4 == 0) goto L3b
                int r5 = r7.getDeviceId()
                android.view.KeyCharacterMap r5 = android.view.KeyCharacterMap.load(r5)
                int r5 = r5.getKeyboardType()
                if (r5 == r1) goto L32
                r5 = 1
                goto L33
            L32:
                r5 = 0
            L33:
                r4.setQwertyMode(r5)
                boolean r3 = r4.performShortcut(r3, r7, r2)
                goto L3c
            L3b:
                r3 = 0
            L3c:
                if (r3 == 0) goto L3f
                goto L6b
            L3f:
                b.b.c.k$i r3 = r0.J
                if (r3 == 0) goto L54
                int r4 = r7.getKeyCode()
                boolean r3 = r0.U(r3, r4, r7, r1)
                if (r3 == 0) goto L54
                b.b.c.k$i r7 = r0.J
                if (r7 == 0) goto L6b
                r7.l = r1
                goto L6b
            L54:
                b.b.c.k$i r3 = r0.J
                if (r3 != 0) goto L6d
                b.b.c.k$i r3 = r0.O(r2)
                r0.V(r3, r7)
                int r4 = r7.getKeyCode()
                boolean r7 = r0.U(r3, r4, r7, r1)
                r3.k = r2
                if (r7 == 0) goto L6d
            L6b:
                r7 = 1
                goto L6e
            L6d:
                r7 = 0
            L6e:
                if (r7 == 0) goto L71
                goto L72
            L71:
                r1 = 0
            L72:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.d.dispatchKeyShortcutEvent(android.view.KeyEvent):boolean");
        }

        @Override // android.view.Window.Callback
        public void onContentChanged() {
        }

        @Override // android.view.Window.Callback
        public boolean onCreatePanelMenu(int i2, Menu menu) {
            if (i2 != 0 || (menu instanceof b.b.h.i.g)) {
                return this.f770d.onCreatePanelMenu(i2, menu);
            }
            return false;
        }

        @Override // android.view.Window.Callback
        public boolean onMenuOpened(int i2, Menu menu) {
            this.f770d.onMenuOpened(i2, menu);
            k kVar = k.this;
            Objects.requireNonNull(kVar);
            if (i2 == 108) {
                kVar.Q();
                b.b.c.a aVar = kVar.l;
                if (aVar != null) {
                    aVar.a(true);
                }
            }
            return true;
        }

        @Override // android.view.Window.Callback
        public void onPanelClosed(int i2, Menu menu) {
            this.f770d.onPanelClosed(i2, menu);
            k kVar = k.this;
            Objects.requireNonNull(kVar);
            if (i2 == 108) {
                kVar.Q();
                b.b.c.a aVar = kVar.l;
                if (aVar != null) {
                    aVar.a(false);
                    return;
                }
                return;
            }
            if (i2 == 0) {
                i O = kVar.O(i2);
                if (O.m) {
                    kVar.F(O, false);
                }
            }
        }

        @Override // android.view.Window.Callback
        public boolean onPreparePanel(int i2, View view, Menu menu) {
            b.b.h.i.g gVar = menu instanceof b.b.h.i.g ? (b.b.h.i.g) menu : null;
            if (i2 == 0 && gVar == null) {
                return false;
            }
            if (gVar != null) {
                gVar.x = true;
            }
            boolean onPreparePanel = this.f770d.onPreparePanel(i2, view, menu);
            if (gVar != null) {
                gVar.x = false;
            }
            return onPreparePanel;
        }

        @Override // android.view.Window.Callback
        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i2) {
            b.b.h.i.g gVar = k.this.O(0).f639h;
            if (gVar != null) {
                this.f770d.onProvideKeyboardShortcuts(list, gVar, i2);
            } else {
                this.f770d.onProvideKeyboardShortcuts(list, menu, i2);
            }
        }

        @Override // android.view.Window.Callback
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (Build.VERSION.SDK_INT >= 23) {
                return null;
            }
            Objects.requireNonNull(k.this);
            return a(callback);
        }

        @Override // android.view.Window.Callback
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i2) {
            Objects.requireNonNull(k.this);
            return i2 != 0 ? this.f770d.onWindowStartingActionMode(callback, i2) : a(callback);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$e.smali */
    public class e extends f {

        /* renamed from: c, reason: collision with root package name */
        public final PowerManager f625c;

        public e(Context context) {
            super();
            this.f625c = (PowerManager) context.getApplicationContext().getSystemService("power");
        }

        @Override // b.b.c.k.f
        public IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        @Override // b.b.c.k.f
        public int c() {
            return this.f625c.isPowerSaveMode() ? 2 : 1;
        }

        @Override // b.b.c.k.f
        public void d() {
            k.this.d();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$f.smali */
    public abstract class f {

        /* renamed from: a, reason: collision with root package name */
        public BroadcastReceiver f627a;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$f$a.smali */
        public class a extends BroadcastReceiver {
            public a() {
            }

            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                f.this.d();
            }
        }

        public f() {
        }

        public void a() {
            BroadcastReceiver broadcastReceiver = this.f627a;
            if (broadcastReceiver != null) {
                try {
                    k.this.f616h.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                this.f627a = null;
            }
        }

        public abstract IntentFilter b();

        public abstract int c();

        public abstract void d();

        public void e() {
            a();
            IntentFilter b2 = b();
            if (b2 == null || b2.countActions() == 0) {
                return;
            }
            if (this.f627a == null) {
                this.f627a = new a();
            }
            k.this.f616h.registerReceiver(this.f627a, b2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$g.smali */
    public class g extends f {

        /* renamed from: c, reason: collision with root package name */
        public final t f630c;

        public g(t tVar) {
            super();
            this.f630c = tVar;
        }

        @Override // b.b.c.k.f
        public IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        @Override // b.b.c.k.f
        public int c() {
            boolean z;
            long j2;
            t tVar = this.f630c;
            t.a aVar = tVar.f667c;
            if (aVar.f669b > System.currentTimeMillis()) {
                z = aVar.f668a;
            } else {
                Context context = tVar.f665a;
                Location a2 = b.h.a.h(context, "android.permission.ACCESS_COARSE_LOCATION", Process.myPid(), Process.myUid(), context.getPackageName()) == 0 ? tVar.a("network") : null;
                Context context2 = tVar.f665a;
                Location a3 = b.h.a.h(context2, "android.permission.ACCESS_FINE_LOCATION", Process.myPid(), Process.myUid(), context2.getPackageName()) == 0 ? tVar.a("gps") : null;
                if (a3 == null || a2 == null ? a3 != null : a3.getTime() > a2.getTime()) {
                    a2 = a3;
                }
                if (a2 != null) {
                    t.a aVar2 = tVar.f667c;
                    long currentTimeMillis = System.currentTimeMillis();
                    if (s.f660d == null) {
                        s.f660d = new s();
                    }
                    s sVar = s.f660d;
                    sVar.a(currentTimeMillis - 86400000, a2.getLatitude(), a2.getLongitude());
                    sVar.a(currentTimeMillis, a2.getLatitude(), a2.getLongitude());
                    boolean z2 = sVar.f663c == 1;
                    long j3 = sVar.f662b;
                    long j4 = sVar.f661a;
                    sVar.a(currentTimeMillis + 86400000, a2.getLatitude(), a2.getLongitude());
                    long j5 = sVar.f662b;
                    if (j3 == -1 || j4 == -1) {
                        j2 = 43200000 + currentTimeMillis;
                    } else {
                        j2 = (currentTimeMillis > j4 ? j5 + 0 : currentTimeMillis > j3 ? j4 + 0 : j3 + 0) + 60000;
                    }
                    aVar2.f668a = z2;
                    aVar2.f669b = j2;
                    z = aVar.f668a;
                } else {
                    Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
                    int i2 = Calendar.getInstance().get(11);
                    z = i2 < 6 || i2 >= 22;
                }
            }
            return z ? 2 : 1;
        }

        @Override // b.b.c.k.f
        public void d() {
            k.this.d();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$h.smali */
    public class h extends ContentFrameLayout {
        public h(Context context) {
            super(context, null);
        }

        @Override // android.view.ViewGroup, android.view.View
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return k.this.H(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        @Override // android.view.ViewGroup
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() == 0) {
                int x = (int) motionEvent.getX();
                int y = (int) motionEvent.getY();
                if (x < -5 || y < -5 || x > getWidth() + 5 || y > getHeight() + 5) {
                    k kVar = k.this;
                    kVar.F(kVar.O(0), true);
                    return true;
                }
            }
            return super.onInterceptTouchEvent(motionEvent);
        }

        @Override // android.view.View
        public void setBackgroundResource(int i2) {
            setBackgroundDrawable(b.b.d.a.a.b(getContext(), i2));
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$i.smali */
    public static final class i {

        /* renamed from: a, reason: collision with root package name */
        public int f632a;

        /* renamed from: b, reason: collision with root package name */
        public int f633b;

        /* renamed from: c, reason: collision with root package name */
        public int f634c;

        /* renamed from: d, reason: collision with root package name */
        public int f635d;

        /* renamed from: e, reason: collision with root package name */
        public ViewGroup f636e;

        /* renamed from: f, reason: collision with root package name */
        public View f637f;

        /* renamed from: g, reason: collision with root package name */
        public View f638g;

        /* renamed from: h, reason: collision with root package name */
        public b.b.h.i.g f639h;

        /* renamed from: i, reason: collision with root package name */
        public b.b.h.i.e f640i;

        /* renamed from: j, reason: collision with root package name */
        public Context f641j;
        public boolean k;
        public boolean l;
        public boolean m;
        public boolean n;
        public boolean o = false;
        public boolean p;
        public Bundle q;

        public i(int i2) {
            this.f632a = i2;
        }

        public void a(b.b.h.i.g gVar) {
            b.b.h.i.e eVar;
            b.b.h.i.g gVar2 = this.f639h;
            if (gVar == gVar2) {
                return;
            }
            if (gVar2 != null) {
                gVar2.u(this.f640i);
            }
            this.f639h = gVar;
            if (gVar == null || (eVar = this.f640i) == null) {
                return;
            }
            gVar.b(eVar, gVar.f821a);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\k$j.smali */
    public final class j implements m.a {
        public j() {
        }

        @Override // b.b.h.i.m.a
        public void a(b.b.h.i.g gVar, boolean z) {
            b.b.h.i.g k = gVar.k();
            boolean z2 = k != gVar;
            k kVar = k.this;
            if (z2) {
                gVar = k;
            }
            i M = kVar.M(gVar);
            if (M != null) {
                if (!z2) {
                    k.this.F(M, z);
                } else {
                    k.this.D(M.f632a, M, k);
                    k.this.F(M, true);
                }
            }
        }

        @Override // b.b.h.i.m.a
        public boolean b(b.b.h.i.g gVar) {
            Window.Callback P;
            if (gVar != gVar.k()) {
                return true;
            }
            k kVar = k.this;
            if (!kVar.C || (P = kVar.P()) == null || k.this.O) {
                return true;
            }
            P.onMenuOpened(108, gVar);
            return true;
        }
    }

    public k(Context context, Window window, b.b.c.i iVar, Object obj) {
        b.e.h<String, Integer> hVar;
        Integer orDefault;
        b.b.c.h hVar2;
        this.P = -100;
        this.f616h = context;
        this.k = iVar;
        this.f615g = obj;
        if (obj instanceof Dialog) {
            while (context != null) {
                if (!(context instanceof b.b.c.h)) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                } else {
                    hVar2 = (b.b.c.h) context;
                    break;
                }
            }
            hVar2 = null;
            if (hVar2 != null) {
                this.P = hVar2.D().g();
            }
        }
        if (this.P == -100 && (orDefault = (hVar = c0).getOrDefault(this.f615g.getClass().getName(), null)) != null) {
            this.P = orDefault.intValue();
            hVar.remove(this.f615g.getClass().getName());
        }
        if (window != null) {
            C(window);
        }
        b.b.i.i.e();
    }

    @Override // b.b.c.j
    public final void A(CharSequence charSequence) {
        this.n = charSequence;
        x xVar = this.o;
        if (xVar != null) {
            xVar.setWindowTitle(charSequence);
            return;
        }
        b.b.c.a aVar = this.l;
        if (aVar != null) {
            ((u) aVar).f674e.setWindowTitle(charSequence);
            return;
        }
        TextView textView = this.y;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:129:0x0203  */
    /* JADX WARN: Removed duplicated region for block: B:133:0x0210  */
    /* JADX WARN: Removed duplicated region for block: B:136:0x0224  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x0237  */
    /* JADX WARN: Removed duplicated region for block: B:144:0x021a  */
    /* JADX WARN: Removed duplicated region for block: B:148:0x00b1  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00d3 A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean B(boolean r14) {
        /*
            Method dump skipped, instructions count: 575
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.B(boolean):boolean");
    }

    public final void C(Window window) {
        if (this.f617i != null) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        Window.Callback callback = window.getCallback();
        if (callback instanceof d) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        d dVar = new d(callback);
        this.f618j = dVar;
        window.setCallback(dVar);
        v0 p = v0.p(this.f616h, null, d0);
        Drawable h2 = p.h(0);
        if (h2 != null) {
            window.setBackgroundDrawable(h2);
        }
        p.f1076b.recycle();
        this.f617i = window;
    }

    public void D(int i2, i iVar, Menu menu) {
        if (menu == null && iVar != null) {
            menu = iVar.f639h;
        }
        if ((iVar == null || iVar.m) && !this.O) {
            this.f618j.f770d.onPanelClosed(i2, menu);
        }
    }

    public void E(b.b.h.i.g gVar) {
        if (this.H) {
            return;
        }
        this.H = true;
        this.o.l();
        Window.Callback P = P();
        if (P != null && !this.O) {
            P.onPanelClosed(108, gVar);
        }
        this.H = false;
    }

    public void F(i iVar, boolean z) {
        ViewGroup viewGroup;
        x xVar;
        if (z && iVar.f632a == 0 && (xVar = this.o) != null && xVar.b()) {
            E(iVar.f639h);
            return;
        }
        WindowManager windowManager = (WindowManager) this.f616h.getSystemService("window");
        if (windowManager != null && iVar.m && (viewGroup = iVar.f636e) != null) {
            windowManager.removeView(viewGroup);
            if (z) {
                D(iVar.f632a, iVar, null);
            }
        }
        iVar.k = false;
        iVar.l = false;
        iVar.m = false;
        iVar.f637f = null;
        iVar.o = true;
        if (this.J == iVar) {
            this.J = null;
        }
    }

    public final Configuration G(Context context, int i2, Configuration configuration) {
        int i3 = i2 != 1 ? i2 != 2 ? context.getApplicationContext().getResources().getConfiguration().uiMode & 48 : 32 : 16;
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i3 | (configuration2.uiMode & (-49));
        return configuration2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:91:0x0123, code lost:
    
        if (r7 != false) goto L92;
     */
    /* JADX WARN: Removed duplicated region for block: B:83:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean H(android.view.KeyEvent r7) {
        /*
            Method dump skipped, instructions count: 299
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.H(android.view.KeyEvent):boolean");
    }

    public void I(int i2) {
        i O = O(i2);
        if (O.f639h != null) {
            Bundle bundle = new Bundle();
            O.f639h.w(bundle);
            if (bundle.size() > 0) {
                O.q = bundle;
            }
            O.f639h.z();
            O.f639h.clear();
        }
        O.p = true;
        O.o = true;
        if ((i2 == 108 || i2 == 0) && this.o != null) {
            i O2 = O(0);
            O2.k = false;
            V(O2, null);
        }
    }

    public void J() {
        b.h.k.t tVar = this.v;
        if (tVar != null) {
            tVar.b();
        }
    }

    public final void K() {
        ViewGroup viewGroup;
        int[] iArr = b.b.b.f595j;
        if (this.w) {
            return;
        }
        TypedArray obtainStyledAttributes = this.f616h.obtainStyledAttributes(iArr);
        if (!obtainStyledAttributes.hasValue(115)) {
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (obtainStyledAttributes.getBoolean(124, false)) {
            u(1);
        } else if (obtainStyledAttributes.getBoolean(115, false)) {
            u(108);
        }
        if (obtainStyledAttributes.getBoolean(116, false)) {
            u(109);
        }
        if (obtainStyledAttributes.getBoolean(117, false)) {
            u(10);
        }
        this.F = obtainStyledAttributes.getBoolean(0, false);
        obtainStyledAttributes.recycle();
        L();
        this.f617i.getDecorView();
        LayoutInflater from = LayoutInflater.from(this.f616h);
        if (this.G) {
            viewGroup = this.E ? (ViewGroup) from.inflate(2131558422, (ViewGroup) null) : (ViewGroup) from.inflate(2131558421, (ViewGroup) null);
        } else if (this.F) {
            viewGroup = (ViewGroup) from.inflate(2131558412, (ViewGroup) null);
            this.D = false;
            this.C = false;
        } else if (this.C) {
            TypedValue typedValue = new TypedValue();
            this.f616h.getTheme().resolveAttribute(2130968587, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new b.b.h.c(this.f616h, typedValue.resourceId) : this.f616h).inflate(2131558423, (ViewGroup) null);
            x xVar = (x) viewGroup.findViewById(2131362010);
            this.o = xVar;
            xVar.setWindowCallback(P());
            if (this.D) {
                this.o.k(109);
            }
            if (this.A) {
                this.o.k(2);
            }
            if (this.B) {
                this.o.k(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            StringBuilder n = c.a.a.a.a.n("AppCompat does not support the current theme features: { windowActionBar: ");
            n.append(this.C);
            n.append(", windowActionBarOverlay: ");
            n.append(this.D);
            n.append(", android:windowIsFloating: ");
            n.append(this.F);
            n.append(", windowActionModeOverlay: ");
            n.append(this.E);
            n.append(", windowNoTitle: ");
            n.append(this.G);
            n.append(" }");
            throw new IllegalArgumentException(n.toString());
        }
        b.h.k.q.u(viewGroup, new l(this));
        if (this.o == null) {
            this.y = (TextView) viewGroup.findViewById(2131362568);
        }
        Method method = b1.f898a;
        try {
            Method method2 = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", new Class[0]);
            if (!method2.isAccessible()) {
                method2.setAccessible(true);
            }
            method2.invoke(viewGroup, new Object[0]);
        } catch (IllegalAccessException e2) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e2);
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
        } catch (InvocationTargetException e3) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e3);
        }
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(2131361845);
        ViewGroup viewGroup2 = (ViewGroup) this.f617i.findViewById(R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f617i.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new m(this));
        this.x = viewGroup;
        Object obj = this.f615g;
        CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.n;
        if (!TextUtils.isEmpty(title)) {
            x xVar2 = this.o;
            if (xVar2 != null) {
                xVar2.setWindowTitle(title);
            } else {
                b.b.c.a aVar = this.l;
                if (aVar != null) {
                    ((u) aVar).f674e.setWindowTitle(title);
                } else {
                    TextView textView = this.y;
                    if (textView != null) {
                        textView.setText(title);
                    }
                }
            }
        }
        ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.x.findViewById(R.id.content);
        View decorView = this.f617i.getDecorView();
        contentFrameLayout2.f177j.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        AtomicInteger atomicInteger = b.h.k.q.f1738a;
        if (contentFrameLayout2.isLaidOut()) {
            contentFrameLayout2.requestLayout();
        }
        TypedArray obtainStyledAttributes2 = this.f616h.obtainStyledAttributes(iArr);
        obtainStyledAttributes2.getValue(122, contentFrameLayout2.getMinWidthMajor());
        obtainStyledAttributes2.getValue(123, contentFrameLayout2.getMinWidthMinor());
        if (obtainStyledAttributes2.hasValue(120)) {
            obtainStyledAttributes2.getValue(120, contentFrameLayout2.getFixedWidthMajor());
        }
        if (obtainStyledAttributes2.hasValue(121)) {
            obtainStyledAttributes2.getValue(121, contentFrameLayout2.getFixedWidthMinor());
        }
        if (obtainStyledAttributes2.hasValue(118)) {
            obtainStyledAttributes2.getValue(118, contentFrameLayout2.getFixedHeightMajor());
        }
        if (obtainStyledAttributes2.hasValue(119)) {
            obtainStyledAttributes2.getValue(119, contentFrameLayout2.getFixedHeightMinor());
        }
        obtainStyledAttributes2.recycle();
        contentFrameLayout2.requestLayout();
        this.w = true;
        i O = O(0);
        if (this.O || O.f639h != null) {
            return;
        }
        R(108);
    }

    public final void L() {
        if (this.f617i == null) {
            Object obj = this.f615g;
            if (obj instanceof Activity) {
                C(((Activity) obj).getWindow());
            }
        }
        if (this.f617i == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    public i M(Menu menu) {
        i[] iVarArr = this.I;
        int length = iVarArr != null ? iVarArr.length : 0;
        for (int i2 = 0; i2 < length; i2++) {
            i iVar = iVarArr[i2];
            if (iVar != null && iVar.f639h == menu) {
                return iVar;
            }
        }
        return null;
    }

    public final f N(Context context) {
        if (this.T == null) {
            if (t.f664d == null) {
                Context applicationContext = context.getApplicationContext();
                t.f664d = new t(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.T = new g(t.f664d);
        }
        return this.T;
    }

    public i O(int i2) {
        i[] iVarArr = this.I;
        if (iVarArr == null || iVarArr.length <= i2) {
            i[] iVarArr2 = new i[i2 + 1];
            if (iVarArr != null) {
                System.arraycopy(iVarArr, 0, iVarArr2, 0, iVarArr.length);
            }
            this.I = iVarArr2;
            iVarArr = iVarArr2;
        }
        i iVar = iVarArr[i2];
        if (iVar != null) {
            return iVar;
        }
        i iVar2 = new i(i2);
        iVarArr[i2] = iVar2;
        return iVar2;
    }

    public final Window.Callback P() {
        return this.f617i.getCallback();
    }

    public final void Q() {
        K();
        if (this.C && this.l == null) {
            Object obj = this.f615g;
            if (obj instanceof Activity) {
                this.l = new u((Activity) this.f615g, this.D);
            } else if (obj instanceof Dialog) {
                this.l = new u((Dialog) this.f615g);
            }
            b.b.c.a aVar = this.l;
            if (aVar != null) {
                aVar.c(this.Y);
            }
        }
    }

    public final void R(int i2) {
        this.W = (1 << i2) | this.W;
        if (this.V) {
            return;
        }
        View decorView = this.f617i.getDecorView();
        Runnable runnable = this.X;
        AtomicInteger atomicInteger = b.h.k.q.f1738a;
        decorView.postOnAnimation(runnable);
        this.V = true;
    }

    public int S(Context context, int i2) {
        if (i2 == -100) {
            return -1;
        }
        if (i2 != -1) {
            if (i2 == 0) {
                if (Build.VERSION.SDK_INT < 23 || ((UiModeManager) context.getApplicationContext().getSystemService(UiModeManager.class)).getNightMode() != 0) {
                    return N(context).c();
                }
                return -1;
            }
            if (i2 != 1 && i2 != 2) {
                if (i2 != 3) {
                    throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                }
                if (this.U == null) {
                    this.U = new e(context);
                }
                return this.U.c();
            }
        }
        return i2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:93:0x0157, code lost:
    
        if (r14 != null) goto L79;
     */
    /* JADX WARN: Removed duplicated region for block: B:58:0x015e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void T(b.b.c.k.i r13, android.view.KeyEvent r14) {
        /*
            Method dump skipped, instructions count: 473
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.T(b.b.c.k$i, android.view.KeyEvent):void");
    }

    public final boolean U(i iVar, int i2, KeyEvent keyEvent, int i3) {
        b.b.h.i.g gVar;
        boolean z = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((iVar.k || V(iVar, keyEvent)) && (gVar = iVar.f639h) != null) {
            z = gVar.performShortcut(i2, keyEvent, i3);
        }
        if (z && (i3 & 1) == 0 && this.o == null) {
            F(iVar, true);
        }
        return z;
    }

    public final boolean V(i iVar, KeyEvent keyEvent) {
        x xVar;
        x xVar2;
        Resources.Theme theme;
        x xVar3;
        x xVar4;
        if (this.O) {
            return false;
        }
        if (iVar.k) {
            return true;
        }
        i iVar2 = this.J;
        if (iVar2 != null && iVar2 != iVar) {
            F(iVar2, false);
        }
        Window.Callback P = P();
        if (P != null) {
            iVar.f638g = P.onCreatePanelView(iVar.f632a);
        }
        int i2 = iVar.f632a;
        boolean z = i2 == 0 || i2 == 108;
        if (z && (xVar4 = this.o) != null) {
            xVar4.c();
        }
        if (iVar.f638g == null) {
            b.b.h.i.g gVar = iVar.f639h;
            if (gVar == null || iVar.p) {
                if (gVar == null) {
                    Context context = this.f616h;
                    int i3 = iVar.f632a;
                    if ((i3 == 0 || i3 == 108) && this.o != null) {
                        TypedValue typedValue = new TypedValue();
                        Resources.Theme theme2 = context.getTheme();
                        theme2.resolveAttribute(2130968587, typedValue, true);
                        if (typedValue.resourceId != 0) {
                            theme = context.getResources().newTheme();
                            theme.setTo(theme2);
                            theme.applyStyle(typedValue.resourceId, true);
                            theme.resolveAttribute(2130968588, typedValue, true);
                        } else {
                            theme2.resolveAttribute(2130968588, typedValue, true);
                            theme = null;
                        }
                        if (typedValue.resourceId != 0) {
                            if (theme == null) {
                                theme = context.getResources().newTheme();
                                theme.setTo(theme2);
                            }
                            theme.applyStyle(typedValue.resourceId, true);
                        }
                        if (theme != null) {
                            b.b.h.c cVar = new b.b.h.c(context, 0);
                            cVar.getTheme().setTo(theme);
                            context = cVar;
                        }
                    }
                    b.b.h.i.g gVar2 = new b.b.h.i.g(context);
                    gVar2.f825e = this;
                    iVar.a(gVar2);
                    if (iVar.f639h == null) {
                        return false;
                    }
                }
                if (z && (xVar2 = this.o) != null) {
                    if (this.p == null) {
                        this.p = new b();
                    }
                    xVar2.a(iVar.f639h, this.p);
                }
                iVar.f639h.z();
                if (!P.onCreatePanelMenu(iVar.f632a, iVar.f639h)) {
                    iVar.a(null);
                    if (z && (xVar = this.o) != null) {
                        xVar.a(null, this.p);
                    }
                    return false;
                }
                iVar.p = false;
            }
            iVar.f639h.z();
            Bundle bundle = iVar.q;
            if (bundle != null) {
                iVar.f639h.v(bundle);
                iVar.q = null;
            }
            if (!P.onPreparePanel(0, iVar.f638g, iVar.f639h)) {
                if (z && (xVar3 = this.o) != null) {
                    xVar3.a(null, this.p);
                }
                iVar.f639h.y();
                return false;
            }
            boolean z2 = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            iVar.n = z2;
            iVar.f639h.setQwertyMode(z2);
            iVar.f639h.y();
        }
        iVar.k = true;
        iVar.l = false;
        this.J = iVar;
        return true;
    }

    public final boolean W() {
        ViewGroup viewGroup;
        if (this.w && (viewGroup = this.x) != null) {
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            if (viewGroup.isLaidOut()) {
                return true;
            }
        }
        return false;
    }

    public final void X() {
        if (this.w) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final int Y(b.h.k.x xVar, Rect rect) {
        boolean z;
        boolean z2;
        int d2 = xVar.d();
        ActionBarContextView actionBarContextView = this.s;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.s.getLayoutParams();
            if (this.s.isShown()) {
                if (this.Z == null) {
                    this.Z = new Rect();
                    this.a0 = new Rect();
                }
                Rect rect2 = this.Z;
                Rect rect3 = this.a0;
                rect2.set(xVar.b(), xVar.d(), xVar.c(), xVar.a());
                b1.a(this.x, rect2, rect3);
                int i2 = rect2.top;
                int i3 = rect2.left;
                int i4 = rect2.right;
                b.h.k.x l = b.h.k.q.l(this.x);
                int b2 = l == null ? 0 : l.b();
                int c2 = l == null ? 0 : l.c();
                if (marginLayoutParams.topMargin == i2 && marginLayoutParams.leftMargin == i3 && marginLayoutParams.rightMargin == i4) {
                    z2 = false;
                } else {
                    marginLayoutParams.topMargin = i2;
                    marginLayoutParams.leftMargin = i3;
                    marginLayoutParams.rightMargin = i4;
                    z2 = true;
                }
                if (i2 <= 0 || this.z != null) {
                    View view = this.z;
                    if (view != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
                        int i5 = marginLayoutParams2.height;
                        int i6 = marginLayoutParams.topMargin;
                        if (i5 != i6 || marginLayoutParams2.leftMargin != b2 || marginLayoutParams2.rightMargin != c2) {
                            marginLayoutParams2.height = i6;
                            marginLayoutParams2.leftMargin = b2;
                            marginLayoutParams2.rightMargin = c2;
                            this.z.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view2 = new View(this.f616h);
                    this.z = view2;
                    view2.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = b2;
                    layoutParams.rightMargin = c2;
                    this.x.addView(this.z, -1, layoutParams);
                }
                View view3 = this.z;
                z = view3 != null;
                if (z && view3.getVisibility() != 0) {
                    View view4 = this.z;
                    AtomicInteger atomicInteger = b.h.k.q.f1738a;
                    view4.setBackgroundColor((view4.getWindowSystemUiVisibility() & 8192) != 0 ? b.h.d.a.b(this.f616h, 2131099654) : b.h.d.a.b(this.f616h, 2131099653));
                }
                if (!this.E && z) {
                    d2 = 0;
                }
                r4 = z2;
            } else {
                if (marginLayoutParams.topMargin != 0) {
                    marginLayoutParams.topMargin = 0;
                } else {
                    r4 = false;
                }
                z = false;
            }
            if (r4) {
                this.s.setLayoutParams(marginLayoutParams);
            }
        }
        View view5 = this.z;
        if (view5 != null) {
            view5.setVisibility(z ? 0 : 8);
        }
        return d2;
    }

    @Override // b.b.h.i.g.a
    public boolean a(b.b.h.i.g gVar, MenuItem menuItem) {
        i M;
        Window.Callback P = P();
        if (P == null || this.O || (M = M(gVar.k())) == null) {
            return false;
        }
        return P.onMenuItemSelected(M.f632a, menuItem);
    }

    @Override // b.b.h.i.g.a
    public void b(b.b.h.i.g gVar) {
        x xVar = this.o;
        if (xVar == null || !xVar.g() || (ViewConfiguration.get(this.f616h).hasPermanentMenuKey() && !this.o.d())) {
            i O = O(0);
            O.o = true;
            F(O, false);
            T(O, null);
            return;
        }
        Window.Callback P = P();
        if (this.o.b()) {
            this.o.e();
            if (this.O) {
                return;
            }
            P.onPanelClosed(108, O(0).f639h);
            return;
        }
        if (P == null || this.O) {
            return;
        }
        if (this.V && (1 & this.W) != 0) {
            this.f617i.getDecorView().removeCallbacks(this.X);
            this.X.run();
        }
        i O2 = O(0);
        b.b.h.i.g gVar2 = O2.f639h;
        if (gVar2 == null || O2.p || !P.onPreparePanel(0, O2.f638g, gVar2)) {
            return;
        }
        P.onMenuOpened(108, O2.f639h);
        this.o.f();
    }

    @Override // b.b.c.j
    public void c(View view, ViewGroup.LayoutParams layoutParams) {
        K();
        ((ViewGroup) this.x.findViewById(R.id.content)).addView(view, layoutParams);
        this.f618j.f770d.onContentChanged();
    }

    @Override // b.b.c.j
    public boolean d() {
        return B(true);
    }

    /* JADX WARN: Removed duplicated region for block: B:113:0x0197  */
    @Override // b.b.c.j
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.content.Context e(android.content.Context r10) {
        /*
            Method dump skipped, instructions count: 493
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.e(android.content.Context):android.content.Context");
    }

    @Override // b.b.c.j
    public <T extends View> T f(int i2) {
        K();
        return (T) this.f617i.findViewById(i2);
    }

    @Override // b.b.c.j
    public int g() {
        return this.P;
    }

    @Override // b.b.c.j
    public MenuInflater h() {
        if (this.m == null) {
            Q();
            b.b.c.a aVar = this.l;
            this.m = new b.b.h.f(aVar != null ? aVar.b() : this.f616h);
        }
        return this.m;
    }

    @Override // b.b.c.j
    public b.b.c.a i() {
        Q();
        return this.l;
    }

    @Override // b.b.c.j
    public void j() {
        LayoutInflater from = LayoutInflater.from(this.f616h);
        if (from.getFactory() == null) {
            from.setFactory2(this);
        } else {
            if (from.getFactory2() instanceof k) {
                return;
            }
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    @Override // b.b.c.j
    public void k() {
        Q();
        b.b.c.a aVar = this.l;
        R(0);
    }

    @Override // b.b.c.j
    public void l(Configuration configuration) {
        if (this.C && this.w) {
            Q();
            b.b.c.a aVar = this.l;
            if (aVar != null) {
                u uVar = (u) aVar;
                uVar.f(uVar.f670a.getResources().getBoolean(2131034112));
            }
        }
        b.b.i.i a2 = b.b.i.i.a();
        Context context = this.f616h;
        synchronized (a2) {
            l0 l0Var = a2.f957a;
            synchronized (l0Var) {
                b.e.e<WeakReference<Drawable.ConstantState>> eVar = l0Var.f982d.get(context);
                if (eVar != null) {
                    eVar.c();
                }
            }
        }
        B(false);
    }

    @Override // b.b.c.j
    public void m(Bundle bundle) {
        this.L = true;
        B(false);
        L();
        Object obj = this.f615g;
        if (obj instanceof Activity) {
            String str = null;
            try {
                Activity activity = (Activity) obj;
                try {
                    str = b.h.a.x(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e2) {
                    throw new IllegalArgumentException(e2);
                }
            } catch (IllegalArgumentException unused) {
            }
            if (str != null) {
                b.b.c.a aVar = this.l;
                if (aVar == null) {
                    this.Y = true;
                } else {
                    aVar.c(true);
                }
            }
            synchronized (b.b.c.j.f614f) {
                b.b.c.j.t(this);
                b.b.c.j.f613e.add(new WeakReference<>(this));
            }
        }
        this.M = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:34:? A[RETURN, SYNTHETIC] */
    @Override // b.b.c.j
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void n() {
        /*
            r3 = this;
            b.e.h<java.lang.String, java.lang.Integer> r0 = b.b.c.k.c0
            java.lang.Object r1 = r3.f615g
            boolean r1 = r1 instanceof android.app.Activity
            if (r1 == 0) goto L13
            java.lang.Object r1 = b.b.c.j.f614f
            monitor-enter(r1)
            b.b.c.j.t(r3)     // Catch: java.lang.Throwable -> L10
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L10
            goto L13
        L10:
            r0 = move-exception
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L10
            throw r0
        L13:
            boolean r1 = r3.V
            if (r1 == 0) goto L22
            android.view.Window r1 = r3.f617i
            android.view.View r1 = r1.getDecorView()
            java.lang.Runnable r2 = r3.X
            r1.removeCallbacks(r2)
        L22:
            r1 = 0
            r3.N = r1
            r1 = 1
            r3.O = r1
            int r1 = r3.P
            r2 = -100
            if (r1 == r2) goto L50
            java.lang.Object r1 = r3.f615g
            boolean r2 = r1 instanceof android.app.Activity
            if (r2 == 0) goto L50
            android.app.Activity r1 = (android.app.Activity) r1
            boolean r1 = r1.isChangingConfigurations()
            if (r1 == 0) goto L50
            java.lang.Object r1 = r3.f615g
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            int r2 = r3.P
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.put(r1, r2)
            goto L5d
        L50:
            java.lang.Object r1 = r3.f615g
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            r0.remove(r1)
        L5d:
            b.b.c.a r0 = r3.l
            if (r0 == 0) goto L64
            java.util.Objects.requireNonNull(r0)
        L64:
            b.b.c.k$f r0 = r3.T
            if (r0 == 0) goto L6b
            r0.a()
        L6b:
            b.b.c.k$f r0 = r3.U
            if (r0 == 0) goto L72
            r0.a()
        L72:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.n():void");
    }

    @Override // b.b.c.j
    public void o(Bundle bundle) {
        K();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:47:0x021b
        	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1179)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.collectHandlerRegions(ExcHandlersRegionMaker.java:53)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.process(ExcHandlersRegionMaker.java:38)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:27)
        */
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v10, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v12, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v13, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v8 */
    @Override // android.view.LayoutInflater.Factory2
    public final android.view.View onCreateView(android.view.View r7, java.lang.String r8, android.content.Context r9, android.util.AttributeSet r10) {
        /*
            Method dump skipped, instructions count: 678
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.k.onCreateView(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // b.b.c.j
    public void p() {
        Q();
        b.b.c.a aVar = this.l;
        if (aVar != null) {
            ((u) aVar).u = true;
        }
    }

    @Override // b.b.c.j
    public void q(Bundle bundle) {
    }

    @Override // b.b.c.j
    public void r() {
        this.N = true;
        d();
    }

    @Override // b.b.c.j
    public void s() {
        this.N = false;
        Q();
        b.b.c.a aVar = this.l;
        if (aVar != null) {
            u uVar = (u) aVar;
            uVar.u = false;
            b.b.h.g gVar = uVar.t;
            if (gVar != null) {
                gVar.a();
            }
        }
    }

    @Override // b.b.c.j
    public boolean u(int i2) {
        if (i2 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i2 = 108;
        } else if (i2 == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i2 = 109;
        }
        if (this.G && i2 == 108) {
            return false;
        }
        if (this.C && i2 == 1) {
            this.C = false;
        }
        if (i2 == 1) {
            X();
            this.G = true;
            return true;
        }
        if (i2 == 2) {
            X();
            this.A = true;
            return true;
        }
        if (i2 == 5) {
            X();
            this.B = true;
            return true;
        }
        if (i2 == 10) {
            X();
            this.E = true;
            return true;
        }
        if (i2 == 108) {
            X();
            this.C = true;
            return true;
        }
        if (i2 != 109) {
            return this.f617i.requestFeature(i2);
        }
        X();
        this.D = true;
        return true;
    }

    @Override // b.b.c.j
    public void v(int i2) {
        K();
        ViewGroup viewGroup = (ViewGroup) this.x.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f616h).inflate(i2, viewGroup);
        this.f618j.f770d.onContentChanged();
    }

    @Override // b.b.c.j
    public void w(View view) {
        K();
        ViewGroup viewGroup = (ViewGroup) this.x.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f618j.f770d.onContentChanged();
    }

    @Override // b.b.c.j
    public void x(View view, ViewGroup.LayoutParams layoutParams) {
        K();
        ViewGroup viewGroup = (ViewGroup) this.x.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f618j.f770d.onContentChanged();
    }

    @Override // b.b.c.j
    public void z(int i2) {
        this.Q = i2;
    }
}
