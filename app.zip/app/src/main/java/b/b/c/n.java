package b.b.c;

import android.app.Dialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import b.b.h.a;
import b.h.k.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\p.smali */
public class p extends Dialog implements i {

    /* renamed from: d, reason: collision with root package name */
    public j f648d;

    /* renamed from: e, reason: collision with root package name */
    public final d.a f649e;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\p$a.smali */
    public class a implements d.a {
        public a() {
        }

        @Override // b.h.k.d.a
        public boolean f(KeyEvent keyEvent) {
            return p.this.b(keyEvent);
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public p(android.content.Context r5, int r6) {
        /*
            r4 = this;
            r0 = 1
            r1 = 2130968895(0x7f04013f, float:1.7546457E38)
            if (r6 != 0) goto L15
            android.util.TypedValue r2 = new android.util.TypedValue
            r2.<init>()
            android.content.res.Resources$Theme r3 = r5.getTheme()
            r3.resolveAttribute(r1, r2, r0)
            int r2 = r2.resourceId
            goto L16
        L15:
            r2 = r6
        L16:
            r4.<init>(r5, r2)
            b.b.c.p$a r2 = new b.b.c.p$a
            r2.<init>()
            r4.f649e = r2
            b.b.c.j r2 = r4.a()
            if (r6 != 0) goto L34
            android.util.TypedValue r6 = new android.util.TypedValue
            r6.<init>()
            android.content.res.Resources$Theme r5 = r5.getTheme()
            r5.resolveAttribute(r1, r6, r0)
            int r6 = r6.resourceId
        L34:
            r2.z(r6)
            r5 = 0
            r2.m(r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.c.p.<init>(android.content.Context, int):void");
    }

    public j a() {
        if (this.f648d == null) {
            int i2 = j.f612d;
            this.f648d = new k(getContext(), getWindow(), this, this);
        }
        return this.f648d;
    }

    @Override // android.app.Dialog
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        a().c(view, layoutParams);
    }

    public boolean b(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean c(int i2) {
        return a().u(i2);
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void dismiss() {
        super.dismiss();
        a().n();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return b.h.k.d.b(this.f649e, getWindow().getDecorView(), this, keyEvent);
    }

    @Override // android.app.Dialog
    public <T extends View> T findViewById(int i2) {
        return (T) a().f(i2);
    }

    @Override // b.b.c.i
    public void g(b.b.h.a aVar) {
    }

    @Override // android.app.Dialog
    public void invalidateOptionsMenu() {
        a().k();
    }

    @Override // b.b.c.i
    public void j(b.b.h.a aVar) {
    }

    @Override // android.app.Dialog
    public void onCreate(Bundle bundle) {
        a().j();
        super.onCreate(bundle);
        a().m(bundle);
    }

    @Override // android.app.Dialog
    public void onStop() {
        super.onStop();
        a().s();
    }

    @Override // android.app.Dialog
    public void setContentView(int i2) {
        a().v(i2);
    }

    @Override // android.app.Dialog
    public void setContentView(View view) {
        a().w(view);
    }

    @Override // android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        a().x(view, layoutParams);
    }

    @Override // android.app.Dialog
    public void setTitle(int i2) {
        super.setTitle(i2);
        a().A(getContext().getString(i2));
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        a().A(charSequence);
    }

    @Override // b.b.c.i
    public b.b.h.a v(a.InterfaceC0014a interfaceC0014a) {
        return null;
    }
}
