package b.b.c;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import b.b.h.a;
import b.b.i.a1;
import b.h.d.a;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\h.smali */
public class h extends b.n.c.e implements i {
    public j s;

    @Override // b.n.c.e
    public void C() {
        D().k();
    }

    public j D() {
        if (this.s == null) {
            int i2 = j.f612d;
            this.s = new k(this, null, this, this);
        }
        return this.s;
    }

    public a E() {
        return D().i();
    }

    public Intent F() {
        return b.h.a.v(this);
    }

    public void G() {
    }

    public void H() {
    }

    @Override // android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        D().c(view, layoutParams);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public void attachBaseContext(Context context) {
        super.attachBaseContext(D().e(context));
    }

    @Override // android.app.Activity
    public void closeOptionsMenu() {
        E();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    @Override // b.h.c.e, android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        keyEvent.getKeyCode();
        E();
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity
    public <T extends View> T findViewById(int i2) {
        return (T) D().f(i2);
    }

    @Override // b.b.c.i
    public void g(b.b.h.a aVar) {
    }

    @Override // android.app.Activity
    public MenuInflater getMenuInflater() {
        return D().h();
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        int i2 = a1.f896a;
        return super.getResources();
    }

    @Override // android.app.Activity
    public void invalidateOptionsMenu() {
        D().k();
    }

    @Override // b.b.c.i
    public void j(b.b.h.a aVar) {
    }

    @Override // b.n.c.e, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        D().l(configuration);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onContentChanged() {
    }

    @Override // b.n.c.e, androidx.activity.ComponentActivity, b.h.c.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        j D = D();
        D.j();
        D.m(bundle);
        super.onCreate(bundle);
    }

    @Override // b.n.c.e, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        D().n();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        Window window;
        if ((Build.VERSION.SDK_INT >= 26 || keyEvent.isCtrlPressed() || KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) || keyEvent.getRepeatCount() != 0 || KeyEvent.isModifierKey(keyEvent.getKeyCode()) || (window = getWindow()) == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent)) ? false : true) {
            return true;
        }
        return super.onKeyDown(i2, keyEvent);
    }

    @Override // b.n.c.e, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        Intent v;
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        a E = E();
        if (menuItem.getItemId() != 16908332 || E == null || (((u) E).f674e.p() & 4) == 0 || (v = b.h.a.v(this)) == null) {
            return false;
        }
        if (!shouldUpRecreateTask(v)) {
            navigateUpTo(v);
            return true;
        }
        ArrayList arrayList = new ArrayList();
        Intent F = F();
        if (F == null) {
            F = b.h.a.v(this);
        }
        if (F != null) {
            ComponentName component = F.getComponent();
            if (component == null) {
                component = F.resolveActivity(getPackageManager());
            }
            int size = arrayList.size();
            try {
                Intent w = b.h.a.w(this, component);
                while (w != null) {
                    arrayList.add(size, w);
                    w = b.h.a.w(this, w.getComponent());
                }
                arrayList.add(F);
            } catch (PackageManager.NameNotFoundException e2) {
                Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                throw new IllegalArgumentException(e2);
            }
        }
        H();
        if (arrayList.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        }
        Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[arrayList.size()]);
        intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
        Object obj = b.h.d.a.f1567a;
        a.C0028a.a(this, intentArr, null);
        try {
            int i3 = b.h.c.a.f1509c;
            finishAffinity();
            return true;
        } catch (IllegalStateException unused) {
            finish();
            return true;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuOpened(int i2, Menu menu) {
        return super.onMenuOpened(i2, menu);
    }

    @Override // b.n.c.e, android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i2, Menu menu) {
        super.onPanelClosed(i2, menu);
    }

    @Override // android.app.Activity
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        D().o(bundle);
    }

    @Override // b.n.c.e, android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        D().p();
    }

    @Override // b.n.c.e, androidx.activity.ComponentActivity, b.h.c.e, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        D().q(bundle);
    }

    @Override // b.n.c.e, android.app.Activity
    public void onStart() {
        super.onStart();
        D().r();
    }

    @Override // b.n.c.e, android.app.Activity
    public void onStop() {
        super.onStop();
        D().s();
    }

    @Override // android.app.Activity
    public void onTitleChanged(CharSequence charSequence, int i2) {
        super.onTitleChanged(charSequence, i2);
        D().A(charSequence);
    }

    @Override // android.app.Activity
    public void openOptionsMenu() {
        E();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    @Override // android.app.Activity
    public void setContentView(int i2) {
        D().v(i2);
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        D().w(view);
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        D().x(view, layoutParams);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public void setTheme(int i2) {
        super.setTheme(i2);
        D().z(i2);
    }

    @Override // b.b.c.i
    public b.b.h.a v(a.InterfaceC0014a interfaceC0014a) {
        return null;
    }
}
