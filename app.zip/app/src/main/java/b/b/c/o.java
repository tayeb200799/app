package b.b.c;

import android.app.Dialog;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\q.smali */
public class q extends b.n.c.c {
    @Override // b.n.c.c
    public void E0(Dialog dialog, int i2) {
        if (!(dialog instanceof p)) {
            super.E0(dialog, i2);
            return;
        }
        p pVar = (p) dialog;
        if (i2 != 1 && i2 != 2) {
            if (i2 != 3) {
                return;
            } else {
                dialog.getWindow().addFlags(24);
            }
        }
        pVar.c(1);
    }
}
