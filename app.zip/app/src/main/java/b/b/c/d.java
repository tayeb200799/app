package b.b.c;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController;
import androidx.core.widget.NestedScrollView;
import b.b.i.d0;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\g.smali */
public class g extends p implements DialogInterface {

    /* renamed from: f, reason: collision with root package name */
    public final AlertController f609f;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\g$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final AlertController.b f610a;

        /* renamed from: b, reason: collision with root package name */
        public final int f611b;

        public a(Context context) {
            int d2 = g.d(context, 0);
            this.f610a = new AlertController.b(new ContextThemeWrapper(context, g.d(context, d2)));
            this.f611b = d2;
        }

        public g a() {
            g gVar = new g(this.f610a.f107a, this.f611b);
            AlertController.b bVar = this.f610a;
            AlertController alertController = gVar.f609f;
            View view = bVar.f111e;
            if (view != null) {
                alertController.G = view;
            } else {
                CharSequence charSequence = bVar.f110d;
                if (charSequence != null) {
                    alertController.f98e = charSequence;
                    TextView textView = alertController.E;
                    if (textView != null) {
                        textView.setText(charSequence);
                    }
                }
                Drawable drawable = bVar.f109c;
                if (drawable != null) {
                    alertController.C = drawable;
                    alertController.B = 0;
                    ImageView imageView = alertController.D;
                    if (imageView != null) {
                        imageView.setVisibility(0);
                        alertController.D.setImageDrawable(drawable);
                    }
                }
            }
            if (bVar.f113g != null) {
                AlertController.RecycleListView recycleListView = (AlertController.RecycleListView) bVar.f108b.inflate(alertController.L, (ViewGroup) null);
                int i2 = bVar.f115i ? alertController.N : alertController.O;
                ListAdapter listAdapter = bVar.f113g;
                if (listAdapter == null) {
                    listAdapter = new AlertController.d(bVar.f107a, i2, R.id.text1, null);
                }
                alertController.H = listAdapter;
                alertController.I = bVar.f116j;
                if (bVar.f114h != null) {
                    recycleListView.setOnItemClickListener(new f(bVar, alertController));
                }
                if (bVar.f115i) {
                    recycleListView.setChoiceMode(1);
                }
                alertController.f100g = recycleListView;
            }
            Objects.requireNonNull(this.f610a);
            gVar.setCancelable(true);
            Objects.requireNonNull(this.f610a);
            gVar.setCanceledOnTouchOutside(true);
            Objects.requireNonNull(this.f610a);
            gVar.setOnCancelListener(null);
            Objects.requireNonNull(this.f610a);
            gVar.setOnDismissListener(null);
            DialogInterface.OnKeyListener onKeyListener = this.f610a.f112f;
            if (onKeyListener != null) {
                gVar.setOnKeyListener(onKeyListener);
            }
            return gVar;
        }
    }

    public g(Context context, int i2) {
        super(context, d(context, i2));
        this.f609f = new AlertController(getContext(), this, getWindow());
    }

    public static int d(Context context, int i2) {
        if (((i2 >>> 24) & 255) >= 1) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(2130968616, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // b.b.c.p, android.app.Dialog
    public void onCreate(Bundle bundle) {
        int i2;
        View view;
        ListAdapter listAdapter;
        View view2;
        View findViewById;
        super.onCreate(bundle);
        AlertController alertController = this.f609f;
        alertController.f95b.setContentView(alertController.K == 0 ? alertController.J : alertController.J);
        View findViewById2 = alertController.f96c.findViewById(2131362386);
        View findViewById3 = findViewById2.findViewById(2131362588);
        View findViewById4 = findViewById2.findViewById(2131361984);
        View findViewById5 = findViewById2.findViewById(2131361926);
        ViewGroup viewGroup = (ViewGroup) findViewById2.findViewById(2131361999);
        View view3 = alertController.f101h;
        if (view3 == null) {
            view3 = alertController.f102i != 0 ? LayoutInflater.from(alertController.f94a).inflate(alertController.f102i, viewGroup, false) : null;
        }
        boolean z = view3 != null;
        if (!z || !AlertController.a(view3)) {
            alertController.f96c.setFlags(131072, 131072);
        }
        if (z) {
            FrameLayout frameLayout = (FrameLayout) alertController.f96c.findViewById(2131361998);
            frameLayout.addView(view3, new ViewGroup.LayoutParams(-1, -1));
            if (alertController.n) {
                frameLayout.setPadding(alertController.f103j, alertController.k, alertController.l, alertController.m);
            }
            if (alertController.f100g != null) {
                ((d0.a) viewGroup.getLayoutParams()).f923a = 0.0f;
            }
        } else {
            viewGroup.setVisibility(8);
        }
        View findViewById6 = viewGroup.findViewById(2131362588);
        View findViewById7 = viewGroup.findViewById(2131361984);
        View findViewById8 = viewGroup.findViewById(2131361926);
        ViewGroup d2 = alertController.d(findViewById6, findViewById3);
        ViewGroup d3 = alertController.d(findViewById7, findViewById4);
        ViewGroup d4 = alertController.d(findViewById8, findViewById5);
        NestedScrollView nestedScrollView = (NestedScrollView) alertController.f96c.findViewById(2131362463);
        alertController.A = nestedScrollView;
        nestedScrollView.setFocusable(false);
        alertController.A.setNestedScrollingEnabled(false);
        TextView textView = (TextView) d3.findViewById(R.id.message);
        alertController.F = textView;
        if (textView != null) {
            CharSequence charSequence = alertController.f99f;
            if (charSequence != null) {
                textView.setText(charSequence);
            } else {
                textView.setVisibility(8);
                alertController.A.removeView(alertController.F);
                if (alertController.f100g != null) {
                    ViewGroup viewGroup2 = (ViewGroup) alertController.A.getParent();
                    int indexOfChild = viewGroup2.indexOfChild(alertController.A);
                    viewGroup2.removeViewAt(indexOfChild);
                    viewGroup2.addView(alertController.f100g, indexOfChild, new ViewGroup.LayoutParams(-1, -1));
                } else {
                    d3.setVisibility(8);
                }
            }
        }
        Button button = (Button) d4.findViewById(R.id.button1);
        alertController.o = button;
        button.setOnClickListener(alertController.R);
        if (TextUtils.isEmpty(alertController.p) && alertController.r == null) {
            alertController.o.setVisibility(8);
            i2 = 0;
        } else {
            alertController.o.setText(alertController.p);
            Drawable drawable = alertController.r;
            if (drawable != null) {
                int i3 = alertController.f97d;
                drawable.setBounds(0, 0, i3, i3);
                alertController.o.setCompoundDrawables(alertController.r, null, null, null);
            }
            alertController.o.setVisibility(0);
            i2 = 1;
        }
        Button button2 = (Button) d4.findViewById(R.id.button2);
        alertController.s = button2;
        button2.setOnClickListener(alertController.R);
        if (TextUtils.isEmpty(alertController.t) && alertController.v == null) {
            alertController.s.setVisibility(8);
        } else {
            alertController.s.setText(alertController.t);
            Drawable drawable2 = alertController.v;
            if (drawable2 != null) {
                int i4 = alertController.f97d;
                drawable2.setBounds(0, 0, i4, i4);
                alertController.s.setCompoundDrawables(alertController.v, null, null, null);
            }
            alertController.s.setVisibility(0);
            i2 |= 2;
        }
        Button button3 = (Button) d4.findViewById(R.id.button3);
        alertController.w = button3;
        button3.setOnClickListener(alertController.R);
        if (TextUtils.isEmpty(alertController.x) && alertController.z == null) {
            alertController.w.setVisibility(8);
            view = null;
        } else {
            alertController.w.setText(alertController.x);
            Drawable drawable3 = alertController.z;
            if (drawable3 != null) {
                int i5 = alertController.f97d;
                drawable3.setBounds(0, 0, i5, i5);
                view = null;
                alertController.w.setCompoundDrawables(alertController.z, null, null, null);
            } else {
                view = null;
            }
            alertController.w.setVisibility(0);
            i2 |= 4;
        }
        Context context = alertController.f94a;
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(2130968614, typedValue, true);
        if (typedValue.data != 0) {
            if (i2 == 1) {
                alertController.b(alertController.o);
            } else if (i2 == 2) {
                alertController.b(alertController.s);
            } else if (i2 == 4) {
                alertController.b(alertController.w);
            }
        }
        if (!(i2 != 0)) {
            d4.setVisibility(8);
        }
        if (alertController.G != null) {
            d2.addView(alertController.G, 0, new ViewGroup.LayoutParams(-1, -2));
            alertController.f96c.findViewById(2131362570).setVisibility(8);
        } else {
            alertController.D = (ImageView) alertController.f96c.findViewById(R.id.icon);
            if ((!TextUtils.isEmpty(alertController.f98e)) && alertController.P) {
                TextView textView2 = (TextView) alertController.f96c.findViewById(2131361869);
                alertController.E = textView2;
                textView2.setText(alertController.f98e);
                int i6 = alertController.B;
                if (i6 != 0) {
                    alertController.D.setImageResource(i6);
                } else {
                    Drawable drawable4 = alertController.C;
                    if (drawable4 != null) {
                        alertController.D.setImageDrawable(drawable4);
                    } else {
                        alertController.E.setPadding(alertController.D.getPaddingLeft(), alertController.D.getPaddingTop(), alertController.D.getPaddingRight(), alertController.D.getPaddingBottom());
                        alertController.D.setVisibility(8);
                    }
                }
            } else {
                alertController.f96c.findViewById(2131362570).setVisibility(8);
                alertController.D.setVisibility(8);
                d2.setVisibility(8);
            }
        }
        boolean z2 = viewGroup.getVisibility() != 8;
        int i7 = (d2 == null || d2.getVisibility() == 8) ? 0 : 1;
        boolean z3 = d4.getVisibility() != 8;
        if (!z3 && (findViewById = d3.findViewById(2131362551)) != null) {
            findViewById.setVisibility(0);
        }
        if (i7 != 0) {
            NestedScrollView nestedScrollView2 = alertController.A;
            if (nestedScrollView2 != null) {
                nestedScrollView2.setClipToPadding(true);
            }
            View findViewById9 = (alertController.f99f == null && alertController.f100g == null) ? view : d2.findViewById(2131362569);
            if (findViewById9 != null) {
                findViewById9.setVisibility(0);
            }
        } else {
            View findViewById10 = d3.findViewById(2131362552);
            if (findViewById10 != null) {
                findViewById10.setVisibility(0);
            }
        }
        ListView listView = alertController.f100g;
        if (listView instanceof AlertController.RecycleListView) {
            AlertController.RecycleListView recycleListView = (AlertController.RecycleListView) listView;
            Objects.requireNonNull(recycleListView);
            if (!z3 || i7 == 0) {
                recycleListView.setPadding(recycleListView.getPaddingLeft(), i7 != 0 ? recycleListView.getPaddingTop() : recycleListView.f104d, recycleListView.getPaddingRight(), z3 ? recycleListView.getPaddingBottom() : recycleListView.f105e);
            }
        }
        if (!z2) {
            View view4 = alertController.f100g;
            if (view4 == null) {
                view4 = alertController.A;
            }
            if (view4 != null) {
                int i8 = i7 | (z3 ? 2 : 0);
                View findViewById11 = alertController.f96c.findViewById(2131362462);
                View findViewById12 = alertController.f96c.findViewById(2131362461);
                int i9 = Build.VERSION.SDK_INT;
                if (i9 >= 23) {
                    AtomicInteger atomicInteger = b.h.k.q.f1738a;
                    if (i9 >= 23) {
                        view4.setScrollIndicators(i8, 3);
                    }
                    if (findViewById11 != null) {
                        d3.removeView(findViewById11);
                    }
                    if (findViewById12 != null) {
                        d3.removeView(findViewById12);
                    }
                } else {
                    if (findViewById11 != null && (i8 & 1) == 0) {
                        d3.removeView(findViewById11);
                        findViewById11 = view;
                    }
                    if (findViewById12 == null || (i8 & 2) != 0) {
                        view2 = findViewById12;
                    } else {
                        d3.removeView(findViewById12);
                        view2 = view;
                    }
                    if (findViewById11 != null || view2 != null) {
                        if (alertController.f99f != null) {
                            alertController.A.setOnScrollChangeListener(new b(alertController, findViewById11, view2));
                            alertController.A.post(new c(alertController, findViewById11, view2));
                        } else {
                            ListView listView2 = alertController.f100g;
                            if (listView2 != null) {
                                listView2.setOnScrollListener(new d(alertController, findViewById11, view2));
                                alertController.f100g.post(new e(alertController, findViewById11, view2));
                            } else {
                                if (findViewById11 != null) {
                                    d3.removeView(findViewById11);
                                }
                                if (view2 != null) {
                                    d3.removeView(view2);
                                }
                            }
                        }
                    }
                }
            }
        }
        ListView listView3 = alertController.f100g;
        if (listView3 == null || (listAdapter = alertController.H) == null) {
            return;
        }
        listView3.setAdapter(listAdapter);
        int i10 = alertController.I;
        if (i10 > -1) {
            listView3.setItemChecked(i10, true);
            listView3.setSelection(i10);
        }
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f609f.A;
        if (nestedScrollView != null && nestedScrollView.l(keyEvent)) {
            return true;
        }
        return super.onKeyDown(i2, keyEvent);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f609f.A;
        if (nestedScrollView != null && nestedScrollView.l(keyEvent)) {
            return true;
        }
        return super.onKeyUp(i2, keyEvent);
    }

    @Override // b.b.c.p, android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        AlertController alertController = this.f609f;
        alertController.f98e = charSequence;
        TextView textView = alertController.E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }
}
