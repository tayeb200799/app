package b.b.e.a;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import b.b.e.a.b;
import b.b.e.a.d;
import b.e.i;

@SuppressLint({"RestrictedAPI"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a.smali */
public class a extends b.b.e.a.d implements b.h.e.l.a {
    public c s;
    public g t;
    public int u;
    public int v;
    public boolean w;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a$b.smali */
    public static class b extends g {

        /* renamed from: a, reason: collision with root package name */
        public final Animatable f695a;

        public b(Animatable animatable) {
            super(null);
            this.f695a = animatable;
        }

        @Override // b.b.e.a.a.g
        public void c() {
            this.f695a.start();
        }

        @Override // b.b.e.a.a.g
        public void d() {
            this.f695a.stop();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a$c.smali */
    public static class c extends d.a {
        public b.e.e<Long> K;
        public i<Integer> L;

        public c(c cVar, a aVar, Resources resources) {
            super(cVar, aVar, resources);
            if (cVar != null) {
                this.K = cVar.K;
                this.L = cVar.L;
            } else {
                this.K = new b.e.e<>();
                this.L = new i<>(10);
            }
        }

        public static long h(int i2, int i3) {
            return i3 | (i2 << 32);
        }

        @Override // b.b.e.a.d.a, b.b.e.a.b.c
        public void e() {
            this.K = this.K.clone();
            this.L = this.L.clone();
        }

        public int i(int i2) {
            if (i2 < 0) {
                return 0;
            }
            return this.L.f(i2, 0).intValue();
        }

        @Override // b.b.e.a.d.a, android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new a(this, null);
        }

        @Override // b.b.e.a.d.a, android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new a(this, resources);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a$d.smali */
    public static class d extends g {

        /* renamed from: a, reason: collision with root package name */
        public final b.z.a.a.c f696a;

        public d(b.z.a.a.c cVar) {
            super(null);
            this.f696a = cVar;
        }

        @Override // b.b.e.a.a.g
        public void c() {
            this.f696a.start();
        }

        @Override // b.b.e.a.a.g
        public void d() {
            this.f696a.stop();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a$e.smali */
    public static class e extends g {

        /* renamed from: a, reason: collision with root package name */
        public final ObjectAnimator f697a;

        /* renamed from: b, reason: collision with root package name */
        public final boolean f698b;

        public e(AnimationDrawable animationDrawable, boolean z, boolean z2) {
            super(null);
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            int i2 = z ? numberOfFrames - 1 : 0;
            int i3 = z ? 0 : numberOfFrames - 1;
            f fVar = new f(animationDrawable, z);
            ObjectAnimator ofInt = ObjectAnimator.ofInt(animationDrawable, "currentIndex", i2, i3);
            ofInt.setAutoCancel(true);
            ofInt.setDuration(fVar.f701c);
            ofInt.setInterpolator(fVar);
            this.f698b = z2;
            this.f697a = ofInt;
        }

        @Override // b.b.e.a.a.g
        public boolean a() {
            return this.f698b;
        }

        @Override // b.b.e.a.a.g
        public void b() {
            this.f697a.reverse();
        }

        @Override // b.b.e.a.a.g
        public void c() {
            this.f697a.start();
        }

        @Override // b.b.e.a.a.g
        public void d() {
            this.f697a.cancel();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a$f.smali */
    public static class f implements TimeInterpolator {

        /* renamed from: a, reason: collision with root package name */
        public int[] f699a;

        /* renamed from: b, reason: collision with root package name */
        public int f700b;

        /* renamed from: c, reason: collision with root package name */
        public int f701c;

        public f(AnimationDrawable animationDrawable, boolean z) {
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            this.f700b = numberOfFrames;
            int[] iArr = this.f699a;
            if (iArr == null || iArr.length < numberOfFrames) {
                this.f699a = new int[numberOfFrames];
            }
            int[] iArr2 = this.f699a;
            int i2 = 0;
            for (int i3 = 0; i3 < numberOfFrames; i3++) {
                int duration = animationDrawable.getDuration(z ? (numberOfFrames - i3) - 1 : i3);
                iArr2[i3] = duration;
                i2 += duration;
            }
            this.f701c = i2;
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            int i2 = (int) ((f2 * this.f701c) + 0.5f);
            int i3 = this.f700b;
            int[] iArr = this.f699a;
            int i4 = 0;
            while (i4 < i3 && i2 >= iArr[i4]) {
                i2 -= iArr[i4];
                i4++;
            }
            return (i4 / i3) + (i4 < i3 ? i2 / this.f701c : 0.0f);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\e\a\a$g.smali */
    public static abstract class g {
        public g(C0012a c0012a) {
        }

        public boolean a() {
            return false;
        }

        public void b() {
        }

        public abstract void c();

        public abstract void d();
    }

    public a() {
        this(null, null);
    }

    public a(c cVar, Resources resources) {
        super(null);
        this.u = -1;
        this.v = -1;
        c cVar2 = new c(cVar, this, resources);
        super.e(cVar2);
        this.s = cVar2;
        onStateChange(getState());
        jumpToCurrentState();
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0216, code lost:
    
        r5.onStateChange(r5.getState());
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x021d, code lost:
    
        return r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x01f8, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException(c.a.a.a.a.j(r21, new java.lang.StringBuilder(), ": <transition> tag requires 'fromId' & 'toId' attributes"));
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static b.b.e.a.a g(android.content.Context r19, android.content.res.Resources r20, org.xmlpull.v1.XmlPullParser r21, android.util.AttributeSet r22, android.content.res.Resources.Theme r23) {
        /*
            Method dump skipped, instructions count: 572
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.e.a.a.g(android.content.Context, android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):b.b.e.a.a");
    }

    @Override // b.b.e.a.d, b.b.e.a.b
    public b.c b() {
        return new c(this.s, this, null);
    }

    @Override // b.b.e.a.d, b.b.e.a.b
    public void e(b.c cVar) {
        super.e(cVar);
        if (cVar instanceof c) {
            this.s = (c) cVar;
        }
    }

    @Override // b.b.e.a.d
    /* renamed from: f */
    public d.a b() {
        return new c(this.s, this, null);
    }

    @Override // b.b.e.a.d, android.graphics.drawable.Drawable
    public boolean isStateful() {
        return true;
    }

    @Override // b.b.e.a.b, android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        g gVar = this.t;
        if (gVar != null) {
            gVar.d();
            this.t = null;
            d(this.u);
            this.u = -1;
            this.v = -1;
        }
    }

    @Override // b.b.e.a.d, b.b.e.a.b, android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.w) {
            super.mutate();
            if (this == this) {
                this.s.e();
                this.w = true;
            }
        }
        return this;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x00eb  */
    @Override // b.b.e.a.d, b.b.e.a.b, android.graphics.drawable.Drawable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onStateChange(int[] r19) {
        /*
            Method dump skipped, instructions count: 252
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.b.e.a.a.onStateChange(int[]):boolean");
    }

    @Override // b.b.e.a.b, android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        g gVar = this.t;
        if (gVar != null && (visible || z2)) {
            if (z) {
                gVar.c();
            } else {
                jumpToCurrentState();
            }
        }
        return visible;
    }
}
