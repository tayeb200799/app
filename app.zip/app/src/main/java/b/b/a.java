package b.b;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import b.b.i.c1;
import b.b.i.y0;
import java.lang.reflect.Field;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\a.smali */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static Field f580a;

    /* renamed from: b, reason: collision with root package name */
    public static boolean f581b;

    /* renamed from: c, reason: collision with root package name */
    public static Class<?> f582c;

    /* renamed from: d, reason: collision with root package name */
    public static boolean f583d;

    /* renamed from: e, reason: collision with root package name */
    public static Field f584e;

    /* renamed from: f, reason: collision with root package name */
    public static boolean f585f;

    /* renamed from: g, reason: collision with root package name */
    public static Field f586g;

    /* renamed from: h, reason: collision with root package name */
    public static boolean f587h;

    public static void a(Object obj) {
        if (!f583d) {
            try {
                f582c = Class.forName("android.content.res.ThemedResourceCache");
            } catch (ClassNotFoundException e2) {
                Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", e2);
            }
            f583d = true;
        }
        Class<?> cls = f582c;
        if (cls == null) {
            return;
        }
        if (!f585f) {
            try {
                Field declaredField = cls.getDeclaredField("mUnthemedEntries");
                f584e = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e3) {
                Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", e3);
            }
            f585f = true;
        }
        Field field = f584e;
        if (field == null) {
            return;
        }
        LongSparseArray longSparseArray = null;
        try {
            longSparseArray = (LongSparseArray) field.get(obj);
        } catch (IllegalAccessException e4) {
            Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", e4);
        }
        if (longSparseArray != null) {
            longSparseArray.clear();
        }
    }

    public static InputConnection b(InputConnection inputConnection, EditorInfo editorInfo, View view) {
        if (inputConnection != null && editorInfo.hintText == null) {
            ViewParent parent = view.getParent();
            while (true) {
                if (!(parent instanceof View)) {
                    break;
                }
                if (parent instanceof c1) {
                    editorInfo.hintText = ((c1) parent).a();
                    break;
                }
                parent = parent.getParent();
            }
        }
        return inputConnection;
    }

    public static void c(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setTooltipText(charSequence);
            return;
        }
        y0 y0Var = y0.m;
        if (y0Var != null && y0Var.f1097d == view) {
            y0.c(null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new y0(view, charSequence);
            return;
        }
        y0 y0Var2 = y0.n;
        if (y0Var2 != null && y0Var2.f1097d == view) {
            y0Var2.b();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }
}
