package b.h.c;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import java.util.Arrays;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\a.smali */
public class a extends b.h.d.a {

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f1509c = 0;

    /* renamed from: b.h.c.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\a$a.smali */
    public class RunnableC0026a implements Runnable {

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ String[] f1510d;

        /* renamed from: e, reason: collision with root package name */
        public final /* synthetic */ Activity f1511e;

        /* renamed from: f, reason: collision with root package name */
        public final /* synthetic */ int f1512f;

        public RunnableC0026a(String[] strArr, Activity activity, int i2) {
            this.f1510d = strArr;
            this.f1511e = activity;
            this.f1512f = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            int[] iArr = new int[this.f1510d.length];
            PackageManager packageManager = this.f1511e.getPackageManager();
            String packageName = this.f1511e.getPackageName();
            int length = this.f1510d.length;
            for (int i2 = 0; i2 < length; i2++) {
                iArr[i2] = packageManager.checkPermission(this.f1510d[i2], packageName);
            }
            ((b) this.f1511e).onRequestPermissionsResult(this.f1512f, this.f1510d, iArr);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\a$b.smali */
    public interface b {
        void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\a$c.smali */
    public interface c {
        void b(int i2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void c(Activity activity, String[] strArr, int i2) {
        for (String str : strArr) {
            if (TextUtils.isEmpty(str)) {
                StringBuilder n = c.a.a.a.a.n("Permission request for permissions ");
                n.append(Arrays.toString(strArr));
                n.append(" must not contain null or empty values");
                throw new IllegalArgumentException(n.toString());
            }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            if (activity instanceof c) {
                ((c) activity).b(i2);
            }
            activity.requestPermissions(strArr, i2);
        } else if (activity instanceof b) {
            new Handler(Looper.getMainLooper()).post(new RunnableC0026a(strArr, activity, i2));
        }
    }

    public static boolean d(Activity activity, String str) {
        if (Build.VERSION.SDK_INT >= 23) {
            return activity.shouldShowRequestPermissionRationale(str);
        }
        return false;
    }
}
