package b.o.a.a;

import android.view.animation.Interpolator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\o\a\a\d.smali */
public abstract class d implements Interpolator {

    /* renamed from: a, reason: collision with root package name */
    public final float[] f2113a;

    /* renamed from: b, reason: collision with root package name */
    public final float f2114b;

    public d(float[] fArr) {
        this.f2113a = fArr;
        this.f2114b = 1.0f / (fArr.length - 1);
    }

    @Override // android.animation.TimeInterpolator
    public float getInterpolation(float f2) {
        if (f2 >= 1.0f) {
            return 1.0f;
        }
        if (f2 <= 0.0f) {
            return 0.0f;
        }
        float[] fArr = this.f2113a;
        int min = Math.min((int) ((fArr.length - 1) * f2), fArr.length - 2);
        float f3 = this.f2114b;
        float f4 = (f2 - (min * f3)) / f3;
        float[] fArr2 = this.f2113a;
        return c.a.a.a.a.a(fArr2[min + 1], fArr2[min], f4, fArr2[min]);
    }
}
