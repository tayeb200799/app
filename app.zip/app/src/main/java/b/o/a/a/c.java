package b.p;

import b.p.g;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\b.smali */
public class b {

    /* renamed from: c, reason: collision with root package name */
    public static b f2112c = new b();

    /* renamed from: a, reason: collision with root package name */
    public final Map<Class<?>, a> f2113a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final Map<Class<?>, Boolean> f2114b = new HashMap();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\b$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final Map<g.a, List<C0044b>> f2115a = new HashMap();

        /* renamed from: b, reason: collision with root package name */
        public final Map<C0044b, g.a> f2116b;

        public a(Map<C0044b, g.a> map) {
            this.f2116b = map;
            for (Map.Entry<C0044b, g.a> entry : map.entrySet()) {
                g.a value = entry.getValue();
                List<C0044b> list = this.f2115a.get(value);
                if (list == null) {
                    list = new ArrayList<>();
                    this.f2115a.put(value, list);
                }
                list.add(entry.getKey());
            }
        }

        public static void a(List<C0044b> list, k kVar, g.a aVar, Object obj) {
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    C0044b c0044b = list.get(size);
                    Objects.requireNonNull(c0044b);
                    try {
                        int i2 = c0044b.f2117a;
                        if (i2 == 0) {
                            c0044b.f2118b.invoke(obj, new Object[0]);
                        } else if (i2 == 1) {
                            c0044b.f2118b.invoke(obj, kVar);
                        } else if (i2 == 2) {
                            c0044b.f2118b.invoke(obj, kVar, aVar);
                        }
                    } catch (IllegalAccessException e2) {
                        throw new RuntimeException(e2);
                    } catch (InvocationTargetException e3) {
                        throw new RuntimeException("Failed to call observer method", e3.getCause());
                    }
                }
            }
        }
    }

    /* renamed from: b.p.b$b, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\p\b$b.smali */
    public static class C0044b {

        /* renamed from: a, reason: collision with root package name */
        public final int f2117a;

        /* renamed from: b, reason: collision with root package name */
        public final Method f2118b;

        public C0044b(int i2, Method method) {
            this.f2117a = i2;
            this.f2118b = method;
            method.setAccessible(true);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || C0044b.class != obj.getClass()) {
                return false;
            }
            C0044b c0044b = (C0044b) obj;
            return this.f2117a == c0044b.f2117a && this.f2118b.getName().equals(c0044b.f2118b.getName());
        }

        public int hashCode() {
            return this.f2118b.getName().hashCode() + (this.f2117a * 31);
        }
    }

    public final a a(Class<?> cls, Method[] methodArr) {
        int i2;
        a b2;
        Class<?> superclass = cls.getSuperclass();
        HashMap hashMap = new HashMap();
        if (superclass != null && (b2 = b(superclass)) != null) {
            hashMap.putAll(b2.f2116b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            for (Map.Entry<C0044b, g.a> entry : b(cls2).f2116b.entrySet()) {
                c(hashMap, entry.getKey(), entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e2) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e2);
            }
        }
        boolean z = false;
        for (Method method : methodArr) {
            r rVar = (r) method.getAnnotation(r.class);
            if (rVar != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i2 = 0;
                } else {
                    if (!parameterTypes[0].isAssignableFrom(k.class)) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i2 = 1;
                }
                g.a value = rVar.value();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(g.a.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (value != g.a.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i2 = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                c(hashMap, new C0044b(i2, method), value, cls);
                z = true;
            }
        }
        a aVar = new a(hashMap);
        this.f2113a.put(cls, aVar);
        this.f2114b.put(cls, Boolean.valueOf(z));
        return aVar;
    }

    public a b(Class<?> cls) {
        a aVar = this.f2113a.get(cls);
        return aVar != null ? aVar : a(cls, null);
    }

    public final void c(Map<C0044b, g.a> map, C0044b c0044b, g.a aVar, Class<?> cls) {
        g.a aVar2 = map.get(c0044b);
        if (aVar2 == null || aVar == aVar2) {
            if (aVar2 == null) {
                map.put(c0044b, aVar);
                return;
            }
            return;
        }
        Method method = c0044b.f2118b;
        StringBuilder n = c.a.a.a.a.n("Method ");
        n.append(method.getName());
        n.append(" in ");
        n.append(cls.getName());
        n.append(" already declared with different @OnLifecycleEvent value: previous value ");
        n.append(aVar2);
        n.append(", new value ");
        n.append(aVar);
        throw new IllegalArgumentException(n.toString());
    }
}
