package b.h.l;

import android.widget.ListView;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\l\c.smali */
public class c extends a {
    public final ListView u;

    public c(ListView listView) {
        super(listView);
        this.u = listView;
    }
}
