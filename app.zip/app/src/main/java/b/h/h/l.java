package b.h.h;

import android.os.Handler;
import java.util.concurrent.Callable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\o.smali */
public class o<T> implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public Callable<T> f1682d;

    /* renamed from: e, reason: collision with root package name */
    public b.h.j.a<T> f1683e;

    /* renamed from: f, reason: collision with root package name */
    public Handler f1684f;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\o$a.smali */
    public class a implements Runnable {

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ b.h.j.a f1685d;

        /* renamed from: e, reason: collision with root package name */
        public final /* synthetic */ Object f1686e;

        public a(o oVar, b.h.j.a aVar, Object obj) {
            this.f1685d = aVar;
            this.f1686e = obj;
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            this.f1685d.a(this.f1686e);
        }
    }

    public o(Handler handler, Callable<T> callable, b.h.j.a<T> aVar) {
        this.f1682d = callable;
        this.f1683e = aVar;
        this.f1684f = handler;
    }

    @Override // java.lang.Runnable
    public void run() {
        T t;
        try {
            t = this.f1682d.call();
        } catch (Exception unused) {
            t = null;
        }
        this.f1684f.post(new a(this, this.f1683e, t));
    }
}
