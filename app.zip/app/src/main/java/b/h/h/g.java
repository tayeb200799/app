package b.h.h;

import b.h.h.j;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\g.smali */
public class g implements b.h.j.a<j.a> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ c f1663a;

    public g(c cVar) {
        this.f1663a = cVar;
    }

    @Override // b.h.j.a
    public void a(j.a aVar) {
        this.f1663a.a(aVar);
    }
}
