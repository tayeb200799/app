package b.h.i;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\b.smali */
public class b implements Spannable {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\b$a.smali */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final TextPaint f1700a;

        /* renamed from: b, reason: collision with root package name */
        public final TextDirectionHeuristic f1701b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1702c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1703d;

        public a(PrecomputedText.Params params) {
            this.f1700a = params.getTextPaint();
            this.f1701b = params.getTextDirection();
            this.f1702c = params.getBreakStrategy();
            this.f1703d = params.getHyphenationFrequency();
            int i2 = Build.VERSION.SDK_INT;
        }

        @SuppressLint({"NewApi"})
        public a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i2, int i3) {
            if (Build.VERSION.SDK_INT >= 29) {
                new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i2).setHyphenationFrequency(i3).setTextDirection(textDirectionHeuristic).build();
            }
            this.f1700a = textPaint;
            this.f1701b = textDirectionHeuristic;
            this.f1702c = i2;
            this.f1703d = i3;
        }

        public boolean a(a aVar) {
            int i2 = Build.VERSION.SDK_INT;
            if ((i2 >= 23 && (this.f1702c != aVar.f1702c || this.f1703d != aVar.f1703d)) || this.f1700a.getTextSize() != aVar.f1700a.getTextSize() || this.f1700a.getTextScaleX() != aVar.f1700a.getTextScaleX() || this.f1700a.getTextSkewX() != aVar.f1700a.getTextSkewX() || this.f1700a.getLetterSpacing() != aVar.f1700a.getLetterSpacing() || !TextUtils.equals(this.f1700a.getFontFeatureSettings(), aVar.f1700a.getFontFeatureSettings()) || this.f1700a.getFlags() != aVar.f1700a.getFlags()) {
                return false;
            }
            if (i2 >= 24) {
                if (!this.f1700a.getTextLocales().equals(aVar.f1700a.getTextLocales())) {
                    return false;
                }
            } else if (!this.f1700a.getTextLocale().equals(aVar.f1700a.getTextLocale())) {
                return false;
            }
            return this.f1700a.getTypeface() == null ? aVar.f1700a.getTypeface() == null : this.f1700a.getTypeface().equals(aVar.f1700a.getTypeface());
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return a(aVar) && this.f1701b == aVar.f1701b;
        }

        public int hashCode() {
            return Build.VERSION.SDK_INT >= 24 ? Objects.hash(Float.valueOf(this.f1700a.getTextSize()), Float.valueOf(this.f1700a.getTextScaleX()), Float.valueOf(this.f1700a.getTextSkewX()), Float.valueOf(this.f1700a.getLetterSpacing()), Integer.valueOf(this.f1700a.getFlags()), this.f1700a.getTextLocales(), this.f1700a.getTypeface(), Boolean.valueOf(this.f1700a.isElegantTextHeight()), this.f1701b, Integer.valueOf(this.f1702c), Integer.valueOf(this.f1703d)) : Objects.hash(Float.valueOf(this.f1700a.getTextSize()), Float.valueOf(this.f1700a.getTextScaleX()), Float.valueOf(this.f1700a.getTextSkewX()), Float.valueOf(this.f1700a.getLetterSpacing()), Integer.valueOf(this.f1700a.getFlags()), this.f1700a.getTextLocale(), this.f1700a.getTypeface(), Boolean.valueOf(this.f1700a.isElegantTextHeight()), this.f1701b, Integer.valueOf(this.f1702c), Integer.valueOf(this.f1703d));
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            StringBuilder n = c.a.a.a.a.n("textSize=");
            n.append(this.f1700a.getTextSize());
            sb.append(n.toString());
            sb.append(", textScaleX=" + this.f1700a.getTextScaleX());
            sb.append(", textSkewX=" + this.f1700a.getTextSkewX());
            int i2 = Build.VERSION.SDK_INT;
            StringBuilder n2 = c.a.a.a.a.n(", letterSpacing=");
            n2.append(this.f1700a.getLetterSpacing());
            sb.append(n2.toString());
            sb.append(", elegantTextHeight=" + this.f1700a.isElegantTextHeight());
            if (i2 >= 24) {
                StringBuilder n3 = c.a.a.a.a.n(", textLocale=");
                n3.append(this.f1700a.getTextLocales());
                sb.append(n3.toString());
            } else {
                StringBuilder n4 = c.a.a.a.a.n(", textLocale=");
                n4.append(this.f1700a.getTextLocale());
                sb.append(n4.toString());
            }
            StringBuilder n5 = c.a.a.a.a.n(", typeface=");
            n5.append(this.f1700a.getTypeface());
            sb.append(n5.toString());
            if (i2 >= 26) {
                StringBuilder n6 = c.a.a.a.a.n(", variationSettings=");
                n6.append(this.f1700a.getFontVariationSettings());
                sb.append(n6.toString());
            }
            StringBuilder n7 = c.a.a.a.a.n(", textDir=");
            n7.append(this.f1701b);
            sb.append(n7.toString());
            sb.append(", breakStrategy=" + this.f1702c);
            sb.append(", hyphenationFrequency=" + this.f1703d);
            sb.append("}");
            return sb.toString();
        }
    }

    @Override // java.lang.CharSequence
    public char charAt(int i2) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    @SuppressLint({"NewApi"})
    public <T> T[] getSpans(int i2, int i3, Class<T> cls) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        throw null;
    }

    @Override // java.lang.CharSequence
    public int length() {
        throw null;
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i2, int i3, Class cls) {
        throw null;
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT < 29) {
            throw null;
        }
        throw null;
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void setSpan(Object obj, int i2, int i3, int i4) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT < 29) {
            throw null;
        }
        throw null;
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i2, int i3) {
        throw null;
    }

    @Override // java.lang.CharSequence
    public String toString() {
        throw null;
    }
}
