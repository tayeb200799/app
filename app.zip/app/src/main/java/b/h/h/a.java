package b.h.h;

import android.graphics.Typeface;
import b.h.d.b.h;
import b.h.e.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\a.smali */
public class a implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ m f1647d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Typeface f1648e;

    public a(c cVar, m mVar, Typeface typeface) {
        this.f1647d = mVar;
        this.f1648e = typeface;
    }

    @Override // java.lang.Runnable
    public void run() {
        m mVar = this.f1647d;
        Typeface typeface = this.f1648e;
        h.c cVar = ((d.a) mVar).f1612a;
        if (cVar != null) {
            cVar.e(typeface);
        }
    }
}
