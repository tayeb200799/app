package b.h.h;

import b.h.h.j;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\i.smali */
public class i implements b.h.j.a<j.a> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f1665a;

    public i(String str) {
        this.f1665a = str;
    }

    @Override // b.h.j.a
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public void a(j.a aVar) {
        synchronized (j.f1668c) {
            b.e.h<String, ArrayList<b.h.j.a<j.a>>> hVar = j.f1669d;
            ArrayList<b.h.j.a<j.a>> arrayList = hVar.get(this.f1665a);
            if (arrayList == null) {
                return;
            }
            hVar.remove(this.f1665a);
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                arrayList.get(i2).a(aVar);
            }
        }
    }
}
