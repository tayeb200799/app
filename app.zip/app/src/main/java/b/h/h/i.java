package b.h.h;

import android.net.Uri;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\l.smali */
public class l {

    /* renamed from: a, reason: collision with root package name */
    public final Uri f1674a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1675b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1676c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1677d;

    /* renamed from: e, reason: collision with root package name */
    public final int f1678e;

    @Deprecated
    public l(Uri uri, int i2, int i3, boolean z, int i4) {
        Objects.requireNonNull(uri);
        this.f1674a = uri;
        this.f1675b = i2;
        this.f1676c = i3;
        this.f1677d = z;
        this.f1678e = i4;
    }
}
