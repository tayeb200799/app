package b.h.h;

import android.util.Base64;
import java.util.List;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\e.smali */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final String f1651a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1652b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1653c;

    /* renamed from: d, reason: collision with root package name */
    public final List<List<byte[]>> f1654d;

    /* renamed from: e, reason: collision with root package name */
    public final String f1655e;

    public e(String str, String str2, String str3, List<List<byte[]>> list) {
        this.f1651a = str;
        this.f1652b = str2;
        this.f1653c = str3;
        Objects.requireNonNull(list);
        this.f1654d = list;
        this.f1655e = str + "-" + str2 + "-" + str3;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        StringBuilder n = c.a.a.a.a.n("FontRequest {mProviderAuthority: ");
        n.append(this.f1651a);
        n.append(", mProviderPackage: ");
        n.append(this.f1652b);
        n.append(", mQuery: ");
        n.append(this.f1653c);
        n.append(", mCertificates:");
        sb.append(n.toString());
        for (int i2 = 0; i2 < this.f1654d.size(); i2++) {
            sb.append(" [");
            List<byte[]> list = this.f1654d.get(i2);
            for (int i3 = 0; i3 < list.size(); i3++) {
                sb.append(" \"");
                sb.append(Base64.encodeToString(list.get(i3), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        sb.append("mCertificatesArray: 0");
        return sb.toString();
    }
}
