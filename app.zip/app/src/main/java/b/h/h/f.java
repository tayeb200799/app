package b.h.h;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\j.smali */
public class j {

    /* renamed from: a, reason: collision with root package name */
    public static final b.e.f<String, Typeface> f1666a = new b.e.f<>(16);

    /* renamed from: b, reason: collision with root package name */
    public static final ExecutorService f1667b;

    /* renamed from: c, reason: collision with root package name */
    public static final Object f1668c;

    /* renamed from: d, reason: collision with root package name */
    public static final b.e.h<String, ArrayList<b.h.j.a<a>>> f1669d;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\j$a.smali */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final Typeface f1670a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1671b;

        public a(int i2) {
            this.f1670a = null;
            this.f1671b = i2;
        }

        @SuppressLint({"WrongConstant"})
        public a(Typeface typeface) {
            this.f1670a = typeface;
            this.f1671b = 0;
        }
    }

    static {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 10000, TimeUnit.MILLISECONDS, new LinkedBlockingDeque(), new n("fonts-androidx", 10));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        f1667b = threadPoolExecutor;
        f1668c = new Object();
        f1669d = new b.e.h<>();
    }

    public static a a(String str, Context context, e eVar, int i2) {
        int i3;
        Typeface a2 = f1666a.a(str);
        if (a2 != null) {
            return new a(a2);
        }
        try {
            k a3 = d.a(context, eVar, null);
            int i4 = a3.f1672a;
            int i5 = 1;
            if (i4 != 0) {
                if (i4 == 1) {
                    i3 = -2;
                }
                i3 = -3;
            } else {
                l[] lVarArr = a3.f1673b;
                if (lVarArr != null && lVarArr.length != 0) {
                    for (l lVar : lVarArr) {
                        int i6 = lVar.f1678e;
                        if (i6 != 0) {
                            if (i6 >= 0) {
                                i3 = i6;
                            }
                            i3 = -3;
                        }
                    }
                    i5 = 0;
                }
                i3 = i5;
            }
            if (i3 != 0) {
                return new a(i3);
            }
            Typeface b2 = b.h.e.d.f1607a.b(context, null, a3.f1673b, i2);
            if (b2 == null) {
                return new a(-3);
            }
            f1666a.b(str, b2);
            return new a(b2);
        } catch (PackageManager.NameNotFoundException unused) {
            return new a(-1);
        }
    }
}
