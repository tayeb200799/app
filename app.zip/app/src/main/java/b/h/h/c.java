package b.h.h;

import android.content.Context;
import b.h.h.j;
import java.util.concurrent.Callable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\f.smali */
public class f implements Callable<j.a> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f1656a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Context f1657b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ e f1658c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1659d;

    public f(String str, Context context, e eVar, int i2) {
        this.f1656a = str;
        this.f1657b = context;
        this.f1658c = eVar;
        this.f1659d = i2;
    }

    @Override // java.util.concurrent.Callable
    public j.a call() {
        return j.a(this.f1656a, this.f1657b, this.f1658c, this.f1659d);
    }
}
