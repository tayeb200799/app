package b.h.h;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\k.smali */
public class k {

    /* renamed from: a, reason: collision with root package name */
    public final int f1675a;

    /* renamed from: b, reason: collision with root package name */
    public final l[] f1676b;

    @Deprecated
    public k(int i2, l[] lVarArr) {
        this.f1675a = i2;
        this.f1676b = lVarArr;
    }
}
