package b.h.g;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\g\c.smali */
public final class c implements d {

    /* renamed from: b, reason: collision with root package name */
    public static final Locale[] f1640b = new Locale[0];

    /* renamed from: a, reason: collision with root package name */
    public final Locale[] f1641a;

    static {
        new Locale("en", "XA");
        new Locale("ar", "XB");
        int i2 = b.f1638b;
        String[] split = "en-Latn".split("-", -1);
        if (split.length > 2) {
            new Locale(split[0], split[1], split[2]);
        } else if (split.length > 1) {
            new Locale(split[0], split[1]);
        } else {
            if (split.length != 1) {
                throw new IllegalArgumentException("Can not parse language tag: [en-Latn]");
            }
            new Locale(split[0]);
        }
    }

    public c(Locale... localeArr) {
        if (localeArr.length == 0) {
            this.f1641a = f1640b;
            return;
        }
        ArrayList arrayList = new ArrayList();
        HashSet hashSet = new HashSet();
        for (int i2 = 0; i2 < localeArr.length; i2++) {
            Locale locale = localeArr[i2];
            if (locale == null) {
                throw new NullPointerException("list[" + i2 + "] is null");
            }
            if (!hashSet.contains(locale)) {
                Locale locale2 = (Locale) locale.clone();
                arrayList.add(locale2);
                locale2.getLanguage();
                String country = locale2.getCountry();
                if (country != null && !country.isEmpty()) {
                    locale2.getCountry();
                }
                int length = localeArr.length - 1;
                hashSet.add(locale2);
            }
        }
        this.f1641a = (Locale[]) arrayList.toArray(new Locale[arrayList.size()]);
    }

    @Override // b.h.g.d
    public Object a() {
        return null;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        Locale[] localeArr = ((c) obj).f1641a;
        if (this.f1641a.length != localeArr.length) {
            return false;
        }
        int i2 = 0;
        while (true) {
            Locale[] localeArr2 = this.f1641a;
            if (i2 >= localeArr2.length) {
                return true;
            }
            if (!localeArr2[i2].equals(localeArr[i2])) {
                return false;
            }
            i2++;
        }
    }

    @Override // b.h.g.d
    public Locale get(int i2) {
        if (i2 >= 0) {
            Locale[] localeArr = this.f1641a;
            if (i2 < localeArr.length) {
                return localeArr[i2];
            }
        }
        return null;
    }

    public int hashCode() {
        int i2 = 1;
        int i3 = 0;
        while (true) {
            Locale[] localeArr = this.f1641a;
            if (i3 >= localeArr.length) {
                return i2;
            }
            i2 = (i2 * 31) + localeArr[i3].hashCode();
            i3++;
        }
    }

    public String toString() {
        StringBuilder n = c.a.a.a.a.n("[");
        int i2 = 0;
        while (true) {
            Locale[] localeArr = this.f1641a;
            if (i2 >= localeArr.length) {
                n.append("]");
                return n.toString();
            }
            n.append(localeArr[i2]);
            if (i2 < this.f1641a.length - 1) {
                n.append(',');
            }
            i2++;
        }
    }
}
