package b.h.g;

import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\g\b.smali */
public final class b {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f1638b = 0;

    /* renamed from: a, reason: collision with root package name */
    public d f1639a;

    static {
        a(new Locale[0]);
    }

    public b(d dVar) {
        this.f1639a = dVar;
    }

    public static b a(Locale... localeArr) {
        return Build.VERSION.SDK_INT >= 24 ? new b(new e(new LocaleList(localeArr))) : new b(new c(localeArr));
    }

    public boolean equals(Object obj) {
        return (obj instanceof b) && this.f1639a.equals(((b) obj).f1639a);
    }

    public int hashCode() {
        return this.f1639a.hashCode();
    }

    public String toString() {
        return this.f1639a.toString();
    }
}
