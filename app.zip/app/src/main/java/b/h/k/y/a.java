package b.h.k.y;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\y\a.smali */
public final class a extends ClickableSpan {

    /* renamed from: d, reason: collision with root package name */
    public final int f1789d;

    /* renamed from: e, reason: collision with root package name */
    public final b f1790e;

    /* renamed from: f, reason: collision with root package name */
    public final int f1791f;

    public a(int i2, b bVar, int i3) {
        this.f1789d = i2;
        this.f1790e = bVar;
        this.f1791f = i3;
    }

    @Override // android.text.style.ClickableSpan
    public void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f1789d);
        b bVar = this.f1790e;
        bVar.f1793a.performAction(this.f1791f, bundle);
    }
}
