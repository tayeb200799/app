package b.h.k;

import android.view.View;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\g.smali */
public interface g {
    void h(View view, View view2, int i2, int i3);

    void i(View view, int i2);

    void j(View view, int i2, int i3, int[] iArr, int i4);

    void n(View view, int i2, int i3, int i4, int i5, int i6);

    boolean o(View view, View view2, int i2, int i3);
}
