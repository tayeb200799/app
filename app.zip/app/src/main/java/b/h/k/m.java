package b.h.k;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import b.h.k.a;
import b.h.k.x;
import b.h.k.y.b;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\q.smali */
public class q {

    /* renamed from: c, reason: collision with root package name */
    public static Field f1740c;

    /* renamed from: e, reason: collision with root package name */
    public static ThreadLocal<Rect> f1742e;

    /* renamed from: a, reason: collision with root package name */
    public static final AtomicInteger f1738a = new AtomicInteger(1);

    /* renamed from: b, reason: collision with root package name */
    public static WeakHashMap<View, t> f1739b = null;

    /* renamed from: d, reason: collision with root package name */
    public static boolean f1741d = false;

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f1743f = {2131361808, 2131361809, 2131361820, 2131361831, 2131361834, 2131361835, 2131361836, 2131361837, 2131361838, 2131361839, 2131361810, 2131361811, 2131361812, 2131361813, 2131361814, 2131361815, 2131361816, 2131361817, 2131361818, 2131361819, 2131361821, 2131361822, 2131361823, 2131361824, 2131361825, 2131361826, 2131361827, 2131361828, 2131361829, 2131361830, 2131361832, 2131361833};

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\q$a.smali */
    public static abstract class a<T> {

        /* renamed from: a, reason: collision with root package name */
        public final int f1744a;

        /* renamed from: b, reason: collision with root package name */
        public final Class<T> f1745b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1746c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1747d;

        public a(int i2, Class<T> cls, int i3) {
            this.f1744a = i2;
            this.f1745b = cls;
            this.f1747d = 0;
            this.f1746c = i3;
        }

        public a(int i2, Class<T> cls, int i3, int i4) {
            this.f1744a = i2;
            this.f1745b = cls;
            this.f1747d = i3;
            this.f1746c = i4;
        }

        public boolean a(Boolean bool, Boolean bool2) {
            return (bool == null ? false : bool.booleanValue()) == (bool2 == null ? false : bool2.booleanValue());
        }

        public abstract T b(View view);

        public T c(View view) {
            if (Build.VERSION.SDK_INT >= this.f1746c) {
                return b(view);
            }
            T t = (T) view.getTag(this.f1744a);
            if (this.f1745b.isInstance(t)) {
                return t;
            }
            return null;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\q$b.smali */
    public interface b {
        boolean a(View view, KeyEvent keyEvent);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\q$c.smali */
    public static class c {

        /* renamed from: d, reason: collision with root package name */
        public static final ArrayList<WeakReference<View>> f1748d = new ArrayList<>();

        /* renamed from: a, reason: collision with root package name */
        public WeakHashMap<View, Boolean> f1749a = null;

        /* renamed from: b, reason: collision with root package name */
        public SparseArray<WeakReference<View>> f1750b = null;

        /* renamed from: c, reason: collision with root package name */
        public WeakReference<KeyEvent> f1751c = null;

        public final View a(View view, KeyEvent keyEvent) {
            WeakHashMap<View, Boolean> weakHashMap = this.f1749a;
            if (weakHashMap != null && weakHashMap.containsKey(view)) {
                if (view instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view;
                    for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                        View a2 = a(viewGroup.getChildAt(childCount), keyEvent);
                        if (a2 != null) {
                            return a2;
                        }
                    }
                }
                if (b(view, keyEvent)) {
                    return view;
                }
            }
            return null;
        }

        public final boolean b(View view, KeyEvent keyEvent) {
            ArrayList arrayList = (ArrayList) view.getTag(2131362541);
            if (arrayList == null) {
                return false;
            }
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                if (((b) arrayList.get(size)).a(view, keyEvent)) {
                    return true;
                }
            }
            return false;
        }
    }

    static {
        new WeakHashMap();
    }

    public static void a(View view, b.a aVar) {
        b.h.k.a g2 = g(view);
        if (g2 == null) {
            g2 = new b.h.k.a();
        }
        t(view, g2);
        q(aVar.a(), view);
        j(view).add(aVar);
        m(view, 0);
    }

    public static t b(View view) {
        if (f1739b == null) {
            f1739b = new WeakHashMap<>();
        }
        t tVar = f1739b.get(view);
        if (tVar != null) {
            return tVar;
        }
        t tVar2 = new t(view);
        f1739b.put(view, tVar2);
        return tVar2;
    }

    public static void c(View view, int i2) {
        view.offsetLeftAndRight(i2);
        if (view.getVisibility() == 0) {
            float translationY = view.getTranslationY();
            view.setTranslationY(1.0f + translationY);
            view.setTranslationY(translationY);
            Object parent = view.getParent();
            if (parent instanceof View) {
                v((View) parent);
            }
        }
    }

    public static void d(View view, int i2) {
        view.offsetTopAndBottom(i2);
        if (view.getVisibility() == 0) {
            float translationY = view.getTranslationY();
            view.setTranslationY(1.0f + translationY);
            view.setTranslationY(translationY);
            Object parent = view.getParent();
            if (parent instanceof View) {
                v((View) parent);
            }
        }
    }

    public static x e(View view, x xVar) {
        WindowInsets h2 = xVar.h();
        if (h2 != null) {
            WindowInsets dispatchApplyWindowInsets = view.dispatchApplyWindowInsets(h2);
            if (!dispatchApplyWindowInsets.equals(h2)) {
                return x.j(dispatchApplyWindowInsets, view);
            }
        }
        return xVar;
    }

    public static boolean f(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        ArrayList<WeakReference<View>> arrayList = c.f1748d;
        c cVar = (c) view.getTag(2131362540);
        if (cVar == null) {
            cVar = new c();
            view.setTag(2131362540, cVar);
        }
        if (keyEvent.getAction() == 0) {
            Boolean bool = Boolean.TRUE;
            WeakHashMap<View, Boolean> weakHashMap = cVar.f1749a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            ArrayList<WeakReference<View>> arrayList2 = c.f1748d;
            if (!arrayList2.isEmpty()) {
                synchronized (arrayList2) {
                    if (cVar.f1749a == null) {
                        cVar.f1749a = new WeakHashMap<>();
                    }
                    int size = arrayList2.size();
                    while (true) {
                        size--;
                        if (size < 0) {
                            break;
                        }
                        ArrayList<WeakReference<View>> arrayList3 = c.f1748d;
                        View view2 = arrayList3.get(size).get();
                        if (view2 == null) {
                            arrayList3.remove(size);
                        } else {
                            cVar.f1749a.put(view2, bool);
                            for (ViewParent parent = view2.getParent(); parent instanceof View; parent = parent.getParent()) {
                                cVar.f1749a.put((View) parent, bool);
                            }
                        }
                    }
                }
            }
        }
        View a2 = cVar.a(view, keyEvent);
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (a2 != null && !KeyEvent.isModifierKey(keyCode)) {
                if (cVar.f1750b == null) {
                    cVar.f1750b = new SparseArray<>();
                }
                cVar.f1750b.put(keyCode, new WeakReference<>(a2));
            }
        }
        return a2 != null;
    }

    public static b.h.k.a g(View view) {
        View.AccessibilityDelegate h2 = h(view);
        if (h2 == null) {
            return null;
        }
        return h2 instanceof a.C0032a ? ((a.C0032a) h2).f1720a : new b.h.k.a(h2);
    }

    public static View.AccessibilityDelegate h(View view) {
        if (Build.VERSION.SDK_INT >= 29) {
            return view.getAccessibilityDelegate();
        }
        if (f1741d) {
            return null;
        }
        if (f1740c == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f1740c = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f1741d = true;
                return null;
            }
        }
        try {
            Object obj = f1740c.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f1741d = true;
            return null;
        }
    }

    public static CharSequence i(View view) {
        return new n(2131362533, CharSequence.class, 8, 28).c(view);
    }

    public static List<b.a> j(View view) {
        ArrayList arrayList = (ArrayList) view.getTag(2131362530);
        if (arrayList != null) {
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        view.setTag(2131362530, arrayList2);
        return arrayList2;
    }

    public static Rect k() {
        if (f1742e == null) {
            f1742e = new ThreadLocal<>();
        }
        Rect rect = f1742e.get();
        if (rect == null) {
            rect = new Rect();
            f1742e.set(rect);
        }
        rect.setEmpty();
        return rect;
    }

    public static x l(View view) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 23) {
            WindowInsets rootWindowInsets = view.getRootWindowInsets();
            if (rootWindowInsets == null) {
                return null;
            }
            x i3 = x.i(rootWindowInsets);
            i3.f1763a.m(i3);
            i3.f1763a.d(view.getRootView());
            return i3;
        }
        if (!x.a.f1767d || !view.isAttachedToWindow()) {
            return null;
        }
        try {
            Object obj = x.a.f1764a.get(view.getRootView());
            if (obj == null) {
                return null;
            }
            Rect rect = (Rect) x.a.f1765b.get(obj);
            Rect rect2 = (Rect) x.a.f1766c.get(obj);
            if (rect == null || rect2 == null) {
                return null;
            }
            x.e dVar = i2 >= 30 ? new x.d() : i2 >= 29 ? new x.c() : new x.b();
            dVar.b(b.h.e.b.a(rect.left, rect.top, rect.right, rect.bottom));
            dVar.c(b.h.e.b.a(rect2.left, rect2.top, rect2.right, rect2.bottom));
            x a2 = dVar.a();
            a2.f1763a.m(a2);
            a2.f1763a.d(view.getRootView());
            return a2;
        } catch (IllegalAccessException e2) {
            StringBuilder n = c.a.a.a.a.n("Failed to get insets from AttachInfo. ");
            n.append(e2.getMessage());
            Log.w("WindowInsetsCompat", n.toString(), e2);
            return null;
        }
    }

    public static void m(View view, int i2) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            boolean z = i(view) != null && view.getVisibility() == 0;
            if (view.getAccessibilityLiveRegion() != 0 || z) {
                AccessibilityEvent obtain = AccessibilityEvent.obtain();
                obtain.setEventType(z ? 32 : 2048);
                obtain.setContentChangeTypes(i2);
                if (z) {
                    obtain.getText().add(i(view));
                    if (view.getImportantForAccessibility() == 0) {
                        view.setImportantForAccessibility(1);
                    }
                    ViewParent parent = view.getParent();
                    while (true) {
                        if (!(parent instanceof View)) {
                            break;
                        }
                        if (((View) parent).getImportantForAccessibility() == 4) {
                            view.setImportantForAccessibility(2);
                            break;
                        }
                        parent = parent.getParent();
                    }
                }
                view.sendAccessibilityEventUnchecked(obtain);
                return;
            }
            if (i2 == 32) {
                AccessibilityEvent obtain2 = AccessibilityEvent.obtain();
                view.onInitializeAccessibilityEvent(obtain2);
                obtain2.setEventType(32);
                obtain2.setContentChangeTypes(i2);
                obtain2.setSource(view);
                view.onPopulateAccessibilityEvent(obtain2);
                obtain2.getText().add(i(view));
                accessibilityManager.sendAccessibilityEvent(obtain2);
                return;
            }
            if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i2);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewCompat", view.getParent().getClass().getSimpleName() + " does not fully implement ViewParent", e2);
                }
            }
        }
    }

    public static void n(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            view.offsetLeftAndRight(i2);
            return;
        }
        Rect k = k();
        boolean z = false;
        Object parent = view.getParent();
        if (parent instanceof View) {
            View view2 = (View) parent;
            k.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            z = !k.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        c(view, i2);
        if (z && k.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(k);
        }
    }

    public static void o(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            view.offsetTopAndBottom(i2);
            return;
        }
        Rect k = k();
        boolean z = false;
        Object parent = view.getParent();
        if (parent instanceof View) {
            View view2 = (View) parent;
            k.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            z = !k.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        d(view, i2);
        if (z && k.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(k);
        }
    }

    public static x p(View view, x xVar) {
        WindowInsets h2 = xVar.h();
        if (h2 != null) {
            WindowInsets onApplyWindowInsets = view.onApplyWindowInsets(h2);
            if (!onApplyWindowInsets.equals(h2)) {
                return x.j(onApplyWindowInsets, view);
            }
        }
        return xVar;
    }

    public static void q(int i2, View view) {
        List<b.a> j2 = j(view);
        for (int i3 = 0; i3 < j2.size(); i3++) {
            if (j2.get(i3).a() == i2) {
                j2.remove(i3);
                return;
            }
        }
    }

    public static void r(View view, b.a aVar, CharSequence charSequence, b.h.k.y.d dVar) {
        a(view, new b.a(null, aVar.f1800b, null, dVar, aVar.f1801c));
    }

    public static void s(@SuppressLint({"ContextFirst"}) View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 29) {
            view.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i2, i3);
        }
    }

    public static void t(View view, b.h.k.a aVar) {
        if (aVar == null && (h(view) instanceof a.C0032a)) {
            aVar = new b.h.k.a();
        }
        view.setAccessibilityDelegate(aVar == null ? null : aVar.f1719b);
    }

    public static void u(View view, j jVar) {
        if (Build.VERSION.SDK_INT < 30) {
            view.setTag(2131362534, jVar);
        }
        if (jVar == null) {
            view.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener) view.getTag(2131362542));
        } else {
            view.setOnApplyWindowInsetsListener(new r(view, jVar));
        }
    }

    public static void v(View view) {
        float translationY = view.getTranslationY();
        view.setTranslationY(1.0f + translationY);
        view.setTranslationY(translationY);
    }
}
