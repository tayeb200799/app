package b.h.k.y;

import android.view.View;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\y\d.smali */
public interface d {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\y\d$a.smali */
    public static abstract class a {
    }

    boolean a(View view, a aVar);
}
