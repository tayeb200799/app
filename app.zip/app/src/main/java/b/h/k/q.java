package b.h.k;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\r.smali */
public class r implements View.OnApplyWindowInsetsListener {

    /* renamed from: a, reason: collision with root package name */
    public x f1752a = null;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f1753b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ j f1754c;

    public r(View view, j jVar) {
        this.f1753b = view;
        this.f1754c = jVar;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        x j2 = x.j(windowInsets, view);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 30) {
            View view2 = this.f1753b;
            View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener) view2.getTag(2131362542);
            if (onApplyWindowInsetsListener != null) {
                onApplyWindowInsetsListener.onApplyWindowInsets(view2, windowInsets);
            }
            if (j2.equals(this.f1752a)) {
                return this.f1754c.a(view, j2).h();
            }
        }
        this.f1752a = j2;
        x a2 = this.f1754c.a(view, j2);
        if (i2 >= 30) {
            return a2.h();
        }
        AtomicInteger atomicInteger = q.f1738a;
        view.requestApplyInsets();
        return a2.h();
    }
}
