package b.h.k;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\k.smali */
public final class k implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* renamed from: d, reason: collision with root package name */
    public final View f1734d;

    /* renamed from: e, reason: collision with root package name */
    public ViewTreeObserver f1735e;

    /* renamed from: f, reason: collision with root package name */
    public final Runnable f1736f;

    public k(View view, Runnable runnable) {
        this.f1734d = view;
        this.f1735e = view.getViewTreeObserver();
        this.f1736f = runnable;
    }

    public static k a(View view, Runnable runnable) {
        Objects.requireNonNull(view, "view == null");
        k kVar = new k(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(kVar);
        view.addOnAttachStateChangeListener(kVar);
        return kVar;
    }

    public void b() {
        if (this.f1735e.isAlive()) {
            this.f1735e.removeOnPreDrawListener(this);
        } else {
            this.f1734d.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        this.f1734d.removeOnAttachStateChangeListener(this);
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public boolean onPreDraw() {
        b();
        this.f1736f.run();
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
        this.f1735e = view.getViewTreeObserver();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        b();
    }
}
