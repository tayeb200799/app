package b.h.k;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x.smali */
public class x {

    /* renamed from: b, reason: collision with root package name */
    public static final x f1765b;

    /* renamed from: a, reason: collision with root package name */
    public final k f1766a;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public static Field f1767a;

        /* renamed from: b, reason: collision with root package name */
        public static Field f1768b;

        /* renamed from: c, reason: collision with root package name */
        public static Field f1769c;

        /* renamed from: d, reason: collision with root package name */
        public static boolean f1770d;

        static {
            try {
                Field declaredField = View.class.getDeclaredField("mAttachInfo");
                f1767a = declaredField;
                declaredField.setAccessible(true);
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                Field declaredField2 = cls.getDeclaredField("mStableInsets");
                f1768b = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = cls.getDeclaredField("mContentInsets");
                f1769c = declaredField3;
                declaredField3.setAccessible(true);
                f1770d = true;
            } catch (ReflectiveOperationException e2) {
                StringBuilder n = c.a.a.a.a.n("Failed to get visible insets from AttachInfo ");
                n.append(e2.getMessage());
                Log.w("WindowInsetsCompat", n.toString(), e2);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$b.smali */
    public static class b extends e {

        /* renamed from: d, reason: collision with root package name */
        public static Field f1771d;

        /* renamed from: e, reason: collision with root package name */
        public static boolean f1772e;

        /* renamed from: f, reason: collision with root package name */
        public static Constructor<WindowInsets> f1773f;

        /* renamed from: g, reason: collision with root package name */
        public static boolean f1774g;

        /* renamed from: b, reason: collision with root package name */
        public WindowInsets f1775b;

        /* renamed from: c, reason: collision with root package name */
        public b.h.e.b f1776c;

        public b() {
            WindowInsets windowInsets;
            if (!f1772e) {
                try {
                    f1771d = WindowInsets.class.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
                }
                f1772e = true;
            }
            Field field = f1771d;
            WindowInsets windowInsets2 = null;
            if (field != null) {
                try {
                    windowInsets = (WindowInsets) field.get(null);
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
                }
                if (windowInsets != null) {
                    windowInsets2 = new WindowInsets(windowInsets);
                    this.f1775b = windowInsets2;
                }
            }
            if (!f1774g) {
                try {
                    f1773f = WindowInsets.class.getConstructor(Rect.class);
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
                }
                f1774g = true;
            }
            Constructor<WindowInsets> constructor = f1773f;
            if (constructor != null) {
                try {
                    windowInsets2 = constructor.newInstance(new Rect());
                } catch (ReflectiveOperationException e5) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
                }
            }
            this.f1775b = windowInsets2;
        }

        public b(x xVar) {
            super(xVar);
            this.f1775b = xVar.h();
        }

        @Override // b.h.k.x.e
        public x a() {
            x i2 = x.i(this.f1775b);
            i2.f1766a.l(null);
            i2.f1766a.n(this.f1776c);
            return i2;
        }

        @Override // b.h.k.x.e
        public void b(b.h.e.b bVar) {
            this.f1776c = bVar;
        }

        @Override // b.h.k.x.e
        public void c(b.h.e.b bVar) {
            WindowInsets windowInsets = this.f1775b;
            if (windowInsets != null) {
                this.f1775b = windowInsets.replaceSystemWindowInsets(bVar.f1604a, bVar.f1605b, bVar.f1606c, bVar.f1607d);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$c.smali */
    public static class c extends e {

        /* renamed from: b, reason: collision with root package name */
        public final WindowInsets.Builder f1777b;

        public c() {
            this.f1777b = new WindowInsets.Builder();
        }

        public c(x xVar) {
            super(xVar);
            WindowInsets h2 = xVar.h();
            this.f1777b = h2 != null ? new WindowInsets.Builder(h2) : new WindowInsets.Builder();
        }

        @Override // b.h.k.x.e
        public x a() {
            x i2 = x.i(this.f1777b.build());
            i2.f1766a.l(null);
            return i2;
        }

        @Override // b.h.k.x.e
        public void b(b.h.e.b bVar) {
            this.f1777b.setStableInsets(bVar.c());
        }

        @Override // b.h.k.x.e
        public void c(b.h.e.b bVar) {
            this.f1777b.setSystemWindowInsets(bVar.c());
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$d.smali */
    public static class d extends c {
        public d() {
        }

        public d(x xVar) {
            super(xVar);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$e.smali */
    public static class e {

        /* renamed from: a, reason: collision with root package name */
        public final x f1778a;

        public e() {
            this.f1778a = new x((x) null);
        }

        public e(x xVar) {
            this.f1778a = xVar;
        }

        public x a() {
            throw null;
        }

        public void b(b.h.e.b bVar) {
            throw null;
        }

        public void c(b.h.e.b bVar) {
            throw null;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$f.smali */
    public static class f extends k {

        /* renamed from: h, reason: collision with root package name */
        public static boolean f1779h;

        /* renamed from: i, reason: collision with root package name */
        public static Method f1780i;

        /* renamed from: j, reason: collision with root package name */
        public static Class<?> f1781j;
        public static Class<?> k;
        public static Field l;
        public static Field m;

        /* renamed from: c, reason: collision with root package name */
        public final WindowInsets f1782c;

        /* renamed from: d, reason: collision with root package name */
        public b.h.e.b[] f1783d;

        /* renamed from: e, reason: collision with root package name */
        public b.h.e.b f1784e;

        /* renamed from: f, reason: collision with root package name */
        public x f1785f;

        /* renamed from: g, reason: collision with root package name */
        public b.h.e.b f1786g;

        public f(x xVar, WindowInsets windowInsets) {
            super(xVar);
            this.f1784e = null;
            this.f1782c = windowInsets;
        }

        @Override // b.h.k.x.k
        public void d(View view) {
            if (Build.VERSION.SDK_INT >= 30) {
                throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
            }
            if (!f1779h) {
                try {
                    f1780i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
                    f1781j = Class.forName("android.view.ViewRootImpl");
                    Class<?> cls = Class.forName("android.view.View$AttachInfo");
                    k = cls;
                    l = cls.getDeclaredField("mVisibleInsets");
                    m = f1781j.getDeclaredField("mAttachInfo");
                    l.setAccessible(true);
                    m.setAccessible(true);
                } catch (ReflectiveOperationException e2) {
                    StringBuilder n = c.a.a.a.a.n("Failed to get visible insets. (Reflection error). ");
                    n.append(e2.getMessage());
                    Log.e("WindowInsetsCompat", n.toString(), e2);
                }
                f1779h = true;
            }
            Method method = f1780i;
            b.h.e.b bVar = null;
            if (method != null && k != null && l != null) {
                try {
                    Object invoke = method.invoke(view, new Object[0]);
                    if (invoke == null) {
                        Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                    } else {
                        Rect rect = (Rect) l.get(m.get(invoke));
                        if (rect != null) {
                            bVar = b.h.e.b.a(rect.left, rect.top, rect.right, rect.bottom);
                        }
                    }
                } catch (ReflectiveOperationException e3) {
                    StringBuilder n2 = c.a.a.a.a.n("Failed to get visible insets. (Reflection error). ");
                    n2.append(e3.getMessage());
                    Log.e("WindowInsetsCompat", n2.toString(), e3);
                }
            }
            if (bVar == null) {
                bVar = b.h.e.b.f1603e;
            }
            this.f1786g = bVar;
        }

        @Override // b.h.k.x.k
        public boolean equals(Object obj) {
            if (super.equals(obj)) {
                return Objects.equals(this.f1786g, ((f) obj).f1786g);
            }
            return false;
        }

        @Override // b.h.k.x.k
        public final b.h.e.b h() {
            if (this.f1784e == null) {
                this.f1784e = b.h.e.b.a(this.f1782c.getSystemWindowInsetLeft(), this.f1782c.getSystemWindowInsetTop(), this.f1782c.getSystemWindowInsetRight(), this.f1782c.getSystemWindowInsetBottom());
            }
            return this.f1784e;
        }

        @Override // b.h.k.x.k
        public x i(int i2, int i3, int i4, int i5) {
            x i6 = x.i(this.f1782c);
            int i7 = Build.VERSION.SDK_INT;
            e dVar = i7 >= 30 ? new d(i6) : i7 >= 29 ? new c(i6) : new b(i6);
            dVar.c(x.e(h(), i2, i3, i4, i5));
            dVar.b(x.e(g(), i2, i3, i4, i5));
            return dVar.a();
        }

        @Override // b.h.k.x.k
        public boolean k() {
            return this.f1782c.isRound();
        }

        @Override // b.h.k.x.k
        public void l(b.h.e.b[] bVarArr) {
            this.f1783d = bVarArr;
        }

        @Override // b.h.k.x.k
        public void m(x xVar) {
            this.f1785f = xVar;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$g.smali */
    public static class g extends f {
        public b.h.e.b n;

        public g(x xVar, WindowInsets windowInsets) {
            super(xVar, windowInsets);
            this.n = null;
        }

        @Override // b.h.k.x.k
        public x b() {
            return x.i(this.f1782c.consumeStableInsets());
        }

        @Override // b.h.k.x.k
        public x c() {
            return x.i(this.f1782c.consumeSystemWindowInsets());
        }

        @Override // b.h.k.x.k
        public final b.h.e.b g() {
            if (this.n == null) {
                this.n = b.h.e.b.a(this.f1782c.getStableInsetLeft(), this.f1782c.getStableInsetTop(), this.f1782c.getStableInsetRight(), this.f1782c.getStableInsetBottom());
            }
            return this.n;
        }

        @Override // b.h.k.x.k
        public boolean j() {
            return this.f1782c.isConsumed();
        }

        @Override // b.h.k.x.k
        public void n(b.h.e.b bVar) {
            this.n = bVar;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$h.smali */
    public static class h extends g {
        public h(x xVar, WindowInsets windowInsets) {
            super(xVar, windowInsets);
        }

        @Override // b.h.k.x.k
        public x a() {
            return x.i(this.f1782c.consumeDisplayCutout());
        }

        @Override // b.h.k.x.k
        public b.h.k.c e() {
            DisplayCutout displayCutout = this.f1782c.getDisplayCutout();
            if (displayCutout == null) {
                return null;
            }
            return new b.h.k.c(displayCutout);
        }

        @Override // b.h.k.x.f, b.h.k.x.k
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof h)) {
                return false;
            }
            h hVar = (h) obj;
            return Objects.equals(this.f1782c, hVar.f1782c) && Objects.equals(this.f1786g, hVar.f1786g);
        }

        @Override // b.h.k.x.k
        public int hashCode() {
            return this.f1782c.hashCode();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$i.smali */
    public static class i extends h {
        public b.h.e.b o;
        public b.h.e.b p;
        public b.h.e.b q;

        public i(x xVar, WindowInsets windowInsets) {
            super(xVar, windowInsets);
            this.o = null;
            this.p = null;
            this.q = null;
        }

        @Override // b.h.k.x.k
        public b.h.e.b f() {
            if (this.p == null) {
                this.p = b.h.e.b.b(this.f1782c.getMandatorySystemGestureInsets());
            }
            return this.p;
        }

        @Override // b.h.k.x.f, b.h.k.x.k
        public x i(int i2, int i3, int i4, int i5) {
            return x.i(this.f1782c.inset(i2, i3, i4, i5));
        }

        @Override // b.h.k.x.g, b.h.k.x.k
        public void n(b.h.e.b bVar) {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$j.smali */
    public static class j extends i {
        public static final x r = x.i(WindowInsets.CONSUMED);

        public j(x xVar, WindowInsets windowInsets) {
            super(xVar, windowInsets);
        }

        @Override // b.h.k.x.f, b.h.k.x.k
        public final void d(View view) {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\x$k.smali */
    public static class k {

        /* renamed from: b, reason: collision with root package name */
        public static final x f1787b;

        /* renamed from: a, reason: collision with root package name */
        public final x f1788a;

        static {
            int i2 = Build.VERSION.SDK_INT;
            f1787b = (i2 >= 30 ? new d() : i2 >= 29 ? new c() : new b()).a().f1766a.a().f1766a.b().f1766a.c();
        }

        public k(x xVar) {
            this.f1788a = xVar;
        }

        public x a() {
            return this.f1788a;
        }

        public x b() {
            return this.f1788a;
        }

        public x c() {
            return this.f1788a;
        }

        public void d(View view) {
        }

        public b.h.k.c e() {
            return null;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof k)) {
                return false;
            }
            k kVar = (k) obj;
            return k() == kVar.k() && j() == kVar.j() && Objects.equals(h(), kVar.h()) && Objects.equals(g(), kVar.g()) && Objects.equals(e(), kVar.e());
        }

        public b.h.e.b f() {
            return h();
        }

        public b.h.e.b g() {
            return b.h.e.b.f1603e;
        }

        public b.h.e.b h() {
            return b.h.e.b.f1603e;
        }

        public int hashCode() {
            return Objects.hash(Boolean.valueOf(k()), Boolean.valueOf(j()), h(), g(), e());
        }

        public x i(int i2, int i3, int i4, int i5) {
            return f1787b;
        }

        public boolean j() {
            return false;
        }

        public boolean k() {
            return false;
        }

        public void l(b.h.e.b[] bVarArr) {
        }

        public void m(x xVar) {
        }

        public void n(b.h.e.b bVar) {
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 30) {
            f1765b = j.r;
        } else {
            f1765b = k.f1787b;
        }
    }

    public x(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            this.f1766a = new j(this, windowInsets);
            return;
        }
        if (i2 >= 29) {
            this.f1766a = new i(this, windowInsets);
        } else if (i2 >= 28) {
            this.f1766a = new h(this, windowInsets);
        } else {
            this.f1766a = new g(this, windowInsets);
        }
    }

    public x(x xVar) {
        this.f1766a = new k(this);
    }

    public static b.h.e.b e(b.h.e.b bVar, int i2, int i3, int i4, int i5) {
        int max = Math.max(0, bVar.f1604a - i2);
        int max2 = Math.max(0, bVar.f1605b - i3);
        int max3 = Math.max(0, bVar.f1606c - i4);
        int max4 = Math.max(0, bVar.f1607d - i5);
        return (max == i2 && max2 == i3 && max3 == i4 && max4 == i5) ? bVar : b.h.e.b.a(max, max2, max3, max4);
    }

    public static x i(WindowInsets windowInsets) {
        return j(windowInsets, null);
    }

    public static x j(WindowInsets windowInsets, View view) {
        Objects.requireNonNull(windowInsets);
        x xVar = new x(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            xVar.f1766a.m(q.l(view));
            xVar.f1766a.d(view.getRootView());
        }
        return xVar;
    }

    @Deprecated
    public int a() {
        return this.f1766a.h().f1607d;
    }

    @Deprecated
    public int b() {
        return this.f1766a.h().f1604a;
    }

    @Deprecated
    public int c() {
        return this.f1766a.h().f1606c;
    }

    @Deprecated
    public int d() {
        return this.f1766a.h().f1605b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof x) {
            return Objects.equals(this.f1766a, ((x) obj).f1766a);
        }
        return false;
    }

    public boolean f() {
        return this.f1766a.j();
    }

    @Deprecated
    public x g(int i2, int i3, int i4, int i5) {
        int i6 = Build.VERSION.SDK_INT;
        e dVar = i6 >= 30 ? new d(this) : i6 >= 29 ? new c(this) : new b(this);
        dVar.c(b.h.e.b.a(i2, i3, i4, i5));
        return dVar.a();
    }

    public WindowInsets h() {
        k kVar = this.f1766a;
        if (kVar instanceof f) {
            return ((f) kVar).f1782c;
        }
        return null;
    }

    public int hashCode() {
        k kVar = this.f1766a;
        if (kVar == null) {
            return 0;
        }
        return kVar.hashCode();
    }
}
