package b.h.k;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\l.smali */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    public Object f1737a;

    public l(Object obj) {
        this.f1737a = obj;
    }
}
