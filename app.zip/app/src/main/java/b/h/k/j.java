package b.h.k;

import android.view.View;
import b.h.k.q;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\n.smali */
public class n extends q.a<CharSequence> {
    public n(int i2, Class cls, int i3, int i4) {
        super(i2, cls, i3, i4);
    }

    @Override // b.h.k.q.a
    public CharSequence b(View view) {
        return view.getAccessibilityPaneTitle();
    }
}
