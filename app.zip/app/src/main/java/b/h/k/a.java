package b.h.k;

import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\c.smali */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final Object f1722a;

    public c(Object obj) {
        this.f1722a = obj;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f1722a, ((c) obj).f1722a);
    }

    public int hashCode() {
        Object obj = this.f1722a;
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }

    public String toString() {
        StringBuilder n = c.a.a.a.a.n("DisplayCutoutCompat{");
        n.append(this.f1722a);
        n.append("}");
        return n.toString();
    }
}
