package b.h.k;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\i.smali */
public class i {

    /* renamed from: a, reason: collision with root package name */
    public int f1732a;

    /* renamed from: b, reason: collision with root package name */
    public int f1733b;

    public int a() {
        return this.f1732a | this.f1733b;
    }

    public void b(int i2) {
        if (i2 == 1) {
            this.f1733b = 0;
        } else {
            this.f1732a = 0;
        }
    }
}
