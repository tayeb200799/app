package b.h.d.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\e.smali */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final String f1577a;

    /* renamed from: b, reason: collision with root package name */
    public int f1578b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1579c;

    /* renamed from: d, reason: collision with root package name */
    public String f1580d;

    /* renamed from: e, reason: collision with root package name */
    public int f1581e;

    /* renamed from: f, reason: collision with root package name */
    public int f1582f;

    public e(String str, int i2, boolean z, String str2, int i3, int i4) {
        this.f1577a = str;
        this.f1578b = i2;
        this.f1579c = z;
        this.f1580d = str2;
        this.f1581e = i3;
        this.f1582f = i4;
    }
}
