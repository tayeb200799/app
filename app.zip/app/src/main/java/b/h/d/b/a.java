package b.h.d.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\e.smali */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final String f1574a;

    /* renamed from: b, reason: collision with root package name */
    public int f1575b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1576c;

    /* renamed from: d, reason: collision with root package name */
    public String f1577d;

    /* renamed from: e, reason: collision with root package name */
    public int f1578e;

    /* renamed from: f, reason: collision with root package name */
    public int f1579f;

    public e(String str, int i2, boolean z, String str2, int i3, int i4) {
        this.f1574a = str;
        this.f1575b = i2;
        this.f1576c = z;
        this.f1577d = str2;
        this.f1578e = i3;
        this.f1579f = i4;
    }
}
