package b.h.e;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.util.Log;
import b.h.d.b.h;
import b.h.h.m;
import java.lang.reflect.Method;

@SuppressLint({"NewApi"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\d.smali */
public class d {

    /* renamed from: a, reason: collision with root package name */
    public static final k f1607a;

    /* renamed from: b, reason: collision with root package name */
    public static final b.e.f<String, Typeface> f1608b;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\d$a.smali */
    public static class a extends m {

        /* renamed from: a, reason: collision with root package name */
        public h.c f1609a;

        public a(h.c cVar) {
            this.f1609a = cVar;
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 29) {
            f1607a = new i();
        } else if (i2 >= 28) {
            f1607a = new h();
        } else if (i2 >= 26) {
            f1607a = new g();
        } else {
            if (i2 >= 24) {
                Method method = f.f1617d;
                if (method == null) {
                    Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
                }
                if (method != null) {
                    f1607a = new f();
                }
            }
            f1607a = new e();
        }
        f1608b = new b.e.f<>(16);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0024, code lost:
    
        if (r0.equals(r4) == false) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static android.graphics.Typeface a(android.content.Context r5, b.h.d.b.c r6, android.content.res.Resources r7, int r8, int r9, b.h.d.b.h.c r10, android.os.Handler r11, boolean r12) {
        /*
            Method dump skipped, instructions count: 362
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.e.d.a(android.content.Context, b.h.d.b.c, android.content.res.Resources, int, int, b.h.d.b.h$c, android.os.Handler, boolean):android.graphics.Typeface");
    }

    public static Typeface b(Context context, Resources resources, int i2, String str, int i3) {
        Typeface d2 = f1607a.d(context, resources, i2, str, i3);
        if (d2 != null) {
            f1608b.b(c(resources, i2, i3), d2);
        }
        return d2;
    }

    public static String c(Resources resources, int i2, int i3) {
        return resources.getResourcePackageName(i2) + "-" + i2 + "-" + i3;
    }
}
