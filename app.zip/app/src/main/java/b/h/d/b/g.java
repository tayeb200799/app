package b.h.d.b;

import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\g.smali */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final int[] f1587a;

    /* renamed from: b, reason: collision with root package name */
    public final float[] f1588b;

    public g(int i2, int i3) {
        this.f1587a = new int[]{i2, i3};
        this.f1588b = new float[]{0.0f, 1.0f};
    }

    public g(int i2, int i3, int i4) {
        this.f1587a = new int[]{i2, i3, i4};
        this.f1588b = new float[]{0.0f, 0.5f, 1.0f};
    }

    public g(List<Integer> list, List<Float> list2) {
        int size = list.size();
        this.f1587a = new int[size];
        this.f1588b = new float[size];
        for (int i2 = 0; i2 < size; i2++) {
            this.f1587a[i2] = list.get(i2).intValue();
            this.f1588b[i2] = list2.get(i2).floatValue();
        }
    }
}
