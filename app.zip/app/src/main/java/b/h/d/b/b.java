package b.h.d.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\f.smali */
public final class f implements c {

    /* renamed from: a, reason: collision with root package name */
    public final b.h.h.e f1580a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1581b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1582c;

    /* renamed from: d, reason: collision with root package name */
    public final String f1583d;

    public f(b.h.h.e eVar, int i2, int i3, String str) {
        this.f1580a = eVar;
        this.f1582c = i2;
        this.f1581b = i3;
        this.f1583d = str;
    }
}
