package b.h.d.b;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.Objects;
import java.util.WeakHashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\h.smali */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public static final ThreadLocal<TypedValue> f1589a = new ThreadLocal<>();

    /* renamed from: b, reason: collision with root package name */
    public static final WeakHashMap<b, SparseArray<a>> f1590b = new WeakHashMap<>(0);

    /* renamed from: c, reason: collision with root package name */
    public static final Object f1591c = new Object();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\h$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final ColorStateList f1592a;

        /* renamed from: b, reason: collision with root package name */
        public final Configuration f1593b;

        public a(ColorStateList colorStateList, Configuration configuration) {
            this.f1592a = colorStateList;
            this.f1593b = configuration;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\h$b.smali */
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public final Resources f1594a;

        /* renamed from: b, reason: collision with root package name */
        public final Resources.Theme f1595b;

        public b(Resources resources, Resources.Theme theme) {
            this.f1594a = resources;
            this.f1595b = theme;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || b.class != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            return this.f1594a.equals(bVar.f1594a) && Objects.equals(this.f1595b, bVar.f1595b);
        }

        public int hashCode() {
            return Objects.hash(this.f1594a, this.f1595b);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\h$c.smali */
    public static abstract class c {

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\h$c$a.smali */
        public class a implements Runnable {

            /* renamed from: d, reason: collision with root package name */
            public final /* synthetic */ Typeface f1596d;

            public a(Typeface typeface) {
                this.f1596d = typeface;
            }

            @Override // java.lang.Runnable
            public void run() {
                c.this.e(this.f1596d);
            }
        }

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\d\b\h$c$b.smali */
        public class b implements Runnable {

            /* renamed from: d, reason: collision with root package name */
            public final /* synthetic */ int f1598d;

            public b(int i2) {
                this.f1598d = i2;
            }

            @Override // java.lang.Runnable
            public void run() {
                c.this.d(this.f1598d);
            }
        }

        public static Handler c(Handler handler) {
            return handler == null ? new Handler(Looper.getMainLooper()) : handler;
        }

        public final void a(int i2, Handler handler) {
            c(handler).post(new b(i2));
        }

        public final void b(Typeface typeface, Handler handler) {
            c(handler).post(new a(typeface));
        }

        public abstract void d(int i2);

        public abstract void e(Typeface typeface);
    }

    public static Typeface a(Context context, int i2) {
        if (context.isRestricted()) {
            return null;
        }
        return b(context, i2, new TypedValue(), 0, null, null, false, false);
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x00bd A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static android.graphics.Typeface b(android.content.Context r16, int r17, android.util.TypedValue r18, int r19, b.h.d.b.h.c r20, android.os.Handler r21, boolean r22, boolean r23) {
        /*
            Method dump skipped, instructions count: 266
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.b.h.b(android.content.Context, int, android.util.TypedValue, int, b.h.d.b.h$c, android.os.Handler, boolean, boolean):android.graphics.Typeface");
    }
}
