package b.h.h;

import android.graphics.Typeface;
import b.h.d.b.h;
import b.h.e.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\a.smali */
public class a implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ m f1644d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Typeface f1645e;

    public a(c cVar, m mVar, Typeface typeface) {
        this.f1644d = mVar;
        this.f1645e = typeface;
    }

    @Override // java.lang.Runnable
    public void run() {
        m mVar = this.f1644d;
        Typeface typeface = this.f1645e;
        h.c cVar = ((d.a) mVar).f1609a;
        if (cVar != null) {
            cVar.e(typeface);
        }
    }
}
