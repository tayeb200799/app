package b.h.h;

import java.util.Comparator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\d.smali */
public class d {

    /* renamed from: a, reason: collision with root package name */
    public static final Comparator<byte[]> f1650a = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\d$a.smali */
    public class a implements Comparator<byte[]> {
        @Override // java.util.Comparator
        public int compare(byte[] bArr, byte[] bArr2) {
            int i2;
            int i3;
            byte[] bArr3 = bArr;
            byte[] bArr4 = bArr2;
            if (bArr3.length == bArr4.length) {
                for (int i4 = 0; i4 < bArr3.length; i4++) {
                    if (bArr3[i4] != bArr4[i4]) {
                        i2 = bArr3[i4];
                        i3 = bArr4[i4];
                    }
                }
                return 0;
            }
            i2 = bArr3.length;
            i3 = bArr4.length;
            return i2 - i3;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x008e A[LOOP:1: B:14:0x004b->B:28:0x008e, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0092 A[EDGE_INSN: B:29:0x0092->B:30:0x0092 BREAK  A[LOOP:1: B:14:0x004b->B:28:0x008e], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static b.h.h.k a(android.content.Context r20, b.h.h.e r21, android.os.CancellationSignal r22) {
        /*
            Method dump skipped, instructions count: 450
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.h.d.a(android.content.Context, b.h.h.e, android.os.CancellationSignal):b.h.h.k");
    }
}
