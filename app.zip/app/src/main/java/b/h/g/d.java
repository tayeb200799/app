package b.h.h;

import b.h.d.b.h;
import b.h.e.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\b.smali */
public class b implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ m f1646d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1647e;

    public b(c cVar, m mVar, int i2) {
        this.f1646d = mVar;
        this.f1647e = i2;
    }

    @Override // java.lang.Runnable
    public void run() {
        m mVar = this.f1646d;
        int i2 = this.f1647e;
        h.c cVar = ((d.a) mVar).f1609a;
        if (cVar != null) {
            cVar.d(i2);
        }
    }
}
