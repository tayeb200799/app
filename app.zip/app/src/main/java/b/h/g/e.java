package b.h.h;

import android.os.Handler;
import b.h.h.j;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\h\c.smali */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public final m f1648a;

    /* renamed from: b, reason: collision with root package name */
    public final Handler f1649b;

    public c(m mVar, Handler handler) {
        this.f1648a = mVar;
        this.f1649b = handler;
    }

    public void a(j.a aVar) {
        int i2 = aVar.f1671b;
        if (!(i2 == 0)) {
            this.f1649b.post(new b(this, this.f1648a, i2));
        } else {
            this.f1649b.post(new a(this, this.f1648a, aVar.f1670a));
        }
    }
}
