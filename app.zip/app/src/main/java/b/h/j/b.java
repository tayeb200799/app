package b.h.j;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\j\f.smali */
public class f<T> extends e<T> {

    /* renamed from: c, reason: collision with root package name */
    public final Object f1716c;

    public f(int i2) {
        super(i2);
        this.f1716c = new Object();
    }

    @Override // b.h.j.e, b.h.j.d
    public boolean a(T t) {
        boolean a2;
        synchronized (this.f1716c) {
            a2 = super.a(t);
        }
        return a2;
    }

    @Override // b.h.j.e, b.h.j.d
    public T b() {
        T t;
        synchronized (this.f1716c) {
            t = (T) super.b();
        }
        return t;
    }
}
