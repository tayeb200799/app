package b.h.k;

import android.os.Build;
import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import b.h.k.y.b;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\a.smali */
public class a {

    /* renamed from: c, reason: collision with root package name */
    public static final View.AccessibilityDelegate f1717c = new View.AccessibilityDelegate();

    /* renamed from: a, reason: collision with root package name */
    public final View.AccessibilityDelegate f1718a;

    /* renamed from: b, reason: collision with root package name */
    public final View.AccessibilityDelegate f1719b;

    /* renamed from: b.h.k.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\k\a$a.smali */
    public static final class C0032a extends View.AccessibilityDelegate {

        /* renamed from: a, reason: collision with root package name */
        public final a f1720a;

        public C0032a(a aVar) {
            this.f1720a = aVar;
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.f1720a.a(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            b.h.k.y.c b2 = this.f1720a.b(view);
            if (b2 != null) {
                return (AccessibilityNodeProvider) b2.f1805a;
            }
            return null;
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f1720a.c(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            int i2;
            b.h.k.y.b bVar = new b.h.k.y.b(accessibilityNodeInfo);
            AtomicInteger atomicInteger = q.f1738a;
            Boolean c2 = new m(2131362537, Boolean.class, 28).c(view);
            boolean booleanValue = c2 == null ? false : c2.booleanValue();
            int i3 = Build.VERSION.SDK_INT;
            if (i3 >= 28) {
                bVar.f1790a.setScreenReaderFocusable(booleanValue);
            } else {
                bVar.h(1, booleanValue);
            }
            Boolean c3 = new p(2131362532, Boolean.class, 28).c(view);
            boolean booleanValue2 = c3 == null ? false : c3.booleanValue();
            if (i3 >= 28) {
                bVar.f1790a.setHeading(booleanValue2);
            } else {
                bVar.h(2, booleanValue2);
            }
            CharSequence i4 = q.i(view);
            if (i3 >= 28) {
                bVar.f1790a.setPaneTitle(i4);
            } else {
                bVar.f1790a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY", i4);
            }
            CharSequence c4 = new o(2131362538, CharSequence.class, 64, 30).c(view);
            if (i3 >= 30) {
                bVar.f1790a.setStateDescription(c4);
            } else {
                bVar.f1790a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY", c4);
            }
            this.f1720a.d(view, bVar);
            CharSequence text = accessibilityNodeInfo.getText();
            if (i3 < 26) {
                bVar.f1790a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
                bVar.f1790a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
                bVar.f1790a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
                bVar.f1790a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
                SparseArray sparseArray = (SparseArray) view.getTag(2131362531);
                if (sparseArray != null) {
                    ArrayList arrayList = new ArrayList();
                    for (int i5 = 0; i5 < sparseArray.size(); i5++) {
                        if (((WeakReference) sparseArray.valueAt(i5)).get() == null) {
                            arrayList.add(Integer.valueOf(i5));
                        }
                    }
                    for (int i6 = 0; i6 < arrayList.size(); i6++) {
                        sparseArray.remove(((Integer) arrayList.get(i6)).intValue());
                    }
                }
                ClickableSpan[] d2 = b.h.k.y.b.d(text);
                if (d2 != null && d2.length > 0) {
                    bVar.f().putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY", 2131361807);
                    SparseArray sparseArray2 = (SparseArray) view.getTag(2131362531);
                    if (sparseArray2 == null) {
                        sparseArray2 = new SparseArray();
                        view.setTag(2131362531, sparseArray2);
                    }
                    for (int i7 = 0; i7 < d2.length; i7++) {
                        ClickableSpan clickableSpan = d2[i7];
                        int i8 = 0;
                        while (true) {
                            if (i8 >= sparseArray2.size()) {
                                i2 = b.h.k.y.b.f1789d;
                                b.h.k.y.b.f1789d = i2 + 1;
                                break;
                            } else {
                                if (clickableSpan.equals((ClickableSpan) ((WeakReference) sparseArray2.valueAt(i8)).get())) {
                                    i2 = sparseArray2.keyAt(i8);
                                    break;
                                }
                                i8++;
                            }
                        }
                        sparseArray2.put(i2, new WeakReference(d2[i7]));
                        ClickableSpan clickableSpan2 = d2[i7];
                        Spanned spanned = (Spanned) text;
                        bVar.b("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").add(Integer.valueOf(spanned.getSpanStart(clickableSpan2)));
                        bVar.b("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY").add(Integer.valueOf(spanned.getSpanEnd(clickableSpan2)));
                        bVar.b("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY").add(Integer.valueOf(spanned.getSpanFlags(clickableSpan2)));
                        bVar.b("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY").add(Integer.valueOf(i2));
                    }
                }
            }
            List list = (List) view.getTag(2131362530);
            if (list == null) {
                list = Collections.emptyList();
            }
            for (int i9 = 0; i9 < list.size(); i9++) {
                bVar.a((b.a) list.get(i9));
            }
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f1720a.e(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.f1720a.f(viewGroup, view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean performAccessibilityAction(View view, int i2, Bundle bundle) {
            return this.f1720a.g(view, i2, bundle);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEvent(View view, int i2) {
            this.f1720a.h(view, i2);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.f1720a.i(view, accessibilityEvent);
        }
    }

    public a() {
        this.f1718a = f1717c;
        this.f1719b = new C0032a(this);
    }

    public a(View.AccessibilityDelegate accessibilityDelegate) {
        this.f1718a = accessibilityDelegate;
        this.f1719b = new C0032a(this);
    }

    public boolean a(View view, AccessibilityEvent accessibilityEvent) {
        return this.f1718a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public b.h.k.y.c b(View view) {
        AccessibilityNodeProvider accessibilityNodeProvider = this.f1718a.getAccessibilityNodeProvider(view);
        if (accessibilityNodeProvider != null) {
            return new b.h.k.y.c(accessibilityNodeProvider);
        }
        return null;
    }

    public void c(View view, AccessibilityEvent accessibilityEvent) {
        this.f1718a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void d(View view, b.h.k.y.b bVar) {
        this.f1718a.onInitializeAccessibilityNodeInfo(view, bVar.f1790a);
    }

    public void e(View view, AccessibilityEvent accessibilityEvent) {
        this.f1718a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean f(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f1718a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0073  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean g(android.view.View r9, int r10, android.os.Bundle r11) {
        /*
            r8 = this;
            r0 = 2131362530(0x7f0a02e2, float:1.8344843E38)
            java.lang.Object r0 = r9.getTag(r0)
            java.util.List r0 = (java.util.List) r0
            if (r0 != 0) goto Lf
            java.util.List r0 = java.util.Collections.emptyList()
        Lf:
            r1 = 0
            r2 = 0
        L11:
            int r3 = r0.size()
            if (r2 >= r3) goto L70
            java.lang.Object r3 = r0.get(r2)
            b.h.k.y.b$a r3 = (b.h.k.y.b.a) r3
            int r4 = r3.a()
            if (r4 != r10) goto L6d
            b.h.k.y.d r0 = r3.f1802d
            if (r0 == 0) goto L70
            r0 = 0
            java.lang.Class<? extends b.h.k.y.d$a> r2 = r3.f1801c
            if (r2 == 0) goto L66
            java.lang.Class[] r4 = new java.lang.Class[r1]     // Catch: java.lang.Exception -> L40
            java.lang.reflect.Constructor r2 = r2.getDeclaredConstructor(r4)     // Catch: java.lang.Exception -> L40
            java.lang.Object[] r4 = new java.lang.Object[r1]     // Catch: java.lang.Exception -> L40
            java.lang.Object r2 = r2.newInstance(r4)     // Catch: java.lang.Exception -> L40
            b.h.k.y.d$a r2 = (b.h.k.y.d.a) r2     // Catch: java.lang.Exception -> L40
            java.util.Objects.requireNonNull(r2)     // Catch: java.lang.Exception -> L3e
            goto L65
        L3e:
            r0 = move-exception
            goto L44
        L40:
            r2 = move-exception
            r7 = r2
            r2 = r0
            r0 = r7
        L44:
            java.lang.Class<? extends b.h.k.y.d$a> r4 = r3.f1801c
            if (r4 != 0) goto L4b
            java.lang.String r4 = "null"
            goto L4f
        L4b:
            java.lang.String r4 = r4.getName()
        L4f:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r6 = "Failed to execute command with argument class ViewCommandArgument: "
            r5.append(r6)
            r5.append(r4)
            java.lang.String r4 = r5.toString()
            java.lang.String r5 = "A11yActionCompat"
            android.util.Log.e(r5, r4, r0)
        L65:
            r0 = r2
        L66:
            b.h.k.y.d r2 = r3.f1802d
            boolean r0 = r2.a(r9, r0)
            goto L71
        L6d:
            int r2 = r2 + 1
            goto L11
        L70:
            r0 = 0
        L71:
            if (r0 != 0) goto L79
            android.view.View$AccessibilityDelegate r0 = r8.f1718a
            boolean r0 = r0.performAccessibilityAction(r9, r10, r11)
        L79:
            if (r0 != 0) goto Lca
            r2 = 2131361807(0x7f0a000f, float:1.8343377E38)
            if (r10 != r2) goto Lca
            r10 = -1
            java.lang.String r0 = "ACCESSIBILITY_CLICKABLE_SPAN_ID"
            int r10 = r11.getInt(r0, r10)
            r11 = 2131362531(0x7f0a02e3, float:1.8344845E38)
            java.lang.Object r11 = r9.getTag(r11)
            android.util.SparseArray r11 = (android.util.SparseArray) r11
            r0 = 1
            if (r11 == 0) goto Lc9
            java.lang.Object r10 = r11.get(r10)
            java.lang.ref.WeakReference r10 = (java.lang.ref.WeakReference) r10
            if (r10 == 0) goto Lc9
            java.lang.Object r10 = r10.get()
            android.text.style.ClickableSpan r10 = (android.text.style.ClickableSpan) r10
            if (r10 == 0) goto Lc2
            android.view.accessibility.AccessibilityNodeInfo r11 = r9.createAccessibilityNodeInfo()
            java.lang.CharSequence r11 = r11.getText()
            android.text.style.ClickableSpan[] r11 = b.h.k.y.b.d(r11)
            r2 = 0
        Lb0:
            if (r11 == 0) goto Lc2
            int r3 = r11.length
            if (r2 >= r3) goto Lc2
            r3 = r11[r2]
            boolean r3 = r10.equals(r3)
            if (r3 == 0) goto Lbf
            r11 = 1
            goto Lc3
        Lbf:
            int r2 = r2 + 1
            goto Lb0
        Lc2:
            r11 = 0
        Lc3:
            if (r11 == 0) goto Lc9
            r10.onClick(r9)
            r1 = 1
        Lc9:
            r0 = r1
        Lca:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.k.a.g(android.view.View, int, android.os.Bundle):boolean");
    }

    public void h(View view, int i2) {
        this.f1718a.sendAccessibilityEvent(view, i2);
    }

    public void i(View view, AccessibilityEvent accessibilityEvent) {
        this.f1718a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }
}
