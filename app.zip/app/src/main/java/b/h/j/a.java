package b.h.j;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\j\e.smali */
public class e<T> implements d<T> {

    /* renamed from: a, reason: collision with root package name */
    public final Object[] f1714a;

    /* renamed from: b, reason: collision with root package name */
    public int f1715b;

    public e(int i2) {
        if (i2 <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f1714a = new Object[i2];
    }

    @Override // b.h.j.d
    public boolean a(T t) {
        int i2;
        boolean z;
        int i3 = 0;
        while (true) {
            i2 = this.f1715b;
            if (i3 >= i2) {
                z = false;
                break;
            }
            if (this.f1714a[i3] == t) {
                z = true;
                break;
            }
            i3++;
        }
        if (z) {
            throw new IllegalStateException("Already in the pool!");
        }
        Object[] objArr = this.f1714a;
        if (i2 >= objArr.length) {
            return false;
        }
        objArr[i2] = t;
        this.f1715b = i2 + 1;
        return true;
    }

    @Override // b.h.j.d
    public T b() {
        int i2 = this.f1715b;
        if (i2 <= 0) {
            return null;
        }
        int i3 = i2 - 1;
        Object[] objArr = this.f1714a;
        T t = (T) objArr[i3];
        objArr[i3] = null;
        this.f1715b = i2 - 1;
        return t;
    }
}
