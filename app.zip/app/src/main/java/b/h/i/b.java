package b.h.i;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\b.smali */
public class b implements Spannable {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\b$a.smali */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final TextPaint f1703a;

        /* renamed from: b, reason: collision with root package name */
        public final TextDirectionHeuristic f1704b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1705c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1706d;

        public a(PrecomputedText.Params params) {
            this.f1703a = params.getTextPaint();
            this.f1704b = params.getTextDirection();
            this.f1705c = params.getBreakStrategy();
            this.f1706d = params.getHyphenationFrequency();
            int i2 = Build.VERSION.SDK_INT;
        }

        @SuppressLint({"NewApi"})
        public a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i2, int i3) {
            if (Build.VERSION.SDK_INT >= 29) {
                new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i2).setHyphenationFrequency(i3).setTextDirection(textDirectionHeuristic).build();
            }
            this.f1703a = textPaint;
            this.f1704b = textDirectionHeuristic;
            this.f1705c = i2;
            this.f1706d = i3;
        }

        public boolean a(a aVar) {
            int i2 = Build.VERSION.SDK_INT;
            if ((i2 >= 23 && (this.f1705c != aVar.f1705c || this.f1706d != aVar.f1706d)) || this.f1703a.getTextSize() != aVar.f1703a.getTextSize() || this.f1703a.getTextScaleX() != aVar.f1703a.getTextScaleX() || this.f1703a.getTextSkewX() != aVar.f1703a.getTextSkewX() || this.f1703a.getLetterSpacing() != aVar.f1703a.getLetterSpacing() || !TextUtils.equals(this.f1703a.getFontFeatureSettings(), aVar.f1703a.getFontFeatureSettings()) || this.f1703a.getFlags() != aVar.f1703a.getFlags()) {
                return false;
            }
            if (i2 >= 24) {
                if (!this.f1703a.getTextLocales().equals(aVar.f1703a.getTextLocales())) {
                    return false;
                }
            } else if (!this.f1703a.getTextLocale().equals(aVar.f1703a.getTextLocale())) {
                return false;
            }
            return this.f1703a.getTypeface() == null ? aVar.f1703a.getTypeface() == null : this.f1703a.getTypeface().equals(aVar.f1703a.getTypeface());
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return a(aVar) && this.f1704b == aVar.f1704b;
        }

        public int hashCode() {
            return Build.VERSION.SDK_INT >= 24 ? Objects.hash(Float.valueOf(this.f1703a.getTextSize()), Float.valueOf(this.f1703a.getTextScaleX()), Float.valueOf(this.f1703a.getTextSkewX()), Float.valueOf(this.f1703a.getLetterSpacing()), Integer.valueOf(this.f1703a.getFlags()), this.f1703a.getTextLocales(), this.f1703a.getTypeface(), Boolean.valueOf(this.f1703a.isElegantTextHeight()), this.f1704b, Integer.valueOf(this.f1705c), Integer.valueOf(this.f1706d)) : Objects.hash(Float.valueOf(this.f1703a.getTextSize()), Float.valueOf(this.f1703a.getTextScaleX()), Float.valueOf(this.f1703a.getTextSkewX()), Float.valueOf(this.f1703a.getLetterSpacing()), Integer.valueOf(this.f1703a.getFlags()), this.f1703a.getTextLocale(), this.f1703a.getTypeface(), Boolean.valueOf(this.f1703a.isElegantTextHeight()), this.f1704b, Integer.valueOf(this.f1705c), Integer.valueOf(this.f1706d));
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            StringBuilder n = c.a.a.a.a.n("textSize=");
            n.append(this.f1703a.getTextSize());
            sb.append(n.toString());
            sb.append(", textScaleX=" + this.f1703a.getTextScaleX());
            sb.append(", textSkewX=" + this.f1703a.getTextSkewX());
            int i2 = Build.VERSION.SDK_INT;
            StringBuilder n2 = c.a.a.a.a.n(", letterSpacing=");
            n2.append(this.f1703a.getLetterSpacing());
            sb.append(n2.toString());
            sb.append(", elegantTextHeight=" + this.f1703a.isElegantTextHeight());
            if (i2 >= 24) {
                StringBuilder n3 = c.a.a.a.a.n(", textLocale=");
                n3.append(this.f1703a.getTextLocales());
                sb.append(n3.toString());
            } else {
                StringBuilder n4 = c.a.a.a.a.n(", textLocale=");
                n4.append(this.f1703a.getTextLocale());
                sb.append(n4.toString());
            }
            StringBuilder n5 = c.a.a.a.a.n(", typeface=");
            n5.append(this.f1703a.getTypeface());
            sb.append(n5.toString());
            if (i2 >= 26) {
                StringBuilder n6 = c.a.a.a.a.n(", variationSettings=");
                n6.append(this.f1703a.getFontVariationSettings());
                sb.append(n6.toString());
            }
            StringBuilder n7 = c.a.a.a.a.n(", textDir=");
            n7.append(this.f1704b);
            sb.append(n7.toString());
            sb.append(", breakStrategy=" + this.f1705c);
            sb.append(", hyphenationFrequency=" + this.f1706d);
            sb.append("}");
            return sb.toString();
        }
    }

    @Override // java.lang.CharSequence
    public char charAt(int i2) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    @SuppressLint({"NewApi"})
    public <T> T[] getSpans(int i2, int i3, Class<T> cls) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        throw null;
    }

    @Override // java.lang.CharSequence
    public int length() {
        throw null;
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i2, int i3, Class cls) {
        throw null;
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT < 29) {
            throw null;
        }
        throw null;
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void setSpan(Object obj, int i2, int i3, int i4) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT < 29) {
            throw null;
        }
        throw null;
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i2, int i3) {
        throw null;
    }

    @Override // java.lang.CharSequence
    public String toString() {
        throw null;
    }
}
