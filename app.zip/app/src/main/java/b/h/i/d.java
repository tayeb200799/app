package b.h.i;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\d.smali */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public static final b.h.i.c f1707a = new C0031d(null, false);

    /* renamed from: b, reason: collision with root package name */
    public static final b.h.i.c f1708b = new C0031d(null, true);

    /* renamed from: c, reason: collision with root package name */
    public static final b.h.i.c f1709c;

    /* renamed from: d, reason: collision with root package name */
    public static final b.h.i.c f1710d;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\d$a.smali */
    public static class a implements b {

        /* renamed from: a, reason: collision with root package name */
        public static final a f1711a = new a();

        @Override // b.h.i.d.b
        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            int i5 = 2;
            while (i2 < i4 && i5 == 2) {
                byte directionality = Character.getDirectionality(charSequence.charAt(i2));
                b.h.i.c cVar = d.f1707a;
                if (directionality != 0) {
                    if (directionality != 1 && directionality != 2) {
                        switch (directionality) {
                            case 14:
                            case 15:
                                break;
                            case 16:
                            case 17:
                                break;
                            default:
                                i5 = 2;
                                break;
                        }
                        i2++;
                    }
                    i5 = 0;
                    i2++;
                }
                i5 = 1;
                i2++;
            }
            return i5;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\d$b.smali */
    public interface b {
        int a(CharSequence charSequence, int i2, int i3);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\d$c.smali */
    public static abstract class c implements b.h.i.c {

        /* renamed from: a, reason: collision with root package name */
        public final b f1712a;

        public c(b bVar) {
            this.f1712a = bVar;
        }

        public abstract boolean a();

        public boolean b(CharSequence charSequence, int i2, int i3) {
            if (i2 < 0 || i3 < 0 || charSequence.length() - i3 < i2) {
                throw new IllegalArgumentException();
            }
            b bVar = this.f1712a;
            if (bVar == null) {
                return a();
            }
            int a2 = bVar.a(charSequence, i2, i3);
            if (a2 == 0) {
                return true;
            }
            if (a2 != 1) {
                return a();
            }
            return false;
        }
    }

    /* renamed from: b.h.i.d$d, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\i\d$d.smali */
    public static class C0031d extends c {

        /* renamed from: b, reason: collision with root package name */
        public final boolean f1713b;

        public C0031d(b bVar, boolean z) {
            super(bVar);
            this.f1713b = z;
        }

        @Override // b.h.i.d.c
        public boolean a() {
            return this.f1713b;
        }
    }

    static {
        a aVar = a.f1711a;
        f1709c = new C0031d(aVar, false);
        f1710d = new C0031d(aVar, true);
    }
}
