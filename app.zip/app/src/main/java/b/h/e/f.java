package b.h.e;

import b.h.e.k;
import b.h.h.l;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\j.smali */
public class j implements k.a<l> {
    public j(k kVar) {
    }

    @Override // b.h.e.k.a
    public int a(l lVar) {
        return lVar.f1676c;
    }

    @Override // b.h.e.k.a
    public boolean b(l lVar) {
        return lVar.f1677d;
    }
}
