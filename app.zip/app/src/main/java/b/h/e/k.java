package b.h.e.l;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\l\c.smali */
public class c extends Drawable implements Drawable.Callback, b, a {

    /* renamed from: j, reason: collision with root package name */
    public static final PorterDuff.Mode f1624j = PorterDuff.Mode.SRC_IN;

    /* renamed from: d, reason: collision with root package name */
    public int f1625d;

    /* renamed from: e, reason: collision with root package name */
    public PorterDuff.Mode f1626e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1627f;

    /* renamed from: g, reason: collision with root package name */
    public e f1628g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1629h;

    /* renamed from: i, reason: collision with root package name */
    public Drawable f1630i;

    public c(Drawable drawable) {
        this.f1628g = new e(this.f1628g);
        a(drawable);
    }

    public c(e eVar, Resources resources) {
        Drawable.ConstantState constantState;
        this.f1628g = eVar;
        if (eVar == null || (constantState = eVar.f1632b) == null) {
            return;
        }
        a(constantState.newDrawable(resources));
    }

    @Override // b.h.e.l.b
    public final void a(Drawable drawable) {
        Drawable drawable2 = this.f1630i;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f1630i = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            setVisible(drawable.isVisible(), true);
            setState(drawable.getState());
            setLevel(drawable.getLevel());
            setBounds(drawable.getBounds());
            e eVar = this.f1628g;
            if (eVar != null) {
                eVar.f1632b = drawable.getConstantState();
            }
        }
        invalidateSelf();
    }

    @Override // b.h.e.l.b
    public final Drawable b() {
        return this.f1630i;
    }

    public boolean c() {
        throw null;
    }

    public final boolean d(int[] iArr) {
        if (!c()) {
            return false;
        }
        e eVar = this.f1628g;
        ColorStateList colorStateList = eVar.f1633c;
        PorterDuff.Mode mode = eVar.f1634d;
        if (colorStateList == null || mode == null) {
            this.f1627f = false;
            clearColorFilter();
        } else {
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (!this.f1627f || colorForState != this.f1625d || mode != this.f1626e) {
                setColorFilter(colorForState, mode);
                this.f1625d = colorForState;
                this.f1626e = mode;
                this.f1627f = true;
                return true;
            }
        }
        return false;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        this.f1630i.draw(canvas);
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        e eVar = this.f1628g;
        return changingConfigurations | (eVar != null ? eVar.getChangingConfigurations() : 0) | this.f1630i.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        e eVar = this.f1628g;
        if (eVar == null) {
            return null;
        }
        if (!(eVar.f1632b != null)) {
            return null;
        }
        eVar.f1631a = getChangingConfigurations();
        return this.f1628g;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable getCurrent() {
        return this.f1630i.getCurrent();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return this.f1630i.getIntrinsicHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return this.f1630i.getIntrinsicWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getLayoutDirection() {
        return b.h.a.s(this.f1630i);
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumHeight() {
        return this.f1630i.getMinimumHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumWidth() {
        return this.f1630i.getMinimumWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return this.f1630i.getOpacity();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        return this.f1630i.getPadding(rect);
    }

    @Override // android.graphics.drawable.Drawable
    public int[] getState() {
        return this.f1630i.getState();
    }

    @Override // android.graphics.drawable.Drawable
    public Region getTransparentRegion() {
        return this.f1630i.getTransparentRegion();
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        return this.f1630i.isAutoMirrored();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        e eVar;
        ColorStateList colorStateList = (!c() || (eVar = this.f1628g) == null) ? null : eVar.f1633c;
        return (colorStateList != null && colorStateList.isStateful()) || this.f1630i.isStateful();
    }

    @Override // android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        this.f1630i.jumpToCurrentState();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.f1629h && super.mutate() == this) {
            this.f1628g = new e(this.f1628g);
            Drawable drawable = this.f1630i;
            if (drawable != null) {
                drawable.mutate();
            }
            e eVar = this.f1628g;
            if (eVar != null) {
                Drawable drawable2 = this.f1630i;
                eVar.f1632b = drawable2 != null ? drawable2.getConstantState() : null;
            }
            this.f1629h = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f1630i;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLayoutDirectionChanged(int i2) {
        return b.h.a.K(this.f1630i, i2);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLevelChange(int i2) {
        return this.f1630i.setLevel(i2);
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        scheduleSelf(runnable, j2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        this.f1630i.setAlpha(i2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z) {
        this.f1630i.setAutoMirrored(z);
    }

    @Override // android.graphics.drawable.Drawable
    public void setChangingConfigurations(int i2) {
        this.f1630i.setChangingConfigurations(i2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.f1630i.setColorFilter(colorFilter);
    }

    @Override // android.graphics.drawable.Drawable
    public void setDither(boolean z) {
        this.f1630i.setDither(z);
    }

    @Override // android.graphics.drawable.Drawable
    public void setFilterBitmap(boolean z) {
        this.f1630i.setFilterBitmap(z);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setState(int[] iArr) {
        return d(iArr) || this.f1630i.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i2) {
        setTintList(ColorStateList.valueOf(i2));
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        throw null;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        return super.setVisible(z, z2) || this.f1630i.setVisible(z, z2);
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
