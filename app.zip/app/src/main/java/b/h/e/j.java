package b.h.e.l;

import android.graphics.drawable.Drawable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\l\b.smali */
public interface b {
    void a(Drawable drawable);

    Drawable b();
}
