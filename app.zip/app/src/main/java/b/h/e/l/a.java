package b.h.e.l;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\l\e.smali */
public final class e extends Drawable.ConstantState {

    /* renamed from: a, reason: collision with root package name */
    public int f1631a;

    /* renamed from: b, reason: collision with root package name */
    public Drawable.ConstantState f1632b;

    /* renamed from: c, reason: collision with root package name */
    public ColorStateList f1633c;

    /* renamed from: d, reason: collision with root package name */
    public PorterDuff.Mode f1634d;

    public e(e eVar) {
        this.f1633c = null;
        this.f1634d = c.f1624j;
        if (eVar != null) {
            this.f1631a = eVar.f1631a;
            this.f1632b = eVar.f1632b;
            this.f1633c = eVar.f1633c;
            this.f1634d = eVar.f1634d;
        }
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public int getChangingConfigurations() {
        int i2 = this.f1631a;
        Drawable.ConstantState constantState = this.f1632b;
        return i2 | (constantState != null ? constantState.getChangingConfigurations() : 0);
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable() {
        return new d(this, null);
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable(Resources resources) {
        return new d(this, resources);
    }
}
