package b.h.g;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\g\a.smali */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1635a;

    /* renamed from: b, reason: collision with root package name */
    public InterfaceC0029a f1636b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1637c;

    /* renamed from: b.h.g.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\g\a$a.smali */
    public interface InterfaceC0029a {
    }
}
