package b.h.e;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import b.h.h.l;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\e\e.smali */
public class e extends k {

    /* renamed from: b, reason: collision with root package name */
    public static Class<?> f1610b;

    /* renamed from: c, reason: collision with root package name */
    public static Constructor<?> f1611c;

    /* renamed from: d, reason: collision with root package name */
    public static Method f1612d;

    /* renamed from: e, reason: collision with root package name */
    public static Method f1613e;

    /* renamed from: f, reason: collision with root package name */
    public static boolean f1614f;

    public static boolean f(Object obj, String str, int i2, boolean z) {
        g();
        try {
            return ((Boolean) f1612d.invoke(obj, str, Integer.valueOf(i2), Boolean.valueOf(z))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public static void g() {
        Method method;
        Class<?> cls;
        Method method2;
        if (f1614f) {
            return;
        }
        f1614f = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(new Class[0]);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi21Impl", e2.getClass().getName(), e2);
            method = null;
            cls = null;
            method2 = null;
        }
        f1611c = constructor;
        f1610b = cls;
        f1612d = method2;
        f1613e = method;
    }

    @Override // b.h.e.k
    public Typeface a(Context context, b.h.d.b.d dVar, Resources resources, int i2) {
        g();
        try {
            Object newInstance = f1611c.newInstance(new Object[0]);
            for (b.h.d.b.e eVar : dVar.f1573a) {
                File y = b.h.a.y(context);
                if (y == null) {
                    return null;
                }
                try {
                    if (!b.h.a.m(y, resources, eVar.f1579f)) {
                        return null;
                    }
                    if (!f(newInstance, y.getPath(), eVar.f1575b, eVar.f1576c)) {
                        return null;
                    }
                    y.delete();
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    y.delete();
                }
            }
            g();
            try {
                Object newInstance2 = Array.newInstance(f1610b, 1);
                Array.set(newInstance2, 0, newInstance);
                return (Typeface) f1613e.invoke(null, newInstance2);
            } catch (IllegalAccessException | InvocationTargetException e2) {
                throw new RuntimeException(e2);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    @Override // b.h.e.k
    public Typeface b(Context context, CancellationSignal cancellationSignal, l[] lVarArr, int i2) {
        File file;
        String readlink;
        if (lVarArr.length < 1) {
            return null;
        }
        try {
            ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(((l) k.e(lVarArr, i2, new j(this))).f1674a, "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            try {
                try {
                    readlink = Os.readlink("/proc/self/fd/" + openFileDescriptor.getFd());
                } catch (ErrnoException unused) {
                }
                try {
                    if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                        file = new File(readlink);
                        if (file != null && file.canRead()) {
                            Typeface createFromFile = Typeface.createFromFile(file);
                            openFileDescriptor.close();
                            return createFromFile;
                        }
                        FileInputStream fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                        Typeface c2 = c(context, fileInputStream);
                        fileInputStream.close();
                        openFileDescriptor.close();
                        return c2;
                    }
                    Typeface c22 = c(context, fileInputStream);
                    fileInputStream.close();
                    openFileDescriptor.close();
                    return c22;
                } finally {
                }
                file = null;
                if (file != null) {
                    Typeface createFromFile2 = Typeface.createFromFile(file);
                    openFileDescriptor.close();
                    return createFromFile2;
                }
                FileInputStream fileInputStream2 = new FileInputStream(openFileDescriptor.getFileDescriptor());
            } finally {
            }
        } catch (IOException unused2) {
            return null;
        }
    }
}
