package b.h.c;

import android.util.Log;
import java.lang.reflect.Method;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\d.smali */
public class d implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1531d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1532e;

    public d(Object obj, Object obj2) {
        this.f1531d = obj;
        this.f1532e = obj2;
    }

    @Override // java.lang.Runnable
    public void run() {
        Boolean bool = Boolean.FALSE;
        try {
            Method method = c.f1517d;
            if (method != null) {
                method.invoke(this.f1531d, this.f1532e, bool, "AppCompat recreation");
            } else {
                c.f1518e.invoke(this.f1531d, this.f1532e, bool);
            }
        } catch (RuntimeException e2) {
            if (e2.getClass() == RuntimeException.class && e2.getMessage() != null && e2.getMessage().startsWith("Unable to stop")) {
                throw e2;
            }
        } catch (Throwable th) {
            Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
        }
    }
}
