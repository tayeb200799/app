package b.h.c;

import android.app.Activity;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\b.smali */
public class b implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Activity f1513d;

    public b(Activity activity) {
        this.f1513d = activity;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.f1513d.isFinishing() || c.b(this.f1513d)) {
            return;
        }
        this.f1513d.recreate();
    }
}
