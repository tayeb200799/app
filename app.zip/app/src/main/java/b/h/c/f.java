package b.h.c;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\j.smali */
public class j {

    /* renamed from: a */
    public Context f1548a;

    /* renamed from: e */
    public CharSequence f1552e;

    /* renamed from: f */
    public CharSequence f1553f;

    /* renamed from: g */
    public PendingIntent f1554g;

    /* renamed from: h */
    public Bitmap f1555h;

    /* renamed from: i */
    public int f1556i;

    /* renamed from: j */
    public int f1557j;
    public l l;
    public boolean n;
    public boolean o;
    public Bundle p;
    public RemoteViews s;
    public RemoteViews t;
    public String u;
    public boolean v;
    public Notification w;

    @Deprecated
    public ArrayList<String> x;

    /* renamed from: b */
    public ArrayList<g> f1549b = new ArrayList<>();

    /* renamed from: c */
    public ArrayList<o> f1550c = new ArrayList<>();

    /* renamed from: d */
    public ArrayList<g> f1551d = new ArrayList<>();
    public boolean k = true;
    public boolean m = false;
    public int q = 0;
    public int r = 0;

    public j(Context context, String str) {
        Notification notification = new Notification();
        this.w = notification;
        this.f1548a = context;
        this.u = str;
        notification.when = System.currentTimeMillis();
        this.w.audioStreamType = -1;
        this.f1557j = 0;
        this.x = new ArrayList<>();
        this.v = true;
    }

    public static CharSequence d(CharSequence charSequence) {
        return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
    }

    public j a(int i2, CharSequence charSequence, PendingIntent pendingIntent) {
        this.f1549b.add(new g(i2, charSequence, pendingIntent));
        return this;
    }

    public Notification b() {
        Notification build;
        Bundle bundle;
        RemoteViews j2;
        RemoteViews h2;
        m mVar = new m(this);
        l lVar = mVar.f1561c.l;
        if (lVar != null) {
            lVar.b(mVar);
        }
        RemoteViews i2 = lVar != null ? lVar.i(mVar) : null;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            build = mVar.f1560b.build();
        } else if (i3 >= 24) {
            build = mVar.f1560b.build();
        } else {
            mVar.f1560b.setExtras(mVar.f1565g);
            build = mVar.f1560b.build();
            RemoteViews remoteViews = mVar.f1562d;
            if (remoteViews != null) {
                build.contentView = remoteViews;
            }
            RemoteViews remoteViews2 = mVar.f1563e;
            if (remoteViews2 != null) {
                build.bigContentView = remoteViews2;
            }
        }
        if (i2 != null) {
            build.contentView = i2;
        } else {
            RemoteViews remoteViews3 = mVar.f1561c.s;
            if (remoteViews3 != null) {
                build.contentView = remoteViews3;
            }
        }
        if (lVar != null && (h2 = lVar.h(mVar)) != null) {
            build.bigContentView = h2;
        }
        if (lVar != null && (j2 = mVar.f1561c.l.j(mVar)) != null) {
            build.headsUpContentView = j2;
        }
        if (lVar != null && (bundle = build.extras) != null) {
            lVar.a(bundle);
        }
        return build;
    }

    public long c() {
        if (this.k) {
            return this.w.when;
        }
        return 0L;
    }

    public j e(boolean z) {
        this.n = z;
        this.o = true;
        return this;
    }

    public j f(CharSequence charSequence) {
        this.f1553f = d(charSequence);
        return this;
    }

    public j g(CharSequence charSequence) {
        this.f1552e = d(charSequence);
        return this;
    }

    public j h(int i2) {
        Notification notification = this.w;
        notification.defaults = i2;
        if ((i2 & 4) != 0) {
            notification.flags |= 1;
        }
        return this;
    }

    public final void i(int i2, boolean z) {
        if (z) {
            Notification notification = this.w;
            notification.flags = i2 | notification.flags;
        } else {
            Notification notification2 = this.w;
            notification2.flags = (~i2) & notification2.flags;
        }
    }

    public j j(Bitmap bitmap) {
        if (bitmap != null && Build.VERSION.SDK_INT < 27) {
            Resources resources = this.f1548a.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(2131165276);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(2131165275);
            if (bitmap.getWidth() > dimensionPixelSize || bitmap.getHeight() > dimensionPixelSize2) {
                double min = Math.min(dimensionPixelSize / Math.max(1, bitmap.getWidth()), dimensionPixelSize2 / Math.max(1, bitmap.getHeight()));
                bitmap = Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(bitmap.getWidth() * min), (int) Math.ceil(bitmap.getHeight() * min), true);
            }
        }
        this.f1555h = bitmap;
        return this;
    }
}
