package b.h.c;

import android.os.Bundle;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\n.smali */
public class n {

    /* renamed from: a, reason: collision with root package name */
    public static final Object f1566a = new Object();

    public static Bundle[] a(p[] pVarArr) {
        if (pVarArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[pVarArr.length];
        if (pVarArr.length <= 0) {
            return bundleArr;
        }
        p pVar = pVarArr[0];
        new Bundle();
        throw null;
    }
}
