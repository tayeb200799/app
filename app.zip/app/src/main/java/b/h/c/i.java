package b.h.c;

import android.app.Notification;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\m.smali */
public class m implements f {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1559a;

    /* renamed from: b, reason: collision with root package name */
    public final Notification.Builder f1560b;

    /* renamed from: c, reason: collision with root package name */
    public final j f1561c;

    /* renamed from: d, reason: collision with root package name */
    public RemoteViews f1562d;

    /* renamed from: e, reason: collision with root package name */
    public RemoteViews f1563e;

    /* renamed from: f, reason: collision with root package name */
    public final List<Bundle> f1564f;

    /* renamed from: g, reason: collision with root package name */
    public final Bundle f1565g;

    public m(j jVar) {
        int i2 = Build.VERSION.SDK_INT;
        this.f1564f = new ArrayList();
        this.f1565g = new Bundle();
        this.f1561c = jVar;
        this.f1559a = jVar.f1548a;
        if (i2 >= 26) {
            this.f1560b = new Notification.Builder(jVar.f1548a, jVar.u);
        } else {
            this.f1560b = new Notification.Builder(jVar.f1548a);
        }
        Notification notification = jVar.w;
        this.f1560b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(jVar.f1552e).setContentText(jVar.f1553f).setContentInfo(null).setContentIntent(jVar.f1554g).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(null, (notification.flags & 128) != 0).setLargeIcon(jVar.f1555h).setNumber(jVar.f1556i).setProgress(0, 0, false);
        this.f1560b.setSubText(null).setUsesChronometer(false).setPriority(jVar.f1557j);
        Iterator<g> it = jVar.f1549b.iterator();
        while (it.hasNext()) {
            g next = it.next();
            IconCompat a2 = next.a();
            Notification.Action.Builder builder = i2 >= 23 ? new Notification.Action.Builder(a2 != null ? a2.i() : null, next.f1543j, next.k) : new Notification.Action.Builder(a2 != null ? a2.c() : 0, next.f1543j, next.k);
            p[] pVarArr = next.f1536c;
            if (pVarArr != null) {
                int length = pVarArr.length;
                RemoteInput[] remoteInputArr = new RemoteInput[length];
                if (pVarArr.length > 0) {
                    p pVar = pVarArr[0];
                    throw null;
                }
                for (int i3 = 0; i3 < length; i3++) {
                    builder.addRemoteInput(remoteInputArr[i3]);
                }
            }
            Bundle bundle = next.f1534a != null ? new Bundle(next.f1534a) : new Bundle();
            bundle.putBoolean("android.support.allowGeneratedReplies", next.f1538e);
            if (i2 >= 24) {
                builder.setAllowGeneratedReplies(next.f1538e);
            }
            bundle.putInt("android.support.action.semanticAction", next.f1540g);
            if (i2 >= 28) {
                builder.setSemanticAction(next.f1540g);
            }
            if (i2 >= 29) {
                builder.setContextual(next.f1541h);
            }
            bundle.putBoolean("android.support.action.showsUserInterface", next.f1539f);
            builder.addExtras(bundle);
            this.f1560b.addAction(builder.build());
        }
        Bundle bundle2 = jVar.p;
        if (bundle2 != null) {
            this.f1565g.putAll(bundle2);
        }
        this.f1562d = jVar.s;
        this.f1563e = jVar.t;
        this.f1560b.setShowWhen(jVar.k);
        this.f1560b.setLocalOnly(jVar.m).setGroup(null).setGroupSummary(false).setSortKey(null);
        this.f1560b.setCategory(null).setColor(jVar.q).setVisibility(jVar.r).setPublicVersion(null).setSound(notification.sound, notification.audioAttributes);
        List a3 = i2 < 28 ? a(b(jVar.f1550c), jVar.x) : jVar.x;
        if (a3 != null && !a3.isEmpty()) {
            Iterator it2 = a3.iterator();
            while (it2.hasNext()) {
                this.f1560b.addPerson((String) it2.next());
            }
        }
        if (jVar.f1551d.size() > 0) {
            if (jVar.p == null) {
                jVar.p = new Bundle();
            }
            Bundle bundle3 = jVar.p.getBundle("android.car.EXTENSIONS");
            bundle3 = bundle3 == null ? new Bundle() : bundle3;
            Bundle bundle4 = new Bundle(bundle3);
            Bundle bundle5 = new Bundle();
            for (int i4 = 0; i4 < jVar.f1551d.size(); i4++) {
                String num = Integer.toString(i4);
                g gVar = jVar.f1551d.get(i4);
                Object obj = n.f1566a;
                Bundle bundle6 = new Bundle();
                IconCompat a4 = gVar.a();
                bundle6.putInt("icon", a4 != null ? a4.c() : 0);
                bundle6.putCharSequence("title", gVar.f1543j);
                bundle6.putParcelable("actionIntent", gVar.k);
                Bundle bundle7 = gVar.f1534a != null ? new Bundle(gVar.f1534a) : new Bundle();
                bundle7.putBoolean("android.support.allowGeneratedReplies", gVar.f1538e);
                bundle6.putBundle("extras", bundle7);
                bundle6.putParcelableArray("remoteInputs", n.a(gVar.f1536c));
                bundle6.putBoolean("showsUserInterface", gVar.f1539f);
                bundle6.putInt("semanticAction", gVar.f1540g);
                bundle5.putBundle(num, bundle6);
            }
            bundle3.putBundle("invisible_actions", bundle5);
            bundle4.putBundle("invisible_actions", bundle5);
            if (jVar.p == null) {
                jVar.p = new Bundle();
            }
            jVar.p.putBundle("android.car.EXTENSIONS", bundle3);
            this.f1565g.putBundle("android.car.EXTENSIONS", bundle4);
        }
        if (i2 >= 24) {
            this.f1560b.setExtras(jVar.p).setRemoteInputHistory(null);
            RemoteViews remoteViews = jVar.s;
            if (remoteViews != null) {
                this.f1560b.setCustomContentView(remoteViews);
            }
            RemoteViews remoteViews2 = jVar.t;
            if (remoteViews2 != null) {
                this.f1560b.setCustomBigContentView(remoteViews2);
            }
        }
        if (i2 >= 26) {
            this.f1560b.setBadgeIconType(0).setSettingsText(null).setShortcutId(null).setTimeoutAfter(0L).setGroupAlertBehavior(0);
            if (jVar.o) {
                this.f1560b.setColorized(jVar.n);
            }
            if (!TextUtils.isEmpty(jVar.u)) {
                this.f1560b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null);
            }
        }
        if (i2 >= 28) {
            Iterator<o> it3 = jVar.f1550c.iterator();
            while (it3.hasNext()) {
                o next2 = it3.next();
                Notification.Builder builder2 = this.f1560b;
                Objects.requireNonNull(next2);
                builder2.addPerson(new Person.Builder().setName(null).setIcon(null).setUri(null).setKey(null).setBot(false).setImportant(false).build());
            }
        }
        if (i2 >= 29) {
            this.f1560b.setAllowSystemGeneratedContextualActions(jVar.v);
            this.f1560b.setBubbleMetadata(null);
        }
    }

    public static List<String> a(List<String> list, List<String> list2) {
        if (list == null) {
            return list2;
        }
        if (list2 == null) {
            return list;
        }
        b.e.c cVar = new b.e.c(list2.size() + list.size());
        cVar.addAll(list);
        cVar.addAll(list2);
        return new ArrayList(cVar);
    }

    public static List<String> b(List<o> list) {
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        Iterator<o> it = list.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            arrayList.add("");
        }
        return arrayList;
    }
}
