package b.h.c;

import android.app.Notification;
import android.content.res.Resources;
import android.os.Build;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\k.smali */
public class k extends l {
    @Override // b.h.c.l
    public void b(f fVar) {
        if (Build.VERSION.SDK_INT >= 24) {
            ((m) fVar).f1560b.setStyle(new Notification.DecoratedCustomViewStyle());
        }
    }

    @Override // b.h.c.l
    public String g() {
        return "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle";
    }

    @Override // b.h.c.l
    public RemoteViews h(f fVar) {
        if (Build.VERSION.SDK_INT >= 24) {
            return null;
        }
        j jVar = this.f1558a;
        RemoteViews remoteViews = jVar.t;
        if (remoteViews == null) {
            remoteViews = jVar.s;
        }
        if (remoteViews == null) {
            return null;
        }
        return l(remoteViews, true);
    }

    @Override // b.h.c.l
    public RemoteViews i(f fVar) {
        RemoteViews remoteViews;
        if (Build.VERSION.SDK_INT < 24 && (remoteViews = this.f1558a.s) != null) {
            return l(remoteViews, false);
        }
        return null;
    }

    @Override // b.h.c.l
    public RemoteViews j(f fVar) {
        if (Build.VERSION.SDK_INT >= 24) {
            return null;
        }
        Objects.requireNonNull(this.f1558a);
        RemoteViews remoteViews = this.f1558a.s;
        return null;
    }

    public final RemoteViews l(RemoteViews remoteViews, boolean z) {
        ArrayList arrayList;
        int min;
        boolean z2 = true;
        RemoteViews c2 = c(true, 2131558593, false);
        c2.removeAllViews(2131361861);
        ArrayList<g> arrayList2 = this.f1558a.f1549b;
        if (arrayList2 == null) {
            arrayList = null;
        } else {
            ArrayList arrayList3 = new ArrayList();
            for (g gVar : arrayList2) {
                if (!gVar.f1541h) {
                    arrayList3.add(gVar);
                }
            }
            arrayList = arrayList3;
        }
        if (!z || arrayList == null || (min = Math.min(arrayList.size(), 3)) <= 0) {
            z2 = false;
        } else {
            for (int i2 = 0; i2 < min; i2++) {
                g gVar2 = (g) arrayList.get(i2);
                boolean z3 = gVar2.k == null;
                RemoteViews remoteViews2 = new RemoteViews(this.f1558a.f1548a.getPackageName(), z3 ? 2131558586 : 2131558585);
                IconCompat a2 = gVar2.a();
                if (a2 != null) {
                    remoteViews2.setImageViewBitmap(2131361854, e(a2, this.f1558a.f1548a.getResources().getColor(2131099862), 0));
                }
                remoteViews2.setTextViewText(2131361860, gVar2.f1543j);
                if (!z3) {
                    remoteViews2.setOnClickPendingIntent(2131361851, gVar2.k);
                }
                remoteViews2.setContentDescription(2131361851, gVar2.f1543j);
                c2.addView(2131361861, remoteViews2);
            }
        }
        int i3 = z2 ? 0 : 8;
        c2.setViewVisibility(2131361861, i3);
        c2.setViewVisibility(2131361853, i3);
        c2.setViewVisibility(2131362568, 8);
        c2.setViewVisibility(2131362549, 8);
        c2.setViewVisibility(2131362548, 8);
        c2.removeAllViews(2131362347);
        c2.addView(2131362347, remoteViews.clone());
        c2.setViewVisibility(2131362347, 0);
        Resources resources = this.f1558a.f1548a.getResources();
        int dimensionPixelSize = resources.getDimensionPixelSize(2131165566);
        int dimensionPixelSize2 = resources.getDimensionPixelSize(2131165567);
        float f2 = resources.getConfiguration().fontScale;
        if (f2 < 1.0f) {
            f2 = 1.0f;
        } else if (f2 > 1.3f) {
            f2 = 1.3f;
        }
        float f3 = (f2 - 1.0f) / 0.29999995f;
        c2.setViewPadding(2131362348, 0, Math.round((f3 * dimensionPixelSize2) + ((1.0f - f3) * dimensionPixelSize)), 0, 0);
        return c2;
    }
}
