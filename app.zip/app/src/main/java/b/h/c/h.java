package b.h.c;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.io.InputStream;
import java.text.NumberFormat;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\l.smali */
public abstract class l {

    /* renamed from: a */
    public j f1558a;

    public void a(Bundle bundle) {
        String g2 = g();
        if (g2 != null) {
            bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", g2);
        }
    }

    public abstract void b(f fVar);

    public RemoteViews c(boolean z, int i2, boolean z2) {
        boolean z3;
        boolean z4;
        Resources resources = this.f1558a.f1548a.getResources();
        RemoteViews remoteViews = new RemoteViews(this.f1558a.f1548a.getPackageName(), i2);
        j jVar = this.f1558a;
        int i3 = jVar.f1557j;
        if (jVar.f1555h != null) {
            remoteViews.setViewVisibility(2131362146, 0);
            remoteViews.setImageViewBitmap(2131362146, this.f1558a.f1555h);
            if (z && this.f1558a.w.icon != 0) {
                int dimensionPixelSize = resources.getDimensionPixelSize(2131165561);
                int dimensionPixelSize2 = dimensionPixelSize - (resources.getDimensionPixelSize(2131165563) * 2);
                j jVar2 = this.f1558a;
                remoteViews.setImageViewBitmap(2131362446, f(jVar2.w.icon, dimensionPixelSize, dimensionPixelSize2, jVar2.q));
                remoteViews.setViewVisibility(2131362446, 0);
            }
        } else if (z && jVar.w.icon != 0) {
            remoteViews.setViewVisibility(2131362146, 0);
            int dimensionPixelSize3 = resources.getDimensionPixelSize(2131165558) - resources.getDimensionPixelSize(2131165555);
            int dimensionPixelSize4 = resources.getDimensionPixelSize(2131165564);
            j jVar3 = this.f1558a;
            remoteViews.setImageViewBitmap(2131362146, f(jVar3.w.icon, dimensionPixelSize3, dimensionPixelSize4, jVar3.q));
        }
        CharSequence charSequence = this.f1558a.f1552e;
        if (charSequence != null) {
            remoteViews.setTextViewText(2131362568, charSequence);
        }
        CharSequence charSequence2 = this.f1558a.f1553f;
        boolean z5 = true;
        if (charSequence2 != null) {
            remoteViews.setTextViewText(2131362548, charSequence2);
            z3 = true;
        } else {
            z3 = false;
        }
        Objects.requireNonNull(this.f1558a);
        if (this.f1558a.f1556i > 0) {
            if (this.f1558a.f1556i > resources.getInteger(2131427349)) {
                remoteViews.setTextViewText(2131362156, resources.getString(2131886485));
            } else {
                remoteViews.setTextViewText(2131362156, NumberFormat.getIntegerInstance().format(this.f1558a.f1556i));
            }
            remoteViews.setViewVisibility(2131362156, 0);
            z3 = true;
            z4 = true;
        } else {
            remoteViews.setViewVisibility(2131362156, 8);
            z4 = false;
        }
        Objects.requireNonNull(this.f1558a);
        if (this.f1558a.c() != 0) {
            Objects.requireNonNull(this.f1558a);
            remoteViews.setViewVisibility(2131362565, 0);
            remoteViews.setLong(2131362565, "setTime", this.f1558a.c());
        } else {
            z5 = z4;
        }
        remoteViews.setViewVisibility(2131362447, z5 ? 0 : 8);
        remoteViews.setViewVisibility(2131362208, z3 ? 0 : 8);
        return remoteViews;
    }

    public final Bitmap d(int i2, int i3, int i4) {
        Context context = this.f1558a.f1548a;
        PorterDuff.Mode mode = IconCompat.k;
        if (context != null) {
            return e(IconCompat.b(context.getResources(), context.getPackageName(), i2), i3, i4);
        }
        throw new IllegalArgumentException("Context must not be null.");
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public final Bitmap e(IconCompat iconCompat, int i2, int i3) {
        Drawable drawable;
        Drawable drawable2;
        Object obj;
        Context context = this.f1558a.f1548a;
        if (iconCompat.f293a == 2 && (obj = iconCompat.f294b) != null) {
            String str = (String) obj;
            if (str.contains(":")) {
                String str2 = str.split(":", -1)[1];
                String str3 = str2.split("/", -1)[0];
                String str4 = str2.split("/", -1)[1];
                String str5 = str.split(":", -1)[0];
                if ("0_resource_name_obfuscated".equals(str4)) {
                    Log.i("IconCompat", "Found obfuscated resource, not trying to update resource id for it");
                } else {
                    String d2 = iconCompat.d();
                    int identifier = IconCompat.e(context, d2).getIdentifier(str4, str3, str5);
                    if (iconCompat.f297e != identifier) {
                        Log.i("IconCompat", "Id has changed for " + d2 + " " + str);
                        iconCompat.f297e = identifier;
                    }
                }
            }
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 23) {
            drawable2 = iconCompat.j(context).loadDrawable(context);
        } else {
            switch (iconCompat.f293a) {
                case 1:
                    drawable = new BitmapDrawable(context.getResources(), (Bitmap) iconCompat.f294b);
                    break;
                case 2:
                    String d3 = iconCompat.d();
                    if (TextUtils.isEmpty(d3)) {
                        d3 = context.getPackageName();
                    }
                    Resources e2 = IconCompat.e(context, d3);
                    try {
                        int i5 = iconCompat.f297e;
                        Resources.Theme theme = context.getTheme();
                        ThreadLocal<TypedValue> threadLocal = b.h.d.b.h.f1586a;
                        drawable = e2.getDrawable(i5, theme);
                        break;
                    } catch (RuntimeException e3) {
                        Log.e("IconCompat", String.format("Unable to load resource 0x%08x from pkg=%s", Integer.valueOf(iconCompat.f297e), iconCompat.f294b), e3);
                        break;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 3 */:
                    drawable = new BitmapDrawable(context.getResources(), BitmapFactory.decodeByteArray((byte[]) iconCompat.f294b, iconCompat.f297e, iconCompat.f298f));
                    break;
                case 4:
                    InputStream h2 = iconCompat.h(context);
                    if (h2 != null) {
                        drawable = new BitmapDrawable(context.getResources(), BitmapFactory.decodeStream(h2));
                        break;
                    }
                    drawable = null;
                    break;
                case 5:
                    drawable = new BitmapDrawable(context.getResources(), IconCompat.a((Bitmap) iconCompat.f294b, false));
                    break;
                case 6:
                    InputStream h3 = iconCompat.h(context);
                    if (h3 != null) {
                        if (i4 < 26) {
                            drawable = new BitmapDrawable(context.getResources(), IconCompat.a(BitmapFactory.decodeStream(h3), false));
                            break;
                        } else {
                            drawable = new AdaptiveIconDrawable(null, new BitmapDrawable(context.getResources(), BitmapFactory.decodeStream(h3)));
                            break;
                        }
                    }
                    drawable = null;
                    break;
                default:
                    drawable = null;
                    break;
            }
            if (drawable != null && (iconCompat.f299g != null || iconCompat.f300h != IconCompat.k)) {
                drawable.mutate();
                drawable.setTintList(iconCompat.f299g);
                drawable.setTintMode(iconCompat.f300h);
            }
            drawable2 = drawable;
        }
        int intrinsicWidth = i3 == 0 ? drawable2.getIntrinsicWidth() : i3;
        if (i3 == 0) {
            i3 = drawable2.getIntrinsicHeight();
        }
        Bitmap createBitmap = Bitmap.createBitmap(intrinsicWidth, i3, Bitmap.Config.ARGB_8888);
        drawable2.setBounds(0, 0, intrinsicWidth, i3);
        if (i2 != 0) {
            drawable2.mutate().setColorFilter(new PorterDuffColorFilter(i2, PorterDuff.Mode.SRC_IN));
        }
        drawable2.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    public final Bitmap f(int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            i5 = 0;
        }
        Bitmap d2 = d(2131231046, i5, i3);
        Canvas canvas = new Canvas(d2);
        Drawable mutate = this.f1558a.f1548a.getResources().getDrawable(i2).mutate();
        mutate.setFilterBitmap(true);
        int i6 = (i3 - i4) / 2;
        int i7 = i4 + i6;
        mutate.setBounds(i6, i6, i7, i7);
        mutate.setColorFilter(new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
        mutate.draw(canvas);
        return d2;
    }

    public String g() {
        return null;
    }

    public RemoteViews h(f fVar) {
        return null;
    }

    public RemoteViews i(f fVar) {
        return null;
    }

    public RemoteViews j(f fVar) {
        return null;
    }

    public void k(j jVar) {
        if (this.f1558a != jVar) {
            this.f1558a = jVar;
            if (jVar.l != this) {
                jVar.l = this;
                k(jVar);
            }
        }
    }
}
