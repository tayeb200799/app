package b.h.c;

import android.app.Notification;
import android.graphics.Bitmap;
import android.os.Build;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\h.smali */
public class h extends l {

    /* renamed from: b */
    public Bitmap f1544b;

    /* renamed from: c */
    public IconCompat f1545c;

    /* renamed from: d */
    public boolean f1546d;

    @Override // b.h.c.l
    public void b(f fVar) {
        int i2 = Build.VERSION.SDK_INT;
        m mVar = (m) fVar;
        Bitmap bitmap = null;
        Notification.BigPictureStyle bigPicture = new Notification.BigPictureStyle(mVar.f1560b).setBigContentTitle(null).bigPicture(this.f1544b);
        if (this.f1546d) {
            IconCompat iconCompat = this.f1545c;
            if (iconCompat == null) {
                bigPicture.bigLargeIcon((Bitmap) null);
                return;
            }
            if (i2 >= 23) {
                bigPicture.bigLargeIcon(iconCompat.j(mVar.f1559a));
                return;
            }
            if (iconCompat.f() != 1) {
                bigPicture.bigLargeIcon((Bitmap) null);
                return;
            }
            IconCompat iconCompat2 = this.f1545c;
            int i3 = iconCompat2.f293a;
            if (i3 == -1 && i2 >= 23) {
                Object obj = iconCompat2.f294b;
                if (obj instanceof Bitmap) {
                    bitmap = (Bitmap) obj;
                }
            } else if (i3 == 1) {
                bitmap = (Bitmap) iconCompat2.f294b;
            } else {
                if (i3 != 5) {
                    throw new IllegalStateException("called getBitmap() on " + iconCompat2);
                }
                bitmap = IconCompat.a((Bitmap) iconCompat2.f294b, true);
            }
            bigPicture.bigLargeIcon(bitmap);
        }
    }

    @Override // b.h.c.l
    public String g() {
        return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }

    public h l(Bitmap bitmap) {
        this.f1545c = null;
        this.f1546d = true;
        return this;
    }
}
