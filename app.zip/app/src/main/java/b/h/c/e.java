package b.h.c;

import android.app.Notification;
import android.os.Bundle;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\c\i.smali */
public class i extends l {

    /* renamed from: b */
    public CharSequence f1547b;

    @Override // b.h.c.l
    public void a(Bundle bundle) {
        bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", "androidx.core.app.NotificationCompat$BigTextStyle");
    }

    @Override // b.h.c.l
    public void b(f fVar) {
        new Notification.BigTextStyle(((m) fVar).f1560b).setBigContentTitle(null).bigText(this.f1547b);
    }

    @Override // b.h.c.l
    public String g() {
        return "androidx.core.app.NotificationCompat$BigTextStyle";
    }

    public i l(CharSequence charSequence) {
        this.f1547b = j.d(charSequence);
        return this;
    }
}
