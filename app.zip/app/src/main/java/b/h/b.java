package b.h;

import android.R;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\h\b.smali */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f1507a = {R.attr.color, R.attr.alpha, 2130968618};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f1508b = {2130968988, 2130968989, 2130968990, 2130968991, 2130968992, 2130968993, 2130968994};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f1509c = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, 2130968986, 2130968995, 2130968996, 2130968997, 2130969573};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f1510d = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f1511e = {R.attr.color, R.attr.offset};
}
