package b.b0.a;

import android.graphics.Rect;
import android.view.View;
import androidx.viewpager.widget.ViewPager;
import b.h.k.j;
import b.h.k.q;
import b.h.k.x;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b0\a\b.smali */
public class b implements j {

    /* renamed from: a, reason: collision with root package name */
    public final Rect f1119a = new Rect();

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewPager f1120b;

    public b(ViewPager viewPager) {
        this.f1120b = viewPager;
    }

    @Override // b.h.k.j
    public x a(View view, x xVar) {
        x p = q.p(view, xVar);
        if (p.f()) {
            return p;
        }
        Rect rect = this.f1119a;
        rect.left = p.b();
        rect.top = p.d();
        rect.right = p.c();
        rect.bottom = p.a();
        int childCount = this.f1120b.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            x e2 = q.e(this.f1120b.getChildAt(i2), p);
            rect.left = Math.min(e2.b(), rect.left);
            rect.top = Math.min(e2.d(), rect.top);
            rect.right = Math.min(e2.c(), rect.right);
            rect.bottom = Math.min(e2.a(), rect.bottom);
        }
        return p.g(rect.left, rect.top, rect.right, rect.bottom);
    }
}
