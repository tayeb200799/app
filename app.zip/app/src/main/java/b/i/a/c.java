package b.j.b;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import b.e.i;
import b.h.k.q;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\j\b\a.smali */
public abstract class a extends b.h.k.a {
    public static final Rect n = new Rect(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    public static final b.j.b.b<b.h.k.y.b> o = new C0038a();
    public static final b.j.b.c<i<b.h.k.y.b>, b.h.k.y.b> p = new b();

    /* renamed from: h, reason: collision with root package name */
    public final AccessibilityManager f1848h;

    /* renamed from: i, reason: collision with root package name */
    public final View f1849i;

    /* renamed from: j, reason: collision with root package name */
    public c f1850j;

    /* renamed from: d, reason: collision with root package name */
    public final Rect f1844d = new Rect();

    /* renamed from: e, reason: collision with root package name */
    public final Rect f1845e = new Rect();

    /* renamed from: f, reason: collision with root package name */
    public final Rect f1846f = new Rect();

    /* renamed from: g, reason: collision with root package name */
    public final int[] f1847g = new int[2];
    public int k = Integer.MIN_VALUE;
    public int l = Integer.MIN_VALUE;
    private int m = Integer.MIN_VALUE;

    /* renamed from: b.j.b.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\j\b\a$a.smali */
    public static class C0038a implements b.j.b.b<b.h.k.y.b> {
        public void a(Object obj, Rect rect) {
            ((b.h.k.y.b) obj).f1790a.getBoundsInParent(rect);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\j\b\a$b.smali */
    public static class b implements b.j.b.c<i<b.h.k.y.b>, b.h.k.y.b> {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\j\b\a$c.smali */
    public class c extends b.h.k.y.c {
        public c() {
        }

        @Override // b.h.k.y.c
        public b.h.k.y.b a(int i2) {
            return new b.h.k.y.b(AccessibilityNodeInfo.obtain(a.this.q(i2).f1790a));
        }

        @Override // b.h.k.y.c
        public b.h.k.y.b b(int i2) {
            int i3 = i2 == 2 ? a.this.k : a.this.l;
            if (i3 == Integer.MIN_VALUE) {
                return null;
            }
            return new b.h.k.y.b(AccessibilityNodeInfo.obtain(a.this.q(i3).f1790a));
        }

        @Override // b.h.k.y.c
        public boolean c(int i2, int i3, Bundle bundle) {
            int i4;
            a aVar = a.this;
            if (i2 == -1) {
                View view = aVar.f1849i;
                AtomicInteger atomicInteger = q.f1738a;
                return view.performAccessibilityAction(i3, bundle);
            }
            boolean z = true;
            if (i3 == 1) {
                return aVar.v(i2);
            }
            if (i3 == 2) {
                return aVar.k(i2);
            }
            if (i3 != 64) {
                return i3 != 128 ? aVar.r(i2, i3, bundle) : aVar.j(i2);
            }
            if (aVar.f1848h.isEnabled() && aVar.f1848h.isTouchExplorationEnabled() && (i4 = aVar.k) != i2) {
                if (i4 != Integer.MIN_VALUE) {
                    aVar.j(i4);
                }
                aVar.k = i2;
                aVar.f1849i.invalidate();
                aVar.w(i2, 32768);
            } else {
                z = false;
            }
            return z;
        }
    }

    public a(View view) {
        if (view == null) {
            throw new IllegalArgumentException("View may not be null");
        }
        this.f1849i = view;
        this.f1848h = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        view.setFocusable(true);
        AtomicInteger atomicInteger = q.f1738a;
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
        }
    }

    @Override // b.h.k.a
    public b.h.k.y.c b(View view) {
        if (this.f1850j == null) {
            this.f1850j = new c();
        }
        return this.f1850j;
    }

    @Override // b.h.k.a
    public void c(View view, AccessibilityEvent accessibilityEvent) {
        this.f1718a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    @Override // b.h.k.a
    public void d(View view, b.h.k.y.b bVar) {
        this.f1718a.onInitializeAccessibilityNodeInfo(view, bVar.f1790a);
        s(bVar);
    }

    public final boolean j(int i2) {
        if (this.k != i2) {
            return false;
        }
        this.k = Integer.MIN_VALUE;
        this.f1849i.invalidate();
        w(i2, 65536);
        return true;
    }

    public final boolean k(int i2) {
        if (this.l != i2) {
            return false;
        }
        this.l = Integer.MIN_VALUE;
        u(i2, false);
        w(i2, 8);
        return true;
    }

    public final b.h.k.y.b l(int i2) {
        AccessibilityNodeInfo obtain = AccessibilityNodeInfo.obtain();
        b.h.k.y.b bVar = new b.h.k.y.b(obtain);
        obtain.setEnabled(true);
        bVar.f1790a.setFocusable(true);
        bVar.f1790a.setClassName("android.view.View");
        Rect rect = n;
        bVar.f1790a.setBoundsInParent(rect);
        bVar.f1790a.setBoundsInScreen(rect);
        View view = this.f1849i;
        bVar.f1791b = -1;
        bVar.f1790a.setParent(view);
        t(i2, bVar);
        if (bVar.g() == null && bVar.e() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
        }
        bVar.f1790a.getBoundsInParent(this.f1845e);
        if (this.f1845e.equals(rect)) {
            throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
        }
        int actions = bVar.f1790a.getActions();
        if ((actions & 64) != 0) {
            throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        if ((actions & 128) != 0) {
            throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        bVar.f1790a.setPackageName(this.f1849i.getContext().getPackageName());
        View view2 = this.f1849i;
        bVar.f1792c = i2;
        bVar.f1790a.setSource(view2, i2);
        boolean z = false;
        if (this.k == i2) {
            bVar.f1790a.setAccessibilityFocused(true);
            bVar.f1790a.addAction(128);
        } else {
            bVar.f1790a.setAccessibilityFocused(false);
            bVar.f1790a.addAction(64);
        }
        boolean z2 = this.l == i2;
        if (z2) {
            bVar.f1790a.addAction(2);
        } else if (bVar.f1790a.isFocusable()) {
            bVar.f1790a.addAction(1);
        }
        bVar.f1790a.setFocused(z2);
        this.f1849i.getLocationOnScreen(this.f1847g);
        bVar.f1790a.getBoundsInScreen(this.f1844d);
        if (this.f1844d.equals(rect)) {
            bVar.f1790a.getBoundsInParent(this.f1844d);
            if (bVar.f1791b != -1) {
                b.h.k.y.b bVar2 = new b.h.k.y.b(AccessibilityNodeInfo.obtain());
                for (int i3 = bVar.f1791b; i3 != -1; i3 = bVar2.f1791b) {
                    View view3 = this.f1849i;
                    bVar2.f1791b = -1;
                    bVar2.f1790a.setParent(view3, -1);
                    bVar2.f1790a.setBoundsInParent(n);
                    t(i3, bVar2);
                    bVar2.f1790a.getBoundsInParent(this.f1845e);
                    Rect rect2 = this.f1844d;
                    Rect rect3 = this.f1845e;
                    rect2.offset(rect3.left, rect3.top);
                }
                bVar2.f1790a.recycle();
            }
            this.f1844d.offset(this.f1847g[0] - this.f1849i.getScrollX(), this.f1847g[1] - this.f1849i.getScrollY());
        }
        if (this.f1849i.getLocalVisibleRect(this.f1846f)) {
            this.f1846f.offset(this.f1847g[0] - this.f1849i.getScrollX(), this.f1847g[1] - this.f1849i.getScrollY());
            if (this.f1844d.intersect(this.f1846f)) {
                bVar.f1790a.setBoundsInScreen(this.f1844d);
                Rect rect4 = this.f1844d;
                if (rect4 != null && !rect4.isEmpty() && this.f1849i.getWindowVisibility() == 0) {
                    Object parent = this.f1849i.getParent();
                    while (true) {
                        if (parent instanceof View) {
                            View view4 = (View) parent;
                            if (view4.getAlpha() <= 0.0f || view4.getVisibility() != 0) {
                                break;
                            }
                            parent = view4.getParent();
                        } else if (parent != null) {
                            z = true;
                        }
                    }
                }
                if (z) {
                    bVar.f1790a.setVisibleToUser(true);
                }
            }
        }
        return bVar;
    }

    public final boolean m(MotionEvent motionEvent) {
        int i2;
        if (this.f1848h.isEnabled() && this.f1848h.isTouchExplorationEnabled()) {
            int action = motionEvent.getAction();
            if (action != 7 && action != 9) {
                if (action != 10 || (i2 = this.m) == Integer.MIN_VALUE) {
                    return false;
                }
                if (i2 != Integer.MIN_VALUE) {
                    this.m = Integer.MIN_VALUE;
                    w(Integer.MIN_VALUE, 128);
                    w(i2, 256);
                }
                return true;
            }
            int n2 = n(motionEvent.getX(), motionEvent.getY());
            int i3 = this.m;
            if (i3 != n2) {
                this.m = n2;
                w(n2, 128);
                w(i3, 256);
            }
            if (n2 != Integer.MIN_VALUE) {
                return true;
            }
        }
        return false;
    }

    public abstract int n(float f2, float f3);

    public abstract void o(List<Integer> list);

    /* JADX WARN: Code restructure failed: missing block: B:45:0x0138, code lost:
    
        if (r13 < ((r17 * r17) + ((r12 * 13) * r12))) goto L70;
     */
    /* JADX WARN: Removed duplicated region for block: B:48:0x013f  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0144 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean p(int r20, android.graphics.Rect r21) {
        /*
            Method dump skipped, instructions count: 482
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.b.a.p(int, android.graphics.Rect):boolean");
    }

    public b.h.k.y.b q(int i2) {
        if (i2 != -1) {
            return l(i2);
        }
        AccessibilityNodeInfo obtain = AccessibilityNodeInfo.obtain(this.f1849i);
        b.h.k.y.b bVar = new b.h.k.y.b(obtain);
        View view = this.f1849i;
        AtomicInteger atomicInteger = q.f1738a;
        view.onInitializeAccessibilityNodeInfo(obtain);
        ArrayList arrayList = new ArrayList();
        o(arrayList);
        if (bVar.f1790a.getChildCount() > 0 && arrayList.size() > 0) {
            throw new RuntimeException("Views cannot have both real and virtual children");
        }
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            bVar.f1790a.addChild(this.f1849i, ((Integer) arrayList.get(i3)).intValue());
        }
        return bVar;
    }

    public abstract boolean r(int i2, int i3, Bundle bundle);

    public void s(b.h.k.y.b bVar) {
    }

    public abstract void t(int i2, b.h.k.y.b bVar);

    public void u(int i2, boolean z) {
    }

    public final boolean v(int i2) {
        int i3;
        if ((!this.f1849i.isFocused() && !this.f1849i.requestFocus()) || (i3 = this.l) == i2) {
            return false;
        }
        if (i3 != Integer.MIN_VALUE) {
            k(i3);
        }
        this.l = i2;
        u(i2, true);
        w(i2, 8);
        return true;
    }

    public final boolean w(int i2, int i3) {
        ViewParent parent;
        AccessibilityEvent obtain;
        if (i2 == Integer.MIN_VALUE || !this.f1848h.isEnabled() || (parent = this.f1849i.getParent()) == null) {
            return false;
        }
        if (i2 != -1) {
            obtain = AccessibilityEvent.obtain(i3);
            b.h.k.y.b q = q(i2);
            obtain.getText().add(q.g());
            obtain.setContentDescription(q.e());
            obtain.setScrollable(q.f1790a.isScrollable());
            obtain.setPassword(q.f1790a.isPassword());
            obtain.setEnabled(q.f1790a.isEnabled());
            obtain.setChecked(q.f1790a.isChecked());
            if (obtain.getText().isEmpty() && obtain.getContentDescription() == null) {
                throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
            }
            obtain.setClassName(q.f1790a.getClassName());
            obtain.setSource(this.f1849i, i2);
            obtain.setPackageName(this.f1849i.getContext().getPackageName());
        } else {
            obtain = AccessibilityEvent.obtain(i3);
            this.f1849i.onInitializeAccessibilityEvent(obtain);
        }
        return parent.requestSendAccessibilityEvent(this.f1849i, obtain);
    }

    public final void x(int i2) {
        int i3 = this.m;
        if (i3 == i2) {
            return;
        }
        this.m = i2;
        w(i2, 128);
        w(i3, 256);
    }
}
