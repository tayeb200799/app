package b.i.a;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import b.i.a.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\i\a\a.smali */
public abstract class a extends BaseAdapter implements Filterable, b.a {

    /* renamed from: d, reason: collision with root package name */
    public boolean f1835d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1836e;

    /* renamed from: f, reason: collision with root package name */
    public Cursor f1837f;

    /* renamed from: g, reason: collision with root package name */
    public Context f1838g;

    /* renamed from: h, reason: collision with root package name */
    public int f1839h;

    /* renamed from: i, reason: collision with root package name */
    public C0036a f1840i;

    /* renamed from: j, reason: collision with root package name */
    public DataSetObserver f1841j;
    public b.i.a.b k;

    /* renamed from: b.i.a.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\i\a\a$a.smali */
    public class C0036a extends ContentObserver {
        public C0036a() {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return true;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z) {
            Cursor cursor;
            a aVar = a.this;
            if (!aVar.f1836e || (cursor = aVar.f1837f) == null || cursor.isClosed()) {
                return;
            }
            aVar.f1835d = aVar.f1837f.requery();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\i\a\a$b.smali */
    public class b extends DataSetObserver {
        public b() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            a aVar = a.this;
            aVar.f1835d = true;
            aVar.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            a aVar = a.this;
            aVar.f1835d = false;
            aVar.notifyDataSetInvalidated();
        }
    }

    public a(Context context, Cursor cursor, boolean z) {
        int i2 = z ? 1 : 2;
        if ((i2 & 1) == 1) {
            i2 |= 2;
            this.f1836e = true;
        } else {
            this.f1836e = false;
        }
        boolean z2 = cursor != null;
        this.f1837f = cursor;
        this.f1835d = z2;
        this.f1838g = context;
        this.f1839h = z2 ? cursor.getColumnIndexOrThrow("_id") : -1;
        if ((i2 & 2) == 2) {
            this.f1840i = new C0036a();
            this.f1841j = new b();
        } else {
            this.f1840i = null;
            this.f1841j = null;
        }
        if (z2) {
            C0036a c0036a = this.f1840i;
            if (c0036a != null) {
                cursor.registerContentObserver(c0036a);
            }
            DataSetObserver dataSetObserver = this.f1841j;
            if (dataSetObserver != null) {
                cursor.registerDataSetObserver(dataSetObserver);
            }
        }
    }

    public abstract void a(View view, Context context, Cursor cursor);

    public void b(Cursor cursor) {
        Cursor cursor2 = this.f1837f;
        if (cursor == cursor2) {
            cursor2 = null;
        } else {
            if (cursor2 != null) {
                C0036a c0036a = this.f1840i;
                if (c0036a != null) {
                    cursor2.unregisterContentObserver(c0036a);
                }
                DataSetObserver dataSetObserver = this.f1841j;
                if (dataSetObserver != null) {
                    cursor2.unregisterDataSetObserver(dataSetObserver);
                }
            }
            this.f1837f = cursor;
            if (cursor != null) {
                C0036a c0036a2 = this.f1840i;
                if (c0036a2 != null) {
                    cursor.registerContentObserver(c0036a2);
                }
                DataSetObserver dataSetObserver2 = this.f1841j;
                if (dataSetObserver2 != null) {
                    cursor.registerDataSetObserver(dataSetObserver2);
                }
                this.f1839h = cursor.getColumnIndexOrThrow("_id");
                this.f1835d = true;
                notifyDataSetChanged();
            } else {
                this.f1839h = -1;
                this.f1835d = false;
                notifyDataSetInvalidated();
            }
        }
        if (cursor2 != null) {
            cursor2.close();
        }
    }

    public abstract CharSequence c(Cursor cursor);

    public abstract View d(Context context, Cursor cursor, ViewGroup viewGroup);

    @Override // android.widget.Adapter
    public int getCount() {
        Cursor cursor;
        if (!this.f1835d || (cursor = this.f1837f) == null) {
            return 0;
        }
        return cursor.getCount();
    }

    @Override // android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
        if (!this.f1835d) {
            return null;
        }
        this.f1837f.moveToPosition(i2);
        if (view == null) {
            c cVar = (c) this;
            view = cVar.n.inflate(cVar.m, viewGroup, false);
        }
        a(view, this.f1838g, this.f1837f);
        return view;
    }

    @Override // android.widget.Filterable
    public Filter getFilter() {
        if (this.k == null) {
            this.k = new b.i.a.b(this);
        }
        return this.k;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i2) {
        Cursor cursor;
        if (!this.f1835d || (cursor = this.f1837f) == null) {
            return null;
        }
        cursor.moveToPosition(i2);
        return this.f1837f;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        Cursor cursor;
        if (this.f1835d && (cursor = this.f1837f) != null && cursor.moveToPosition(i2)) {
            return this.f1837f.getLong(this.f1839h);
        }
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (!this.f1835d) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        }
        if (!this.f1837f.moveToPosition(i2)) {
            throw new IllegalStateException(c.a.a.a.a.c("couldn't move cursor to position ", i2));
        }
        if (view == null) {
            view = d(this.f1838g, this.f1837f, viewGroup);
        }
        a(view, this.f1838g, this.f1837f);
        return view;
    }
}
