package b.r.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\r\a\a.smali */
public final class a {

    /* renamed from: f */
    public static final Object f2170f = new Object();

    /* renamed from: g */
    public static a f2171g;

    /* renamed from: a */
    public final Context f2172a;

    /* renamed from: b */
    public final HashMap<BroadcastReceiver, ArrayList<c>> f2173b = new HashMap<>();

    /* renamed from: c */
    public final HashMap<String, ArrayList<c>> f2174c = new HashMap<>();

    /* renamed from: d */
    public final ArrayList<b> f2175d = new ArrayList<>();

    /* renamed from: e */
    public final Handler f2176e;

    /* renamed from: b.r.a.a$a */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\r\a\a$a.smali */
    public class HandlerC0046a extends Handler {
        public HandlerC0046a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int size;
            b[] bVarArr;
            if (message.what != 1) {
                super.handleMessage(message);
                return;
            }
            a aVar = a.this;
            while (true) {
                synchronized (aVar.f2173b) {
                    size = aVar.f2175d.size();
                    if (size <= 0) {
                        return;
                    }
                    bVarArr = new b[size];
                    aVar.f2175d.toArray(bVarArr);
                    aVar.f2175d.clear();
                }
                for (int i2 = 0; i2 < size; i2++) {
                    b bVar = bVarArr[i2];
                    int size2 = bVar.f2179b.size();
                    for (int i3 = 0; i3 < size2; i3++) {
                        c cVar = bVar.f2179b.get(i3);
                        if (!cVar.f2183d) {
                            cVar.f2181b.onReceive(aVar.f2172a, bVar.f2178a);
                        }
                    }
                }
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\r\a\a$b.smali */
    public static final class b {

        /* renamed from: a */
        public final Intent f2178a;

        /* renamed from: b */
        public final ArrayList<c> f2179b;

        public b(Intent intent, ArrayList<c> arrayList) {
            this.f2178a = intent;
            this.f2179b = arrayList;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\r\a\a$c.smali */
    public static final class c {

        /* renamed from: a */
        public final IntentFilter f2180a;

        /* renamed from: b */
        public final BroadcastReceiver f2181b;

        /* renamed from: c */
        public boolean f2182c;

        /* renamed from: d */
        public boolean f2183d;

        public c(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
            this.f2180a = intentFilter;
            this.f2181b = broadcastReceiver;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(128);
            sb.append("Receiver{");
            sb.append(this.f2181b);
            sb.append(" filter=");
            sb.append(this.f2180a);
            if (this.f2183d) {
                sb.append(" DEAD");
            }
            sb.append("}");
            return sb.toString();
        }
    }

    public a(Context context) {
        this.f2172a = context;
        this.f2176e = new HandlerC0046a(context.getMainLooper());
    }

    public static a a(Context context) {
        a aVar;
        synchronized (f2170f) {
            if (f2171g == null) {
                f2171g = new a(context.getApplicationContext());
            }
            aVar = f2171g;
        }
        return aVar;
    }
}
