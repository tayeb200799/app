package b.q.a;

import b.p.a0;
import b.p.k;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\q\a\a.smali */
public abstract class a {
    public static <T extends k & a0> a b(T t) {
        return new b(t, t.q());
    }

    @Deprecated
    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);
}
