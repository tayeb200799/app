package b.f.a;

import java.util.Arrays;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\g.smali */
public class g implements Comparable<g> {
    public static int q = 1;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1241d;

    /* renamed from: h, reason: collision with root package name */
    public float f1245h;
    public a l;

    /* renamed from: e, reason: collision with root package name */
    public int f1242e = -1;

    /* renamed from: f, reason: collision with root package name */
    public int f1243f = -1;

    /* renamed from: g, reason: collision with root package name */
    public int f1244g = 0;

    /* renamed from: i, reason: collision with root package name */
    public boolean f1246i = false;

    /* renamed from: j, reason: collision with root package name */
    public float[] f1247j = new float[9];
    public float[] k = new float[9];
    public b[] m = new b[16];
    public int n = 0;
    public int o = 0;
    public int p = -1;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\g$a.smali */
    public enum a {
        UNRESTRICTED,
        CONSTANT,
        SLACK,
        ERROR,
        UNKNOWN
    }

    public g(a aVar) {
        this.l = aVar;
    }

    @Override // java.lang.Comparable
    public int compareTo(g gVar) {
        return this.f1242e - gVar.f1242e;
    }

    public final void f(b bVar) {
        int i2 = 0;
        while (true) {
            int i3 = this.n;
            if (i2 >= i3) {
                b[] bVarArr = this.m;
                if (i3 >= bVarArr.length) {
                    this.m = (b[]) Arrays.copyOf(bVarArr, bVarArr.length * 2);
                }
                b[] bVarArr2 = this.m;
                int i4 = this.n;
                bVarArr2[i4] = bVar;
                this.n = i4 + 1;
                return;
            }
            if (this.m[i2] == bVar) {
                return;
            } else {
                i2++;
            }
        }
    }

    public final void h(b bVar) {
        int i2 = this.n;
        int i3 = 0;
        while (i3 < i2) {
            if (this.m[i3] == bVar) {
                while (i3 < i2 - 1) {
                    b[] bVarArr = this.m;
                    int i4 = i3 + 1;
                    bVarArr[i3] = bVarArr[i4];
                    i3 = i4;
                }
                this.n--;
                return;
            }
            i3++;
        }
    }

    public void i() {
        this.l = a.UNKNOWN;
        this.f1244g = 0;
        this.f1242e = -1;
        this.f1243f = -1;
        this.f1245h = 0.0f;
        this.f1246i = false;
        this.p = -1;
        int i2 = this.n;
        for (int i3 = 0; i3 < i2; i3++) {
            this.m[i3] = null;
        }
        this.n = 0;
        this.o = 0;
        this.f1241d = false;
        Arrays.fill(this.k, 0.0f);
    }

    public void j(d dVar, float f2) {
        this.f1245h = f2;
        this.f1246i = true;
        this.p = -1;
        int i2 = this.n;
        this.f1243f = -1;
        for (int i3 = 0; i3 < i2; i3++) {
            this.m[i3].k(dVar, this, false);
        }
        this.n = 0;
    }

    public final void m(d dVar, b bVar) {
        int i2 = this.n;
        for (int i3 = 0; i3 < i2; i3++) {
            this.m[i3].l(dVar, bVar, false);
        }
        this.n = 0;
    }

    public String toString() {
        StringBuilder n = c.a.a.a.a.n("");
        n.append(this.f1242e);
        return n.toString();
    }
}
