package b.f.a.i.l;

import b.f.a.i.l.f;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\g.smali */
public class g extends f {
    public int m;

    public g(o oVar) {
        super(oVar);
        if (oVar instanceof k) {
            this.f1324e = f.a.HORIZONTAL_DIMENSION;
        } else {
            this.f1324e = f.a.VERTICAL_DIMENSION;
        }
    }

    @Override // b.f.a.i.l.f
    public void c(int i2) {
        if (this.f1329j) {
            return;
        }
        this.f1329j = true;
        this.f1326g = i2;
        for (d dVar : this.k) {
            dVar.a(dVar);
        }
    }
}
