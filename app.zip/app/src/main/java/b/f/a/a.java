package b.f.a;

import b.f.a.g;
import java.util.Arrays;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\d.smali */
public class d {
    public static boolean p = false;
    public static int q = 1000;
    public static long r;

    /* renamed from: c, reason: collision with root package name */
    public a f1224c;

    /* renamed from: f, reason: collision with root package name */
    public b[] f1227f;
    public final c l;
    public a o;

    /* renamed from: a, reason: collision with root package name */
    public boolean f1222a = false;

    /* renamed from: b, reason: collision with root package name */
    public int f1223b = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f1225d = 32;

    /* renamed from: e, reason: collision with root package name */
    public int f1226e = 32;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1228g = false;

    /* renamed from: h, reason: collision with root package name */
    public boolean[] f1229h = new boolean[32];

    /* renamed from: i, reason: collision with root package name */
    public int f1230i = 1;

    /* renamed from: j, reason: collision with root package name */
    public int f1231j = 0;
    public int k = 32;
    public g[] m = new g[q];
    public int n = 0;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\d$a.smali */
    public interface a {
        g a(d dVar, boolean[] zArr);

        void b(g gVar);

        void clear();

        boolean isEmpty();
    }

    public d() {
        this.f1227f = null;
        this.f1227f = new b[32];
        t();
        c cVar = new c();
        this.l = cVar;
        this.f1224c = new f(cVar);
        this.o = new b(cVar);
    }

    public final g a(g.a aVar, String str) {
        g a2 = this.l.f1220c.a();
        if (a2 == null) {
            a2 = new g(aVar);
            a2.l = aVar;
        } else {
            a2.i();
            a2.l = aVar;
        }
        int i2 = this.n;
        int i3 = q;
        if (i2 >= i3) {
            int i4 = i3 * 2;
            q = i4;
            this.m = (g[]) Arrays.copyOf(this.m, i4);
        }
        g[] gVarArr = this.m;
        int i5 = this.n;
        this.n = i5 + 1;
        gVarArr[i5] = a2;
        return a2;
    }

    public void b(g gVar, g gVar2, int i2, float f2, g gVar3, g gVar4, int i3, int i4) {
        b m = m();
        if (gVar2 == gVar3) {
            m.f1216d.g(gVar, 1.0f);
            m.f1216d.g(gVar4, 1.0f);
            m.f1216d.g(gVar2, -2.0f);
        } else if (f2 == 0.5f) {
            m.f1216d.g(gVar, 1.0f);
            m.f1216d.g(gVar2, -1.0f);
            m.f1216d.g(gVar3, -1.0f);
            m.f1216d.g(gVar4, 1.0f);
            if (i2 > 0 || i3 > 0) {
                m.f1214b = (-i2) + i3;
            }
        } else if (f2 <= 0.0f) {
            m.f1216d.g(gVar, -1.0f);
            m.f1216d.g(gVar2, 1.0f);
            m.f1214b = i2;
        } else if (f2 >= 1.0f) {
            m.f1216d.g(gVar4, -1.0f);
            m.f1216d.g(gVar3, 1.0f);
            m.f1214b = -i3;
        } else {
            float f3 = 1.0f - f2;
            m.f1216d.g(gVar, f3 * 1.0f);
            m.f1216d.g(gVar2, f3 * (-1.0f));
            m.f1216d.g(gVar3, (-1.0f) * f2);
            m.f1216d.g(gVar4, 1.0f * f2);
            if (i2 > 0 || i3 > 0) {
                m.f1214b = (i3 * f2) + ((-i2) * f3);
            }
        }
        if (i4 != 8) {
            m.c(this, i4);
        }
        c(m);
    }

    /* JADX WARN: Removed duplicated region for block: B:132:0x01bb A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:133:0x01bc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void c(b.f.a.b r17) {
        /*
            Method dump skipped, instructions count: 453
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.d.c(b.f.a.b):void");
    }

    public b d(g gVar, g gVar2, int i2, int i3) {
        if (i3 == 8 && gVar2.f1246i && gVar.f1243f == -1) {
            gVar.j(this, gVar2.f1245h + i2);
            return null;
        }
        b m = m();
        boolean z = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z = true;
            }
            m.f1214b = i2;
        }
        if (z) {
            m.f1216d.g(gVar, 1.0f);
            m.f1216d.g(gVar2, -1.0f);
        } else {
            m.f1216d.g(gVar, -1.0f);
            m.f1216d.g(gVar2, 1.0f);
        }
        if (i3 != 8) {
            m.c(this, i3);
        }
        c(m);
        return m;
    }

    public void e(g gVar, int i2) {
        int i3 = gVar.f1243f;
        if (i3 == -1) {
            gVar.j(this, i2);
            for (int i4 = 0; i4 < this.f1223b + 1; i4++) {
                g gVar2 = this.l.f1221d[i4];
            }
            return;
        }
        if (i3 == -1) {
            b m = m();
            m.f1213a = gVar;
            float f2 = i2;
            gVar.f1245h = f2;
            m.f1214b = f2;
            m.f1217e = true;
            c(m);
            return;
        }
        b bVar = this.f1227f[i3];
        if (bVar.f1217e) {
            bVar.f1214b = i2;
            return;
        }
        if (bVar.f1216d.c() == 0) {
            bVar.f1217e = true;
            bVar.f1214b = i2;
            return;
        }
        b m2 = m();
        if (i2 < 0) {
            m2.f1214b = i2 * (-1);
            m2.f1216d.g(gVar, 1.0f);
        } else {
            m2.f1214b = i2;
            m2.f1216d.g(gVar, -1.0f);
        }
        c(m2);
    }

    public void f(g gVar, g gVar2, int i2, int i3) {
        b m = m();
        g n = n();
        n.f1244g = 0;
        m.e(gVar, gVar2, n, i2);
        if (i3 != 8) {
            m.f1216d.g(k(i3, null), (int) (m.f1216d.d(n) * (-1.0f)));
        }
        c(m);
    }

    public void g(g gVar, g gVar2, int i2, int i3) {
        b m = m();
        g n = n();
        n.f1244g = 0;
        m.f(gVar, gVar2, n, i2);
        if (i3 != 8) {
            m.f1216d.g(k(i3, null), (int) (m.f1216d.d(n) * (-1.0f)));
        }
        c(m);
    }

    public void h(g gVar, g gVar2, g gVar3, g gVar4, float f2, int i2) {
        b m = m();
        m.d(gVar, gVar2, gVar3, gVar4, f2);
        if (i2 != 8) {
            m.c(this, i2);
        }
        c(m);
    }

    public final void i(b bVar) {
        int i2;
        if (bVar.f1217e) {
            bVar.f1213a.j(this, bVar.f1214b);
        } else {
            b[] bVarArr = this.f1227f;
            int i3 = this.f1231j;
            bVarArr[i3] = bVar;
            g gVar = bVar.f1213a;
            gVar.f1243f = i3;
            this.f1231j = i3 + 1;
            gVar.m(this, bVar);
        }
        if (this.f1222a) {
            int i4 = 0;
            while (i4 < this.f1231j) {
                if (this.f1227f[i4] == null) {
                    System.out.println("WTF");
                }
                b[] bVarArr2 = this.f1227f;
                if (bVarArr2[i4] != null && bVarArr2[i4].f1217e) {
                    b bVar2 = bVarArr2[i4];
                    bVar2.f1213a.j(this, bVar2.f1214b);
                    this.l.f1219b.b(bVar2);
                    this.f1227f[i4] = null;
                    int i5 = i4 + 1;
                    int i6 = i5;
                    while (true) {
                        i2 = this.f1231j;
                        if (i5 >= i2) {
                            break;
                        }
                        b[] bVarArr3 = this.f1227f;
                        int i7 = i5 - 1;
                        bVarArr3[i7] = bVarArr3[i5];
                        if (bVarArr3[i7].f1213a.f1243f == i5) {
                            bVarArr3[i7].f1213a.f1243f = i7;
                        }
                        i6 = i5;
                        i5++;
                    }
                    if (i6 < i2) {
                        this.f1227f[i6] = null;
                    }
                    this.f1231j = i2 - 1;
                    i4--;
                }
                i4++;
            }
            this.f1222a = false;
        }
    }

    public final void j() {
        for (int i2 = 0; i2 < this.f1231j; i2++) {
            b bVar = this.f1227f[i2];
            bVar.f1213a.f1245h = bVar.f1214b;
        }
    }

    public g k(int i2, String str) {
        if (this.f1230i + 1 >= this.f1226e) {
            p();
        }
        g a2 = a(g.a.ERROR, str);
        int i3 = this.f1223b + 1;
        this.f1223b = i3;
        this.f1230i++;
        a2.f1242e = i3;
        a2.f1244g = i2;
        this.l.f1221d[i3] = a2;
        this.f1224c.b(a2);
        return a2;
    }

    public g l(Object obj) {
        g gVar = null;
        if (obj == null) {
            return null;
        }
        if (this.f1230i + 1 >= this.f1226e) {
            p();
        }
        if (obj instanceof b.f.a.i.c) {
            b.f.a.i.c cVar = (b.f.a.i.c) obj;
            gVar = cVar.f1275i;
            if (gVar == null) {
                cVar.i();
                gVar = cVar.f1275i;
            }
            int i2 = gVar.f1242e;
            if (i2 == -1 || i2 > this.f1223b || this.l.f1221d[i2] == null) {
                if (i2 != -1) {
                    gVar.i();
                }
                int i3 = this.f1223b + 1;
                this.f1223b = i3;
                this.f1230i++;
                gVar.f1242e = i3;
                gVar.l = g.a.UNRESTRICTED;
                this.l.f1221d[i3] = gVar;
            }
        }
        return gVar;
    }

    public b m() {
        b a2 = this.l.f1219b.a();
        if (a2 == null) {
            a2 = new b(this.l);
            r++;
        } else {
            a2.f1213a = null;
            a2.f1216d.clear();
            a2.f1214b = 0.0f;
            a2.f1217e = false;
        }
        g.q++;
        return a2;
    }

    public g n() {
        if (this.f1230i + 1 >= this.f1226e) {
            p();
        }
        g a2 = a(g.a.SLACK, null);
        int i2 = this.f1223b + 1;
        this.f1223b = i2;
        this.f1230i++;
        a2.f1242e = i2;
        this.l.f1221d[i2] = a2;
        return a2;
    }

    public int o(Object obj) {
        g gVar = ((b.f.a.i.c) obj).f1275i;
        if (gVar != null) {
            return (int) (gVar.f1245h + 0.5f);
        }
        return 0;
    }

    public final void p() {
        int i2 = this.f1225d * 2;
        this.f1225d = i2;
        this.f1227f = (b[]) Arrays.copyOf(this.f1227f, i2);
        c cVar = this.l;
        cVar.f1221d = (g[]) Arrays.copyOf(cVar.f1221d, this.f1225d);
        int i3 = this.f1225d;
        this.f1229h = new boolean[i3];
        this.f1226e = i3;
        this.k = i3;
    }

    public void q() {
        if (this.f1224c.isEmpty()) {
            j();
            return;
        }
        if (!this.f1228g) {
            r(this.f1224c);
            return;
        }
        boolean z = false;
        int i2 = 0;
        while (true) {
            if (i2 >= this.f1231j) {
                z = true;
                break;
            } else if (!this.f1227f[i2].f1217e) {
                break;
            } else {
                i2++;
            }
        }
        if (z) {
            j();
        } else {
            r(this.f1224c);
        }
    }

    public void r(a aVar) {
        float f2;
        int i2;
        boolean z;
        g.a aVar2 = g.a.UNRESTRICTED;
        int i3 = 0;
        while (true) {
            f2 = 0.0f;
            i2 = 1;
            if (i3 >= this.f1231j) {
                z = false;
                break;
            }
            b[] bVarArr = this.f1227f;
            if (bVarArr[i3].f1213a.l != aVar2 && bVarArr[i3].f1214b < 0.0f) {
                z = true;
                break;
            }
            i3++;
        }
        if (z) {
            boolean z2 = false;
            int i4 = 0;
            while (!z2) {
                i4 += i2;
                float f3 = Float.MAX_VALUE;
                int i5 = 0;
                int i6 = -1;
                int i7 = -1;
                int i8 = 0;
                while (i5 < this.f1231j) {
                    b bVar = this.f1227f[i5];
                    if (bVar.f1213a.l != aVar2 && !bVar.f1217e && bVar.f1214b < f2) {
                        int c2 = bVar.f1216d.c();
                        int i9 = 0;
                        while (i9 < c2) {
                            g h2 = bVar.f1216d.h(i9);
                            float d2 = bVar.f1216d.d(h2);
                            if (d2 > f2) {
                                for (int i10 = 0; i10 < 9; i10++) {
                                    float f4 = h2.f1247j[i10] / d2;
                                    if ((f4 < f3 && i10 == i8) || i10 > i8) {
                                        i7 = h2.f1242e;
                                        i8 = i10;
                                        f3 = f4;
                                        i6 = i5;
                                    }
                                }
                            }
                            i9++;
                            f2 = 0.0f;
                        }
                    }
                    i5++;
                    f2 = 0.0f;
                }
                if (i6 != -1) {
                    b bVar2 = this.f1227f[i6];
                    bVar2.f1213a.f1243f = -1;
                    bVar2.j(this.l.f1221d[i7]);
                    g gVar = bVar2.f1213a;
                    gVar.f1243f = i6;
                    gVar.m(this, bVar2);
                } else {
                    z2 = true;
                }
                if (i4 > this.f1230i / 2) {
                    z2 = true;
                }
                f2 = 0.0f;
                i2 = 1;
            }
        }
        s(aVar);
        j();
    }

    public final int s(a aVar) {
        for (int i2 = 0; i2 < this.f1230i; i2++) {
            this.f1229h[i2] = false;
        }
        boolean z = false;
        int i3 = 0;
        while (!z) {
            i3++;
            if (i3 >= this.f1230i * 2) {
                return i3;
            }
            g gVar = ((b) aVar).f1213a;
            if (gVar != null) {
                this.f1229h[gVar.f1242e] = true;
            }
            g a2 = aVar.a(this, this.f1229h);
            if (a2 != null) {
                boolean[] zArr = this.f1229h;
                int i4 = a2.f1242e;
                if (zArr[i4]) {
                    return i3;
                }
                zArr[i4] = true;
            }
            if (a2 != null) {
                float f2 = Float.MAX_VALUE;
                int i5 = -1;
                for (int i6 = 0; i6 < this.f1231j; i6++) {
                    b bVar = this.f1227f[i6];
                    if (bVar.f1213a.l != g.a.UNRESTRICTED && !bVar.f1217e && bVar.f1216d.e(a2)) {
                        float d2 = bVar.f1216d.d(a2);
                        if (d2 < 0.0f) {
                            float f3 = (-bVar.f1214b) / d2;
                            if (f3 < f2) {
                                i5 = i6;
                                f2 = f3;
                            }
                        }
                    }
                }
                if (i5 > -1) {
                    b bVar2 = this.f1227f[i5];
                    bVar2.f1213a.f1243f = -1;
                    bVar2.j(a2);
                    g gVar2 = bVar2.f1213a;
                    gVar2.f1243f = i5;
                    gVar2.m(this, bVar2);
                }
            } else {
                z = true;
            }
        }
        return i3;
    }

    public final void t() {
        for (int i2 = 0; i2 < this.f1231j; i2++) {
            b bVar = this.f1227f[i2];
            if (bVar != null) {
                this.l.f1219b.b(bVar);
            }
            this.f1227f[i2] = null;
        }
    }

    public void u() {
        c cVar;
        int i2 = 0;
        while (true) {
            cVar = this.l;
            g[] gVarArr = cVar.f1221d;
            if (i2 >= gVarArr.length) {
                break;
            }
            g gVar = gVarArr[i2];
            if (gVar != null) {
                gVar.i();
            }
            i2++;
        }
        e<g> eVar = cVar.f1220c;
        g[] gVarArr2 = this.m;
        int i3 = this.n;
        Objects.requireNonNull(eVar);
        if (i3 > gVarArr2.length) {
            i3 = gVarArr2.length;
        }
        for (int i4 = 0; i4 < i3; i4++) {
            g gVar2 = gVarArr2[i4];
            int i5 = eVar.f1233b;
            Object[] objArr = eVar.f1232a;
            if (i5 < objArr.length) {
                objArr[i5] = gVar2;
                eVar.f1233b = i5 + 1;
            }
        }
        this.n = 0;
        Arrays.fill(this.l.f1221d, (Object) null);
        this.f1223b = 0;
        this.f1224c.clear();
        this.f1230i = 1;
        for (int i6 = 0; i6 < this.f1231j; i6++) {
            b[] bVarArr = this.f1227f;
            if (bVarArr[i6] != null) {
                Objects.requireNonNull(bVarArr[i6]);
            }
        }
        t();
        this.f1231j = 0;
        this.o = new b(this.l);
    }
}
