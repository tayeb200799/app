package b.f.a.i.l;

import b.f.a.i.c;
import b.f.a.i.d;
import b.f.a.i.l.b;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\h.smali */
public class h {

    /* renamed from: a, reason: collision with root package name */
    public static b.a f1337a = new b.a();

    /* renamed from: b, reason: collision with root package name */
    public static int f1338b;

    /* renamed from: c, reason: collision with root package name */
    public static int f1339c;

    public static boolean a(b.f.a.i.d dVar) {
        d.a aVar = d.a.MATCH_CONSTRAINT;
        d.a aVar2 = d.a.WRAP_CONTENT;
        d.a aVar3 = d.a.FIXED;
        d.a m = dVar.m();
        d.a t = dVar.t();
        b.f.a.i.d dVar2 = dVar.V;
        b.f.a.i.e eVar = dVar2 != null ? (b.f.a.i.e) dVar2 : null;
        if (eVar != null) {
            eVar.m();
        }
        if (eVar != null) {
            eVar.t();
        }
        boolean z = m == aVar3 || dVar.D() || m == aVar2 || (m == aVar && dVar.r == 0 && dVar.Y == 0.0f && dVar.x(0)) || (m == aVar && dVar.r == 1 && dVar.y(0, dVar.u()));
        boolean z2 = t == aVar3 || dVar.E() || t == aVar2 || (t == aVar && dVar.s == 0 && dVar.Y == 0.0f && dVar.x(1)) || (t == aVar && dVar.s == 1 && dVar.y(1, dVar.l()));
        if (dVar.Y <= 0.0f || !(z || z2)) {
            return z && z2;
        }
        return true;
    }

    public static void b(int i2, b.f.a.i.d dVar, b.InterfaceC0021b interfaceC0021b, boolean z) {
        b.f.a.i.c cVar;
        b.f.a.i.c cVar2;
        b.f.a.i.c cVar3;
        b.f.a.i.c cVar4;
        d.a aVar = d.a.MATCH_CONSTRAINT;
        if (dVar.m) {
            return;
        }
        f1338b++;
        int i3 = 0;
        if (!(dVar instanceof b.f.a.i.e) && dVar.C() && a(dVar)) {
            b.f.a.i.e.e0(dVar, interfaceC0021b, new b.a(), 0);
        }
        b.f.a.i.c i4 = dVar.i(c.a.LEFT);
        b.f.a.i.c i5 = dVar.i(c.a.RIGHT);
        int c2 = i4.c();
        int c3 = i5.c();
        HashSet<b.f.a.i.c> hashSet = i4.f1267a;
        if (hashSet != null && i4.f1269c) {
            Iterator<b.f.a.i.c> it = hashSet.iterator();
            while (it.hasNext()) {
                b.f.a.i.c next = it.next();
                b.f.a.i.d dVar2 = next.f1270d;
                int i6 = i2 + 1;
                boolean a2 = a(dVar2);
                if (dVar2.C() && a2) {
                    b.f.a.i.e.e0(dVar2, interfaceC0021b, new b.a(), i3);
                }
                b.f.a.i.c cVar5 = dVar2.J;
                boolean z2 = (next == cVar5 && (cVar4 = dVar2.L.f1272f) != null && cVar4.f1269c) || (next == dVar2.L && (cVar3 = cVar5.f1272f) != null && cVar3.f1269c);
                if (dVar2.m() != aVar || a2) {
                    if (!dVar2.C()) {
                        b.f.a.i.c cVar6 = dVar2.J;
                        if (next == cVar6 && dVar2.L.f1272f == null) {
                            int d2 = cVar6.d() + c2;
                            dVar2.L(d2, dVar2.u() + d2);
                            b(i6, dVar2, interfaceC0021b, z);
                        } else {
                            b.f.a.i.c cVar7 = dVar2.L;
                            if (next == cVar7 && cVar6.f1272f == null) {
                                int d3 = c2 - cVar7.d();
                                dVar2.L(d3 - dVar2.u(), d3);
                                b(i6, dVar2, interfaceC0021b, z);
                            } else if (z2 && !dVar2.A()) {
                                c(i6, interfaceC0021b, dVar2, z);
                            }
                        }
                    }
                } else if (dVar2.m() == aVar && dVar2.v >= 0 && dVar2.u >= 0 && ((dVar2.i0 == 8 || (dVar2.r == 0 && dVar2.Y == 0.0f)) && !dVar2.A() && !dVar2.G && z2 && !dVar2.A())) {
                    d(i6, dVar, interfaceC0021b, dVar2, z);
                }
                i3 = 0;
            }
        }
        if (dVar instanceof b.f.a.i.f) {
            return;
        }
        HashSet<b.f.a.i.c> hashSet2 = i5.f1267a;
        if (hashSet2 != null && i5.f1269c) {
            Iterator<b.f.a.i.c> it2 = hashSet2.iterator();
            while (it2.hasNext()) {
                b.f.a.i.c next2 = it2.next();
                b.f.a.i.d dVar3 = next2.f1270d;
                int i7 = i2 + 1;
                boolean a3 = a(dVar3);
                if (dVar3.C() && a3) {
                    b.f.a.i.e.e0(dVar3, interfaceC0021b, new b.a(), 0);
                }
                b.f.a.i.c cVar8 = dVar3.J;
                boolean z3 = (next2 == cVar8 && (cVar2 = dVar3.L.f1272f) != null && cVar2.f1269c) || (next2 == dVar3.L && (cVar = cVar8.f1272f) != null && cVar.f1269c);
                if (dVar3.m() != aVar || a3) {
                    if (!dVar3.C()) {
                        b.f.a.i.c cVar9 = dVar3.J;
                        if (next2 == cVar9 && dVar3.L.f1272f == null) {
                            int d4 = cVar9.d() + c3;
                            dVar3.L(d4, dVar3.u() + d4);
                            b(i7, dVar3, interfaceC0021b, z);
                        } else {
                            b.f.a.i.c cVar10 = dVar3.L;
                            if (next2 == cVar10 && cVar9.f1272f == null) {
                                int d5 = c3 - cVar10.d();
                                dVar3.L(d5 - dVar3.u(), d5);
                                b(i7, dVar3, interfaceC0021b, z);
                            } else if (z3 && !dVar3.A()) {
                                c(i7, interfaceC0021b, dVar3, z);
                            }
                        }
                    }
                } else if (dVar3.m() == aVar && dVar3.v >= 0 && dVar3.u >= 0 && (dVar3.i0 == 8 || (dVar3.r == 0 && dVar3.Y == 0.0f))) {
                    if (!dVar3.A() && !dVar3.G && z3 && !dVar3.A()) {
                        d(i7, dVar, interfaceC0021b, dVar3, z);
                    }
                }
            }
        }
        dVar.m = true;
    }

    public static void c(int i2, b.InterfaceC0021b interfaceC0021b, b.f.a.i.d dVar, boolean z) {
        float f2 = dVar.f0;
        int c2 = dVar.J.f1272f.c();
        int c3 = dVar.L.f1272f.c();
        int d2 = dVar.J.d() + c2;
        int d3 = c3 - dVar.L.d();
        if (c2 == c3) {
            f2 = 0.5f;
        } else {
            c2 = d2;
            c3 = d3;
        }
        int u = dVar.u();
        int i3 = (c3 - c2) - u;
        if (c2 > c3) {
            i3 = (c2 - c3) - u;
        }
        int i4 = ((int) (i3 > 0 ? (f2 * i3) + 0.5f : f2 * i3)) + c2;
        int i5 = i4 + u;
        if (c2 > c3) {
            i5 = i4 - u;
        }
        dVar.L(i4, i5);
        b(i2 + 1, dVar, interfaceC0021b, z);
    }

    public static void d(int i2, b.f.a.i.d dVar, b.InterfaceC0021b interfaceC0021b, b.f.a.i.d dVar2, boolean z) {
        float f2 = dVar2.f0;
        int d2 = dVar2.J.d() + dVar2.J.f1272f.c();
        int c2 = dVar2.L.f1272f.c() - dVar2.L.d();
        if (c2 >= d2) {
            int u = dVar2.u();
            if (dVar2.i0 != 8) {
                int i3 = dVar2.r;
                if (i3 == 2) {
                    u = (int) (dVar2.f0 * 0.5f * (dVar instanceof b.f.a.i.e ? dVar.u() : dVar.V.u()));
                } else if (i3 == 0) {
                    u = c2 - d2;
                }
                u = Math.max(dVar2.u, u);
                int i4 = dVar2.v;
                if (i4 > 0) {
                    u = Math.min(i4, u);
                }
            }
            int i5 = d2 + ((int) ((f2 * ((c2 - d2) - u)) + 0.5f));
            dVar2.L(i5, u + i5);
            b(i2 + 1, dVar2, interfaceC0021b, z);
        }
    }

    public static void e(int i2, b.InterfaceC0021b interfaceC0021b, b.f.a.i.d dVar) {
        float f2 = dVar.g0;
        int c2 = dVar.K.f1272f.c();
        int c3 = dVar.M.f1272f.c();
        int d2 = dVar.K.d() + c2;
        int d3 = c3 - dVar.M.d();
        if (c2 == c3) {
            f2 = 0.5f;
        } else {
            c2 = d2;
            c3 = d3;
        }
        int l = dVar.l();
        int i3 = (c3 - c2) - l;
        if (c2 > c3) {
            i3 = (c2 - c3) - l;
        }
        int i4 = (int) (i3 > 0 ? (f2 * i3) + 0.5f : f2 * i3);
        int i5 = c2 + i4;
        int i6 = i5 + l;
        if (c2 > c3) {
            i5 = c2 - i4;
            i6 = i5 - l;
        }
        dVar.M(i5, i6);
        g(i2 + 1, dVar, interfaceC0021b);
    }

    public static void f(int i2, b.f.a.i.d dVar, b.InterfaceC0021b interfaceC0021b, b.f.a.i.d dVar2) {
        float f2 = dVar2.g0;
        int d2 = dVar2.K.d() + dVar2.K.f1272f.c();
        int c2 = dVar2.M.f1272f.c() - dVar2.M.d();
        if (c2 >= d2) {
            int l = dVar2.l();
            if (dVar2.i0 != 8) {
                int i3 = dVar2.s;
                if (i3 == 2) {
                    l = (int) (f2 * 0.5f * (dVar instanceof b.f.a.i.e ? dVar.l() : dVar.V.l()));
                } else if (i3 == 0) {
                    l = c2 - d2;
                }
                l = Math.max(dVar2.x, l);
                int i4 = dVar2.y;
                if (i4 > 0) {
                    l = Math.min(i4, l);
                }
            }
            int i5 = d2 + ((int) ((f2 * ((c2 - d2) - l)) + 0.5f));
            dVar2.M(i5, l + i5);
            g(i2 + 1, dVar2, interfaceC0021b);
        }
    }

    public static void g(int i2, b.f.a.i.d dVar, b.InterfaceC0021b interfaceC0021b) {
        b.f.a.i.c cVar;
        b.f.a.i.c cVar2;
        b.f.a.i.c cVar3;
        b.f.a.i.c cVar4;
        d.a aVar = d.a.MATCH_CONSTRAINT;
        if (dVar.n) {
            return;
        }
        f1339c++;
        if (!(dVar instanceof b.f.a.i.e) && dVar.C() && a(dVar)) {
            b.f.a.i.e.e0(dVar, interfaceC0021b, new b.a(), 0);
        }
        b.f.a.i.c i3 = dVar.i(c.a.TOP);
        b.f.a.i.c i4 = dVar.i(c.a.BOTTOM);
        int c2 = i3.c();
        int c3 = i4.c();
        HashSet<b.f.a.i.c> hashSet = i3.f1267a;
        if (hashSet != null && i3.f1269c) {
            Iterator<b.f.a.i.c> it = hashSet.iterator();
            while (it.hasNext()) {
                b.f.a.i.c next = it.next();
                b.f.a.i.d dVar2 = next.f1270d;
                int i5 = i2 + 1;
                boolean a2 = a(dVar2);
                if (dVar2.C() && a2) {
                    b.f.a.i.e.e0(dVar2, interfaceC0021b, new b.a(), 0);
                }
                b.f.a.i.c cVar5 = dVar2.K;
                boolean z = (next == cVar5 && (cVar4 = dVar2.M.f1272f) != null && cVar4.f1269c) || (next == dVar2.M && (cVar3 = cVar5.f1272f) != null && cVar3.f1269c);
                if (dVar2.t() != aVar || a2) {
                    if (!dVar2.C()) {
                        b.f.a.i.c cVar6 = dVar2.K;
                        if (next == cVar6 && dVar2.M.f1272f == null) {
                            int d2 = cVar6.d() + c2;
                            dVar2.M(d2, dVar2.l() + d2);
                            g(i5, dVar2, interfaceC0021b);
                        } else {
                            b.f.a.i.c cVar7 = dVar2.M;
                            if (next == cVar7 && cVar6.f1272f == null) {
                                int d3 = c2 - cVar7.d();
                                dVar2.M(d3 - dVar2.l(), d3);
                                g(i5, dVar2, interfaceC0021b);
                            } else if (z && !dVar2.B()) {
                                e(i5, interfaceC0021b, dVar2);
                            }
                        }
                    }
                } else if (dVar2.t() == aVar && dVar2.y >= 0 && dVar2.x >= 0 && ((dVar2.i0 == 8 || (dVar2.s == 0 && dVar2.Y == 0.0f)) && !dVar2.B() && !dVar2.G && z && !dVar2.B())) {
                    f(i5, dVar, interfaceC0021b, dVar2);
                }
            }
        }
        if (dVar instanceof b.f.a.i.f) {
            return;
        }
        HashSet<b.f.a.i.c> hashSet2 = i4.f1267a;
        if (hashSet2 != null && i4.f1269c) {
            Iterator<b.f.a.i.c> it2 = hashSet2.iterator();
            while (it2.hasNext()) {
                b.f.a.i.c next2 = it2.next();
                b.f.a.i.d dVar3 = next2.f1270d;
                int i6 = i2 + 1;
                boolean a3 = a(dVar3);
                if (dVar3.C() && a3) {
                    b.f.a.i.e.e0(dVar3, interfaceC0021b, new b.a(), 0);
                }
                b.f.a.i.c cVar8 = dVar3.K;
                boolean z2 = (next2 == cVar8 && (cVar2 = dVar3.M.f1272f) != null && cVar2.f1269c) || (next2 == dVar3.M && (cVar = cVar8.f1272f) != null && cVar.f1269c);
                if (dVar3.t() != aVar || a3) {
                    if (!dVar3.C()) {
                        b.f.a.i.c cVar9 = dVar3.K;
                        if (next2 == cVar9 && dVar3.M.f1272f == null) {
                            int d4 = cVar9.d() + c3;
                            dVar3.M(d4, dVar3.l() + d4);
                            g(i6, dVar3, interfaceC0021b);
                        } else {
                            b.f.a.i.c cVar10 = dVar3.M;
                            if (next2 == cVar10 && cVar9.f1272f == null) {
                                int d5 = c3 - cVar10.d();
                                dVar3.M(d5 - dVar3.l(), d5);
                                g(i6, dVar3, interfaceC0021b);
                            } else if (z2 && !dVar3.B()) {
                                e(i6, interfaceC0021b, dVar3);
                            }
                        }
                    }
                } else if (dVar3.t() == aVar && dVar3.y >= 0 && dVar3.x >= 0 && (dVar3.i0 == 8 || (dVar3.s == 0 && dVar3.Y == 0.0f))) {
                    if (!dVar3.B() && !dVar3.G && z2 && !dVar3.B()) {
                        f(i6, dVar, interfaceC0021b, dVar3);
                    }
                }
            }
        }
        b.f.a.i.c i7 = dVar.i(c.a.BASELINE);
        if (i7.f1267a != null && i7.f1269c) {
            int c4 = i7.c();
            Iterator<b.f.a.i.c> it3 = i7.f1267a.iterator();
            while (it3.hasNext()) {
                b.f.a.i.c next3 = it3.next();
                b.f.a.i.d dVar4 = next3.f1270d;
                int i8 = i2 + 1;
                boolean a4 = a(dVar4);
                if (dVar4.C() && a4) {
                    b.f.a.i.e.e0(dVar4, interfaceC0021b, new b.a(), 0);
                }
                if (dVar4.t() != aVar || a4) {
                    if (!dVar4.C() && next3 == dVar4.N) {
                        int d6 = next3.d() + c4;
                        if (dVar4.E) {
                            int i9 = d6 - dVar4.c0;
                            int i10 = dVar4.X + i9;
                            dVar4.b0 = i9;
                            dVar4.K.j(i9);
                            dVar4.M.j(i10);
                            b.f.a.i.c cVar11 = dVar4.N;
                            cVar11.f1268b = d6;
                            cVar11.f1269c = true;
                            dVar4.l = true;
                        }
                        g(i8, dVar4, interfaceC0021b);
                    }
                }
            }
        }
        dVar.n = true;
    }
}
