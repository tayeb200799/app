package b.f.b.a;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import b.f.b.a.d;
import b.f.c.c;
import b.h.k.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\b\a\c.smali */
public class c extends ConstraintLayout implements h {
    public static final /* synthetic */ int b0 = 0;
    public int A;
    public boolean B;
    public long C;
    public float D;
    public float E;
    public float F;
    public long G;
    public float H;
    public InterfaceC0022c I;
    public int J;
    public b.f.b.a.a K;
    public long L;
    public boolean M;
    public ArrayList<b.f.b.a.b> N;
    public ArrayList<b.f.b.a.b> O;
    public CopyOnWriteArrayList<InterfaceC0022c> P;
    public int Q;
    public float R;
    public float S;
    public boolean T;
    public b U;
    public boolean V;
    public d W;
    public boolean a0;
    public float x;
    public int y;
    public int z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\b\a\c$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            c.this.U.a();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\b\a\c$b.smali */
    public class b {

        /* renamed from: a, reason: collision with root package name */
        public float f1367a = Float.NaN;

        /* renamed from: b, reason: collision with root package name */
        public float f1368b = Float.NaN;

        /* renamed from: c, reason: collision with root package name */
        public int f1369c = -1;

        /* renamed from: d, reason: collision with root package name */
        public int f1370d = -1;

        public b() {
        }

        public void a() {
            int a2;
            d dVar = d.SETUP;
            int i2 = this.f1369c;
            if (i2 != -1 || this.f1370d != -1) {
                if (i2 == -1) {
                    c.this.w(this.f1370d);
                } else {
                    int i3 = this.f1370d;
                    if (i3 == -1) {
                        c cVar = c.this;
                        cVar.setState(dVar);
                        cVar.z = i2;
                        cVar.y = -1;
                        cVar.A = -1;
                        b.f.c.c cVar2 = cVar.n;
                        if (cVar2 != null) {
                            float f2 = -1;
                            int i4 = cVar2.f1400b;
                            if (i4 == i2) {
                                c.a valueAt = i2 == -1 ? cVar2.f1402d.valueAt(0) : cVar2.f1402d.get(i4);
                                int i5 = cVar2.f1401c;
                                if ((i5 == -1 || !valueAt.f1405b.get(i5).a(f2, f2)) && cVar2.f1401c != (a2 = valueAt.a(f2, f2))) {
                                    b.f.c.d dVar2 = a2 == -1 ? null : valueAt.f1405b.get(a2).f1413f;
                                    if (a2 != -1) {
                                        int i6 = valueAt.f1405b.get(a2).f1412e;
                                    }
                                    if (dVar2 != null) {
                                        cVar2.f1401c = a2;
                                        dVar2.a(cVar2.f1399a);
                                    }
                                }
                            } else {
                                cVar2.f1400b = i2;
                                c.a aVar = cVar2.f1402d.get(i2);
                                int a3 = aVar.a(f2, f2);
                                b.f.c.d dVar3 = a3 == -1 ? aVar.f1407d : aVar.f1405b.get(a3).f1413f;
                                if (a3 != -1) {
                                    int i7 = aVar.f1405b.get(a3).f1412e;
                                }
                                if (dVar3 == null) {
                                    Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i2 + ", dim =" + f2 + ", " + f2);
                                } else {
                                    cVar2.f1401c = a3;
                                    dVar3.a(cVar2.f1399a);
                                }
                            }
                        }
                    } else {
                        c.this.v(i2, i3);
                    }
                }
                c.this.setState(dVar);
            }
            if (Float.isNaN(this.f1368b)) {
                if (Float.isNaN(this.f1367a)) {
                    return;
                }
                c.this.setProgress(this.f1367a);
                return;
            }
            c cVar3 = c.this;
            float f3 = this.f1367a;
            float f4 = this.f1368b;
            if (cVar3.isAttachedToWindow()) {
                cVar3.setProgress(f3);
                cVar3.setState(d.MOVING);
                cVar3.x = f4;
                if (f4 == 0.0f && f3 != 0.0f) {
                    int i8 = (f3 > 1.0f ? 1 : (f3 == 1.0f ? 0 : -1));
                }
            } else {
                if (cVar3.U == null) {
                    cVar3.U = cVar3.new b();
                }
                b bVar = cVar3.U;
                bVar.f1367a = f3;
                bVar.f1368b = f4;
            }
            this.f1367a = Float.NaN;
            this.f1368b = Float.NaN;
            this.f1369c = -1;
            this.f1370d = -1;
        }
    }

    /* renamed from: b.f.b.a.c$c, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\b\a\c$c.smali */
    public interface InterfaceC0022c {
        void a(c cVar, int i2, int i3, float f2);

        void b(c cVar, int i2, int i3);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\b\a\c$d.smali */
    public enum d {
        UNDEFINED,
        SETUP,
        MOVING,
        FINISHED
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        s(false);
        super.dispatchDraw(canvas);
    }

    public int[] getConstraintSetIds() {
        return null;
    }

    public int getCurrentState() {
        return this.z;
    }

    public ArrayList<d.a> getDefinedTransitions() {
        return null;
    }

    public b.f.b.a.a getDesignTool() {
        if (this.K == null) {
            this.K = new b.f.b.a.a(this);
        }
        return this.K;
    }

    public int getEndState() {
        return this.A;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.F;
    }

    public b.f.b.a.d getScene() {
        return null;
    }

    public int getStartState() {
        return this.y;
    }

    public float getTargetPosition() {
        return this.H;
    }

    public Bundle getTransitionState() {
        if (this.U == null) {
            this.U = new b();
        }
        b bVar = this.U;
        c cVar = c.this;
        bVar.f1370d = cVar.A;
        bVar.f1369c = cVar.y;
        bVar.f1368b = cVar.getVelocity();
        bVar.f1367a = c.this.getProgress();
        b bVar2 = this.U;
        Objects.requireNonNull(bVar2);
        Bundle bundle = new Bundle();
        bundle.putFloat("motion.progress", bVar2.f1367a);
        bundle.putFloat("motion.velocity", bVar2.f1368b);
        bundle.putInt("motion.StartState", bVar2.f1369c);
        bundle.putInt("motion.EndState", bVar2.f1370d);
        return bundle;
    }

    public long getTransitionTimeMs() {
        return (long) (this.D * 1000.0f);
    }

    public float getVelocity() {
        return this.x;
    }

    @Override // b.h.k.g
    public void h(View view, View view2, int i2, int i3) {
        this.L = getNanoTime();
    }

    @Override // b.h.k.g
    public void i(View view, int i2) {
    }

    @Override // android.view.View
    public boolean isAttachedToWindow() {
        return super.isAttachedToWindow();
    }

    @Override // b.h.k.g
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void k(int i2) {
        this.n = null;
    }

    @Override // b.h.k.h
    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i2 == 0 && i3 == 0) {
            return;
        }
        iArr[0] = iArr[0] + i4;
        iArr[1] = iArr[1] + i5;
    }

    @Override // b.h.k.g
    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
    }

    @Override // b.h.k.g
    public boolean o(View view, View view2, int i2, int i3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Display display = getDisplay();
        if (display != null) {
            display.getRotation();
        }
        b bVar = this.U;
        if (bVar != null) {
            if (this.V) {
                post(new a());
            } else {
                bVar.a();
            }
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return false;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        this.T = true;
        try {
            super.onLayout(z, i2, i3, i4, i5);
        } finally {
            this.T = false;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i2) {
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof b.f.b.a.b) {
            b.f.b.a.b bVar = (b.f.b.a.b) view;
            if (this.P == null) {
                this.P = new CopyOnWriteArrayList<>();
            }
            this.P.add(bVar);
            if (bVar.l) {
                if (this.N == null) {
                    this.N = new ArrayList<>();
                }
                this.N.add(bVar);
            }
            if (bVar.m) {
                if (this.O == null) {
                    this.O = new ArrayList<>();
                }
                this.O.add(bVar);
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList<b.f.b.a.b> arrayList = this.N;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList<b.f.b.a.b> arrayList2 = this.O;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View, android.view.ViewParent
    public void requestLayout() {
        int i2 = this.z;
        super.requestLayout();
    }

    public void s(boolean z) {
        boolean z2;
        int i2;
        d dVar = d.FINISHED;
        if (this.G == -1) {
            this.G = getNanoTime();
        }
        float f2 = this.F;
        if (f2 > 0.0f && f2 < 1.0f) {
            this.z = -1;
        }
        boolean z3 = false;
        if (this.M) {
            float signum = Math.signum(this.H - f2);
            long nanoTime = getNanoTime();
            float f3 = (((nanoTime - this.G) * signum) * 1.0E-9f) / this.D;
            float f4 = this.F + f3;
            if ((signum > 0.0f && f4 >= this.H) || (signum <= 0.0f && f4 <= this.H)) {
                f4 = this.H;
            }
            this.F = f4;
            this.E = f4;
            this.G = nanoTime;
            this.x = f3;
            if (Math.abs(f3) > 1.0E-5f) {
                setState(d.MOVING);
            }
            if ((signum > 0.0f && f4 >= this.H) || (signum <= 0.0f && f4 <= this.H)) {
                f4 = this.H;
            }
            if (f4 >= 1.0f || f4 <= 0.0f) {
                setState(dVar);
            }
            int childCount = getChildCount();
            this.M = false;
            getNanoTime();
            this.S = f4;
            if (childCount > 0) {
                getChildAt(0);
                throw null;
            }
            boolean z4 = (signum > 0.0f && f4 >= this.H) || (signum <= 0.0f && f4 <= this.H);
            if (!this.M && z4) {
                setState(dVar);
            }
            boolean z5 = (!z4) | this.M;
            this.M = z5;
            if (f4 <= 0.0f && (i2 = this.y) != -1 && this.z != i2) {
                this.z = i2;
                throw null;
            }
            if (f4 >= 1.0d) {
                int i3 = this.z;
                int i4 = this.A;
                if (i3 != i4) {
                    this.z = i4;
                    throw null;
                }
            }
            if (z5) {
                invalidate();
            } else if ((signum > 0.0f && f4 == 1.0f) || (signum < 0.0f && f4 == 0.0f)) {
                setState(dVar);
            }
            if (!this.M && (signum <= 0.0f || f4 != 1.0f)) {
                int i5 = (signum > 0.0f ? 1 : (signum == 0.0f ? 0 : -1));
            }
        }
        float f5 = this.F;
        if (f5 < 1.0f) {
            if (f5 <= 0.0f) {
                int i6 = this.z;
                int i7 = this.y;
                z2 = i6 != i7;
                this.z = i7;
            }
            this.a0 |= z3;
            if (z3 && !this.T) {
                requestLayout();
            }
            this.E = this.F;
        }
        int i8 = this.z;
        int i9 = this.A;
        z2 = i8 != i9;
        this.z = i9;
        z3 = z2;
        this.a0 |= z3;
        if (z3) {
            requestLayout();
        }
        this.E = this.F;
    }

    public void setDebugMode(int i2) {
        this.J = i2;
        invalidate();
    }

    public void setDelayedApplicationOfInitialState(boolean z) {
        this.V = z;
    }

    public void setInteractionEnabled(boolean z) {
        this.B = z;
    }

    public void setInterpolatedProgress(float f2) {
        setProgress(f2);
    }

    public void setOnHide(float f2) {
        ArrayList<b.f.b.a.b> arrayList = this.O;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.O.get(i2).setProgress(f2);
            }
        }
    }

    public void setOnShow(float f2) {
        ArrayList<b.f.b.a.b> arrayList = this.N;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.N.get(i2).setProgress(f2);
            }
        }
    }

    public void setProgress(float f2) {
        d dVar = d.FINISHED;
        d dVar2 = d.MOVING;
        if (f2 < 0.0f || f2 > 1.0f) {
            Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive");
        }
        if (!isAttachedToWindow()) {
            if (this.U == null) {
                this.U = new b();
            }
            this.U.f1367a = f2;
            return;
        }
        if (f2 <= 0.0f) {
            if (this.F == 1.0f && this.z == this.A) {
                setState(dVar2);
            }
            this.z = this.y;
            if (this.F == 0.0f) {
                setState(dVar);
                return;
            }
            return;
        }
        if (f2 < 1.0f) {
            this.z = -1;
            setState(dVar2);
            return;
        }
        if (this.F == 0.0f && this.z == this.y) {
            setState(dVar2);
        }
        this.z = this.A;
        if (this.F == 1.0f) {
            setState(dVar);
        }
    }

    public void setScene(b.f.b.a.d dVar) {
        g();
        throw null;
    }

    public void setStartState(int i2) {
        if (isAttachedToWindow()) {
            this.z = i2;
            return;
        }
        if (this.U == null) {
            this.U = new b();
        }
        b bVar = this.U;
        bVar.f1369c = i2;
        bVar.f1370d = i2;
    }

    public void setState(d dVar) {
        d dVar2 = d.FINISHED;
        if (dVar == dVar2 && this.z == -1) {
            return;
        }
        d dVar3 = this.W;
        this.W = dVar;
        d dVar4 = d.MOVING;
        if (dVar3 == dVar4 && dVar == dVar4) {
            t();
        }
        int ordinal = dVar3.ordinal();
        if (ordinal != 0 && ordinal != 1) {
            if (ordinal == 2 && dVar == dVar2) {
                u();
                return;
            }
            return;
        }
        if (dVar == dVar4) {
            t();
        }
        if (dVar == dVar2) {
            u();
        }
    }

    public void setTransition(int i2) {
    }

    public void setTransition(d.a aVar) {
        throw null;
    }

    public void setTransitionDuration(int i2) {
        Log.e("MotionLayout", "MotionScene not defined");
    }

    public void setTransitionListener(InterfaceC0022c interfaceC0022c) {
        this.I = interfaceC0022c;
    }

    public void setTransitionState(Bundle bundle) {
        if (this.U == null) {
            this.U = new b();
        }
        b bVar = this.U;
        Objects.requireNonNull(bVar);
        bVar.f1367a = bundle.getFloat("motion.progress");
        bVar.f1368b = bundle.getFloat("motion.velocity");
        bVar.f1369c = bundle.getInt("motion.StartState");
        bVar.f1370d = bundle.getInt("motion.EndState");
        if (isAttachedToWindow()) {
            this.U.a();
        }
    }

    public final void t() {
        CopyOnWriteArrayList<InterfaceC0022c> copyOnWriteArrayList;
        if ((this.I == null && ((copyOnWriteArrayList = this.P) == null || copyOnWriteArrayList.isEmpty())) || this.R == this.E) {
            return;
        }
        if (this.Q != -1) {
            InterfaceC0022c interfaceC0022c = this.I;
            if (interfaceC0022c != null) {
                interfaceC0022c.b(this, this.y, this.A);
            }
            CopyOnWriteArrayList<InterfaceC0022c> copyOnWriteArrayList2 = this.P;
            if (copyOnWriteArrayList2 != null) {
                Iterator<InterfaceC0022c> it = copyOnWriteArrayList2.iterator();
                while (it.hasNext()) {
                    it.next().b(this, this.y, this.A);
                }
            }
        }
        this.Q = -1;
        float f2 = this.E;
        this.R = f2;
        InterfaceC0022c interfaceC0022c2 = this.I;
        if (interfaceC0022c2 != null) {
            interfaceC0022c2.a(this, this.y, this.A, f2);
        }
        CopyOnWriteArrayList<InterfaceC0022c> copyOnWriteArrayList3 = this.P;
        if (copyOnWriteArrayList3 != null) {
            Iterator<InterfaceC0022c> it2 = copyOnWriteArrayList3.iterator();
            while (it2.hasNext()) {
                it2.next().a(this, this.y, this.A, this.E);
            }
        }
    }

    @Override // android.view.View
    public String toString() {
        Context context = getContext();
        return b.d.a.d(context, this.y) + "->" + b.d.a.d(context, this.A) + " (pos:" + this.F + " Dpos/Dt:" + this.x;
    }

    public void u() {
        CopyOnWriteArrayList<InterfaceC0022c> copyOnWriteArrayList;
        if (!(this.I == null && ((copyOnWriteArrayList = this.P) == null || copyOnWriteArrayList.isEmpty())) && this.Q == -1) {
            this.Q = this.z;
            throw null;
        }
        if (this.I != null) {
            throw null;
        }
        CopyOnWriteArrayList<InterfaceC0022c> copyOnWriteArrayList2 = this.P;
        if (copyOnWriteArrayList2 != null && !copyOnWriteArrayList2.isEmpty()) {
            throw null;
        }
    }

    public void v(int i2, int i3) {
        if (isAttachedToWindow()) {
            return;
        }
        if (this.U == null) {
            this.U = new b();
        }
        b bVar = this.U;
        bVar.f1369c = i2;
        bVar.f1370d = i3;
    }

    public void w(int i2) {
        if (!isAttachedToWindow()) {
            if (this.U == null) {
                this.U = new b();
            }
            this.U.f1370d = i2;
            return;
        }
        int i3 = this.z;
        if (i3 == i2 || this.y == i2 || this.A == i2) {
            return;
        }
        this.A = i2;
        if (i3 != -1) {
            v(i3, i2);
            this.F = 0.0f;
            return;
        }
        this.H = 1.0f;
        this.E = 0.0f;
        this.F = 0.0f;
        this.G = getNanoTime();
        this.C = getNanoTime();
        throw null;
    }
}
