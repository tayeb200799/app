package b.f.a.i;

import b.f.a.i.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\i.smali */
public class i {

    /* renamed from: a, reason: collision with root package name */
    public static boolean[] f1298a = new boolean[3];

    public static void a(e eVar, b.f.a.d dVar, d dVar2) {
        d.a aVar = d.a.MATCH_PARENT;
        dVar2.o = -1;
        dVar2.p = -1;
        d.a aVar2 = eVar.U[0];
        d.a aVar3 = d.a.WRAP_CONTENT;
        if (aVar2 != aVar3 && dVar2.U[0] == aVar) {
            int i2 = dVar2.J.f1273g;
            int u = eVar.u() - dVar2.L.f1273g;
            c cVar = dVar2.J;
            cVar.f1275i = dVar.l(cVar);
            c cVar2 = dVar2.L;
            cVar2.f1275i = dVar.l(cVar2);
            dVar.e(dVar2.J.f1275i, i2);
            dVar.e(dVar2.L.f1275i, u);
            dVar2.o = 2;
            dVar2.a0 = i2;
            int i3 = u - i2;
            dVar2.W = i3;
            int i4 = dVar2.d0;
            if (i3 < i4) {
                dVar2.W = i4;
            }
        }
        if (eVar.U[1] == aVar3 || dVar2.U[1] != aVar) {
            return;
        }
        int i5 = dVar2.K.f1273g;
        int l = eVar.l() - dVar2.M.f1273g;
        c cVar3 = dVar2.K;
        cVar3.f1275i = dVar.l(cVar3);
        c cVar4 = dVar2.M;
        cVar4.f1275i = dVar.l(cVar4);
        dVar.e(dVar2.K.f1275i, i5);
        dVar.e(dVar2.M.f1275i, l);
        if (dVar2.c0 > 0 || dVar2.i0 == 8) {
            c cVar5 = dVar2.N;
            cVar5.f1275i = dVar.l(cVar5);
            dVar.e(dVar2.N.f1275i, dVar2.c0 + i5);
        }
        dVar2.p = 2;
        dVar2.b0 = i5;
        int i6 = l - i5;
        dVar2.X = i6;
        int i7 = dVar2.e0;
        if (i6 < i7) {
            dVar2.X = i7;
        }
    }

    public static final boolean b(int i2, int i3) {
        return (i2 & i3) == i3;
    }
}
