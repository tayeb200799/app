package b.f.a.i;

import b.f.a.i.c;
import b.f.a.i.l.m;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\d.smali */
public class d {
    public int A;
    public float B;
    public int[] C;
    public float D;
    public boolean E;
    public boolean F;
    public boolean G;
    public int H;
    public int I;
    public c J;
    public c K;
    public c L;
    public c M;
    public c N;
    public c O;
    public c P;
    public c Q;
    public c[] R;
    public ArrayList<c> S;
    public boolean[] T;
    public a[] U;
    public d V;
    public int W;
    public int X;
    public float Y;
    public int Z;
    public int a0;

    /* renamed from: b, reason: collision with root package name */
    public b.f.a.i.l.c f1284b;
    public int b0;

    /* renamed from: c, reason: collision with root package name */
    public b.f.a.i.l.c f1285c;
    public int c0;
    public int d0;
    public int e0;
    public float f0;
    public float g0;
    public Object h0;
    public int i0;

    /* renamed from: j, reason: collision with root package name */
    public String f1292j;
    public String j0;
    public boolean k;
    public int k0;
    public boolean l;
    public int l0;
    public boolean m;
    public float[] m0;
    public boolean n;
    public d[] n0;
    public int o;
    public d[] o0;
    public int p;
    public int p0;
    public int q;
    public int q0;
    public int r;
    public int s;
    public int[] t;
    public int u;
    public int v;
    public float w;
    public int x;
    public int y;
    public float z;

    /* renamed from: a, reason: collision with root package name */
    public boolean f1283a = false;

    /* renamed from: d, reason: collision with root package name */
    public b.f.a.i.l.k f1286d = null;

    /* renamed from: e, reason: collision with root package name */
    public m f1287e = null;

    /* renamed from: f, reason: collision with root package name */
    public boolean[] f1288f = {true, true};

    /* renamed from: g, reason: collision with root package name */
    public boolean f1289g = true;

    /* renamed from: h, reason: collision with root package name */
    public int f1290h = -1;

    /* renamed from: i, reason: collision with root package name */
    public int f1291i = -1;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\d$a.smali */
    public enum a {
        FIXED,
        WRAP_CONTENT,
        MATCH_CONSTRAINT,
        MATCH_PARENT
    }

    public d() {
        new HashMap();
        this.k = false;
        this.l = false;
        this.m = false;
        this.n = false;
        this.o = -1;
        this.p = -1;
        this.q = 0;
        this.r = 0;
        this.s = 0;
        this.t = new int[2];
        this.u = 0;
        this.v = 0;
        this.w = 1.0f;
        this.x = 0;
        this.y = 0;
        this.z = 1.0f;
        this.A = -1;
        this.B = 1.0f;
        this.C = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.D = 0.0f;
        this.E = false;
        this.G = false;
        this.H = 0;
        this.I = 0;
        c cVar = new c(this, c.a.LEFT);
        this.J = cVar;
        c cVar2 = new c(this, c.a.TOP);
        this.K = cVar2;
        c cVar3 = new c(this, c.a.RIGHT);
        this.L = cVar3;
        c cVar4 = new c(this, c.a.BOTTOM);
        this.M = cVar4;
        c cVar5 = new c(this, c.a.BASELINE);
        this.N = cVar5;
        this.O = new c(this, c.a.CENTER_X);
        this.P = new c(this, c.a.CENTER_Y);
        c cVar6 = new c(this, c.a.CENTER);
        this.Q = cVar6;
        this.R = new c[]{cVar, cVar3, cVar2, cVar4, cVar5, cVar6};
        ArrayList<c> arrayList = new ArrayList<>();
        this.S = arrayList;
        this.T = new boolean[2];
        a aVar = a.FIXED;
        this.U = new a[]{aVar, aVar};
        this.V = null;
        this.W = 0;
        this.X = 0;
        this.Y = 0.0f;
        this.Z = -1;
        this.a0 = 0;
        this.b0 = 0;
        this.c0 = 0;
        this.f0 = 0.5f;
        this.g0 = 0.5f;
        this.i0 = 0;
        this.j0 = null;
        this.k0 = 0;
        this.l0 = 0;
        this.m0 = new float[]{-1.0f, -1.0f};
        this.n0 = new d[]{null, null};
        this.o0 = new d[]{null, null};
        this.p0 = -1;
        this.q0 = -1;
        arrayList.add(this.J);
        this.S.add(this.K);
        this.S.add(this.L);
        this.S.add(this.M);
        this.S.add(this.O);
        this.S.add(this.P);
        this.S.add(this.Q);
        this.S.add(this.N);
    }

    public boolean A() {
        c cVar = this.J;
        c cVar2 = cVar.f1272f;
        if (cVar2 != null && cVar2.f1272f == cVar) {
            return true;
        }
        c cVar3 = this.L;
        c cVar4 = cVar3.f1272f;
        return cVar4 != null && cVar4.f1272f == cVar3;
    }

    public boolean B() {
        c cVar = this.K;
        c cVar2 = cVar.f1272f;
        if (cVar2 != null && cVar2.f1272f == cVar) {
            return true;
        }
        c cVar3 = this.M;
        c cVar4 = cVar3.f1272f;
        return cVar4 != null && cVar4.f1272f == cVar3;
    }

    public boolean C() {
        return this.f1289g && this.i0 != 8;
    }

    public boolean D() {
        return this.k || (this.J.f1269c && this.L.f1269c);
    }

    public boolean E() {
        return this.l || (this.K.f1269c && this.M.f1269c);
    }

    public void F() {
        this.J.h();
        this.K.h();
        this.L.h();
        this.M.h();
        this.N.h();
        this.O.h();
        this.P.h();
        this.Q.h();
        this.V = null;
        this.D = 0.0f;
        this.W = 0;
        this.X = 0;
        this.Y = 0.0f;
        this.Z = -1;
        this.a0 = 0;
        this.b0 = 0;
        this.c0 = 0;
        this.d0 = 0;
        this.e0 = 0;
        this.f0 = 0.5f;
        this.g0 = 0.5f;
        a[] aVarArr = this.U;
        a aVar = a.FIXED;
        aVarArr[0] = aVar;
        aVarArr[1] = aVar;
        this.h0 = null;
        this.i0 = 0;
        this.k0 = 0;
        this.l0 = 0;
        float[] fArr = this.m0;
        fArr[0] = -1.0f;
        fArr[1] = -1.0f;
        this.o = -1;
        this.p = -1;
        int[] iArr = this.C;
        iArr[0] = Integer.MAX_VALUE;
        iArr[1] = Integer.MAX_VALUE;
        this.r = 0;
        this.s = 0;
        this.w = 1.0f;
        this.z = 1.0f;
        this.v = Integer.MAX_VALUE;
        this.y = Integer.MAX_VALUE;
        this.u = 0;
        this.x = 0;
        this.A = -1;
        this.B = 1.0f;
        boolean[] zArr = this.f1288f;
        zArr[0] = true;
        zArr[1] = true;
        this.G = false;
        boolean[] zArr2 = this.T;
        zArr2[0] = false;
        zArr2[1] = false;
        this.f1289g = true;
        int[] iArr2 = this.t;
        iArr2[0] = 0;
        iArr2[1] = 0;
        this.f1290h = -1;
        this.f1291i = -1;
    }

    public void G() {
        this.k = false;
        this.l = false;
        this.m = false;
        this.n = false;
        int size = this.S.size();
        for (int i2 = 0; i2 < size; i2++) {
            c cVar = this.S.get(i2);
            cVar.f1269c = false;
            cVar.f1268b = 0;
        }
    }

    public void H(b.f.a.c cVar) {
        this.J.i();
        this.K.i();
        this.L.i();
        this.M.i();
        this.N.i();
        this.Q.i();
        this.O.i();
        this.P.i();
    }

    public final void I(StringBuilder sb, String str, float f2, float f3) {
        if (f2 == f3) {
            return;
        }
        sb.append(str);
        sb.append(" :   ");
        sb.append(f2);
        sb.append(",\n");
    }

    public final void J(StringBuilder sb, String str, int i2, int i3) {
        if (i2 == i3) {
            return;
        }
        sb.append(str);
        sb.append(" :   ");
        sb.append(i2);
        sb.append(",\n");
    }

    public void K(int i2) {
        this.c0 = i2;
        this.E = i2 > 0;
    }

    public void L(int i2, int i3) {
        if (this.k) {
            return;
        }
        c cVar = this.J;
        cVar.f1268b = i2;
        cVar.f1269c = true;
        c cVar2 = this.L;
        cVar2.f1268b = i3;
        cVar2.f1269c = true;
        this.a0 = i2;
        this.W = i3 - i2;
        this.k = true;
    }

    public void M(int i2, int i3) {
        if (this.l) {
            return;
        }
        c cVar = this.K;
        cVar.f1268b = i2;
        cVar.f1269c = true;
        c cVar2 = this.M;
        cVar2.f1268b = i3;
        cVar2.f1269c = true;
        this.b0 = i2;
        this.X = i3 - i2;
        if (this.E) {
            this.N.j(i2 + this.c0);
        }
        this.l = true;
    }

    public void N(int i2) {
        this.X = i2;
        int i3 = this.e0;
        if (i2 < i3) {
            this.X = i3;
        }
    }

    public void O(a aVar) {
        this.U[0] = aVar;
    }

    public void P(int i2) {
        if (i2 < 0) {
            this.e0 = 0;
        } else {
            this.e0 = i2;
        }
    }

    public void Q(int i2) {
        if (i2 < 0) {
            this.d0 = 0;
        } else {
            this.d0 = i2;
        }
    }

    public void R(a aVar) {
        this.U[1] = aVar;
    }

    public void S(int i2) {
        this.W = i2;
        int i3 = this.d0;
        if (i2 < i3) {
            this.W = i3;
        }
    }

    public void T(boolean z, boolean z2) {
        int i2;
        int i3;
        a aVar = a.FIXED;
        b.f.a.i.l.k kVar = this.f1286d;
        boolean z3 = z & kVar.f1355g;
        m mVar = this.f1287e;
        boolean z4 = z2 & mVar.f1355g;
        int i4 = kVar.f1356h.f1326g;
        int i5 = mVar.f1356h.f1326g;
        int i6 = kVar.f1357i.f1326g;
        int i7 = mVar.f1357i.f1326g;
        int i8 = i7 - i5;
        if (i6 - i4 < 0 || i8 < 0 || i4 == Integer.MIN_VALUE || i4 == Integer.MAX_VALUE || i5 == Integer.MIN_VALUE || i5 == Integer.MAX_VALUE || i6 == Integer.MIN_VALUE || i6 == Integer.MAX_VALUE || i7 == Integer.MIN_VALUE || i7 == Integer.MAX_VALUE) {
            i6 = 0;
            i7 = 0;
            i4 = 0;
            i5 = 0;
        }
        int i9 = i6 - i4;
        int i10 = i7 - i5;
        if (z3) {
            this.a0 = i4;
        }
        if (z4) {
            this.b0 = i5;
        }
        if (this.i0 == 8) {
            this.W = 0;
            this.X = 0;
            return;
        }
        if (z3) {
            if (this.U[0] == aVar && i9 < (i3 = this.W)) {
                i9 = i3;
            }
            this.W = i9;
            int i11 = this.d0;
            if (i9 < i11) {
                this.W = i11;
            }
        }
        if (z4) {
            if (this.U[1] == aVar && i10 < (i2 = this.X)) {
                i10 = i2;
            }
            this.X = i10;
            int i12 = this.e0;
            if (i10 < i12) {
                this.X = i12;
            }
        }
    }

    public void U(b.f.a.d dVar, boolean z) {
        int i2;
        int i3;
        m mVar;
        b.f.a.i.l.k kVar;
        int o = dVar.o(this.J);
        int o2 = dVar.o(this.K);
        int o3 = dVar.o(this.L);
        int o4 = dVar.o(this.M);
        if (z && (kVar = this.f1286d) != null) {
            b.f.a.i.l.f fVar = kVar.f1356h;
            if (fVar.f1329j) {
                b.f.a.i.l.f fVar2 = kVar.f1357i;
                if (fVar2.f1329j) {
                    o = fVar.f1326g;
                    o3 = fVar2.f1326g;
                }
            }
        }
        if (z && (mVar = this.f1287e) != null) {
            b.f.a.i.l.f fVar3 = mVar.f1356h;
            if (fVar3.f1329j) {
                b.f.a.i.l.f fVar4 = mVar.f1357i;
                if (fVar4.f1329j) {
                    o2 = fVar3.f1326g;
                    o4 = fVar4.f1326g;
                }
            }
        }
        int i4 = o4 - o2;
        if (o3 - o < 0 || i4 < 0 || o == Integer.MIN_VALUE || o == Integer.MAX_VALUE || o2 == Integer.MIN_VALUE || o2 == Integer.MAX_VALUE || o3 == Integer.MIN_VALUE || o3 == Integer.MAX_VALUE || o4 == Integer.MIN_VALUE || o4 == Integer.MAX_VALUE) {
            o4 = 0;
            o = 0;
            o2 = 0;
            o3 = 0;
        }
        a aVar = a.MATCH_CONSTRAINT;
        int i5 = o3 - o;
        int i6 = o4 - o2;
        this.a0 = o;
        this.b0 = o2;
        if (this.i0 == 8) {
            this.W = 0;
            this.X = 0;
            return;
        }
        a[] aVarArr = this.U;
        a aVar2 = aVarArr[0];
        a aVar3 = a.FIXED;
        if (aVar2 == aVar3 && i5 < (i3 = this.W)) {
            i5 = i3;
        }
        if (aVarArr[1] == aVar3 && i6 < (i2 = this.X)) {
            i6 = i2;
        }
        this.W = i5;
        this.X = i6;
        int i7 = this.e0;
        if (i6 < i7) {
            this.X = i7;
        }
        int i8 = this.d0;
        if (i5 < i8) {
            this.W = i8;
        }
        int i9 = this.v;
        if (i9 > 0 && aVarArr[0] == aVar) {
            this.W = Math.min(this.W, i9);
        }
        int i10 = this.y;
        if (i10 > 0 && this.U[1] == aVar) {
            this.X = Math.min(this.X, i10);
        }
        int i11 = this.W;
        if (i5 != i11) {
            this.f1290h = i11;
        }
        int i12 = this.X;
        if (i6 != i12) {
            this.f1291i = i12;
        }
    }

    public void b(e eVar, b.f.a.d dVar, HashSet<d> hashSet, int i2, boolean z) {
        if (z) {
            if (!hashSet.contains(this)) {
                return;
            }
            i.a(eVar, dVar, this);
            hashSet.remove(this);
            d(dVar, eVar.f0(64));
        }
        if (i2 == 0) {
            HashSet<c> hashSet2 = this.J.f1267a;
            if (hashSet2 != null) {
                Iterator<c> it = hashSet2.iterator();
                while (it.hasNext()) {
                    it.next().f1270d.b(eVar, dVar, hashSet, i2, true);
                }
            }
            HashSet<c> hashSet3 = this.L.f1267a;
            if (hashSet3 != null) {
                Iterator<c> it2 = hashSet3.iterator();
                while (it2.hasNext()) {
                    it2.next().f1270d.b(eVar, dVar, hashSet, i2, true);
                }
                return;
            }
            return;
        }
        HashSet<c> hashSet4 = this.K.f1267a;
        if (hashSet4 != null) {
            Iterator<c> it3 = hashSet4.iterator();
            while (it3.hasNext()) {
                it3.next().f1270d.b(eVar, dVar, hashSet, i2, true);
            }
        }
        HashSet<c> hashSet5 = this.M.f1267a;
        if (hashSet5 != null) {
            Iterator<c> it4 = hashSet5.iterator();
            while (it4.hasNext()) {
                it4.next().f1270d.b(eVar, dVar, hashSet, i2, true);
            }
        }
        HashSet<c> hashSet6 = this.N.f1267a;
        if (hashSet6 != null) {
            Iterator<c> it5 = hashSet6.iterator();
            while (it5.hasNext()) {
                it5.next().f1270d.b(eVar, dVar, hashSet, i2, true);
            }
        }
    }

    public boolean c() {
        return (this instanceof j) || (this instanceof f);
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x01fe  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0209  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x0210  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x022f  */
    /* JADX WARN: Removed duplicated region for block: B:179:0x0386  */
    /* JADX WARN: Removed duplicated region for block: B:184:0x0395  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:190:0x03a8  */
    /* JADX WARN: Removed duplicated region for block: B:194:0x03b1  */
    /* JADX WARN: Removed duplicated region for block: B:197:0x03ca  */
    /* JADX WARN: Removed duplicated region for block: B:207:0x03e3  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x04c5  */
    /* JADX WARN: Removed duplicated region for block: B:233:0x053d  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x0542  */
    /* JADX WARN: Removed duplicated region for block: B:257:0x05d5  */
    /* JADX WARN: Removed duplicated region for block: B:260:0x061e  */
    /* JADX WARN: Removed duplicated region for block: B:265:0x0653  */
    /* JADX WARN: Removed duplicated region for block: B:269:0x0649  */
    /* JADX WARN: Removed duplicated region for block: B:270:0x05d8  */
    /* JADX WARN: Removed duplicated region for block: B:285:0x053f  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x0529  */
    /* JADX WARN: Removed duplicated region for block: B:293:0x042b  */
    /* JADX WARN: Removed duplicated region for block: B:296:0x0439  */
    /* JADX WARN: Removed duplicated region for block: B:299:0x0462  */
    /* JADX WARN: Removed duplicated region for block: B:301:0x0465  */
    /* JADX WARN: Removed duplicated region for block: B:302:0x0441  */
    /* JADX WARN: Removed duplicated region for block: B:303:0x0433  */
    /* JADX WARN: Removed duplicated region for block: B:308:0x0390  */
    /* JADX WARN: Removed duplicated region for block: B:336:0x0371  */
    /* JADX WARN: Removed duplicated region for block: B:337:0x0212  */
    /* JADX WARN: Removed duplicated region for block: B:338:0x020b  */
    /* JADX WARN: Removed duplicated region for block: B:341:0x01eb  */
    /* JADX WARN: Removed duplicated region for block: B:343:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:350:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0143  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x017e  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x01f6  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void d(b.f.a.d r51, boolean r52) {
        /*
            Method dump skipped, instructions count: 1772
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.d.d(b.f.a.d, boolean):void");
    }

    public boolean e() {
        return this.i0 != 8;
    }

    /* JADX WARN: Removed duplicated region for block: B:137:0x037e  */
    /* JADX WARN: Removed duplicated region for block: B:151:0x03f2  */
    /* JADX WARN: Removed duplicated region for block: B:169:0x0436  */
    /* JADX WARN: Removed duplicated region for block: B:199:0x047f  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x041a  */
    /* JADX WARN: Removed duplicated region for block: B:219:0x03c8  */
    /* JADX WARN: Removed duplicated region for block: B:255:0x02c3  */
    /* JADX WARN: Removed duplicated region for block: B:257:0x02c7  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:294:0x04c9  */
    /* JADX WARN: Removed duplicated region for block: B:296:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0091  */
    /* JADX WARN: Removed duplicated region for block: B:347:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00b3  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x04da A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:76:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:85:0x04b5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:95:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void f(b.f.a.d r36, boolean r37, boolean r38, boolean r39, boolean r40, b.f.a.g r41, b.f.a.g r42, b.f.a.i.d.a r43, boolean r44, b.f.a.i.c r45, b.f.a.i.c r46, int r47, int r48, int r49, int r50, float r51, boolean r52, boolean r53, boolean r54, boolean r55, boolean r56, int r57, int r58, int r59, int r60, float r61, boolean r62) {
        /*
            Method dump skipped, instructions count: 1299
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.d.f(b.f.a.d, boolean, boolean, boolean, boolean, b.f.a.g, b.f.a.g, b.f.a.i.d$a, boolean, b.f.a.i.c, b.f.a.i.c, int, int, int, int, float, boolean, boolean, boolean, boolean, boolean, int, int, int, int, float, boolean):void");
    }

    public void g(b.f.a.d dVar) {
        dVar.l(this.J);
        dVar.l(this.K);
        dVar.l(this.L);
        dVar.l(this.M);
        if (this.c0 > 0) {
            dVar.l(this.N);
        }
    }

    public void h() {
        if (this.f1286d == null) {
            this.f1286d = new b.f.a.i.l.k(this);
        }
        if (this.f1287e == null) {
            this.f1287e = new m(this);
        }
    }

    public c i(c.a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                return null;
            case 1:
                return this.J;
            case 2:
                return this.K;
            case ModuleDescriptor.MODULE_VERSION /* 3 */:
                return this.L;
            case 4:
                return this.M;
            case 5:
                return this.N;
            case 6:
                return this.Q;
            case 7:
                return this.O;
            case 8:
                return this.P;
            default:
                throw new AssertionError(aVar.name());
        }
    }

    public int j() {
        return w() + this.X;
    }

    public a k(int i2) {
        if (i2 == 0) {
            return m();
        }
        if (i2 == 1) {
            return t();
        }
        return null;
    }

    public int l() {
        if (this.i0 == 8) {
            return 0;
        }
        return this.X;
    }

    public a m() {
        return this.U[0];
    }

    public d n(int i2) {
        c cVar;
        c cVar2;
        if (i2 != 0) {
            if (i2 == 1 && (cVar2 = (cVar = this.M).f1272f) != null && cVar2.f1272f == cVar) {
                return cVar2.f1270d;
            }
            return null;
        }
        c cVar3 = this.L;
        c cVar4 = cVar3.f1272f;
        if (cVar4 == null || cVar4.f1272f != cVar3) {
            return null;
        }
        return cVar4.f1270d;
    }

    public d o(int i2) {
        c cVar;
        c cVar2;
        if (i2 != 0) {
            if (i2 == 1 && (cVar2 = (cVar = this.K).f1272f) != null && cVar2.f1272f == cVar) {
                return cVar2.f1270d;
            }
            return null;
        }
        c cVar3 = this.J;
        c cVar4 = cVar3.f1272f;
        if (cVar4 == null || cVar4.f1272f != cVar3) {
            return null;
        }
        return cVar4.f1270d;
    }

    public int p() {
        return v() + this.W;
    }

    public void q(StringBuilder sb) {
        StringBuilder n = c.a.a.a.a.n("  ");
        n.append(this.f1292j);
        n.append(":{\n");
        sb.append(n.toString());
        sb.append("    actualWidth:" + this.W);
        sb.append("\n");
        sb.append("    actualHeight:" + this.X);
        sb.append("\n");
        sb.append("    actualLeft:" + this.a0);
        sb.append("\n");
        sb.append("    actualTop:" + this.b0);
        sb.append("\n");
        s(sb, "left", this.J);
        s(sb, "top", this.K);
        s(sb, "right", this.L);
        s(sb, "bottom", this.M);
        s(sb, "baseline", this.N);
        s(sb, "centerX", this.O);
        s(sb, "centerY", this.P);
        int i2 = this.W;
        int i3 = this.d0;
        int i4 = this.C[0];
        int i5 = this.u;
        int i6 = this.r;
        float f2 = this.w;
        float f3 = this.m0[0];
        r(sb, "    width", i2, i3, i4, i5, i6, f2);
        int i7 = this.X;
        int i8 = this.e0;
        int i9 = this.C[1];
        int i10 = this.x;
        int i11 = this.s;
        float f4 = this.z;
        float f5 = this.m0[1];
        r(sb, "    height", i7, i8, i9, i10, i11, f4);
        float f6 = this.Y;
        int i12 = this.Z;
        if (f6 != 0.0f) {
            sb.append("    dimensionRatio");
            sb.append(" :  [");
            sb.append(f6);
            sb.append(",");
            sb.append(i12);
            sb.append("");
            sb.append("],\n");
        }
        I(sb, "    horizontalBias", this.f0, 0.5f);
        I(sb, "    verticalBias", this.g0, 0.5f);
        J(sb, "    horizontalChainStyle", this.k0, 0);
        J(sb, "    verticalChainStyle", this.l0, 0);
        sb.append("  }");
    }

    public final void r(StringBuilder sb, String str, int i2, int i3, int i4, int i5, int i6, float f2) {
        sb.append(str);
        sb.append(" :  {\n");
        J(sb, "      size", i2, 0);
        J(sb, "      min", i3, 0);
        J(sb, "      max", i4, Integer.MAX_VALUE);
        J(sb, "      matchMin", i5, 0);
        J(sb, "      matchDef", i6, 0);
        I(sb, "      matchPercent", f2, 1.0f);
        sb.append("    },\n");
    }

    public final void s(StringBuilder sb, String str, c cVar) {
        if (cVar.f1272f == null) {
            return;
        }
        sb.append("    ");
        sb.append(str);
        sb.append(" : [ '");
        sb.append(cVar.f1272f);
        sb.append("'");
        if (cVar.f1274h != Integer.MIN_VALUE || cVar.f1273g != 0) {
            sb.append(",");
            sb.append(cVar.f1273g);
            if (cVar.f1274h != Integer.MIN_VALUE) {
                sb.append(",");
                sb.append(cVar.f1274h);
                sb.append(",");
            }
        }
        sb.append(" ] ,\n");
    }

    public a t() {
        return this.U[1];
    }

    public String toString() {
        String str = "";
        StringBuilder n = c.a.a.a.a.n("");
        if (this.j0 != null) {
            StringBuilder n2 = c.a.a.a.a.n("id: ");
            n2.append(this.j0);
            n2.append(" ");
            str = n2.toString();
        }
        n.append(str);
        n.append("(");
        n.append(this.a0);
        n.append(", ");
        n.append(this.b0);
        n.append(") - (");
        n.append(this.W);
        n.append(" x ");
        n.append(this.X);
        n.append(")");
        return n.toString();
    }

    public int u() {
        if (this.i0 == 8) {
            return 0;
        }
        return this.W;
    }

    public int v() {
        d dVar = this.V;
        return (dVar == null || !(dVar instanceof e)) ? this.a0 : ((e) dVar).y0 + this.a0;
    }

    public int w() {
        d dVar = this.V;
        return (dVar == null || !(dVar instanceof e)) ? this.b0 : ((e) dVar).z0 + this.b0;
    }

    public boolean x(int i2) {
        if (i2 == 0) {
            return (this.J.f1272f != null ? 1 : 0) + (this.L.f1272f != null ? 1 : 0) < 2;
        }
        return ((this.K.f1272f != null ? 1 : 0) + (this.M.f1272f != null ? 1 : 0)) + (this.N.f1272f != null ? 1 : 0) < 2;
    }

    public boolean y(int i2, int i3) {
        c cVar;
        c cVar2;
        if (i2 == 0) {
            c cVar3 = this.J.f1272f;
            if (cVar3 != null && cVar3.f1269c && (cVar2 = this.L.f1272f) != null && cVar2.f1269c) {
                return (cVar2.c() - this.L.d()) - (this.J.d() + this.J.f1272f.c()) >= i3;
            }
        } else {
            c cVar4 = this.K.f1272f;
            if (cVar4 != null && cVar4.f1269c && (cVar = this.M.f1272f) != null && cVar.f1269c) {
                return (cVar.c() - this.M.d()) - (this.K.d() + this.K.f1272f.c()) >= i3;
            }
        }
        return false;
    }

    public final boolean z(int i2) {
        int i3 = i2 * 2;
        c[] cVarArr = this.R;
        if (cVarArr[i3].f1272f != null && cVarArr[i3].f1272f.f1272f != cVarArr[i3]) {
            int i4 = i3 + 1;
            if (cVarArr[i4].f1272f != null && cVarArr[i4].f1272f.f1272f == cVarArr[i4]) {
                return true;
            }
        }
        return false;
    }
}
