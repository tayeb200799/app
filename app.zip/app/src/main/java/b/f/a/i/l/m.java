package b.f.a.i.l;

import b.f.a.i.c;
import b.f.a.i.d;
import b.f.a.i.l.f;
import b.f.a.i.l.o;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\m.smali */
public class m extends o {
    public f k;
    public g l;

    public m(b.f.a.i.d dVar) {
        super(dVar);
        f fVar = new f(this);
        this.k = fVar;
        this.l = null;
        this.f1359h.f1327e = f.a.TOP;
        this.f1360i.f1327e = f.a.BOTTOM;
        fVar.f1327e = f.a.BASELINE;
        this.f1357f = 1;
    }

    @Override // b.f.a.i.l.o, b.f.a.i.l.d
    public void a(d dVar) {
        float f2;
        float f3;
        float f4;
        int i2;
        d.a aVar = d.a.MATCH_CONSTRAINT;
        int ordinal = this.f1361j.ordinal();
        if (ordinal != 1 && ordinal != 2 && ordinal == 3) {
            b.f.a.i.d dVar2 = this.f1353b;
            l(dVar2.K, dVar2.M, 1);
            return;
        }
        g gVar = this.f1356e;
        if (gVar.f1325c && !gVar.f1332j && this.f1355d == aVar) {
            b.f.a.i.d dVar3 = this.f1353b;
            int i3 = dVar3.s;
            if (i3 == 2) {
                b.f.a.i.d dVar4 = dVar3.V;
                if (dVar4 != null) {
                    if (dVar4.f1290e.f1356e.f1332j) {
                        gVar.c((int) ((r1.f1329g * dVar3.z) + 0.5f));
                    }
                }
            } else if (i3 == 3) {
                g gVar2 = dVar3.f1289d.f1356e;
                if (gVar2.f1332j) {
                    int i4 = dVar3.Z;
                    if (i4 == -1) {
                        f2 = gVar2.f1329g;
                        f3 = dVar3.Y;
                    } else if (i4 == 0) {
                        f4 = gVar2.f1329g * dVar3.Y;
                        i2 = (int) (f4 + 0.5f);
                        gVar.c(i2);
                    } else if (i4 != 1) {
                        i2 = 0;
                        gVar.c(i2);
                    } else {
                        f2 = gVar2.f1329g;
                        f3 = dVar3.Y;
                    }
                    f4 = f2 / f3;
                    i2 = (int) (f4 + 0.5f);
                    gVar.c(i2);
                }
            }
        }
        f fVar = this.f1359h;
        if (fVar.f1325c) {
            f fVar2 = this.f1360i;
            if (fVar2.f1325c) {
                if (fVar.f1332j && fVar2.f1332j && this.f1356e.f1332j) {
                    return;
                }
                if (!this.f1356e.f1332j && this.f1355d == aVar) {
                    b.f.a.i.d dVar5 = this.f1353b;
                    if (dVar5.r == 0 && !dVar5.B()) {
                        f fVar3 = this.f1359h.l.get(0);
                        f fVar4 = this.f1360i.l.get(0);
                        int i5 = fVar3.f1329g;
                        f fVar5 = this.f1359h;
                        int i6 = i5 + fVar5.f1328f;
                        int i7 = fVar4.f1329g + this.f1360i.f1328f;
                        fVar5.c(i6);
                        this.f1360i.c(i7);
                        this.f1356e.c(i7 - i6);
                        return;
                    }
                }
                if (!this.f1356e.f1332j && this.f1355d == aVar && this.f1352a == 1 && this.f1359h.l.size() > 0 && this.f1360i.l.size() > 0) {
                    f fVar6 = this.f1359h.l.get(0);
                    int i8 = (this.f1360i.l.get(0).f1329g + this.f1360i.f1328f) - (fVar6.f1329g + this.f1359h.f1328f);
                    g gVar3 = this.f1356e;
                    int i9 = gVar3.m;
                    if (i8 < i9) {
                        gVar3.c(i8);
                    } else {
                        gVar3.c(i9);
                    }
                }
                if (this.f1356e.f1332j && this.f1359h.l.size() > 0 && this.f1360i.l.size() > 0) {
                    f fVar7 = this.f1359h.l.get(0);
                    f fVar8 = this.f1360i.l.get(0);
                    int i10 = fVar7.f1329g;
                    f fVar9 = this.f1359h;
                    int i11 = fVar9.f1328f + i10;
                    int i12 = fVar8.f1329g;
                    int i13 = this.f1360i.f1328f + i12;
                    float f5 = this.f1353b.g0;
                    if (fVar7 == fVar8) {
                        f5 = 0.5f;
                    } else {
                        i10 = i11;
                        i12 = i13;
                    }
                    fVar9.c((int) ((((i12 - i10) - this.f1356e.f1329g) * f5) + i10 + 0.5f));
                    this.f1360i.c(this.f1359h.f1329g + this.f1356e.f1329g);
                }
            }
        }
    }

    @Override // b.f.a.i.l.o
    public void d() {
        b.f.a.i.d dVar;
        b.f.a.i.d dVar2;
        b.f.a.i.d dVar3;
        d.a aVar = d.a.MATCH_PARENT;
        d.a aVar2 = d.a.FIXED;
        d.a aVar3 = d.a.MATCH_CONSTRAINT;
        b.f.a.i.d dVar4 = this.f1353b;
        if (dVar4.f1286a) {
            this.f1356e.c(dVar4.l());
        }
        if (!this.f1356e.f1332j) {
            this.f1355d = this.f1353b.t();
            if (this.f1353b.E) {
                this.l = new a(this);
            }
            d.a aVar4 = this.f1355d;
            if (aVar4 != aVar3) {
                if (aVar4 == aVar && (dVar3 = this.f1353b.V) != null && dVar3.t() == aVar2) {
                    int l = (dVar3.l() - this.f1353b.K.d()) - this.f1353b.M.d();
                    b(this.f1359h, dVar3.f1290e.f1359h, this.f1353b.K.d());
                    b(this.f1360i, dVar3.f1290e.f1360i, -this.f1353b.M.d());
                    this.f1356e.c(l);
                    return;
                }
                if (this.f1355d == aVar2) {
                    this.f1356e.c(this.f1353b.l());
                }
            }
        } else if (this.f1355d == aVar && (dVar = this.f1353b.V) != null && dVar.t() == aVar2) {
            b(this.f1359h, dVar.f1290e.f1359h, this.f1353b.K.d());
            b(this.f1360i, dVar.f1290e.f1360i, -this.f1353b.M.d());
            return;
        }
        g gVar = this.f1356e;
        boolean z = gVar.f1332j;
        if (z) {
            b.f.a.i.d dVar5 = this.f1353b;
            if (dVar5.f1286a) {
                b.f.a.i.c[] cVarArr = dVar5.R;
                if (cVarArr[2].f1275f != null && cVarArr[3].f1275f != null) {
                    if (dVar5.B()) {
                        this.f1359h.f1328f = this.f1353b.R[2].d();
                        this.f1360i.f1328f = -this.f1353b.R[3].d();
                    } else {
                        f h2 = h(this.f1353b.R[2]);
                        if (h2 != null) {
                            f fVar = this.f1359h;
                            int d2 = this.f1353b.R[2].d();
                            fVar.l.add(h2);
                            fVar.f1328f = d2;
                            h2.k.add(fVar);
                        }
                        f h3 = h(this.f1353b.R[3]);
                        if (h3 != null) {
                            f fVar2 = this.f1360i;
                            int i2 = -this.f1353b.R[3].d();
                            fVar2.l.add(h3);
                            fVar2.f1328f = i2;
                            h3.k.add(fVar2);
                        }
                        this.f1359h.f1324b = true;
                        this.f1360i.f1324b = true;
                    }
                    b.f.a.i.d dVar6 = this.f1353b;
                    if (dVar6.E) {
                        b(this.k, this.f1359h, dVar6.c0);
                        return;
                    }
                    return;
                }
                if (cVarArr[2].f1275f != null) {
                    f h4 = h(cVarArr[2]);
                    if (h4 != null) {
                        f fVar3 = this.f1359h;
                        int d3 = this.f1353b.R[2].d();
                        fVar3.l.add(h4);
                        fVar3.f1328f = d3;
                        h4.k.add(fVar3);
                        b(this.f1360i, this.f1359h, this.f1356e.f1329g);
                        b.f.a.i.d dVar7 = this.f1353b;
                        if (dVar7.E) {
                            b(this.k, this.f1359h, dVar7.c0);
                            return;
                        }
                        return;
                    }
                    return;
                }
                if (cVarArr[3].f1275f != null) {
                    f h5 = h(cVarArr[3]);
                    if (h5 != null) {
                        f fVar4 = this.f1360i;
                        int i3 = -this.f1353b.R[3].d();
                        fVar4.l.add(h5);
                        fVar4.f1328f = i3;
                        h5.k.add(fVar4);
                        b(this.f1359h, this.f1360i, -this.f1356e.f1329g);
                    }
                    b.f.a.i.d dVar8 = this.f1353b;
                    if (dVar8.E) {
                        b(this.k, this.f1359h, dVar8.c0);
                        return;
                    }
                    return;
                }
                if (cVarArr[4].f1275f != null) {
                    f h6 = h(cVarArr[4]);
                    if (h6 != null) {
                        f fVar5 = this.k;
                        fVar5.l.add(h6);
                        fVar5.f1328f = 0;
                        h6.k.add(fVar5);
                        b(this.f1359h, this.k, -this.f1353b.c0);
                        b(this.f1360i, this.f1359h, this.f1356e.f1329g);
                        return;
                    }
                    return;
                }
                if ((dVar5 instanceof b.f.a.i.g) || dVar5.V == null || dVar5.i(c.a.CENTER).f1275f != null) {
                    return;
                }
                b.f.a.i.d dVar9 = this.f1353b;
                b(this.f1359h, dVar9.V.f1290e.f1359h, dVar9.w());
                b(this.f1360i, this.f1359h, this.f1356e.f1329g);
                b.f.a.i.d dVar10 = this.f1353b;
                if (dVar10.E) {
                    b(this.k, this.f1359h, dVar10.c0);
                    return;
                }
                return;
            }
        }
        if (z || this.f1355d != aVar3) {
            gVar.k.add(this);
            if (gVar.f1332j) {
                a(this);
            }
        } else {
            b.f.a.i.d dVar11 = this.f1353b;
            int i4 = dVar11.s;
            if (i4 == 2) {
                b.f.a.i.d dVar12 = dVar11.V;
                if (dVar12 != null) {
                    g gVar2 = dVar12.f1290e.f1356e;
                    gVar.l.add(gVar2);
                    gVar2.k.add(this.f1356e);
                    g gVar3 = this.f1356e;
                    gVar3.f1324b = true;
                    gVar3.k.add(this.f1359h);
                    this.f1356e.k.add(this.f1360i);
                }
            } else if (i4 == 3 && !dVar11.B()) {
                b.f.a.i.d dVar13 = this.f1353b;
                if (dVar13.r != 3) {
                    g gVar4 = dVar13.f1289d.f1356e;
                    this.f1356e.l.add(gVar4);
                    gVar4.k.add(this.f1356e);
                    g gVar5 = this.f1356e;
                    gVar5.f1324b = true;
                    gVar5.k.add(this.f1359h);
                    this.f1356e.k.add(this.f1360i);
                }
            }
        }
        b.f.a.i.d dVar14 = this.f1353b;
        b.f.a.i.c[] cVarArr2 = dVar14.R;
        if (cVarArr2[2].f1275f != null && cVarArr2[3].f1275f != null) {
            if (dVar14.B()) {
                this.f1359h.f1328f = this.f1353b.R[2].d();
                this.f1360i.f1328f = -this.f1353b.R[3].d();
            } else {
                f h7 = h(this.f1353b.R[2]);
                f h8 = h(this.f1353b.R[3]);
                if (h7 != null) {
                    h7.k.add(this);
                    if (h7.f1332j) {
                        a(this);
                    }
                }
                if (h8 != null) {
                    h8.k.add(this);
                    if (h8.f1332j) {
                        a(this);
                    }
                }
                this.f1361j = o.a.CENTER;
            }
            if (this.f1353b.E) {
                c(this.k, this.f1359h, 1, this.l);
            }
        } else if (cVarArr2[2].f1275f != null) {
            f h9 = h(cVarArr2[2]);
            if (h9 != null) {
                f fVar6 = this.f1359h;
                int d4 = this.f1353b.R[2].d();
                fVar6.l.add(h9);
                fVar6.f1328f = d4;
                h9.k.add(fVar6);
                c(this.f1360i, this.f1359h, 1, this.f1356e);
                if (this.f1353b.E) {
                    c(this.k, this.f1359h, 1, this.l);
                }
                if (this.f1355d == aVar3) {
                    b.f.a.i.d dVar15 = this.f1353b;
                    if (dVar15.Y > 0.0f) {
                        k kVar = dVar15.f1289d;
                        if (kVar.f1355d == aVar3) {
                            kVar.f1356e.k.add(this.f1356e);
                            this.f1356e.l.add(this.f1353b.f1289d.f1356e);
                            this.f1356e.f1323a = this;
                        }
                    }
                }
            }
        } else if (cVarArr2[3].f1275f != null) {
            f h10 = h(cVarArr2[3]);
            if (h10 != null) {
                f fVar7 = this.f1360i;
                int i5 = -this.f1353b.R[3].d();
                fVar7.l.add(h10);
                fVar7.f1328f = i5;
                h10.k.add(fVar7);
                c(this.f1359h, this.f1360i, -1, this.f1356e);
                if (this.f1353b.E) {
                    c(this.k, this.f1359h, 1, this.l);
                }
            }
        } else if (cVarArr2[4].f1275f != null) {
            f h11 = h(cVarArr2[4]);
            if (h11 != null) {
                f fVar8 = this.k;
                fVar8.l.add(h11);
                fVar8.f1328f = 0;
                h11.k.add(fVar8);
                c(this.f1359h, this.k, -1, this.l);
                c(this.f1360i, this.f1359h, 1, this.f1356e);
            }
        } else if (!(dVar14 instanceof b.f.a.i.g) && (dVar2 = dVar14.V) != null) {
            b(this.f1359h, dVar2.f1290e.f1359h, dVar14.w());
            c(this.f1360i, this.f1359h, 1, this.f1356e);
            if (this.f1353b.E) {
                c(this.k, this.f1359h, 1, this.l);
            }
            if (this.f1355d == aVar3) {
                b.f.a.i.d dVar16 = this.f1353b;
                if (dVar16.Y > 0.0f) {
                    k kVar2 = dVar16.f1289d;
                    if (kVar2.f1355d == aVar3) {
                        kVar2.f1356e.k.add(this.f1356e);
                        this.f1356e.l.add(this.f1353b.f1289d.f1356e);
                        this.f1356e.f1323a = this;
                    }
                }
            }
        }
        if (this.f1356e.l.size() == 0) {
            this.f1356e.f1325c = true;
        }
    }

    @Override // b.f.a.i.l.o
    public void e() {
        f fVar = this.f1359h;
        if (fVar.f1332j) {
            this.f1353b.b0 = fVar.f1329g;
        }
    }

    @Override // b.f.a.i.l.o
    public void f() {
        this.f1354c = null;
        this.f1359h.b();
        this.f1360i.b();
        this.k.b();
        this.f1356e.b();
        this.f1358g = false;
    }

    @Override // b.f.a.i.l.o
    public boolean k() {
        return this.f1355d != d.a.MATCH_CONSTRAINT || this.f1353b.s == 0;
    }

    public void m() {
        this.f1358g = false;
        this.f1359h.b();
        this.f1359h.f1332j = false;
        this.f1360i.b();
        this.f1360i.f1332j = false;
        this.k.b();
        this.k.f1332j = false;
        this.f1356e.f1332j = false;
    }

    public String toString() {
        StringBuilder n = c.a.a.a.a.n("VerticalRun ");
        n.append(this.f1353b.j0);
        return n.toString();
    }
}
