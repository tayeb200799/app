package b.f.a.i.l;

import androidx.constraintlayout.widget.ConstraintLayout;
import b.f.a.i.d;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\b.smali */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList<b.f.a.i.d> f1299a = new ArrayList<>();

    /* renamed from: b, reason: collision with root package name */
    public a f1300b = new a();

    /* renamed from: c, reason: collision with root package name */
    public b.f.a.i.e f1301c;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\b$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public d.a f1302a;

        /* renamed from: b, reason: collision with root package name */
        public d.a f1303b;

        /* renamed from: c, reason: collision with root package name */
        public int f1304c;

        /* renamed from: d, reason: collision with root package name */
        public int f1305d;

        /* renamed from: e, reason: collision with root package name */
        public int f1306e;

        /* renamed from: f, reason: collision with root package name */
        public int f1307f;

        /* renamed from: g, reason: collision with root package name */
        public int f1308g;

        /* renamed from: h, reason: collision with root package name */
        public boolean f1309h;

        /* renamed from: i, reason: collision with root package name */
        public boolean f1310i;

        /* renamed from: j, reason: collision with root package name */
        public int f1311j;
    }

    /* renamed from: b.f.a.i.l.b$b, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\b$b.smali */
    public interface InterfaceC0021b {
    }

    public b(b.f.a.i.e eVar) {
        this.f1301c = eVar;
    }

    public final boolean a(InterfaceC0021b interfaceC0021b, b.f.a.i.d dVar, int i2) {
        d.a aVar = d.a.FIXED;
        this.f1300b.f1302a = dVar.m();
        this.f1300b.f1303b = dVar.t();
        this.f1300b.f1304c = dVar.u();
        this.f1300b.f1305d = dVar.l();
        a aVar2 = this.f1300b;
        aVar2.f1310i = false;
        aVar2.f1311j = i2;
        d.a aVar3 = aVar2.f1302a;
        d.a aVar4 = d.a.MATCH_CONSTRAINT;
        boolean z = aVar3 == aVar4;
        boolean z2 = aVar2.f1303b == aVar4;
        boolean z3 = z && dVar.Y > 0.0f;
        boolean z4 = z2 && dVar.Y > 0.0f;
        if (z3 && dVar.t[0] == 4) {
            aVar2.f1302a = aVar;
        }
        if (z4 && dVar.t[1] == 4) {
            aVar2.f1303b = aVar;
        }
        ((ConstraintLayout.b) interfaceC0021b).b(dVar, aVar2);
        dVar.S(this.f1300b.f1306e);
        dVar.N(this.f1300b.f1307f);
        a aVar5 = this.f1300b;
        dVar.E = aVar5.f1309h;
        dVar.K(aVar5.f1308g);
        a aVar6 = this.f1300b;
        aVar6.f1311j = 0;
        return aVar6.f1310i;
    }

    public final void b(b.f.a.i.e eVar, int i2, int i3, int i4) {
        int i5 = eVar.d0;
        int i6 = eVar.e0;
        eVar.Q(0);
        eVar.P(0);
        eVar.W = i3;
        int i7 = eVar.d0;
        if (i3 < i7) {
            eVar.W = i7;
        }
        eVar.X = i4;
        int i8 = eVar.e0;
        if (i4 < i8) {
            eVar.X = i8;
        }
        eVar.Q(i5);
        eVar.P(i6);
        b.f.a.i.e eVar2 = this.f1301c;
        eVar2.u0 = i2;
        eVar2.V();
    }

    public void c(b.f.a.i.e eVar) {
        this.f1299a.clear();
        int size = eVar.r0.size();
        for (int i2 = 0; i2 < size; i2++) {
            b.f.a.i.d dVar = eVar.r0.get(i2);
            d.a m = dVar.m();
            d.a aVar = d.a.MATCH_CONSTRAINT;
            if (m == aVar || dVar.t() == aVar) {
                this.f1299a.add(dVar);
            }
        }
        eVar.d0();
    }
}
