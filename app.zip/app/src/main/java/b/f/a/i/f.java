package b.f.a.i;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\j.smali */
public class j extends h {
    @Override // b.f.a.i.h, b.f.a.i.g
    public void a(e eVar) {
        for (int i2 = 0; i2 < this.s0; i2++) {
            d dVar = this.r0[i2];
            if (dVar != null) {
                dVar.G = true;
            }
        }
    }
}
