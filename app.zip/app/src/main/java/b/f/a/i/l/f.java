package b.f.a.i.l;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\i.smali */
public class i extends o {
    public i(b.f.a.i.d dVar) {
        super(dVar);
        dVar.f1286d.f();
        dVar.f1287e.f();
        this.f1354f = ((b.f.a.i.f) dVar).v0;
    }

    @Override // b.f.a.i.l.o, b.f.a.i.l.d
    public void a(d dVar) {
        f fVar = this.f1356h;
        if (fVar.f1322c && !fVar.f1329j) {
            this.f1356h.c((int) ((fVar.l.get(0).f1326g * ((b.f.a.i.f) this.f1350b).r0) + 0.5f));
        }
    }

    @Override // b.f.a.i.l.o
    public void d() {
        b.f.a.i.d dVar = this.f1350b;
        b.f.a.i.f fVar = (b.f.a.i.f) dVar;
        int i2 = fVar.s0;
        int i3 = fVar.t0;
        if (fVar.v0 == 1) {
            if (i2 != -1) {
                this.f1356h.l.add(dVar.V.f1286d.f1356h);
                this.f1350b.V.f1286d.f1356h.k.add(this.f1356h);
                this.f1356h.f1325f = i2;
            } else if (i3 != -1) {
                this.f1356h.l.add(dVar.V.f1286d.f1357i);
                this.f1350b.V.f1286d.f1357i.k.add(this.f1356h);
                this.f1356h.f1325f = -i3;
            } else {
                f fVar2 = this.f1356h;
                fVar2.f1321b = true;
                fVar2.l.add(dVar.V.f1286d.f1357i);
                this.f1350b.V.f1286d.f1357i.k.add(this.f1356h);
            }
            m(this.f1350b.f1286d.f1356h);
            m(this.f1350b.f1286d.f1357i);
            return;
        }
        if (i2 != -1) {
            this.f1356h.l.add(dVar.V.f1287e.f1356h);
            this.f1350b.V.f1287e.f1356h.k.add(this.f1356h);
            this.f1356h.f1325f = i2;
        } else if (i3 != -1) {
            this.f1356h.l.add(dVar.V.f1287e.f1357i);
            this.f1350b.V.f1287e.f1357i.k.add(this.f1356h);
            this.f1356h.f1325f = -i3;
        } else {
            f fVar3 = this.f1356h;
            fVar3.f1321b = true;
            fVar3.l.add(dVar.V.f1287e.f1357i);
            this.f1350b.V.f1287e.f1357i.k.add(this.f1356h);
        }
        m(this.f1350b.f1287e.f1356h);
        m(this.f1350b.f1287e.f1357i);
    }

    @Override // b.f.a.i.l.o
    public void e() {
        b.f.a.i.d dVar = this.f1350b;
        if (((b.f.a.i.f) dVar).v0 == 1) {
            dVar.a0 = this.f1356h.f1326g;
        } else {
            dVar.b0 = this.f1356h.f1326g;
        }
    }

    @Override // b.f.a.i.l.o
    public void f() {
        this.f1356h.b();
    }

    @Override // b.f.a.i.l.o
    public boolean k() {
        return false;
    }

    public final void m(f fVar) {
        this.f1356h.k.add(fVar);
        fVar.l.add(this.f1356h);
    }
}
