package b.f.a.i;

import androidx.constraintlayout.widget.ConstraintLayout;
import b.f.a.i.d;
import b.f.a.i.l.b;
import b.f.a.i.l.o;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\e.smali */
public class e extends k {
    public int u0;
    public int y0;
    public int z0;
    public b.f.a.i.l.b s0 = new b.f.a.i.l.b(this);
    public b.f.a.i.l.e t0 = new b.f.a.i.l.e(this);
    public b.InterfaceC0021b v0 = null;
    public boolean w0 = false;
    public b.f.a.d x0 = new b.f.a.d();
    public int A0 = 0;
    public int B0 = 0;
    public b[] C0 = new b[4];
    public b[] D0 = new b[4];
    public int E0 = 257;
    public boolean F0 = false;
    public boolean G0 = false;
    public WeakReference<c> H0 = null;
    public WeakReference<c> I0 = null;
    public WeakReference<c> J0 = null;
    public WeakReference<c> K0 = null;
    public HashSet<d> L0 = new HashSet<>();
    public b.a M0 = new b.a();

    public static boolean e0(d dVar, b.InterfaceC0021b interfaceC0021b, b.a aVar, int i2) {
        int i3;
        int i4;
        d.a aVar2 = d.a.WRAP_CONTENT;
        d.a aVar3 = d.a.FIXED;
        if (interfaceC0021b == null) {
            return false;
        }
        if (dVar.i0 == 8 || (dVar instanceof f) || (dVar instanceof a)) {
            aVar.f1306e = 0;
            aVar.f1307f = 0;
            return false;
        }
        aVar.f1302a = dVar.m();
        aVar.f1303b = dVar.t();
        aVar.f1304c = dVar.u();
        aVar.f1305d = dVar.l();
        aVar.f1310i = false;
        aVar.f1311j = i2;
        d.a aVar4 = aVar.f1302a;
        d.a aVar5 = d.a.MATCH_CONSTRAINT;
        boolean z = aVar4 == aVar5;
        boolean z2 = aVar.f1303b == aVar5;
        boolean z3 = z && dVar.Y > 0.0f;
        boolean z4 = z2 && dVar.Y > 0.0f;
        if (z && dVar.x(0) && dVar.r == 0 && !z3) {
            aVar.f1302a = aVar2;
            if (z2 && dVar.s == 0) {
                aVar.f1302a = aVar3;
            }
            z = false;
        }
        if (z2 && dVar.x(1) && dVar.s == 0 && !z4) {
            aVar.f1303b = aVar2;
            if (z && dVar.r == 0) {
                aVar.f1303b = aVar3;
            }
            z2 = false;
        }
        if (dVar.D()) {
            aVar.f1302a = aVar3;
            z = false;
        }
        if (dVar.E()) {
            aVar.f1303b = aVar3;
            z2 = false;
        }
        if (z3) {
            if (dVar.t[0] == 4) {
                aVar.f1302a = aVar3;
            } else if (!z2) {
                if (aVar.f1303b == aVar3) {
                    i4 = aVar.f1305d;
                } else {
                    aVar.f1302a = aVar2;
                    ((ConstraintLayout.b) interfaceC0021b).b(dVar, aVar);
                    i4 = aVar.f1307f;
                }
                aVar.f1302a = aVar3;
                aVar.f1304c = (int) (dVar.Y * i4);
            }
        }
        if (z4) {
            if (dVar.t[1] == 4) {
                aVar.f1303b = aVar3;
            } else if (!z) {
                if (aVar.f1302a == aVar3) {
                    i3 = aVar.f1304c;
                } else {
                    aVar.f1303b = aVar2;
                    ((ConstraintLayout.b) interfaceC0021b).b(dVar, aVar);
                    i3 = aVar.f1306e;
                }
                aVar.f1303b = aVar3;
                if (dVar.Z == -1) {
                    aVar.f1305d = (int) (i3 / dVar.Y);
                } else {
                    aVar.f1305d = (int) (dVar.Y * i3);
                }
            }
        }
        ((ConstraintLayout.b) interfaceC0021b).b(dVar, aVar);
        dVar.S(aVar.f1306e);
        dVar.N(aVar.f1307f);
        dVar.E = aVar.f1309h;
        dVar.K(aVar.f1308g);
        aVar.f1311j = 0;
        return aVar.f1310i;
    }

    @Override // b.f.a.i.k, b.f.a.i.d
    public void F() {
        this.x0.u();
        this.y0 = 0;
        this.z0 = 0;
        super.F();
    }

    @Override // b.f.a.i.d
    public void T(boolean z, boolean z2) {
        super.T(z, z2);
        int size = this.r0.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.r0.get(i2).T(z, z2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:357:0x060c, code lost:
    
        r0 = false;
     */
    /* JADX WARN: Removed duplicated region for block: B:197:0x067a  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x0692 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:206:0x069f  */
    /* JADX WARN: Removed duplicated region for block: B:211:0x06b3  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x06d0  */
    /* JADX WARN: Removed duplicated region for block: B:257:0x07db  */
    /* JADX WARN: Removed duplicated region for block: B:274:0x083e A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:292:0x08b9  */
    /* JADX WARN: Removed duplicated region for block: B:295:0x08d4  */
    /* JADX WARN: Removed duplicated region for block: B:297:0x08e3  */
    /* JADX WARN: Removed duplicated region for block: B:310:0x0920  */
    /* JADX WARN: Removed duplicated region for block: B:313:0x0922  */
    /* JADX WARN: Removed duplicated region for block: B:316:0x08e0  */
    /* JADX WARN: Removed duplicated region for block: B:318:0x0820  */
    /* JADX WARN: Removed duplicated region for block: B:342:0x0930  */
    /* JADX WARN: Removed duplicated region for block: B:368:0x0632  */
    /* JADX WARN: Removed duplicated region for block: B:375:0x0648  */
    /* JADX WARN: Removed duplicated region for block: B:581:0x05d7  */
    /* JADX WARN: Removed duplicated region for block: B:602:0x0609 A[ADDED_TO_REGION] */
    /* JADX WARN: Type inference failed for: r3v13 */
    /* JADX WARN: Type inference failed for: r3v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r3v16 */
    @Override // b.f.a.i.k
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void V() {
        /*
            Method dump skipped, instructions count: 2368
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.e.V():void");
    }

    public void W(d dVar, int i2) {
        if (i2 == 0) {
            int i3 = this.A0 + 1;
            b[] bVarArr = this.D0;
            if (i3 >= bVarArr.length) {
                this.D0 = (b[]) Arrays.copyOf(bVarArr, bVarArr.length * 2);
            }
            b[] bVarArr2 = this.D0;
            int i4 = this.A0;
            bVarArr2[i4] = new b(dVar, 0, this.w0);
            this.A0 = i4 + 1;
            return;
        }
        if (i2 == 1) {
            int i5 = this.B0 + 1;
            b[] bVarArr3 = this.C0;
            if (i5 >= bVarArr3.length) {
                this.C0 = (b[]) Arrays.copyOf(bVarArr3, bVarArr3.length * 2);
            }
            b[] bVarArr4 = this.C0;
            int i6 = this.B0;
            bVarArr4[i6] = new b(dVar, 1, this.w0);
            this.B0 = i6 + 1;
        }
    }

    public boolean X(b.f.a.d dVar) {
        boolean z;
        d.a aVar = d.a.FIXED;
        d.a aVar2 = d.a.WRAP_CONTENT;
        boolean f0 = f0(64);
        d(dVar, f0);
        int size = this.r0.size();
        boolean z2 = false;
        for (int i2 = 0; i2 < size; i2++) {
            d dVar2 = this.r0.get(i2);
            boolean[] zArr = dVar2.T;
            zArr[0] = false;
            zArr[1] = false;
            if (dVar2 instanceof a) {
                z2 = true;
            }
        }
        if (z2) {
            for (int i3 = 0; i3 < size; i3++) {
                d dVar3 = this.r0.get(i3);
                if (dVar3 instanceof a) {
                    a aVar3 = (a) dVar3;
                    for (int i4 = 0; i4 < aVar3.s0; i4++) {
                        d dVar4 = aVar3.r0[i4];
                        if (aVar3.u0 || dVar4.e()) {
                            int i5 = aVar3.t0;
                            if (i5 == 0 || i5 == 1) {
                                dVar4.T[0] = true;
                            } else if (i5 == 2 || i5 == 3) {
                                dVar4.T[1] = true;
                            }
                        }
                    }
                }
            }
        }
        this.L0.clear();
        for (int i6 = 0; i6 < size; i6++) {
            d dVar5 = this.r0.get(i6);
            if (dVar5.c()) {
                if (dVar5 instanceof j) {
                    this.L0.add(dVar5);
                } else {
                    dVar5.d(dVar, f0);
                }
            }
        }
        while (this.L0.size() > 0) {
            int size2 = this.L0.size();
            Iterator<d> it = this.L0.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                j jVar = (j) it.next();
                HashSet<d> hashSet = this.L0;
                int i7 = 0;
                while (true) {
                    if (i7 >= jVar.s0) {
                        z = false;
                        break;
                    }
                    if (hashSet.contains(jVar.r0[i7])) {
                        z = true;
                        break;
                    }
                    i7++;
                }
                if (z) {
                    jVar.d(dVar, f0);
                    this.L0.remove(jVar);
                    break;
                }
            }
            if (size2 == this.L0.size()) {
                Iterator<d> it2 = this.L0.iterator();
                while (it2.hasNext()) {
                    it2.next().d(dVar, f0);
                }
                this.L0.clear();
            }
        }
        if (b.f.a.d.p) {
            HashSet<d> hashSet2 = new HashSet<>();
            for (int i8 = 0; i8 < size; i8++) {
                d dVar6 = this.r0.get(i8);
                if (!dVar6.c()) {
                    hashSet2.add(dVar6);
                }
            }
            b(this, dVar, hashSet2, m() == aVar2 ? 0 : 1, false);
            Iterator<d> it3 = hashSet2.iterator();
            while (it3.hasNext()) {
                d next = it3.next();
                i.a(this, dVar, next);
                next.d(dVar, f0);
            }
        } else {
            for (int i9 = 0; i9 < size; i9++) {
                d dVar7 = this.r0.get(i9);
                if (dVar7 instanceof e) {
                    d.a[] aVarArr = dVar7.U;
                    d.a aVar4 = aVarArr[0];
                    d.a aVar5 = aVarArr[1];
                    if (aVar4 == aVar2) {
                        aVarArr[0] = aVar;
                    }
                    if (aVar5 == aVar2) {
                        aVarArr[1] = aVar;
                    }
                    dVar7.d(dVar, f0);
                    if (aVar4 == aVar2) {
                        dVar7.O(aVar4);
                    }
                    if (aVar5 == aVar2) {
                        dVar7.R(aVar5);
                    }
                } else {
                    i.a(this, dVar, dVar7);
                    if (!dVar7.c()) {
                        dVar7.d(dVar, f0);
                    }
                }
            }
        }
        if (this.A0 > 0) {
            b.d.a.a(this, dVar, null, 0);
        }
        if (this.B0 > 0) {
            b.d.a.a(this, dVar, null, 1);
        }
        return true;
    }

    public void Y(c cVar) {
        WeakReference<c> weakReference = this.K0;
        if (weakReference == null || weakReference.get() == null || cVar.c() > this.K0.get().c()) {
            this.K0 = new WeakReference<>(cVar);
        }
    }

    public void Z(c cVar) {
        WeakReference<c> weakReference = this.I0;
        if (weakReference == null || weakReference.get() == null || cVar.c() > this.I0.get().c()) {
            this.I0 = new WeakReference<>(cVar);
        }
    }

    public void a0(c cVar) {
        WeakReference<c> weakReference = this.J0;
        if (weakReference == null || weakReference.get() == null || cVar.c() > this.J0.get().c()) {
            this.J0 = new WeakReference<>(cVar);
        }
    }

    public void b0(c cVar) {
        WeakReference<c> weakReference = this.H0;
        if (weakReference == null || weakReference.get() == null || cVar.c() > this.H0.get().c()) {
            this.H0 = new WeakReference<>(cVar);
        }
    }

    public boolean c0(boolean z, int i2) {
        boolean z2;
        b.f.a.i.l.e eVar = this.t0;
        d.a aVar = d.a.MATCH_PARENT;
        d.a aVar2 = d.a.WRAP_CONTENT;
        d.a aVar3 = d.a.FIXED;
        boolean z3 = true;
        boolean z4 = z & true;
        d.a k = eVar.f1312a.k(0);
        d.a k2 = eVar.f1312a.k(1);
        int v = eVar.f1312a.v();
        int w = eVar.f1312a.w();
        if (z4 && (k == aVar2 || k2 == aVar2)) {
            Iterator<o> it = eVar.f1316e.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                o next = it.next();
                if (next.f1354f == i2 && !next.k()) {
                    z4 = false;
                    break;
                }
            }
            if (i2 == 0) {
                if (z4 && k == aVar2) {
                    e eVar2 = eVar.f1312a;
                    eVar2.U[0] = aVar3;
                    eVar2.S(eVar.d(eVar2, 0));
                    e eVar3 = eVar.f1312a;
                    eVar3.f1286d.f1353e.c(eVar3.u());
                }
            } else if (z4 && k2 == aVar2) {
                e eVar4 = eVar.f1312a;
                eVar4.U[1] = aVar3;
                eVar4.N(eVar.d(eVar4, 1));
                e eVar5 = eVar.f1312a;
                eVar5.f1287e.f1353e.c(eVar5.l());
            }
        }
        if (i2 == 0) {
            e eVar6 = eVar.f1312a;
            d.a[] aVarArr = eVar6.U;
            if (aVarArr[0] == aVar3 || aVarArr[0] == aVar) {
                int u = eVar6.u() + v;
                eVar.f1312a.f1286d.f1357i.c(u);
                eVar.f1312a.f1286d.f1353e.c(u - v);
                z2 = true;
            }
            z2 = false;
        } else {
            e eVar7 = eVar.f1312a;
            d.a[] aVarArr2 = eVar7.U;
            if (aVarArr2[1] == aVar3 || aVarArr2[1] == aVar) {
                int l = eVar7.l() + w;
                eVar.f1312a.f1287e.f1357i.c(l);
                eVar.f1312a.f1287e.f1353e.c(l - w);
                z2 = true;
            }
            z2 = false;
        }
        eVar.g();
        Iterator<o> it2 = eVar.f1316e.iterator();
        while (it2.hasNext()) {
            o next2 = it2.next();
            if (next2.f1354f == i2 && (next2.f1350b != eVar.f1312a || next2.f1355g)) {
                next2.e();
            }
        }
        Iterator<o> it3 = eVar.f1316e.iterator();
        while (it3.hasNext()) {
            o next3 = it3.next();
            if (next3.f1354f == i2 && (z2 || next3.f1350b != eVar.f1312a)) {
                if (!next3.f1356h.f1329j || !next3.f1357i.f1329j || (!(next3 instanceof b.f.a.i.l.c) && !next3.f1353e.f1329j)) {
                    z3 = false;
                    break;
                }
            }
        }
        eVar.f1312a.O(k);
        eVar.f1312a.R(k2);
        return z3;
    }

    public void d0() {
        this.t0.f1313b = true;
    }

    public boolean f0(int i2) {
        return (this.E0 & i2) == i2;
    }

    public void g0(int i2) {
        this.E0 = i2;
        b.f.a.d.p = f0(512);
    }

    @Override // b.f.a.i.d
    public void q(StringBuilder sb) {
        sb.append(this.f1292j + ":{\n");
        sb.append("  actualWidth:" + this.W);
        sb.append("\n");
        sb.append("  actualHeight:" + this.X);
        sb.append("\n");
        Iterator<d> it = this.r0.iterator();
        while (it.hasNext()) {
            it.next().q(sb);
            sb.append(",\n");
        }
        sb.append("}");
    }
}
