package b.f.a.i.l;

import b.f.a.i.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\o.smali */
public abstract class o implements d {

    /* renamed from: a, reason: collision with root package name */
    public int f1349a;

    /* renamed from: b, reason: collision with root package name */
    public b.f.a.i.d f1350b;

    /* renamed from: c, reason: collision with root package name */
    public l f1351c;

    /* renamed from: d, reason: collision with root package name */
    public d.a f1352d;

    /* renamed from: e, reason: collision with root package name */
    public g f1353e = new g(this);

    /* renamed from: f, reason: collision with root package name */
    public int f1354f = 0;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1355g = false;

    /* renamed from: h, reason: collision with root package name */
    public f f1356h = new f(this);

    /* renamed from: i, reason: collision with root package name */
    public f f1357i = new f(this);

    /* renamed from: j, reason: collision with root package name */
    public a f1358j = a.NONE;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\o$a.smali */
    public enum a {
        NONE,
        START,
        END,
        CENTER
    }

    public o(b.f.a.i.d dVar) {
        this.f1350b = dVar;
    }

    @Override // b.f.a.i.l.d
    public void a(d dVar) {
    }

    public final void b(f fVar, f fVar2, int i2) {
        fVar.l.add(fVar2);
        fVar.f1325f = i2;
        fVar2.k.add(fVar);
    }

    public final void c(f fVar, f fVar2, int i2, g gVar) {
        fVar.l.add(fVar2);
        fVar.l.add(this.f1353e);
        fVar.f1327h = i2;
        fVar.f1328i = gVar;
        fVar2.k.add(fVar);
        gVar.k.add(fVar);
    }

    public abstract void d();

    public abstract void e();

    public abstract void f();

    public final int g(int i2, int i3) {
        int max;
        if (i3 == 0) {
            b.f.a.i.d dVar = this.f1350b;
            int i4 = dVar.v;
            max = Math.max(dVar.u, i2);
            if (i4 > 0) {
                max = Math.min(i4, i2);
            }
            if (max == i2) {
                return i2;
            }
        } else {
            b.f.a.i.d dVar2 = this.f1350b;
            int i5 = dVar2.y;
            max = Math.max(dVar2.x, i2);
            if (i5 > 0) {
                max = Math.min(i5, i2);
            }
            if (max == i2) {
                return i2;
            }
        }
        return max;
    }

    public final f h(b.f.a.i.c cVar) {
        b.f.a.i.c cVar2 = cVar.f1272f;
        if (cVar2 == null) {
            return null;
        }
        b.f.a.i.d dVar = cVar2.f1270d;
        int ordinal = cVar2.f1271e.ordinal();
        if (ordinal == 1) {
            return dVar.f1286d.f1356h;
        }
        if (ordinal == 2) {
            return dVar.f1287e.f1356h;
        }
        if (ordinal == 3) {
            return dVar.f1286d.f1357i;
        }
        if (ordinal == 4) {
            return dVar.f1287e.f1357i;
        }
        if (ordinal != 5) {
            return null;
        }
        return dVar.f1287e.k;
    }

    public final f i(b.f.a.i.c cVar, int i2) {
        b.f.a.i.c cVar2 = cVar.f1272f;
        if (cVar2 == null) {
            return null;
        }
        b.f.a.i.d dVar = cVar2.f1270d;
        o oVar = i2 == 0 ? dVar.f1286d : dVar.f1287e;
        int ordinal = cVar2.f1271e.ordinal();
        if (ordinal == 1 || ordinal == 2) {
            return oVar.f1356h;
        }
        if (ordinal == 3 || ordinal == 4) {
            return oVar.f1357i;
        }
        return null;
    }

    public long j() {
        if (this.f1353e.f1329j) {
            return r0.f1326g;
        }
        return 0L;
    }

    public abstract boolean k();

    /* JADX WARN: Code restructure failed: missing block: B:24:0x0053, code lost:
    
        if (r10.f1349a == 3) goto L51;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void l(b.f.a.i.c r13, b.f.a.i.c r14, int r15) {
        /*
            Method dump skipped, instructions count: 250
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.l.o.l(b.f.a.i.c, b.f.a.i.c, int):void");
    }
}
