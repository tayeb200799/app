package b.f.a.h.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\h\a\a.smali */
public class a {

    /* renamed from: b, reason: collision with root package name */
    public static a f1257b = new a();

    /* renamed from: c, reason: collision with root package name */
    public static String[] f1258c = {"standard", "accelerate", "decelerate", "linear"};

    /* renamed from: a, reason: collision with root package name */
    public String f1259a = "identity";

    public String toString() {
        return this.f1259a;
    }
}
