package b.f.a.i.l;

import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\l.smali */
public class l {

    /* renamed from: c, reason: collision with root package name */
    public static int f1340c;

    /* renamed from: a, reason: collision with root package name */
    public o f1341a;

    /* renamed from: b, reason: collision with root package name */
    public ArrayList<o> f1342b = new ArrayList<>();

    public l(o oVar, int i2) {
        this.f1341a = null;
        f1340c++;
        this.f1341a = oVar;
    }

    public final long a(f fVar, long j2) {
        o oVar = fVar.f1323d;
        if (oVar instanceof j) {
            return j2;
        }
        int size = fVar.k.size();
        long j3 = j2;
        for (int i2 = 0; i2 < size; i2++) {
            d dVar = fVar.k.get(i2);
            if (dVar instanceof f) {
                f fVar2 = (f) dVar;
                if (fVar2.f1323d != oVar) {
                    j3 = Math.min(j3, a(fVar2, fVar2.f1325f + j2));
                }
            }
        }
        if (fVar != oVar.f1357i) {
            return j3;
        }
        long j4 = j2 - oVar.j();
        return Math.min(Math.min(j3, a(oVar.f1356h, j4)), j4 - oVar.f1356h.f1325f);
    }

    public final long b(f fVar, long j2) {
        o oVar = fVar.f1323d;
        if (oVar instanceof j) {
            return j2;
        }
        int size = fVar.k.size();
        long j3 = j2;
        for (int i2 = 0; i2 < size; i2++) {
            d dVar = fVar.k.get(i2);
            if (dVar instanceof f) {
                f fVar2 = (f) dVar;
                if (fVar2.f1323d != oVar) {
                    j3 = Math.max(j3, b(fVar2, fVar2.f1325f + j2));
                }
            }
        }
        if (fVar != oVar.f1356h) {
            return j3;
        }
        long j4 = j2 + oVar.j();
        return Math.max(Math.max(j3, b(oVar.f1357i, j4)), j4 - oVar.f1357i.f1325f);
    }
}
