package b.f.a.i;

import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\k.smali */
public class k extends d {
    public ArrayList<d> r0 = new ArrayList<>();

    @Override // b.f.a.i.d
    public void F() {
        this.r0.clear();
        super.F();
    }

    @Override // b.f.a.i.d
    public void H(b.f.a.c cVar) {
        super.H(cVar);
        int size = this.r0.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.r0.get(i2).H(cVar);
        }
    }

    public void V() {
        ArrayList<d> arrayList = this.r0;
        if (arrayList == null) {
            return;
        }
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            d dVar = this.r0.get(i2);
            if (dVar instanceof k) {
                ((k) dVar).V();
            }
        }
    }
}
