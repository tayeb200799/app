package b.f.a.i.l;

import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\c.smali */
public class c extends o {
    public ArrayList<o> k;
    public int l;

    public c(b.f.a.i.d dVar, int i2) {
        super(dVar);
        b.f.a.i.d dVar2;
        this.k = new ArrayList<>();
        this.f1357f = i2;
        b.f.a.i.d dVar3 = this.f1353b;
        b.f.a.i.d o = dVar3.o(i2);
        while (true) {
            b.f.a.i.d dVar4 = o;
            dVar2 = dVar3;
            dVar3 = dVar4;
            if (dVar3 == null) {
                break;
            } else {
                o = dVar3.o(this.f1357f);
            }
        }
        this.f1353b = dVar2;
        ArrayList<o> arrayList = this.k;
        int i3 = this.f1357f;
        arrayList.add(i3 == 0 ? dVar2.f1289d : i3 == 1 ? dVar2.f1290e : null);
        b.f.a.i.d n = dVar2.n(this.f1357f);
        while (n != null) {
            ArrayList<o> arrayList2 = this.k;
            int i4 = this.f1357f;
            arrayList2.add(i4 == 0 ? n.f1289d : i4 == 1 ? n.f1290e : null);
            n = n.n(this.f1357f);
        }
        Iterator<o> it = this.k.iterator();
        while (it.hasNext()) {
            o next = it.next();
            int i5 = this.f1357f;
            if (i5 == 0) {
                next.f1353b.f1287b = this;
            } else if (i5 == 1) {
                next.f1353b.f1288c = this;
            }
        }
        if ((this.f1357f == 0 && ((b.f.a.i.e) this.f1353b.V).w0) && this.k.size() > 1) {
            ArrayList<o> arrayList3 = this.k;
            this.f1353b = arrayList3.get(arrayList3.size() - 1).f1353b;
        }
        this.l = this.f1357f == 0 ? this.f1353b.k0 : this.f1353b.l0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:287:0x03d2, code lost:
    
        r10 = r10 - r8;
     */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00db  */
    @Override // b.f.a.i.l.o, b.f.a.i.l.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void a(b.f.a.i.l.d r27) {
        /*
            Method dump skipped, instructions count: 1017
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.l.c.a(b.f.a.i.l.d):void");
    }

    @Override // b.f.a.i.l.o
    public void d() {
        Iterator<o> it = this.k.iterator();
        while (it.hasNext()) {
            it.next().d();
        }
        int size = this.k.size();
        if (size < 1) {
            return;
        }
        b.f.a.i.d dVar = this.k.get(0).f1353b;
        b.f.a.i.d dVar2 = this.k.get(size - 1).f1353b;
        if (this.f1357f == 0) {
            b.f.a.i.c cVar = dVar.J;
            b.f.a.i.c cVar2 = dVar2.L;
            f i2 = i(cVar, 0);
            int d2 = cVar.d();
            b.f.a.i.d m = m();
            if (m != null) {
                d2 = m.J.d();
            }
            if (i2 != null) {
                f fVar = this.f1359h;
                fVar.l.add(i2);
                fVar.f1328f = d2;
                i2.k.add(fVar);
            }
            f i3 = i(cVar2, 0);
            int d3 = cVar2.d();
            b.f.a.i.d n = n();
            if (n != null) {
                d3 = n.L.d();
            }
            if (i3 != null) {
                f fVar2 = this.f1360i;
                fVar2.l.add(i3);
                fVar2.f1328f = -d3;
                i3.k.add(fVar2);
            }
        } else {
            b.f.a.i.c cVar3 = dVar.K;
            b.f.a.i.c cVar4 = dVar2.M;
            f i4 = i(cVar3, 1);
            int d4 = cVar3.d();
            b.f.a.i.d m2 = m();
            if (m2 != null) {
                d4 = m2.K.d();
            }
            if (i4 != null) {
                f fVar3 = this.f1359h;
                fVar3.l.add(i4);
                fVar3.f1328f = d4;
                i4.k.add(fVar3);
            }
            f i5 = i(cVar4, 1);
            int d5 = cVar4.d();
            b.f.a.i.d n2 = n();
            if (n2 != null) {
                d5 = n2.M.d();
            }
            if (i5 != null) {
                f fVar4 = this.f1360i;
                fVar4.l.add(i5);
                fVar4.f1328f = -d5;
                i5.k.add(fVar4);
            }
        }
        this.f1359h.f1323a = this;
        this.f1360i.f1323a = this;
    }

    @Override // b.f.a.i.l.o
    public void e() {
        for (int i2 = 0; i2 < this.k.size(); i2++) {
            this.k.get(i2).e();
        }
    }

    @Override // b.f.a.i.l.o
    public void f() {
        this.f1354c = null;
        Iterator<o> it = this.k.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
    }

    @Override // b.f.a.i.l.o
    public long j() {
        int size = this.k.size();
        long j2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            j2 = r4.f1360i.f1328f + this.k.get(i2).j() + j2 + r4.f1359h.f1328f;
        }
        return j2;
    }

    @Override // b.f.a.i.l.o
    public boolean k() {
        int size = this.k.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!this.k.get(i2).k()) {
                return false;
            }
        }
        return true;
    }

    public final b.f.a.i.d m() {
        for (int i2 = 0; i2 < this.k.size(); i2++) {
            b.f.a.i.d dVar = this.k.get(i2).f1353b;
            if (dVar.i0 != 8) {
                return dVar;
            }
        }
        return null;
    }

    public final b.f.a.i.d n() {
        for (int size = this.k.size() - 1; size >= 0; size--) {
            b.f.a.i.d dVar = this.k.get(size).f1353b;
            if (dVar.i0 != 8) {
                return dVar;
            }
        }
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ChainRun ");
        sb.append(this.f1357f == 0 ? "horizontal : " : "vertical : ");
        Iterator<o> it = this.k.iterator();
        while (it.hasNext()) {
            o next = it.next();
            sb.append("<");
            sb.append(next);
            sb.append("> ");
        }
        return sb.toString();
    }
}
