package b.f.a.i;

import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\b.smali */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public d f1257a;

    /* renamed from: b, reason: collision with root package name */
    public d f1258b;

    /* renamed from: c, reason: collision with root package name */
    public d f1259c;

    /* renamed from: d, reason: collision with root package name */
    public d f1260d;

    /* renamed from: e, reason: collision with root package name */
    public d f1261e;

    /* renamed from: f, reason: collision with root package name */
    public d f1262f;

    /* renamed from: g, reason: collision with root package name */
    public d f1263g;

    /* renamed from: h, reason: collision with root package name */
    public ArrayList<d> f1264h;

    /* renamed from: i, reason: collision with root package name */
    public int f1265i;

    /* renamed from: j, reason: collision with root package name */
    public int f1266j;
    public float k = 0.0f;
    public int l;
    public int m;
    public int n;
    public int o;
    public boolean p;
    public boolean q;
    public boolean r;
    public boolean s;
    public boolean t;

    public b(d dVar, int i2, boolean z) {
        this.p = false;
        this.f1257a = dVar;
        this.o = i2;
        this.p = z;
    }
}
