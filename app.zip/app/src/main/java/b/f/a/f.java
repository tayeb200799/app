package b.f.a;

import b.f.a.b;
import java.util.Arrays;
import java.util.Comparator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\f.smali */
public class f extends b.f.a.b {

    /* renamed from: f, reason: collision with root package name */
    public int f1237f;

    /* renamed from: g, reason: collision with root package name */
    public g[] f1238g;

    /* renamed from: h, reason: collision with root package name */
    public g[] f1239h;

    /* renamed from: i, reason: collision with root package name */
    public int f1240i;

    /* renamed from: j, reason: collision with root package name */
    public b f1241j;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\f$a.smali */
    public class a implements Comparator<g> {
        public a(f fVar) {
        }

        @Override // java.util.Comparator
        public int compare(g gVar, g gVar2) {
            return gVar.f1245e - gVar2.f1245e;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\f$b.smali */
    public class b {

        /* renamed from: a, reason: collision with root package name */
        public g f1242a;

        public b(f fVar) {
        }

        public String toString() {
            String str = "[ ";
            if (this.f1242a != null) {
                for (int i2 = 0; i2 < 9; i2++) {
                    StringBuilder n = c.a.a.a.a.n(str);
                    n.append(this.f1242a.k[i2]);
                    n.append(" ");
                    str = n.toString();
                }
            }
            return str + "] " + this.f1242a;
        }
    }

    public f(c cVar) {
        super(cVar);
        this.f1237f = 128;
        this.f1238g = new g[128];
        this.f1239h = new g[128];
        this.f1240i = 0;
        this.f1241j = new b(this);
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0053, code lost:
    
        if (r8 < r7) goto L31;
     */
    @Override // b.f.a.b, b.f.a.d.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public b.f.a.g a(b.f.a.d r11, boolean[] r12) {
        /*
            r10 = this;
            r11 = 0
            r0 = -1
            r1 = 0
            r2 = -1
        L4:
            int r3 = r10.f1240i
            if (r1 >= r3) goto L5d
            b.f.a.g[] r3 = r10.f1238g
            r4 = r3[r1]
            int r5 = r4.f1245e
            boolean r5 = r12[r5]
            if (r5 == 0) goto L13
            goto L5a
        L13:
            b.f.a.f$b r5 = r10.f1241j
            r5.f1242a = r4
            r4 = 8
            r6 = 1
            if (r2 != r0) goto L39
            java.util.Objects.requireNonNull(r5)
        L1f:
            if (r4 < 0) goto L35
            b.f.a.g r3 = r5.f1242a
            float[] r3 = r3.k
            r3 = r3[r4]
            r7 = 0
            int r8 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r8 <= 0) goto L2d
            goto L35
        L2d:
            int r3 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r3 >= 0) goto L32
            goto L36
        L32:
            int r4 = r4 + (-1)
            goto L1f
        L35:
            r6 = 0
        L36:
            if (r6 == 0) goto L5a
            goto L59
        L39:
            r3 = r3[r2]
            java.util.Objects.requireNonNull(r5)
        L3e:
            if (r4 < 0) goto L56
            float[] r7 = r3.k
            r7 = r7[r4]
            b.f.a.g r8 = r5.f1242a
            float[] r8 = r8.k
            r8 = r8[r4]
            int r9 = (r8 > r7 ? 1 : (r8 == r7 ? 0 : -1))
            if (r9 != 0) goto L51
            int r4 = r4 + (-1)
            goto L3e
        L51:
            int r3 = (r8 > r7 ? 1 : (r8 == r7 ? 0 : -1))
            if (r3 >= 0) goto L56
            goto L57
        L56:
            r6 = 0
        L57:
            if (r6 == 0) goto L5a
        L59:
            r2 = r1
        L5a:
            int r1 = r1 + 1
            goto L4
        L5d:
            if (r2 != r0) goto L61
            r11 = 0
            return r11
        L61:
            b.f.a.g[] r11 = r10.f1238g
            r11 = r11[r2]
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.f.a(b.f.a.d, boolean[]):b.f.a.g");
    }

    @Override // b.f.a.b, b.f.a.d.a
    public void b(g gVar) {
        this.f1241j.f1242a = gVar;
        Arrays.fill(gVar.k, 0.0f);
        gVar.k[gVar.f1247g] = 1.0f;
        m(gVar);
    }

    @Override // b.f.a.b, b.f.a.d.a
    public void clear() {
        this.f1240i = 0;
        this.f1217b = 0.0f;
    }

    @Override // b.f.a.b, b.f.a.d.a
    public boolean isEmpty() {
        return this.f1240i == 0;
    }

    @Override // b.f.a.b
    public void l(d dVar, b.f.a.b bVar, boolean z) {
        g gVar = bVar.f1216a;
        if (gVar == null) {
            return;
        }
        b.a aVar = bVar.f1219d;
        int c2 = aVar.c();
        for (int i2 = 0; i2 < c2; i2++) {
            g h2 = aVar.h(i2);
            float a2 = aVar.a(i2);
            b bVar2 = this.f1241j;
            bVar2.f1242a = h2;
            boolean z2 = true;
            if (h2.f1244d) {
                for (int i3 = 0; i3 < 9; i3++) {
                    float[] fArr = bVar2.f1242a.k;
                    fArr[i3] = (gVar.k[i3] * a2) + fArr[i3];
                    if (Math.abs(fArr[i3]) < 1.0E-4f) {
                        bVar2.f1242a.k[i3] = 0.0f;
                    } else {
                        z2 = false;
                    }
                }
                if (z2) {
                    f.this.n(bVar2.f1242a);
                }
                z2 = false;
            } else {
                for (int i4 = 0; i4 < 9; i4++) {
                    float f2 = gVar.k[i4];
                    if (f2 != 0.0f) {
                        float f3 = f2 * a2;
                        if (Math.abs(f3) < 1.0E-4f) {
                            f3 = 0.0f;
                        }
                        bVar2.f1242a.k[i4] = f3;
                    } else {
                        bVar2.f1242a.k[i4] = 0.0f;
                    }
                }
            }
            if (z2) {
                m(h2);
            }
            this.f1217b = (bVar.f1217b * a2) + this.f1217b;
        }
        n(gVar);
    }

    public final void m(g gVar) {
        int i2;
        int i3 = this.f1240i + 1;
        g[] gVarArr = this.f1238g;
        if (i3 > gVarArr.length) {
            g[] gVarArr2 = (g[]) Arrays.copyOf(gVarArr, gVarArr.length * 2);
            this.f1238g = gVarArr2;
            this.f1239h = (g[]) Arrays.copyOf(gVarArr2, gVarArr2.length * 2);
        }
        g[] gVarArr3 = this.f1238g;
        int i4 = this.f1240i;
        gVarArr3[i4] = gVar;
        int i5 = i4 + 1;
        this.f1240i = i5;
        if (i5 > 1 && gVarArr3[i5 - 1].f1245e > gVar.f1245e) {
            int i6 = 0;
            while (true) {
                i2 = this.f1240i;
                if (i6 >= i2) {
                    break;
                }
                this.f1239h[i6] = this.f1238g[i6];
                i6++;
            }
            Arrays.sort(this.f1239h, 0, i2, new a(this));
            for (int i7 = 0; i7 < this.f1240i; i7++) {
                this.f1238g[i7] = this.f1239h[i7];
            }
        }
        gVar.f1244d = true;
        gVar.f(this);
    }

    public final void n(g gVar) {
        int i2 = 0;
        while (i2 < this.f1240i) {
            if (this.f1238g[i2] == gVar) {
                while (true) {
                    int i3 = this.f1240i;
                    if (i2 >= i3 - 1) {
                        this.f1240i = i3 - 1;
                        gVar.f1244d = false;
                        return;
                    } else {
                        g[] gVarArr = this.f1238g;
                        int i4 = i2 + 1;
                        gVarArr[i2] = gVarArr[i4];
                        i2 = i4;
                    }
                }
            } else {
                i2++;
            }
        }
    }

    @Override // b.f.a.b
    public String toString() {
        String str = " goal -> (" + this.f1217b + ") : ";
        for (int i2 = 0; i2 < this.f1240i; i2++) {
            this.f1241j.f1242a = this.f1238g[i2];
            StringBuilder n = c.a.a.a.a.n(str);
            n.append(this.f1241j);
            n.append(" ");
            str = n.toString();
        }
        return str;
    }
}
