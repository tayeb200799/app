package b.f.a;

import b.f.a.d;
import b.f.a.g;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\b.smali */
public class b implements d.a {

    /* renamed from: d, reason: collision with root package name */
    public a f1219d;

    /* renamed from: a, reason: collision with root package name */
    public g f1216a = null;

    /* renamed from: b, reason: collision with root package name */
    public float f1217b = 0.0f;

    /* renamed from: c, reason: collision with root package name */
    public ArrayList<g> f1218c = new ArrayList<>();

    /* renamed from: e, reason: collision with root package name */
    public boolean f1220e = false;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\b$a.smali */
    public interface a {
        float a(int i2);

        float b(g gVar, boolean z);

        int c();

        void clear();

        float d(g gVar);

        boolean e(g gVar);

        float f(b bVar, boolean z);

        void g(g gVar, float f2);

        g h(int i2);

        void i(g gVar, float f2, boolean z);

        void j(float f2);

        void k();
    }

    public b() {
    }

    public b(c cVar) {
        this.f1219d = new b.f.a.a(this, cVar);
    }

    @Override // b.f.a.d.a
    public g a(d dVar, boolean[] zArr) {
        return i(zArr, null);
    }

    @Override // b.f.a.d.a
    public void b(g gVar) {
        float f2;
        int i2 = gVar.f1247g;
        if (i2 != 1) {
            if (i2 == 2) {
                f2 = 1000.0f;
            } else if (i2 == 3) {
                f2 = 1000000.0f;
            } else if (i2 == 4) {
                f2 = 1.0E9f;
            } else if (i2 == 5) {
                f2 = 1.0E12f;
            }
            this.f1219d.g(gVar, f2);
        }
        f2 = 1.0f;
        this.f1219d.g(gVar, f2);
    }

    public b c(d dVar, int i2) {
        this.f1219d.g(dVar.k(i2, "ep"), 1.0f);
        this.f1219d.g(dVar.k(i2, "em"), -1.0f);
        return this;
    }

    @Override // b.f.a.d.a
    public void clear() {
        this.f1219d.clear();
        this.f1216a = null;
        this.f1217b = 0.0f;
    }

    public b d(g gVar, g gVar2, g gVar3, g gVar4, float f2) {
        this.f1219d.g(gVar, -1.0f);
        this.f1219d.g(gVar2, 1.0f);
        this.f1219d.g(gVar3, f2);
        this.f1219d.g(gVar4, -f2);
        return this;
    }

    public b e(g gVar, g gVar2, g gVar3, int i2) {
        boolean z = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z = true;
            }
            this.f1217b = i2;
        }
        if (z) {
            this.f1219d.g(gVar, 1.0f);
            this.f1219d.g(gVar2, -1.0f);
            this.f1219d.g(gVar3, -1.0f);
        } else {
            this.f1219d.g(gVar, -1.0f);
            this.f1219d.g(gVar2, 1.0f);
            this.f1219d.g(gVar3, 1.0f);
        }
        return this;
    }

    public b f(g gVar, g gVar2, g gVar3, int i2) {
        boolean z = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z = true;
            }
            this.f1217b = i2;
        }
        if (z) {
            this.f1219d.g(gVar, 1.0f);
            this.f1219d.g(gVar2, -1.0f);
            this.f1219d.g(gVar3, 1.0f);
        } else {
            this.f1219d.g(gVar, -1.0f);
            this.f1219d.g(gVar2, 1.0f);
            this.f1219d.g(gVar3, -1.0f);
        }
        return this;
    }

    public b g(g gVar, g gVar2, g gVar3, g gVar4, float f2) {
        this.f1219d.g(gVar3, 0.5f);
        this.f1219d.g(gVar4, 0.5f);
        this.f1219d.g(gVar, -0.5f);
        this.f1219d.g(gVar2, -0.5f);
        this.f1217b = -f2;
        return this;
    }

    public final boolean h(g gVar) {
        return gVar.o <= 1;
    }

    public final g i(boolean[] zArr, g gVar) {
        g.a aVar;
        int c2 = this.f1219d.c();
        g gVar2 = null;
        float f2 = 0.0f;
        for (int i2 = 0; i2 < c2; i2++) {
            float a2 = this.f1219d.a(i2);
            if (a2 < 0.0f) {
                g h2 = this.f1219d.h(i2);
                if ((zArr == null || !zArr[h2.f1245e]) && h2 != gVar && (((aVar = h2.l) == g.a.SLACK || aVar == g.a.ERROR) && a2 < f2)) {
                    f2 = a2;
                    gVar2 = h2;
                }
            }
        }
        return gVar2;
    }

    @Override // b.f.a.d.a
    public boolean isEmpty() {
        return this.f1216a == null && this.f1217b == 0.0f && this.f1219d.c() == 0;
    }

    public void j(g gVar) {
        g gVar2 = this.f1216a;
        if (gVar2 != null) {
            this.f1219d.g(gVar2, -1.0f);
            this.f1216a.f1246f = -1;
            this.f1216a = null;
        }
        float b2 = this.f1219d.b(gVar, true) * (-1.0f);
        this.f1216a = gVar;
        if (b2 == 1.0f) {
            return;
        }
        this.f1217b /= b2;
        this.f1219d.j(b2);
    }

    public void k(d dVar, g gVar, boolean z) {
        if (gVar.f1249i) {
            float d2 = this.f1219d.d(gVar);
            this.f1217b = (gVar.f1248h * d2) + this.f1217b;
            this.f1219d.b(gVar, z);
            if (z) {
                gVar.h(this);
            }
            if (this.f1219d.c() == 0) {
                this.f1220e = true;
                dVar.f1225a = true;
            }
        }
    }

    public void l(d dVar, b bVar, boolean z) {
        float f2 = this.f1219d.f(bVar, z);
        this.f1217b = (bVar.f1217b * f2) + this.f1217b;
        if (z) {
            bVar.f1216a.h(this);
        }
        if (this.f1216a == null || this.f1219d.c() != 0) {
            return;
        }
        this.f1220e = true;
        dVar.f1225a = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x007f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.String toString() {
        /*
            r9 = this;
            b.f.a.g r0 = r9.f1216a
            if (r0 != 0) goto L7
            java.lang.String r0 = "0"
            goto L16
        L7:
            java.lang.String r0 = ""
            java.lang.StringBuilder r0 = c.a.a.a.a.n(r0)
            b.f.a.g r1 = r9.f1216a
            r0.append(r1)
            java.lang.String r0 = r0.toString()
        L16:
            java.lang.String r1 = " = "
            java.lang.String r0 = c.a.a.a.a.f(r0, r1)
            float r1 = r9.f1217b
            r2 = 0
            r3 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 == 0) goto L33
            java.lang.StringBuilder r0 = c.a.a.a.a.n(r0)
            float r1 = r9.f1217b
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r1 = 1
            goto L34
        L33:
            r1 = 0
        L34:
            b.f.a.b$a r4 = r9.f1219d
            int r4 = r4.c()
        L3a:
            if (r3 >= r4) goto L9a
            b.f.a.b$a r5 = r9.f1219d
            b.f.a.g r5 = r5.h(r3)
            if (r5 != 0) goto L45
            goto L97
        L45:
            b.f.a.b$a r6 = r9.f1219d
            float r6 = r6.a(r3)
            int r7 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1))
            if (r7 != 0) goto L50
            goto L97
        L50:
            java.lang.String r5 = r5.toString()
            r8 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r1 != 0) goto L63
            int r1 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1))
            if (r1 >= 0) goto L74
            java.lang.String r1 = "- "
            java.lang.String r0 = c.a.a.a.a.f(r0, r1)
            goto L72
        L63:
            if (r7 <= 0) goto L6c
            java.lang.String r1 = " + "
            java.lang.String r0 = c.a.a.a.a.f(r0, r1)
            goto L74
        L6c:
            java.lang.String r1 = " - "
            java.lang.String r0 = c.a.a.a.a.f(r0, r1)
        L72:
            float r6 = r6 * r8
        L74:
            r1 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r6 > r1 ? 1 : (r6 == r1 ? 0 : -1))
            if (r1 != 0) goto L7f
            java.lang.String r0 = c.a.a.a.a.f(r0, r5)
            goto L96
        L7f:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            r1.append(r6)
            java.lang.String r0 = " "
            r1.append(r0)
            r1.append(r5)
            java.lang.String r0 = r1.toString()
        L96:
            r1 = 1
        L97:
            int r3 = r3 + 1
            goto L3a
        L9a:
            if (r1 != 0) goto La2
            java.lang.String r1 = "0.0"
            java.lang.String r0 = c.a.a.a.a.f(r0, r1)
        La2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.b.toString():java.lang.String");
    }
}
