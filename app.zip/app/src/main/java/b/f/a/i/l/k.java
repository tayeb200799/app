package b.f.a.i.l;

import b.f.a.i.c;
import b.f.a.i.d;
import b.f.a.i.l.f;
import b.f.a.i.l.o;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\k.smali */
public class k extends o {
    public static int[] k = new int[2];

    public k(b.f.a.i.d dVar) {
        super(dVar);
        this.f1359h.f1327e = f.a.LEFT;
        this.f1360i.f1327e = f.a.RIGHT;
        this.f1357f = 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:114:0x028a, code lost:
    
        if (r7 != 1) goto L136;
     */
    @Override // b.f.a.i.l.o, b.f.a.i.l.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void a(b.f.a.i.l.d r18) {
        /*
            Method dump skipped, instructions count: 1030
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.l.k.a(b.f.a.i.l.d):void");
    }

    @Override // b.f.a.i.l.o
    public void d() {
        b.f.a.i.d dVar;
        b.f.a.i.d dVar2;
        b.f.a.i.d dVar3;
        d.a aVar = d.a.MATCH_CONSTRAINT;
        d.a aVar2 = d.a.MATCH_PARENT;
        d.a aVar3 = d.a.FIXED;
        b.f.a.i.d dVar4 = this.f1353b;
        if (dVar4.f1286a) {
            this.f1356e.c(dVar4.u());
        }
        if (!this.f1356e.f1332j) {
            d.a m = this.f1353b.m();
            this.f1355d = m;
            if (m != aVar) {
                if (m == aVar2 && (dVar3 = this.f1353b.V) != null && (dVar3.m() == aVar3 || dVar3.m() == aVar2)) {
                    int u = (dVar3.u() - this.f1353b.J.d()) - this.f1353b.L.d();
                    b(this.f1359h, dVar3.f1289d.f1359h, this.f1353b.J.d());
                    b(this.f1360i, dVar3.f1289d.f1360i, -this.f1353b.L.d());
                    this.f1356e.c(u);
                    return;
                }
                if (this.f1355d == aVar3) {
                    this.f1356e.c(this.f1353b.u());
                }
            }
        } else if (this.f1355d == aVar2 && (dVar = this.f1353b.V) != null && (dVar.m() == aVar3 || dVar.m() == aVar2)) {
            b(this.f1359h, dVar.f1289d.f1359h, this.f1353b.J.d());
            b(this.f1360i, dVar.f1289d.f1360i, -this.f1353b.L.d());
            return;
        }
        g gVar = this.f1356e;
        if (gVar.f1332j) {
            b.f.a.i.d dVar5 = this.f1353b;
            if (dVar5.f1286a) {
                b.f.a.i.c[] cVarArr = dVar5.R;
                if (cVarArr[0].f1275f != null && cVarArr[1].f1275f != null) {
                    if (dVar5.A()) {
                        this.f1359h.f1328f = this.f1353b.R[0].d();
                        this.f1360i.f1328f = -this.f1353b.R[1].d();
                        return;
                    }
                    f h2 = h(this.f1353b.R[0]);
                    if (h2 != null) {
                        f fVar = this.f1359h;
                        int d2 = this.f1353b.R[0].d();
                        fVar.l.add(h2);
                        fVar.f1328f = d2;
                        h2.k.add(fVar);
                    }
                    f h3 = h(this.f1353b.R[1]);
                    if (h3 != null) {
                        f fVar2 = this.f1360i;
                        int i2 = -this.f1353b.R[1].d();
                        fVar2.l.add(h3);
                        fVar2.f1328f = i2;
                        h3.k.add(fVar2);
                    }
                    this.f1359h.f1324b = true;
                    this.f1360i.f1324b = true;
                    return;
                }
                if (cVarArr[0].f1275f != null) {
                    f h4 = h(cVarArr[0]);
                    if (h4 != null) {
                        f fVar3 = this.f1359h;
                        int d3 = this.f1353b.R[0].d();
                        fVar3.l.add(h4);
                        fVar3.f1328f = d3;
                        h4.k.add(fVar3);
                        b(this.f1360i, this.f1359h, this.f1356e.f1329g);
                        return;
                    }
                    return;
                }
                if (cVarArr[1].f1275f == null) {
                    if ((dVar5 instanceof b.f.a.i.g) || dVar5.V == null || dVar5.i(c.a.CENTER).f1275f != null) {
                        return;
                    }
                    b.f.a.i.d dVar6 = this.f1353b;
                    b(this.f1359h, dVar6.V.f1289d.f1359h, dVar6.v());
                    b(this.f1360i, this.f1359h, this.f1356e.f1329g);
                    return;
                }
                f h5 = h(cVarArr[1]);
                if (h5 != null) {
                    f fVar4 = this.f1360i;
                    int i3 = -this.f1353b.R[1].d();
                    fVar4.l.add(h5);
                    fVar4.f1328f = i3;
                    h5.k.add(fVar4);
                    b(this.f1359h, this.f1360i, -this.f1356e.f1329g);
                    return;
                }
                return;
            }
        }
        if (this.f1355d == aVar) {
            b.f.a.i.d dVar7 = this.f1353b;
            int i4 = dVar7.r;
            if (i4 == 2) {
                b.f.a.i.d dVar8 = dVar7.V;
                if (dVar8 != null) {
                    g gVar2 = dVar8.f1290e.f1356e;
                    gVar.l.add(gVar2);
                    gVar2.k.add(this.f1356e);
                    g gVar3 = this.f1356e;
                    gVar3.f1324b = true;
                    gVar3.k.add(this.f1359h);
                    this.f1356e.k.add(this.f1360i);
                }
            } else if (i4 == 3) {
                if (dVar7.s == 3) {
                    this.f1359h.f1323a = this;
                    this.f1360i.f1323a = this;
                    m mVar = dVar7.f1290e;
                    mVar.f1359h.f1323a = this;
                    mVar.f1360i.f1323a = this;
                    gVar.f1323a = this;
                    if (dVar7.B()) {
                        this.f1356e.l.add(this.f1353b.f1290e.f1356e);
                        this.f1353b.f1290e.f1356e.k.add(this.f1356e);
                        m mVar2 = this.f1353b.f1290e;
                        mVar2.f1356e.f1323a = this;
                        this.f1356e.l.add(mVar2.f1359h);
                        this.f1356e.l.add(this.f1353b.f1290e.f1360i);
                        this.f1353b.f1290e.f1359h.k.add(this.f1356e);
                        this.f1353b.f1290e.f1360i.k.add(this.f1356e);
                    } else if (this.f1353b.A()) {
                        this.f1353b.f1290e.f1356e.l.add(this.f1356e);
                        this.f1356e.k.add(this.f1353b.f1290e.f1356e);
                    } else {
                        this.f1353b.f1290e.f1356e.l.add(this.f1356e);
                    }
                } else {
                    g gVar4 = dVar7.f1290e.f1356e;
                    gVar.l.add(gVar4);
                    gVar4.k.add(this.f1356e);
                    this.f1353b.f1290e.f1359h.k.add(this.f1356e);
                    this.f1353b.f1290e.f1360i.k.add(this.f1356e);
                    g gVar5 = this.f1356e;
                    gVar5.f1324b = true;
                    gVar5.k.add(this.f1359h);
                    this.f1356e.k.add(this.f1360i);
                    this.f1359h.l.add(this.f1356e);
                    this.f1360i.l.add(this.f1356e);
                }
            }
        }
        b.f.a.i.d dVar9 = this.f1353b;
        b.f.a.i.c[] cVarArr2 = dVar9.R;
        if (cVarArr2[0].f1275f != null && cVarArr2[1].f1275f != null) {
            if (dVar9.A()) {
                this.f1359h.f1328f = this.f1353b.R[0].d();
                this.f1360i.f1328f = -this.f1353b.R[1].d();
                return;
            }
            f h6 = h(this.f1353b.R[0]);
            f h7 = h(this.f1353b.R[1]);
            if (h6 != null) {
                h6.k.add(this);
                if (h6.f1332j) {
                    a(this);
                }
            }
            if (h7 != null) {
                h7.k.add(this);
                if (h7.f1332j) {
                    a(this);
                }
            }
            this.f1361j = o.a.CENTER;
            return;
        }
        if (cVarArr2[0].f1275f != null) {
            f h8 = h(cVarArr2[0]);
            if (h8 != null) {
                f fVar5 = this.f1359h;
                int d4 = this.f1353b.R[0].d();
                fVar5.l.add(h8);
                fVar5.f1328f = d4;
                h8.k.add(fVar5);
                c(this.f1360i, this.f1359h, 1, this.f1356e);
                return;
            }
            return;
        }
        if (cVarArr2[1].f1275f == null) {
            if ((dVar9 instanceof b.f.a.i.g) || (dVar2 = dVar9.V) == null) {
                return;
            }
            b(this.f1359h, dVar2.f1289d.f1359h, dVar9.v());
            c(this.f1360i, this.f1359h, 1, this.f1356e);
            return;
        }
        f h9 = h(cVarArr2[1]);
        if (h9 != null) {
            f fVar6 = this.f1360i;
            int i5 = -this.f1353b.R[1].d();
            fVar6.l.add(h9);
            fVar6.f1328f = i5;
            h9.k.add(fVar6);
            c(this.f1359h, this.f1360i, -1, this.f1356e);
        }
    }

    @Override // b.f.a.i.l.o
    public void e() {
        f fVar = this.f1359h;
        if (fVar.f1332j) {
            this.f1353b.a0 = fVar.f1329g;
        }
    }

    @Override // b.f.a.i.l.o
    public void f() {
        this.f1354c = null;
        this.f1359h.b();
        this.f1360i.b();
        this.f1356e.b();
        this.f1358g = false;
    }

    @Override // b.f.a.i.l.o
    public boolean k() {
        return this.f1355d != d.a.MATCH_CONSTRAINT || this.f1353b.r == 0;
    }

    public final void m(int[] iArr, int i2, int i3, int i4, int i5, float f2, int i6) {
        int i7 = i3 - i2;
        int i8 = i5 - i4;
        if (i6 != -1) {
            if (i6 == 0) {
                iArr[0] = (int) ((i8 * f2) + 0.5f);
                iArr[1] = i8;
                return;
            } else {
                if (i6 != 1) {
                    return;
                }
                iArr[0] = i7;
                iArr[1] = (int) ((i7 * f2) + 0.5f);
                return;
            }
        }
        int i9 = (int) ((i8 * f2) + 0.5f);
        int i10 = (int) ((i7 / f2) + 0.5f);
        if (i9 <= i7 && i8 <= i8) {
            iArr[0] = i9;
            iArr[1] = i8;
        } else {
            if (i7 > i7 || i10 > i8) {
                return;
            }
            iArr[0] = i7;
            iArr[1] = i10;
        }
    }

    public void n() {
        this.f1358g = false;
        this.f1359h.b();
        this.f1359h.f1332j = false;
        this.f1360i.b();
        this.f1360i.f1332j = false;
        this.f1356e.f1332j = false;
    }

    public String toString() {
        StringBuilder n = c.a.a.a.a.n("HorizontalRun ");
        n.append(this.f1353b.j0);
        return n.toString();
    }
}
