package b.f.a.i.l;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\n.smali */
public class n {

    /* renamed from: f, reason: collision with root package name */
    public static int f1343f;

    /* renamed from: b, reason: collision with root package name */
    public int f1345b;

    /* renamed from: c, reason: collision with root package name */
    public int f1346c;

    /* renamed from: a, reason: collision with root package name */
    public ArrayList<b.f.a.i.d> f1344a = new ArrayList<>();

    /* renamed from: d, reason: collision with root package name */
    public ArrayList<a> f1347d = null;

    /* renamed from: e, reason: collision with root package name */
    public int f1348e = -1;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\a\i\l\n$a.smali */
    public class a {
        public a(n nVar, b.f.a.i.d dVar, b.f.a.d dVar2, int i2) {
            new WeakReference(dVar);
            dVar2.o(dVar.J);
            dVar2.o(dVar.K);
            dVar2.o(dVar.L);
            dVar2.o(dVar.M);
            dVar2.o(dVar.N);
        }
    }

    public n(int i2) {
        this.f1345b = -1;
        this.f1346c = 0;
        int i3 = f1343f;
        f1343f = i3 + 1;
        this.f1345b = i3;
        this.f1346c = i2;
    }

    public boolean a(b.f.a.i.d dVar) {
        if (this.f1344a.contains(dVar)) {
            return false;
        }
        this.f1344a.add(dVar);
        return true;
    }

    public void b(ArrayList<n> arrayList) {
        int size = this.f1344a.size();
        if (this.f1348e != -1 && size > 0) {
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                n nVar = arrayList.get(i2);
                if (this.f1348e == nVar.f1345b) {
                    d(this.f1346c, nVar);
                }
            }
        }
        if (size == 0) {
            arrayList.remove(this);
        }
    }

    public int c(b.f.a.d dVar, int i2) {
        int o;
        int o2;
        if (this.f1344a.size() == 0) {
            return 0;
        }
        ArrayList<b.f.a.i.d> arrayList = this.f1344a;
        b.f.a.i.e eVar = (b.f.a.i.e) arrayList.get(0).V;
        dVar.u();
        eVar.d(dVar, false);
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            arrayList.get(i3).d(dVar, false);
        }
        if (i2 == 0 && eVar.A0 > 0) {
            b.d.a.a(eVar, dVar, arrayList, 0);
        }
        if (i2 == 1 && eVar.B0 > 0) {
            b.d.a.a(eVar, dVar, arrayList, 1);
        }
        try {
            dVar.q();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        this.f1347d = new ArrayList<>();
        for (int i4 = 0; i4 < arrayList.size(); i4++) {
            this.f1347d.add(new a(this, arrayList.get(i4), dVar, i2));
        }
        if (i2 == 0) {
            o = dVar.o(eVar.J);
            o2 = dVar.o(eVar.L);
            dVar.u();
        } else {
            o = dVar.o(eVar.K);
            o2 = dVar.o(eVar.M);
            dVar.u();
        }
        return o2 - o;
    }

    public void d(int i2, n nVar) {
        Iterator<b.f.a.i.d> it = this.f1344a.iterator();
        while (it.hasNext()) {
            b.f.a.i.d next = it.next();
            nVar.a(next);
            if (i2 == 0) {
                next.p0 = nVar.f1345b;
            } else {
                next.q0 = nVar.f1345b;
            }
        }
        this.f1348e = nVar.f1345b;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        int i2 = this.f1346c;
        sb.append(i2 == 0 ? "Horizontal" : i2 == 1 ? "Vertical" : i2 == 2 ? "Both" : "Unknown");
        sb.append(" [");
        sb.append(this.f1345b);
        sb.append("] <");
        String sb2 = sb.toString();
        Iterator<b.f.a.i.d> it = this.f1344a.iterator();
        while (it.hasNext()) {
            sb2 = sb2 + " " + it.next().j0;
        }
        return c.a.a.a.a.f(sb2, " >");
    }
}
