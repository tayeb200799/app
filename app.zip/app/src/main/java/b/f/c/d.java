package b.f.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import b.f.c.e;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d.smali */
public class d {

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f1417d = {0, 4, 8};

    /* renamed from: e, reason: collision with root package name */
    public static SparseIntArray f1418e = new SparseIntArray();

    /* renamed from: f, reason: collision with root package name */
    public static SparseIntArray f1419f = new SparseIntArray();

    /* renamed from: a, reason: collision with root package name */
    public HashMap<String, b.f.c.a> f1420a = new HashMap<>();

    /* renamed from: b, reason: collision with root package name */
    public boolean f1421b = true;

    /* renamed from: c, reason: collision with root package name */
    public HashMap<Integer, a> f1422c = new HashMap<>();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public int f1423a;

        /* renamed from: b, reason: collision with root package name */
        public final C0025d f1424b = new C0025d();

        /* renamed from: c, reason: collision with root package name */
        public final c f1425c = new c();

        /* renamed from: d, reason: collision with root package name */
        public final b f1426d = new b();

        /* renamed from: e, reason: collision with root package name */
        public final e f1427e = new e();

        /* renamed from: f, reason: collision with root package name */
        public HashMap<String, b.f.c.a> f1428f = new HashMap<>();

        /* renamed from: g, reason: collision with root package name */
        public C0024a f1429g;

        /* renamed from: b.f.c.d$a$a, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d$a$a.smali */
        public static class C0024a {

            /* renamed from: a, reason: collision with root package name */
            public int[] f1430a = new int[10];

            /* renamed from: b, reason: collision with root package name */
            public int[] f1431b = new int[10];

            /* renamed from: c, reason: collision with root package name */
            public int f1432c = 0;

            /* renamed from: d, reason: collision with root package name */
            public int[] f1433d = new int[10];

            /* renamed from: e, reason: collision with root package name */
            public float[] f1434e = new float[10];

            /* renamed from: f, reason: collision with root package name */
            public int f1435f = 0;

            /* renamed from: g, reason: collision with root package name */
            public int[] f1436g = new int[5];

            /* renamed from: h, reason: collision with root package name */
            public String[] f1437h = new String[5];

            /* renamed from: i, reason: collision with root package name */
            public int f1438i = 0;

            /* renamed from: j, reason: collision with root package name */
            public int[] f1439j = new int[4];
            public boolean[] k = new boolean[4];
            public int l = 0;

            public void a(int i2, float f2) {
                int i3 = this.f1435f;
                int[] iArr = this.f1433d;
                if (i3 >= iArr.length) {
                    this.f1433d = Arrays.copyOf(iArr, iArr.length * 2);
                    float[] fArr = this.f1434e;
                    this.f1434e = Arrays.copyOf(fArr, fArr.length * 2);
                }
                int[] iArr2 = this.f1433d;
                int i4 = this.f1435f;
                iArr2[i4] = i2;
                float[] fArr2 = this.f1434e;
                this.f1435f = i4 + 1;
                fArr2[i4] = f2;
            }

            public void b(int i2, int i3) {
                int i4 = this.f1432c;
                int[] iArr = this.f1430a;
                if (i4 >= iArr.length) {
                    this.f1430a = Arrays.copyOf(iArr, iArr.length * 2);
                    int[] iArr2 = this.f1431b;
                    this.f1431b = Arrays.copyOf(iArr2, iArr2.length * 2);
                }
                int[] iArr3 = this.f1430a;
                int i5 = this.f1432c;
                iArr3[i5] = i2;
                int[] iArr4 = this.f1431b;
                this.f1432c = i5 + 1;
                iArr4[i5] = i3;
            }

            public void c(int i2, String str) {
                int i3 = this.f1438i;
                int[] iArr = this.f1436g;
                if (i3 >= iArr.length) {
                    this.f1436g = Arrays.copyOf(iArr, iArr.length * 2);
                    String[] strArr = this.f1437h;
                    this.f1437h = (String[]) Arrays.copyOf(strArr, strArr.length * 2);
                }
                int[] iArr2 = this.f1436g;
                int i4 = this.f1438i;
                iArr2[i4] = i2;
                String[] strArr2 = this.f1437h;
                this.f1438i = i4 + 1;
                strArr2[i4] = str;
            }

            public void d(int i2, boolean z) {
                int i3 = this.l;
                int[] iArr = this.f1439j;
                if (i3 >= iArr.length) {
                    this.f1439j = Arrays.copyOf(iArr, iArr.length * 2);
                    boolean[] zArr = this.k;
                    this.k = Arrays.copyOf(zArr, zArr.length * 2);
                }
                int[] iArr2 = this.f1439j;
                int i4 = this.l;
                iArr2[i4] = i2;
                boolean[] zArr2 = this.k;
                this.l = i4 + 1;
                zArr2[i4] = z;
            }
        }

        public void a(ConstraintLayout.a aVar) {
            b bVar = this.f1426d;
            aVar.f253e = bVar.f1448i;
            aVar.f254f = bVar.f1449j;
            aVar.f255g = bVar.k;
            aVar.f256h = bVar.l;
            aVar.f257i = bVar.m;
            aVar.f258j = bVar.n;
            aVar.k = bVar.o;
            aVar.l = bVar.p;
            aVar.m = bVar.q;
            aVar.n = bVar.r;
            aVar.o = bVar.s;
            aVar.s = bVar.t;
            aVar.t = bVar.u;
            aVar.u = bVar.v;
            aVar.v = bVar.w;
            ((ViewGroup.MarginLayoutParams) aVar).leftMargin = bVar.G;
            ((ViewGroup.MarginLayoutParams) aVar).rightMargin = bVar.H;
            ((ViewGroup.MarginLayoutParams) aVar).topMargin = bVar.I;
            ((ViewGroup.MarginLayoutParams) aVar).bottomMargin = bVar.J;
            aVar.A = bVar.S;
            aVar.B = bVar.R;
            aVar.x = bVar.O;
            aVar.z = bVar.Q;
            aVar.E = bVar.x;
            aVar.F = bVar.y;
            b bVar2 = this.f1426d;
            aVar.p = bVar2.A;
            aVar.q = bVar2.B;
            aVar.r = bVar2.C;
            aVar.G = bVar2.z;
            aVar.T = bVar2.D;
            aVar.U = bVar2.E;
            aVar.I = bVar2.U;
            aVar.H = bVar2.V;
            aVar.K = bVar2.X;
            aVar.J = bVar2.W;
            aVar.W = bVar2.m0;
            aVar.X = bVar2.n0;
            aVar.L = bVar2.Y;
            aVar.M = bVar2.Z;
            aVar.P = bVar2.a0;
            aVar.Q = bVar2.b0;
            aVar.N = bVar2.c0;
            aVar.O = bVar2.d0;
            aVar.R = bVar2.e0;
            aVar.S = bVar2.f0;
            aVar.V = bVar2.F;
            aVar.f251c = bVar2.f1446g;
            aVar.f249a = bVar2.f1444e;
            aVar.f250b = bVar2.f1445f;
            ((ViewGroup.MarginLayoutParams) aVar).width = bVar2.f1442c;
            b bVar3 = this.f1426d;
            ((ViewGroup.MarginLayoutParams) aVar).height = bVar3.f1443d;
            String str = bVar3.l0;
            if (str != null) {
                aVar.Y = str;
            }
            aVar.Z = bVar3.p0;
            aVar.setMarginStart(bVar3.L);
            aVar.setMarginEnd(this.f1426d.K);
            aVar.a();
        }

        public final void b(int i2, ConstraintLayout.a aVar) {
            this.f1423a = i2;
            b bVar = this.f1426d;
            bVar.f1448i = aVar.f253e;
            bVar.f1449j = aVar.f254f;
            bVar.k = aVar.f255g;
            bVar.l = aVar.f256h;
            bVar.m = aVar.f257i;
            bVar.n = aVar.f258j;
            bVar.o = aVar.k;
            bVar.p = aVar.l;
            bVar.q = aVar.m;
            bVar.r = aVar.n;
            bVar.s = aVar.o;
            bVar.t = aVar.s;
            bVar.u = aVar.t;
            bVar.v = aVar.u;
            bVar.w = aVar.v;
            bVar.x = aVar.E;
            bVar.y = aVar.F;
            bVar.z = aVar.G;
            bVar.A = aVar.p;
            bVar.B = aVar.q;
            bVar.C = aVar.r;
            bVar.D = aVar.T;
            bVar.E = aVar.U;
            bVar.F = aVar.V;
            bVar.f1446g = aVar.f251c;
            b bVar2 = this.f1426d;
            bVar2.f1444e = aVar.f249a;
            bVar2.f1445f = aVar.f250b;
            bVar2.f1442c = ((ViewGroup.MarginLayoutParams) aVar).width;
            bVar2.f1443d = ((ViewGroup.MarginLayoutParams) aVar).height;
            bVar2.G = ((ViewGroup.MarginLayoutParams) aVar).leftMargin;
            bVar2.H = ((ViewGroup.MarginLayoutParams) aVar).rightMargin;
            bVar2.I = ((ViewGroup.MarginLayoutParams) aVar).topMargin;
            bVar2.J = ((ViewGroup.MarginLayoutParams) aVar).bottomMargin;
            bVar2.M = aVar.D;
            bVar2.U = aVar.I;
            bVar2.V = aVar.H;
            bVar2.X = aVar.K;
            bVar2.W = aVar.J;
            bVar2.m0 = aVar.W;
            bVar2.n0 = aVar.X;
            bVar2.Y = aVar.L;
            bVar2.Z = aVar.M;
            bVar2.a0 = aVar.P;
            bVar2.b0 = aVar.Q;
            bVar2.c0 = aVar.N;
            bVar2.d0 = aVar.O;
            bVar2.e0 = aVar.R;
            bVar2.f0 = aVar.S;
            bVar2.l0 = aVar.Y;
            bVar2.O = aVar.x;
            b bVar3 = this.f1426d;
            bVar3.Q = aVar.z;
            bVar3.N = aVar.w;
            bVar3.P = aVar.y;
            bVar3.S = aVar.A;
            bVar3.R = aVar.B;
            bVar3.T = aVar.C;
            bVar3.p0 = aVar.Z;
            bVar3.K = aVar.getMarginEnd();
            this.f1426d.L = aVar.getMarginStart();
        }

        public final void c(int i2, e.a aVar) {
            b(i2, aVar);
            this.f1424b.f1463d = aVar.r0;
            e eVar = this.f1427e;
            eVar.f1466b = aVar.u0;
            eVar.f1467c = aVar.v0;
            eVar.f1468d = aVar.w0;
            eVar.f1469e = aVar.x0;
            eVar.f1470f = aVar.y0;
            eVar.f1471g = aVar.z0;
            eVar.f1472h = aVar.A0;
            eVar.f1474j = aVar.B0;
            eVar.k = aVar.C0;
            eVar.l = aVar.D0;
            eVar.n = aVar.t0;
            eVar.m = aVar.s0;
        }

        public Object clone() {
            a aVar = new a();
            b bVar = aVar.f1426d;
            b bVar2 = this.f1426d;
            Objects.requireNonNull(bVar);
            bVar.f1440a = bVar2.f1440a;
            bVar.f1442c = bVar2.f1442c;
            bVar.f1441b = bVar2.f1441b;
            bVar.f1443d = bVar2.f1443d;
            bVar.f1444e = bVar2.f1444e;
            bVar.f1445f = bVar2.f1445f;
            bVar.f1446g = bVar2.f1446g;
            bVar.f1447h = bVar2.f1447h;
            bVar.f1448i = bVar2.f1448i;
            bVar.f1449j = bVar2.f1449j;
            bVar.k = bVar2.k;
            bVar.l = bVar2.l;
            bVar.m = bVar2.m;
            bVar.n = bVar2.n;
            bVar.o = bVar2.o;
            bVar.p = bVar2.p;
            bVar.q = bVar2.q;
            bVar.r = bVar2.r;
            bVar.s = bVar2.s;
            bVar.t = bVar2.t;
            bVar.u = bVar2.u;
            bVar.v = bVar2.v;
            bVar.w = bVar2.w;
            bVar.x = bVar2.x;
            bVar.y = bVar2.y;
            bVar.z = bVar2.z;
            bVar.A = bVar2.A;
            bVar.B = bVar2.B;
            bVar.C = bVar2.C;
            bVar.D = bVar2.D;
            bVar.E = bVar2.E;
            bVar.F = bVar2.F;
            bVar.G = bVar2.G;
            bVar.H = bVar2.H;
            bVar.I = bVar2.I;
            bVar.J = bVar2.J;
            bVar.K = bVar2.K;
            bVar.L = bVar2.L;
            bVar.M = bVar2.M;
            bVar.N = bVar2.N;
            bVar.O = bVar2.O;
            bVar.P = bVar2.P;
            bVar.Q = bVar2.Q;
            bVar.R = bVar2.R;
            bVar.S = bVar2.S;
            bVar.T = bVar2.T;
            bVar.U = bVar2.U;
            bVar.V = bVar2.V;
            bVar.W = bVar2.W;
            bVar.X = bVar2.X;
            bVar.Y = bVar2.Y;
            bVar.Z = bVar2.Z;
            bVar.a0 = bVar2.a0;
            bVar.b0 = bVar2.b0;
            bVar.c0 = bVar2.c0;
            bVar.d0 = bVar2.d0;
            bVar.e0 = bVar2.e0;
            bVar.f0 = bVar2.f0;
            bVar.g0 = bVar2.g0;
            bVar.h0 = bVar2.h0;
            bVar.i0 = bVar2.i0;
            bVar.l0 = bVar2.l0;
            int[] iArr = bVar2.j0;
            if (iArr == null || bVar2.k0 != null) {
                bVar.j0 = null;
            } else {
                bVar.j0 = Arrays.copyOf(iArr, iArr.length);
            }
            bVar.k0 = bVar2.k0;
            bVar.m0 = bVar2.m0;
            bVar.n0 = bVar2.n0;
            bVar.o0 = bVar2.o0;
            bVar.p0 = bVar2.p0;
            c cVar = aVar.f1425c;
            c cVar2 = this.f1425c;
            Objects.requireNonNull(cVar);
            cVar.f1450a = cVar2.f1450a;
            cVar.f1451b = cVar2.f1451b;
            cVar.f1453d = cVar2.f1453d;
            cVar.f1454e = cVar2.f1454e;
            cVar.f1455f = cVar2.f1455f;
            cVar.f1458i = cVar2.f1458i;
            cVar.f1456g = cVar2.f1456g;
            cVar.f1457h = cVar2.f1457h;
            C0025d c0025d = aVar.f1424b;
            C0025d c0025d2 = this.f1424b;
            Objects.requireNonNull(c0025d);
            c0025d.f1460a = c0025d2.f1460a;
            c0025d.f1461b = c0025d2.f1461b;
            c0025d.f1463d = c0025d2.f1463d;
            c0025d.f1464e = c0025d2.f1464e;
            c0025d.f1462c = c0025d2.f1462c;
            e eVar = aVar.f1427e;
            e eVar2 = this.f1427e;
            Objects.requireNonNull(eVar);
            eVar.f1465a = eVar2.f1465a;
            eVar.f1466b = eVar2.f1466b;
            eVar.f1467c = eVar2.f1467c;
            eVar.f1468d = eVar2.f1468d;
            eVar.f1469e = eVar2.f1469e;
            eVar.f1470f = eVar2.f1470f;
            eVar.f1471g = eVar2.f1471g;
            eVar.f1472h = eVar2.f1472h;
            eVar.f1473i = eVar2.f1473i;
            eVar.f1474j = eVar2.f1474j;
            eVar.k = eVar2.k;
            eVar.l = eVar2.l;
            eVar.m = eVar2.m;
            eVar.n = eVar2.n;
            aVar.f1423a = this.f1423a;
            aVar.f1429g = this.f1429g;
            return aVar;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d$b.smali */
    public static class b {
        public static SparseIntArray q0;

        /* renamed from: c, reason: collision with root package name */
        public int f1442c;

        /* renamed from: d, reason: collision with root package name */
        public int f1443d;
        public int[] j0;
        public String k0;
        public String l0;

        /* renamed from: a, reason: collision with root package name */
        public boolean f1440a = false;

        /* renamed from: b, reason: collision with root package name */
        public boolean f1441b = false;

        /* renamed from: e, reason: collision with root package name */
        public int f1444e = -1;

        /* renamed from: f, reason: collision with root package name */
        public int f1445f = -1;

        /* renamed from: g, reason: collision with root package name */
        public float f1446g = -1.0f;

        /* renamed from: h, reason: collision with root package name */
        public boolean f1447h = true;

        /* renamed from: i, reason: collision with root package name */
        public int f1448i = -1;

        /* renamed from: j, reason: collision with root package name */
        public int f1449j = -1;
        public int k = -1;
        public int l = -1;
        public int m = -1;
        public int n = -1;
        public int o = -1;
        public int p = -1;
        public int q = -1;
        public int r = -1;
        public int s = -1;
        public int t = -1;
        public int u = -1;
        public int v = -1;
        public int w = -1;
        public float x = 0.5f;
        public float y = 0.5f;
        public String z = null;
        public int A = -1;
        public int B = 0;
        public float C = 0.0f;
        public int D = -1;
        public int E = -1;
        public int F = -1;
        public int G = 0;
        public int H = 0;
        public int I = 0;
        public int J = 0;
        public int K = 0;
        public int L = 0;
        public int M = 0;
        public int N = Integer.MIN_VALUE;
        public int O = Integer.MIN_VALUE;
        public int P = Integer.MIN_VALUE;
        public int Q = Integer.MIN_VALUE;
        public int R = Integer.MIN_VALUE;
        public int S = Integer.MIN_VALUE;
        public int T = Integer.MIN_VALUE;
        public float U = -1.0f;
        public float V = -1.0f;
        public int W = 0;
        public int X = 0;
        public int Y = 0;
        public int Z = 0;
        public int a0 = 0;
        public int b0 = 0;
        public int c0 = 0;
        public int d0 = 0;
        public float e0 = 1.0f;
        public float f0 = 1.0f;
        public int g0 = -1;
        public int h0 = 0;
        public int i0 = -1;
        public boolean m0 = false;
        public boolean n0 = false;
        public boolean o0 = true;
        public int p0 = 0;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            q0 = sparseIntArray;
            sparseIntArray.append(43, 24);
            q0.append(44, 25);
            q0.append(46, 28);
            q0.append(47, 29);
            q0.append(52, 35);
            q0.append(51, 34);
            q0.append(24, 4);
            q0.append(23, 3);
            q0.append(19, 1);
            q0.append(61, 6);
            q0.append(62, 7);
            q0.append(31, 17);
            q0.append(32, 18);
            q0.append(33, 19);
            q0.append(15, 90);
            q0.append(0, 26);
            q0.append(48, 31);
            q0.append(49, 32);
            q0.append(30, 10);
            q0.append(29, 9);
            q0.append(66, 13);
            q0.append(69, 16);
            q0.append(67, 14);
            q0.append(64, 11);
            q0.append(68, 15);
            q0.append(65, 12);
            q0.append(55, 38);
            q0.append(41, 37);
            q0.append(40, 39);
            q0.append(54, 40);
            q0.append(39, 20);
            q0.append(53, 36);
            q0.append(28, 5);
            q0.append(42, 91);
            q0.append(50, 91);
            q0.append(45, 91);
            q0.append(22, 91);
            q0.append(18, 91);
            q0.append(3, 23);
            q0.append(5, 27);
            q0.append(7, 30);
            q0.append(8, 8);
            q0.append(4, 33);
            q0.append(6, 2);
            q0.append(1, 22);
            q0.append(2, 21);
            q0.append(56, 41);
            q0.append(34, 42);
            q0.append(17, 41);
            q0.append(16, 42);
            q0.append(71, 76);
            q0.append(25, 61);
            q0.append(27, 62);
            q0.append(26, 63);
            q0.append(60, 69);
            q0.append(38, 70);
            q0.append(12, 71);
            q0.append(10, 72);
            q0.append(11, 73);
            q0.append(13, 74);
            q0.append(9, 75);
        }

        public void a(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.f1484f);
            this.f1441b = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                int i3 = q0.get(index);
                switch (i3) {
                    case 1:
                        int i4 = this.q;
                        int[] iArr = d.f1417d;
                        int resourceId = obtainStyledAttributes.getResourceId(index, i4);
                        if (resourceId == -1) {
                            resourceId = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.q = resourceId;
                        break;
                    case 2:
                        this.J = obtainStyledAttributes.getDimensionPixelSize(index, this.J);
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        int i5 = this.p;
                        int[] iArr2 = d.f1417d;
                        int resourceId2 = obtainStyledAttributes.getResourceId(index, i5);
                        if (resourceId2 == -1) {
                            resourceId2 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.p = resourceId2;
                        break;
                    case 4:
                        int i6 = this.o;
                        int[] iArr3 = d.f1417d;
                        int resourceId3 = obtainStyledAttributes.getResourceId(index, i6);
                        if (resourceId3 == -1) {
                            resourceId3 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.o = resourceId3;
                        break;
                    case 5:
                        this.z = obtainStyledAttributes.getString(index);
                        break;
                    case 6:
                        this.D = obtainStyledAttributes.getDimensionPixelOffset(index, this.D);
                        break;
                    case 7:
                        this.E = obtainStyledAttributes.getDimensionPixelOffset(index, this.E);
                        break;
                    case 8:
                        this.K = obtainStyledAttributes.getDimensionPixelSize(index, this.K);
                        break;
                    case 9:
                        int i7 = this.w;
                        int[] iArr4 = d.f1417d;
                        int resourceId4 = obtainStyledAttributes.getResourceId(index, i7);
                        if (resourceId4 == -1) {
                            resourceId4 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.w = resourceId4;
                        break;
                    case 10:
                        int i8 = this.v;
                        int[] iArr5 = d.f1417d;
                        int resourceId5 = obtainStyledAttributes.getResourceId(index, i8);
                        if (resourceId5 == -1) {
                            resourceId5 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.v = resourceId5;
                        break;
                    case 11:
                        this.Q = obtainStyledAttributes.getDimensionPixelSize(index, this.Q);
                        break;
                    case 12:
                        this.R = obtainStyledAttributes.getDimensionPixelSize(index, this.R);
                        break;
                    case 13:
                        this.N = obtainStyledAttributes.getDimensionPixelSize(index, this.N);
                        break;
                    case 14:
                        this.P = obtainStyledAttributes.getDimensionPixelSize(index, this.P);
                        break;
                    case 15:
                        this.S = obtainStyledAttributes.getDimensionPixelSize(index, this.S);
                        break;
                    case 16:
                        this.O = obtainStyledAttributes.getDimensionPixelSize(index, this.O);
                        break;
                    case 17:
                        this.f1444e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1444e);
                        break;
                    case 18:
                        this.f1445f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1445f);
                        break;
                    case 19:
                        this.f1446g = obtainStyledAttributes.getFloat(index, this.f1446g);
                        break;
                    case 20:
                        this.x = obtainStyledAttributes.getFloat(index, this.x);
                        break;
                    case 21:
                        this.f1443d = obtainStyledAttributes.getLayoutDimension(index, this.f1443d);
                        break;
                    case 22:
                        this.f1442c = obtainStyledAttributes.getLayoutDimension(index, this.f1442c);
                        break;
                    case 23:
                        this.G = obtainStyledAttributes.getDimensionPixelSize(index, this.G);
                        break;
                    case 24:
                        int i9 = this.f1448i;
                        int[] iArr6 = d.f1417d;
                        int resourceId6 = obtainStyledAttributes.getResourceId(index, i9);
                        if (resourceId6 == -1) {
                            resourceId6 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.f1448i = resourceId6;
                        break;
                    case 25:
                        int i10 = this.f1449j;
                        int[] iArr7 = d.f1417d;
                        int resourceId7 = obtainStyledAttributes.getResourceId(index, i10);
                        if (resourceId7 == -1) {
                            resourceId7 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.f1449j = resourceId7;
                        break;
                    case 26:
                        this.F = obtainStyledAttributes.getInt(index, this.F);
                        break;
                    case 27:
                        this.H = obtainStyledAttributes.getDimensionPixelSize(index, this.H);
                        break;
                    case 28:
                        int i11 = this.k;
                        int[] iArr8 = d.f1417d;
                        int resourceId8 = obtainStyledAttributes.getResourceId(index, i11);
                        if (resourceId8 == -1) {
                            resourceId8 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.k = resourceId8;
                        break;
                    case 29:
                        int i12 = this.l;
                        int[] iArr9 = d.f1417d;
                        int resourceId9 = obtainStyledAttributes.getResourceId(index, i12);
                        if (resourceId9 == -1) {
                            resourceId9 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.l = resourceId9;
                        break;
                    case 30:
                        this.L = obtainStyledAttributes.getDimensionPixelSize(index, this.L);
                        break;
                    case 31:
                        int i13 = this.t;
                        int[] iArr10 = d.f1417d;
                        int resourceId10 = obtainStyledAttributes.getResourceId(index, i13);
                        if (resourceId10 == -1) {
                            resourceId10 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.t = resourceId10;
                        break;
                    case 32:
                        int i14 = this.u;
                        int[] iArr11 = d.f1417d;
                        int resourceId11 = obtainStyledAttributes.getResourceId(index, i14);
                        if (resourceId11 == -1) {
                            resourceId11 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.u = resourceId11;
                        break;
                    case 33:
                        this.I = obtainStyledAttributes.getDimensionPixelSize(index, this.I);
                        break;
                    case 34:
                        int i15 = this.n;
                        int[] iArr12 = d.f1417d;
                        int resourceId12 = obtainStyledAttributes.getResourceId(index, i15);
                        if (resourceId12 == -1) {
                            resourceId12 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.n = resourceId12;
                        break;
                    case 35:
                        int i16 = this.m;
                        int[] iArr13 = d.f1417d;
                        int resourceId13 = obtainStyledAttributes.getResourceId(index, i16);
                        if (resourceId13 == -1) {
                            resourceId13 = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.m = resourceId13;
                        break;
                    case 36:
                        this.y = obtainStyledAttributes.getFloat(index, this.y);
                        break;
                    case 37:
                        this.V = obtainStyledAttributes.getFloat(index, this.V);
                        break;
                    case 38:
                        this.U = obtainStyledAttributes.getFloat(index, this.U);
                        break;
                    case 39:
                        this.W = obtainStyledAttributes.getInt(index, this.W);
                        break;
                    case 40:
                        this.X = obtainStyledAttributes.getInt(index, this.X);
                        break;
                    case 41:
                        d.g(this, obtainStyledAttributes, index, 0);
                        break;
                    case 42:
                        d.g(this, obtainStyledAttributes, index, 1);
                        break;
                    default:
                        switch (i3) {
                            case 61:
                                int i17 = this.A;
                                int[] iArr14 = d.f1417d;
                                int resourceId14 = obtainStyledAttributes.getResourceId(index, i17);
                                if (resourceId14 == -1) {
                                    resourceId14 = obtainStyledAttributes.getInt(index, -1);
                                }
                                this.A = resourceId14;
                                break;
                            case 62:
                                this.B = obtainStyledAttributes.getDimensionPixelSize(index, this.B);
                                break;
                            case 63:
                                this.C = obtainStyledAttributes.getFloat(index, this.C);
                                break;
                            default:
                                switch (i3) {
                                    case 69:
                                        this.e0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                        break;
                                    case 70:
                                        this.f0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                        break;
                                    case 71:
                                        Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                        break;
                                    case 72:
                                        this.g0 = obtainStyledAttributes.getInt(index, this.g0);
                                        break;
                                    case 73:
                                        this.h0 = obtainStyledAttributes.getDimensionPixelSize(index, this.h0);
                                        break;
                                    case 74:
                                        this.k0 = obtainStyledAttributes.getString(index);
                                        break;
                                    case 75:
                                        this.o0 = obtainStyledAttributes.getBoolean(index, this.o0);
                                        break;
                                    case 76:
                                        this.p0 = obtainStyledAttributes.getInt(index, this.p0);
                                        break;
                                    case 77:
                                        int i18 = this.r;
                                        int[] iArr15 = d.f1417d;
                                        int resourceId15 = obtainStyledAttributes.getResourceId(index, i18);
                                        if (resourceId15 == -1) {
                                            resourceId15 = obtainStyledAttributes.getInt(index, -1);
                                        }
                                        this.r = resourceId15;
                                        break;
                                    case 78:
                                        int i19 = this.s;
                                        int[] iArr16 = d.f1417d;
                                        int resourceId16 = obtainStyledAttributes.getResourceId(index, i19);
                                        if (resourceId16 == -1) {
                                            resourceId16 = obtainStyledAttributes.getInt(index, -1);
                                        }
                                        this.s = resourceId16;
                                        break;
                                    case 79:
                                        this.T = obtainStyledAttributes.getDimensionPixelSize(index, this.T);
                                        break;
                                    case 80:
                                        this.M = obtainStyledAttributes.getDimensionPixelSize(index, this.M);
                                        break;
                                    case 81:
                                        this.Y = obtainStyledAttributes.getInt(index, this.Y);
                                        break;
                                    case 82:
                                        this.Z = obtainStyledAttributes.getInt(index, this.Z);
                                        break;
                                    case 83:
                                        this.b0 = obtainStyledAttributes.getDimensionPixelSize(index, this.b0);
                                        break;
                                    case 84:
                                        this.a0 = obtainStyledAttributes.getDimensionPixelSize(index, this.a0);
                                        break;
                                    case 85:
                                        this.d0 = obtainStyledAttributes.getDimensionPixelSize(index, this.d0);
                                        break;
                                    case 86:
                                        this.c0 = obtainStyledAttributes.getDimensionPixelSize(index, this.c0);
                                        break;
                                    case 87:
                                        this.m0 = obtainStyledAttributes.getBoolean(index, this.m0);
                                        break;
                                    case 88:
                                        this.n0 = obtainStyledAttributes.getBoolean(index, this.n0);
                                        break;
                                    case 89:
                                        this.l0 = obtainStyledAttributes.getString(index);
                                        break;
                                    case 90:
                                        this.f1447h = obtainStyledAttributes.getBoolean(index, this.f1447h);
                                        break;
                                    case 91:
                                        StringBuilder n = c.a.a.a.a.n("unused attribute 0x");
                                        n.append(Integer.toHexString(index));
                                        n.append("   ");
                                        n.append(q0.get(index));
                                        Log.w("ConstraintSet", n.toString());
                                        break;
                                    default:
                                        StringBuilder n2 = c.a.a.a.a.n("Unknown attribute 0x");
                                        n2.append(Integer.toHexString(index));
                                        n2.append("   ");
                                        n2.append(q0.get(index));
                                        Log.w("ConstraintSet", n2.toString());
                                        break;
                                }
                        }
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d$c.smali */
    public static class c {
        public static SparseIntArray o;

        /* renamed from: a, reason: collision with root package name */
        public boolean f1450a = false;

        /* renamed from: b, reason: collision with root package name */
        public int f1451b = -1;

        /* renamed from: c, reason: collision with root package name */
        public int f1452c = 0;

        /* renamed from: d, reason: collision with root package name */
        public String f1453d = null;

        /* renamed from: e, reason: collision with root package name */
        public int f1454e = -1;

        /* renamed from: f, reason: collision with root package name */
        public int f1455f = 0;

        /* renamed from: g, reason: collision with root package name */
        public float f1456g = Float.NaN;

        /* renamed from: h, reason: collision with root package name */
        public int f1457h = -1;

        /* renamed from: i, reason: collision with root package name */
        public float f1458i = Float.NaN;

        /* renamed from: j, reason: collision with root package name */
        public float f1459j = Float.NaN;
        public int k = -1;
        public String l = null;
        public int m = -3;
        public int n = -1;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            o = sparseIntArray;
            sparseIntArray.append(3, 1);
            o.append(5, 2);
            o.append(9, 3);
            o.append(2, 4);
            o.append(1, 5);
            o.append(0, 6);
            o.append(4, 7);
            o.append(8, 8);
            o.append(7, 9);
            o.append(6, 10);
        }

        public void a(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.f1485g);
            this.f1450a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (o.get(index)) {
                    case 1:
                        this.f1458i = obtainStyledAttributes.getFloat(index, this.f1458i);
                        break;
                    case 2:
                        this.f1454e = obtainStyledAttributes.getInt(index, this.f1454e);
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        if (obtainStyledAttributes.peekValue(index).type == 3) {
                            this.f1453d = obtainStyledAttributes.getString(index);
                            break;
                        } else {
                            this.f1453d = b.f.a.h.a.a.f1258c[obtainStyledAttributes.getInteger(index, 0)];
                            break;
                        }
                    case 4:
                        this.f1455f = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 5:
                        int i3 = this.f1451b;
                        int[] iArr = d.f1417d;
                        int resourceId = obtainStyledAttributes.getResourceId(index, i3);
                        if (resourceId == -1) {
                            resourceId = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.f1451b = resourceId;
                        break;
                    case 6:
                        this.f1452c = obtainStyledAttributes.getInteger(index, this.f1452c);
                        break;
                    case 7:
                        this.f1456g = obtainStyledAttributes.getFloat(index, this.f1456g);
                        break;
                    case 8:
                        this.k = obtainStyledAttributes.getInteger(index, this.k);
                        break;
                    case 9:
                        this.f1459j = obtainStyledAttributes.getFloat(index, this.f1459j);
                        break;
                    case 10:
                        int i4 = obtainStyledAttributes.peekValue(index).type;
                        if (i4 == 1) {
                            int resourceId2 = obtainStyledAttributes.getResourceId(index, -1);
                            this.n = resourceId2;
                            if (resourceId2 != -1) {
                                this.m = -2;
                                break;
                            } else {
                                break;
                            }
                        } else if (i4 == 3) {
                            String string = obtainStyledAttributes.getString(index);
                            this.l = string;
                            if (string.indexOf("/") > 0) {
                                this.n = obtainStyledAttributes.getResourceId(index, -1);
                                this.m = -2;
                                break;
                            } else {
                                this.m = -1;
                                break;
                            }
                        } else {
                            this.m = obtainStyledAttributes.getInteger(index, this.n);
                            break;
                        }
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: b.f.c.d$d, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d$d.smali */
    public static class C0025d {

        /* renamed from: a, reason: collision with root package name */
        public boolean f1460a = false;

        /* renamed from: b, reason: collision with root package name */
        public int f1461b = 0;

        /* renamed from: c, reason: collision with root package name */
        public int f1462c = 0;

        /* renamed from: d, reason: collision with root package name */
        public float f1463d = 1.0f;

        /* renamed from: e, reason: collision with root package name */
        public float f1464e = Float.NaN;

        public void a(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.f1487i);
            this.f1460a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 1) {
                    this.f1463d = obtainStyledAttributes.getFloat(index, this.f1463d);
                } else if (index == 0) {
                    int i3 = obtainStyledAttributes.getInt(index, this.f1461b);
                    this.f1461b = i3;
                    int[] iArr = d.f1417d;
                    this.f1461b = d.f1417d[i3];
                } else if (index == 4) {
                    this.f1462c = obtainStyledAttributes.getInt(index, this.f1462c);
                } else if (index == 3) {
                    this.f1464e = obtainStyledAttributes.getFloat(index, this.f1464e);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\d$e.smali */
    public static class e {
        public static SparseIntArray o;

        /* renamed from: a, reason: collision with root package name */
        public boolean f1465a = false;

        /* renamed from: b, reason: collision with root package name */
        public float f1466b = 0.0f;

        /* renamed from: c, reason: collision with root package name */
        public float f1467c = 0.0f;

        /* renamed from: d, reason: collision with root package name */
        public float f1468d = 0.0f;

        /* renamed from: e, reason: collision with root package name */
        public float f1469e = 1.0f;

        /* renamed from: f, reason: collision with root package name */
        public float f1470f = 1.0f;

        /* renamed from: g, reason: collision with root package name */
        public float f1471g = Float.NaN;

        /* renamed from: h, reason: collision with root package name */
        public float f1472h = Float.NaN;

        /* renamed from: i, reason: collision with root package name */
        public int f1473i = -1;

        /* renamed from: j, reason: collision with root package name */
        public float f1474j = 0.0f;
        public float k = 0.0f;
        public float l = 0.0f;
        public boolean m = false;
        public float n = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            o = sparseIntArray;
            sparseIntArray.append(6, 1);
            o.append(7, 2);
            o.append(8, 3);
            o.append(4, 4);
            o.append(5, 5);
            o.append(0, 6);
            o.append(1, 7);
            o.append(2, 8);
            o.append(3, 9);
            o.append(9, 10);
            o.append(10, 11);
            o.append(11, 12);
        }

        public void a(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.k);
            this.f1465a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (o.get(index)) {
                    case 1:
                        this.f1466b = obtainStyledAttributes.getFloat(index, this.f1466b);
                        break;
                    case 2:
                        this.f1467c = obtainStyledAttributes.getFloat(index, this.f1467c);
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        this.f1468d = obtainStyledAttributes.getFloat(index, this.f1468d);
                        break;
                    case 4:
                        this.f1469e = obtainStyledAttributes.getFloat(index, this.f1469e);
                        break;
                    case 5:
                        this.f1470f = obtainStyledAttributes.getFloat(index, this.f1470f);
                        break;
                    case 6:
                        this.f1471g = obtainStyledAttributes.getDimension(index, this.f1471g);
                        break;
                    case 7:
                        this.f1472h = obtainStyledAttributes.getDimension(index, this.f1472h);
                        break;
                    case 8:
                        this.f1474j = obtainStyledAttributes.getDimension(index, this.f1474j);
                        break;
                    case 9:
                        this.k = obtainStyledAttributes.getDimension(index, this.k);
                        break;
                    case 10:
                        this.l = obtainStyledAttributes.getDimension(index, this.l);
                        break;
                    case 11:
                        this.m = true;
                        this.n = obtainStyledAttributes.getDimension(index, this.n);
                        break;
                    case 12:
                        int i3 = this.f1473i;
                        int[] iArr = d.f1417d;
                        int resourceId = obtainStyledAttributes.getResourceId(index, i3);
                        if (resourceId == -1) {
                            resourceId = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.f1473i = resourceId;
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    static {
        f1418e.append(82, 25);
        f1418e.append(83, 26);
        f1418e.append(85, 29);
        f1418e.append(86, 30);
        f1418e.append(92, 36);
        f1418e.append(91, 35);
        f1418e.append(63, 4);
        f1418e.append(62, 3);
        f1418e.append(58, 1);
        f1418e.append(60, 91);
        f1418e.append(59, 92);
        f1418e.append(101, 6);
        f1418e.append(102, 7);
        f1418e.append(70, 17);
        f1418e.append(71, 18);
        f1418e.append(72, 19);
        f1418e.append(54, 99);
        f1418e.append(0, 27);
        f1418e.append(87, 32);
        f1418e.append(88, 33);
        f1418e.append(69, 10);
        f1418e.append(68, 9);
        f1418e.append(106, 13);
        f1418e.append(109, 16);
        f1418e.append(107, 14);
        f1418e.append(104, 11);
        f1418e.append(108, 15);
        f1418e.append(105, 12);
        f1418e.append(95, 40);
        f1418e.append(80, 39);
        f1418e.append(79, 41);
        f1418e.append(94, 42);
        f1418e.append(78, 20);
        f1418e.append(93, 37);
        f1418e.append(67, 5);
        f1418e.append(81, 87);
        f1418e.append(90, 87);
        f1418e.append(84, 87);
        f1418e.append(61, 87);
        f1418e.append(57, 87);
        f1418e.append(5, 24);
        f1418e.append(7, 28);
        f1418e.append(23, 31);
        f1418e.append(24, 8);
        f1418e.append(6, 34);
        f1418e.append(8, 2);
        f1418e.append(3, 23);
        f1418e.append(4, 21);
        f1418e.append(96, 95);
        f1418e.append(73, 96);
        f1418e.append(2, 22);
        f1418e.append(13, 43);
        f1418e.append(26, 44);
        f1418e.append(21, 45);
        f1418e.append(22, 46);
        f1418e.append(20, 60);
        f1418e.append(18, 47);
        f1418e.append(19, 48);
        f1418e.append(14, 49);
        f1418e.append(15, 50);
        f1418e.append(16, 51);
        f1418e.append(17, 52);
        f1418e.append(25, 53);
        f1418e.append(97, 54);
        f1418e.append(74, 55);
        f1418e.append(98, 56);
        f1418e.append(75, 57);
        f1418e.append(99, 58);
        f1418e.append(76, 59);
        f1418e.append(64, 61);
        f1418e.append(66, 62);
        f1418e.append(65, 63);
        f1418e.append(28, 64);
        f1418e.append(121, 65);
        f1418e.append(35, 66);
        f1418e.append(122, 67);
        f1418e.append(113, 79);
        f1418e.append(1, 38);
        f1418e.append(112, 68);
        f1418e.append(100, 69);
        f1418e.append(77, 70);
        f1418e.append(111, 97);
        f1418e.append(32, 71);
        f1418e.append(30, 72);
        f1418e.append(31, 73);
        f1418e.append(33, 74);
        f1418e.append(29, 75);
        f1418e.append(114, 76);
        f1418e.append(89, 77);
        f1418e.append(123, 78);
        f1418e.append(56, 80);
        f1418e.append(55, 81);
        f1418e.append(116, 82);
        f1418e.append(120, 83);
        f1418e.append(119, 84);
        f1418e.append(118, 85);
        f1418e.append(117, 86);
        f1419f.append(85, 6);
        f1419f.append(85, 7);
        f1419f.append(0, 27);
        f1419f.append(89, 13);
        f1419f.append(92, 16);
        f1419f.append(90, 14);
        f1419f.append(87, 11);
        f1419f.append(91, 15);
        f1419f.append(88, 12);
        f1419f.append(78, 40);
        f1419f.append(71, 39);
        f1419f.append(70, 41);
        f1419f.append(77, 42);
        f1419f.append(69, 20);
        f1419f.append(76, 37);
        f1419f.append(60, 5);
        f1419f.append(72, 87);
        f1419f.append(75, 87);
        f1419f.append(73, 87);
        f1419f.append(57, 87);
        f1419f.append(56, 87);
        f1419f.append(5, 24);
        f1419f.append(7, 28);
        f1419f.append(23, 31);
        f1419f.append(24, 8);
        f1419f.append(6, 34);
        f1419f.append(8, 2);
        f1419f.append(3, 23);
        f1419f.append(4, 21);
        f1419f.append(79, 95);
        f1419f.append(64, 96);
        f1419f.append(2, 22);
        f1419f.append(13, 43);
        f1419f.append(26, 44);
        f1419f.append(21, 45);
        f1419f.append(22, 46);
        f1419f.append(20, 60);
        f1419f.append(18, 47);
        f1419f.append(19, 48);
        f1419f.append(14, 49);
        f1419f.append(15, 50);
        f1419f.append(16, 51);
        f1419f.append(17, 52);
        f1419f.append(25, 53);
        f1419f.append(80, 54);
        f1419f.append(65, 55);
        f1419f.append(81, 56);
        f1419f.append(66, 57);
        f1419f.append(82, 58);
        f1419f.append(67, 59);
        f1419f.append(59, 62);
        f1419f.append(58, 63);
        f1419f.append(28, 64);
        f1419f.append(105, 65);
        f1419f.append(34, 66);
        f1419f.append(106, 67);
        f1419f.append(96, 79);
        f1419f.append(1, 38);
        f1419f.append(97, 98);
        f1419f.append(95, 68);
        f1419f.append(83, 69);
        f1419f.append(68, 70);
        f1419f.append(32, 71);
        f1419f.append(30, 72);
        f1419f.append(31, 73);
        f1419f.append(33, 74);
        f1419f.append(29, 75);
        f1419f.append(98, 76);
        f1419f.append(74, 77);
        f1419f.append(107, 78);
        f1419f.append(55, 80);
        f1419f.append(54, 81);
        f1419f.append(100, 82);
        f1419f.append(104, 83);
        f1419f.append(103, 84);
        f1419f.append(102, 85);
        f1419f.append(101, 86);
        f1419f.append(94, 97);
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x003f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void g(java.lang.Object r8, android.content.res.TypedArray r9, int r10, int r11) {
        /*
            Method dump skipped, instructions count: 372
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.c.d.g(java.lang.Object, android.content.res.TypedArray, int, int):void");
    }

    public static void h(ConstraintLayout.a aVar, String str) {
        if (str != null) {
            int length = str.length();
            int indexOf = str.indexOf(44);
            int i2 = -1;
            if (indexOf > 0 && indexOf < length - 1) {
                String substring = str.substring(0, indexOf);
                i2 = substring.equalsIgnoreCase("W") ? 0 : substring.equalsIgnoreCase("H") ? 1 : -1;
                r2 = indexOf + 1;
            }
            int indexOf2 = str.indexOf(58);
            try {
                if (indexOf2 < 0 || indexOf2 >= length - 1) {
                    String substring2 = str.substring(r2);
                    if (substring2.length() > 0) {
                        Float.parseFloat(substring2);
                    }
                } else {
                    String substring3 = str.substring(r2, indexOf2);
                    String substring4 = str.substring(indexOf2 + 1);
                    if (substring3.length() > 0 && substring4.length() > 0) {
                        float parseFloat = Float.parseFloat(substring3);
                        float parseFloat2 = Float.parseFloat(substring4);
                        if (parseFloat > 0.0f && parseFloat2 > 0.0f) {
                            if (i2 == 1) {
                                Math.abs(parseFloat2 / parseFloat);
                            } else {
                                Math.abs(parseFloat / parseFloat2);
                            }
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
        }
        aVar.G = str;
    }

    public void a(ConstraintLayout constraintLayout) {
        b(constraintLayout, true);
        constraintLayout.setConstraintSet(null);
        constraintLayout.requestLayout();
    }

    public void b(ConstraintLayout constraintLayout, boolean z) {
        int childCount = constraintLayout.getChildCount();
        HashSet hashSet = new HashSet(this.f1422c.keySet());
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            int id = childAt.getId();
            if (!this.f1422c.containsKey(Integer.valueOf(id))) {
                StringBuilder n = c.a.a.a.a.n("id unknown ");
                n.append(b.d.a.e(childAt));
                Log.w("ConstraintSet", n.toString());
            } else {
                if (this.f1421b && id == -1) {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
                if (id != -1) {
                    if (this.f1422c.containsKey(Integer.valueOf(id))) {
                        hashSet.remove(Integer.valueOf(id));
                        a aVar = this.f1422c.get(Integer.valueOf(id));
                        if (aVar != null) {
                            if (childAt instanceof Barrier) {
                                aVar.f1426d.i0 = 1;
                                Barrier barrier = (Barrier) childAt;
                                barrier.setId(id);
                                barrier.setType(aVar.f1426d.g0);
                                barrier.setMargin(aVar.f1426d.h0);
                                barrier.setAllowsGoneWidget(aVar.f1426d.o0);
                                b bVar = aVar.f1426d;
                                int[] iArr = bVar.j0;
                                if (iArr != null) {
                                    barrier.setReferencedIds(iArr);
                                } else {
                                    String str = bVar.k0;
                                    if (str != null) {
                                        bVar.j0 = d(barrier, str);
                                        barrier.setReferencedIds(aVar.f1426d.j0);
                                    }
                                }
                            }
                            ConstraintLayout.a aVar2 = (ConstraintLayout.a) childAt.getLayoutParams();
                            aVar2.a();
                            aVar.a(aVar2);
                            if (z) {
                                b.f.c.a.b(childAt, aVar.f1428f);
                            }
                            childAt.setLayoutParams(aVar2);
                            C0025d c0025d = aVar.f1424b;
                            if (c0025d.f1462c == 0) {
                                childAt.setVisibility(c0025d.f1461b);
                            }
                            childAt.setAlpha(aVar.f1424b.f1463d);
                            childAt.setRotation(aVar.f1427e.f1466b);
                            childAt.setRotationX(aVar.f1427e.f1467c);
                            childAt.setRotationY(aVar.f1427e.f1468d);
                            childAt.setScaleX(aVar.f1427e.f1469e);
                            childAt.setScaleY(aVar.f1427e.f1470f);
                            e eVar = aVar.f1427e;
                            if (eVar.f1473i != -1) {
                                if (((View) childAt.getParent()).findViewById(aVar.f1427e.f1473i) != null) {
                                    float bottom = (r4.getBottom() + r4.getTop()) / 2.0f;
                                    float right = (r4.getRight() + r4.getLeft()) / 2.0f;
                                    if (childAt.getRight() - childAt.getLeft() > 0 && childAt.getBottom() - childAt.getTop() > 0) {
                                        childAt.setPivotX(right - childAt.getLeft());
                                        childAt.setPivotY(bottom - childAt.getTop());
                                    }
                                }
                            } else {
                                if (!Float.isNaN(eVar.f1471g)) {
                                    childAt.setPivotX(aVar.f1427e.f1471g);
                                }
                                if (!Float.isNaN(aVar.f1427e.f1472h)) {
                                    childAt.setPivotY(aVar.f1427e.f1472h);
                                }
                            }
                            childAt.setTranslationX(aVar.f1427e.f1474j);
                            childAt.setTranslationY(aVar.f1427e.k);
                            childAt.setTranslationZ(aVar.f1427e.l);
                            e eVar2 = aVar.f1427e;
                            if (eVar2.m) {
                                childAt.setElevation(eVar2.n);
                            }
                        }
                    } else {
                        Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                    }
                }
            }
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            a aVar3 = this.f1422c.get(num);
            if (aVar3 != null) {
                if (aVar3.f1426d.i0 == 1) {
                    Barrier barrier2 = new Barrier(constraintLayout.getContext());
                    barrier2.setId(num.intValue());
                    b bVar2 = aVar3.f1426d;
                    int[] iArr2 = bVar2.j0;
                    if (iArr2 != null) {
                        barrier2.setReferencedIds(iArr2);
                    } else {
                        String str2 = bVar2.k0;
                        if (str2 != null) {
                            bVar2.j0 = d(barrier2, str2);
                            barrier2.setReferencedIds(aVar3.f1426d.j0);
                        }
                    }
                    barrier2.setType(aVar3.f1426d.g0);
                    barrier2.setMargin(aVar3.f1426d.h0);
                    ConstraintLayout.a generateDefaultLayoutParams = constraintLayout.generateDefaultLayoutParams();
                    barrier2.n();
                    aVar3.a(generateDefaultLayoutParams);
                    constraintLayout.addView(barrier2, generateDefaultLayoutParams);
                }
                if (aVar3.f1426d.f1440a) {
                    View guideline = new Guideline(constraintLayout.getContext());
                    guideline.setId(num.intValue());
                    ConstraintLayout.a generateDefaultLayoutParams2 = constraintLayout.generateDefaultLayoutParams();
                    aVar3.a(generateDefaultLayoutParams2);
                    constraintLayout.addView(guideline, generateDefaultLayoutParams2);
                }
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = constraintLayout.getChildAt(i3);
            if (childAt2 instanceof b.f.c.b) {
                ((b.f.c.b) childAt2).g(constraintLayout);
            }
        }
    }

    public void c(ConstraintLayout constraintLayout) {
        d dVar = this;
        int childCount = constraintLayout.getChildCount();
        dVar.f1422c.clear();
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = constraintLayout.getChildAt(i2);
            ConstraintLayout.a aVar = (ConstraintLayout.a) childAt.getLayoutParams();
            int id = childAt.getId();
            if (dVar.f1421b && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!dVar.f1422c.containsKey(Integer.valueOf(id))) {
                dVar.f1422c.put(Integer.valueOf(id), new a());
            }
            a aVar2 = dVar.f1422c.get(Integer.valueOf(id));
            if (aVar2 != null) {
                HashMap<String, b.f.c.a> hashMap = dVar.f1420a;
                HashMap<String, b.f.c.a> hashMap2 = new HashMap<>();
                Class<?> cls = childAt.getClass();
                for (String str : hashMap.keySet()) {
                    b.f.c.a aVar3 = hashMap.get(str);
                    try {
                    } catch (IllegalAccessException e2) {
                        e = e2;
                    } catch (NoSuchMethodException e3) {
                        e = e3;
                    } catch (InvocationTargetException e4) {
                        e = e4;
                    }
                    if (str.equals("BackgroundColor")) {
                        hashMap2.put(str, new b.f.c.a(aVar3, Integer.valueOf(((ColorDrawable) childAt.getBackground()).getColor())));
                    } else {
                        try {
                            hashMap2.put(str, new b.f.c.a(aVar3, cls.getMethod("getMap" + str, new Class[0]).invoke(childAt, new Object[0])));
                        } catch (IllegalAccessException e5) {
                            e = e5;
                            e.printStackTrace();
                        } catch (NoSuchMethodException e6) {
                            e = e6;
                            e.printStackTrace();
                        } catch (InvocationTargetException e7) {
                            e = e7;
                            e.printStackTrace();
                        }
                    }
                }
                aVar2.f1428f = hashMap2;
                aVar2.b(id, aVar);
                aVar2.f1424b.f1461b = childAt.getVisibility();
                aVar2.f1424b.f1463d = childAt.getAlpha();
                aVar2.f1427e.f1466b = childAt.getRotation();
                aVar2.f1427e.f1467c = childAt.getRotationX();
                aVar2.f1427e.f1468d = childAt.getRotationY();
                aVar2.f1427e.f1469e = childAt.getScaleX();
                aVar2.f1427e.f1470f = childAt.getScaleY();
                float pivotX = childAt.getPivotX();
                float pivotY = childAt.getPivotY();
                if (pivotX != 0.0d || pivotY != 0.0d) {
                    e eVar = aVar2.f1427e;
                    eVar.f1471g = pivotX;
                    eVar.f1472h = pivotY;
                }
                aVar2.f1427e.f1474j = childAt.getTranslationX();
                aVar2.f1427e.k = childAt.getTranslationY();
                aVar2.f1427e.l = childAt.getTranslationZ();
                e eVar2 = aVar2.f1427e;
                if (eVar2.m) {
                    eVar2.n = childAt.getElevation();
                }
                if (childAt instanceof Barrier) {
                    Barrier barrier = (Barrier) childAt;
                    aVar2.f1426d.o0 = barrier.getAllowsGoneWidget();
                    aVar2.f1426d.j0 = barrier.getReferencedIds();
                    aVar2.f1426d.g0 = barrier.getType();
                    aVar2.f1426d.h0 = barrier.getMargin();
                }
            }
            i2++;
            dVar = this;
        }
    }

    public final int[] d(View view, String str) {
        int i2;
        Object c2;
        String[] split = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[split.length];
        int i3 = 0;
        int i4 = 0;
        while (i3 < split.length) {
            String trim = split[i3].trim();
            try {
                i2 = h.class.getField(trim).getInt(null);
            } catch (Exception unused) {
                i2 = 0;
            }
            if (i2 == 0) {
                i2 = context.getResources().getIdentifier(trim, "id", context.getPackageName());
            }
            if (i2 == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (c2 = ((ConstraintLayout) view.getParent()).c(0, trim)) != null && (c2 instanceof Integer)) {
                i2 = ((Integer) c2).intValue();
            }
            iArr[i4] = i2;
            i3++;
            i4++;
        }
        return i4 != split.length ? Arrays.copyOf(iArr, i4) : iArr;
    }

    public final a e(Context context, AttributeSet attributeSet, boolean z) {
        a aVar = new a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z ? i.f1481c : i.f1479a);
        String[] strArr = b.f.a.h.a.a.f1258c;
        int[] iArr = f1417d;
        if (z) {
            int indexCount = obtainStyledAttributes.getIndexCount();
            a.C0024a c0024a = new a.C0024a();
            aVar.f1429g = c0024a;
            aVar.f1425c.f1450a = false;
            aVar.f1426d.f1441b = false;
            aVar.f1424b.f1460a = false;
            aVar.f1427e.f1465a = false;
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (f1419f.get(index)) {
                    case 2:
                        c0024a.b(2, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.J));
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                    case 4:
                    case 9:
                    case 10:
                    case 25:
                    case 26:
                    case 29:
                    case 30:
                    case 32:
                    case 33:
                    case 35:
                    case 36:
                    case 61:
                    case 88:
                    case 89:
                    case 90:
                    case 91:
                    case 92:
                    default:
                        StringBuilder n = c.a.a.a.a.n("Unknown attribute 0x");
                        n.append(Integer.toHexString(index));
                        n.append("   ");
                        n.append(f1418e.get(index));
                        Log.w("ConstraintSet", n.toString());
                        break;
                    case 5:
                        c0024a.c(5, obtainStyledAttributes.getString(index));
                        break;
                    case 6:
                        c0024a.b(6, obtainStyledAttributes.getDimensionPixelOffset(index, aVar.f1426d.D));
                        break;
                    case 7:
                        c0024a.b(7, obtainStyledAttributes.getDimensionPixelOffset(index, aVar.f1426d.E));
                        break;
                    case 8:
                        c0024a.b(8, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.K));
                        break;
                    case 11:
                        c0024a.b(11, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.Q));
                        break;
                    case 12:
                        c0024a.b(12, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.R));
                        break;
                    case 13:
                        c0024a.b(13, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.N));
                        break;
                    case 14:
                        c0024a.b(14, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.P));
                        break;
                    case 15:
                        c0024a.b(15, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.S));
                        break;
                    case 16:
                        c0024a.b(16, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.O));
                        break;
                    case 17:
                        c0024a.b(17, obtainStyledAttributes.getDimensionPixelOffset(index, aVar.f1426d.f1444e));
                        break;
                    case 18:
                        c0024a.b(18, obtainStyledAttributes.getDimensionPixelOffset(index, aVar.f1426d.f1445f));
                        break;
                    case 19:
                        c0024a.a(19, obtainStyledAttributes.getFloat(index, aVar.f1426d.f1446g));
                        break;
                    case 20:
                        c0024a.a(20, obtainStyledAttributes.getFloat(index, aVar.f1426d.x));
                        break;
                    case 21:
                        c0024a.b(21, obtainStyledAttributes.getLayoutDimension(index, aVar.f1426d.f1443d));
                        break;
                    case 22:
                        c0024a.b(22, iArr[obtainStyledAttributes.getInt(index, aVar.f1424b.f1461b)]);
                        break;
                    case 23:
                        c0024a.b(23, obtainStyledAttributes.getLayoutDimension(index, aVar.f1426d.f1442c));
                        break;
                    case 24:
                        c0024a.b(24, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.G));
                        break;
                    case 27:
                        c0024a.b(27, obtainStyledAttributes.getInt(index, aVar.f1426d.F));
                        break;
                    case 28:
                        c0024a.b(28, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.H));
                        break;
                    case 31:
                        c0024a.b(31, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.L));
                        break;
                    case 34:
                        c0024a.b(34, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.I));
                        break;
                    case 37:
                        c0024a.a(37, obtainStyledAttributes.getFloat(index, aVar.f1426d.y));
                        break;
                    case 38:
                        int resourceId = obtainStyledAttributes.getResourceId(index, aVar.f1423a);
                        aVar.f1423a = resourceId;
                        c0024a.b(38, resourceId);
                        break;
                    case 39:
                        c0024a.a(39, obtainStyledAttributes.getFloat(index, aVar.f1426d.V));
                        break;
                    case 40:
                        c0024a.a(40, obtainStyledAttributes.getFloat(index, aVar.f1426d.U));
                        break;
                    case 41:
                        c0024a.b(41, obtainStyledAttributes.getInt(index, aVar.f1426d.W));
                        break;
                    case 42:
                        c0024a.b(42, obtainStyledAttributes.getInt(index, aVar.f1426d.X));
                        break;
                    case 43:
                        c0024a.a(43, obtainStyledAttributes.getFloat(index, aVar.f1424b.f1463d));
                        break;
                    case 44:
                        c0024a.d(44, true);
                        c0024a.a(44, obtainStyledAttributes.getDimension(index, aVar.f1427e.n));
                        break;
                    case 45:
                        c0024a.a(45, obtainStyledAttributes.getFloat(index, aVar.f1427e.f1467c));
                        break;
                    case 46:
                        c0024a.a(46, obtainStyledAttributes.getFloat(index, aVar.f1427e.f1468d));
                        break;
                    case 47:
                        c0024a.a(47, obtainStyledAttributes.getFloat(index, aVar.f1427e.f1469e));
                        break;
                    case 48:
                        c0024a.a(48, obtainStyledAttributes.getFloat(index, aVar.f1427e.f1470f));
                        break;
                    case 49:
                        c0024a.a(49, obtainStyledAttributes.getDimension(index, aVar.f1427e.f1471g));
                        break;
                    case 50:
                        c0024a.a(50, obtainStyledAttributes.getDimension(index, aVar.f1427e.f1472h));
                        break;
                    case 51:
                        c0024a.a(51, obtainStyledAttributes.getDimension(index, aVar.f1427e.f1474j));
                        break;
                    case 52:
                        c0024a.a(52, obtainStyledAttributes.getDimension(index, aVar.f1427e.k));
                        break;
                    case 53:
                        c0024a.a(53, obtainStyledAttributes.getDimension(index, aVar.f1427e.l));
                        break;
                    case 54:
                        c0024a.b(54, obtainStyledAttributes.getInt(index, aVar.f1426d.Y));
                        break;
                    case 55:
                        c0024a.b(55, obtainStyledAttributes.getInt(index, aVar.f1426d.Z));
                        break;
                    case 56:
                        c0024a.b(56, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.a0));
                        break;
                    case 57:
                        c0024a.b(57, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.b0));
                        break;
                    case 58:
                        c0024a.b(58, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.c0));
                        break;
                    case 59:
                        c0024a.b(59, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.d0));
                        break;
                    case 60:
                        c0024a.a(60, obtainStyledAttributes.getFloat(index, aVar.f1427e.f1466b));
                        break;
                    case 62:
                        c0024a.b(62, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.B));
                        break;
                    case 63:
                        c0024a.a(63, obtainStyledAttributes.getFloat(index, aVar.f1426d.C));
                        break;
                    case 64:
                        int resourceId2 = obtainStyledAttributes.getResourceId(index, aVar.f1425c.f1451b);
                        if (resourceId2 == -1) {
                            resourceId2 = obtainStyledAttributes.getInt(index, -1);
                        }
                        c0024a.b(64, resourceId2);
                        break;
                    case 65:
                        if (obtainStyledAttributes.peekValue(index).type == 3) {
                            c0024a.c(65, obtainStyledAttributes.getString(index));
                            break;
                        } else {
                            c0024a.c(65, strArr[obtainStyledAttributes.getInteger(index, 0)]);
                            break;
                        }
                    case 66:
                        c0024a.b(66, obtainStyledAttributes.getInt(index, 0));
                        break;
                    case 67:
                        c0024a.a(67, obtainStyledAttributes.getFloat(index, aVar.f1425c.f1458i));
                        break;
                    case 68:
                        c0024a.a(68, obtainStyledAttributes.getFloat(index, aVar.f1424b.f1464e));
                        break;
                    case 69:
                        c0024a.a(69, obtainStyledAttributes.getFloat(index, 1.0f));
                        break;
                    case 70:
                        c0024a.a(70, obtainStyledAttributes.getFloat(index, 1.0f));
                        break;
                    case 71:
                        Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                        break;
                    case 72:
                        c0024a.b(72, obtainStyledAttributes.getInt(index, aVar.f1426d.g0));
                        break;
                    case 73:
                        c0024a.b(73, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.h0));
                        break;
                    case 74:
                        c0024a.c(74, obtainStyledAttributes.getString(index));
                        break;
                    case 75:
                        c0024a.d(75, obtainStyledAttributes.getBoolean(index, aVar.f1426d.o0));
                        break;
                    case 76:
                        c0024a.b(76, obtainStyledAttributes.getInt(index, aVar.f1425c.f1454e));
                        break;
                    case 77:
                        c0024a.c(77, obtainStyledAttributes.getString(index));
                        break;
                    case 78:
                        c0024a.b(78, obtainStyledAttributes.getInt(index, aVar.f1424b.f1462c));
                        break;
                    case 79:
                        c0024a.a(79, obtainStyledAttributes.getFloat(index, aVar.f1425c.f1456g));
                        break;
                    case 80:
                        c0024a.d(80, obtainStyledAttributes.getBoolean(index, aVar.f1426d.m0));
                        break;
                    case 81:
                        c0024a.d(81, obtainStyledAttributes.getBoolean(index, aVar.f1426d.n0));
                        break;
                    case 82:
                        c0024a.b(82, obtainStyledAttributes.getInteger(index, aVar.f1425c.f1452c));
                        break;
                    case 83:
                        int resourceId3 = obtainStyledAttributes.getResourceId(index, aVar.f1427e.f1473i);
                        if (resourceId3 == -1) {
                            resourceId3 = obtainStyledAttributes.getInt(index, -1);
                        }
                        c0024a.b(83, resourceId3);
                        break;
                    case 84:
                        c0024a.b(84, obtainStyledAttributes.getInteger(index, aVar.f1425c.k));
                        break;
                    case 85:
                        c0024a.a(85, obtainStyledAttributes.getFloat(index, aVar.f1425c.f1459j));
                        break;
                    case 86:
                        int i3 = obtainStyledAttributes.peekValue(index).type;
                        if (i3 == 1) {
                            aVar.f1425c.n = obtainStyledAttributes.getResourceId(index, -1);
                            c0024a.b(89, aVar.f1425c.n);
                            c cVar = aVar.f1425c;
                            if (cVar.n != -1) {
                                cVar.m = -2;
                                c0024a.b(88, -2);
                                break;
                            } else {
                                break;
                            }
                        } else if (i3 == 3) {
                            aVar.f1425c.l = obtainStyledAttributes.getString(index);
                            c0024a.c(90, aVar.f1425c.l);
                            if (aVar.f1425c.l.indexOf("/") > 0) {
                                aVar.f1425c.n = obtainStyledAttributes.getResourceId(index, -1);
                                c0024a.b(89, aVar.f1425c.n);
                                aVar.f1425c.m = -2;
                                c0024a.b(88, -2);
                                break;
                            } else {
                                aVar.f1425c.m = -1;
                                c0024a.b(88, -1);
                                break;
                            }
                        } else {
                            c cVar2 = aVar.f1425c;
                            cVar2.m = obtainStyledAttributes.getInteger(index, cVar2.n);
                            c0024a.b(88, aVar.f1425c.m);
                            break;
                        }
                    case 87:
                        StringBuilder n2 = c.a.a.a.a.n("unused attribute 0x");
                        n2.append(Integer.toHexString(index));
                        n2.append("   ");
                        n2.append(f1418e.get(index));
                        Log.w("ConstraintSet", n2.toString());
                        break;
                    case 93:
                        c0024a.b(93, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.M));
                        break;
                    case 94:
                        c0024a.b(94, obtainStyledAttributes.getDimensionPixelSize(index, aVar.f1426d.T));
                        break;
                    case 95:
                        g(c0024a, obtainStyledAttributes, index, 0);
                        break;
                    case 96:
                        g(c0024a, obtainStyledAttributes, index, 1);
                        break;
                    case 97:
                        c0024a.b(97, obtainStyledAttributes.getInt(index, aVar.f1426d.p0));
                        break;
                    case 98:
                        int i4 = b.f.b.a.c.b0;
                        if (obtainStyledAttributes.peekValue(index).type == 3) {
                            obtainStyledAttributes.getString(index);
                            break;
                        } else {
                            aVar.f1423a = obtainStyledAttributes.getResourceId(index, aVar.f1423a);
                            break;
                        }
                    case 99:
                        c0024a.d(99, obtainStyledAttributes.getBoolean(index, aVar.f1426d.f1447h));
                        break;
                }
            }
        } else {
            int indexCount2 = obtainStyledAttributes.getIndexCount();
            for (int i5 = 0; i5 < indexCount2; i5++) {
                int index2 = obtainStyledAttributes.getIndex(i5);
                if (index2 != 1 && 23 != index2 && 24 != index2) {
                    aVar.f1425c.f1450a = true;
                    aVar.f1426d.f1441b = true;
                    aVar.f1424b.f1460a = true;
                    aVar.f1427e.f1465a = true;
                }
                switch (f1418e.get(index2)) {
                    case 1:
                        b bVar = aVar.f1426d;
                        int resourceId4 = obtainStyledAttributes.getResourceId(index2, bVar.q);
                        if (resourceId4 == -1) {
                            resourceId4 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar.q = resourceId4;
                        break;
                    case 2:
                        b bVar2 = aVar.f1426d;
                        bVar2.J = obtainStyledAttributes.getDimensionPixelSize(index2, bVar2.J);
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        b bVar3 = aVar.f1426d;
                        int resourceId5 = obtainStyledAttributes.getResourceId(index2, bVar3.p);
                        if (resourceId5 == -1) {
                            resourceId5 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar3.p = resourceId5;
                        break;
                    case 4:
                        b bVar4 = aVar.f1426d;
                        int resourceId6 = obtainStyledAttributes.getResourceId(index2, bVar4.o);
                        if (resourceId6 == -1) {
                            resourceId6 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar4.o = resourceId6;
                        break;
                    case 5:
                        aVar.f1426d.z = obtainStyledAttributes.getString(index2);
                        break;
                    case 6:
                        b bVar5 = aVar.f1426d;
                        bVar5.D = obtainStyledAttributes.getDimensionPixelOffset(index2, bVar5.D);
                        break;
                    case 7:
                        b bVar6 = aVar.f1426d;
                        bVar6.E = obtainStyledAttributes.getDimensionPixelOffset(index2, bVar6.E);
                        break;
                    case 8:
                        b bVar7 = aVar.f1426d;
                        bVar7.K = obtainStyledAttributes.getDimensionPixelSize(index2, bVar7.K);
                        break;
                    case 9:
                        b bVar8 = aVar.f1426d;
                        int resourceId7 = obtainStyledAttributes.getResourceId(index2, bVar8.w);
                        if (resourceId7 == -1) {
                            resourceId7 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar8.w = resourceId7;
                        break;
                    case 10:
                        b bVar9 = aVar.f1426d;
                        int resourceId8 = obtainStyledAttributes.getResourceId(index2, bVar9.v);
                        if (resourceId8 == -1) {
                            resourceId8 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar9.v = resourceId8;
                        break;
                    case 11:
                        b bVar10 = aVar.f1426d;
                        bVar10.Q = obtainStyledAttributes.getDimensionPixelSize(index2, bVar10.Q);
                        break;
                    case 12:
                        b bVar11 = aVar.f1426d;
                        bVar11.R = obtainStyledAttributes.getDimensionPixelSize(index2, bVar11.R);
                        break;
                    case 13:
                        b bVar12 = aVar.f1426d;
                        bVar12.N = obtainStyledAttributes.getDimensionPixelSize(index2, bVar12.N);
                        break;
                    case 14:
                        b bVar13 = aVar.f1426d;
                        bVar13.P = obtainStyledAttributes.getDimensionPixelSize(index2, bVar13.P);
                        break;
                    case 15:
                        b bVar14 = aVar.f1426d;
                        bVar14.S = obtainStyledAttributes.getDimensionPixelSize(index2, bVar14.S);
                        break;
                    case 16:
                        b bVar15 = aVar.f1426d;
                        bVar15.O = obtainStyledAttributes.getDimensionPixelSize(index2, bVar15.O);
                        break;
                    case 17:
                        b bVar16 = aVar.f1426d;
                        bVar16.f1444e = obtainStyledAttributes.getDimensionPixelOffset(index2, bVar16.f1444e);
                        break;
                    case 18:
                        b bVar17 = aVar.f1426d;
                        bVar17.f1445f = obtainStyledAttributes.getDimensionPixelOffset(index2, bVar17.f1445f);
                        break;
                    case 19:
                        b bVar18 = aVar.f1426d;
                        bVar18.f1446g = obtainStyledAttributes.getFloat(index2, bVar18.f1446g);
                        break;
                    case 20:
                        b bVar19 = aVar.f1426d;
                        bVar19.x = obtainStyledAttributes.getFloat(index2, bVar19.x);
                        break;
                    case 21:
                        b bVar20 = aVar.f1426d;
                        bVar20.f1443d = obtainStyledAttributes.getLayoutDimension(index2, bVar20.f1443d);
                        break;
                    case 22:
                        C0025d c0025d = aVar.f1424b;
                        c0025d.f1461b = obtainStyledAttributes.getInt(index2, c0025d.f1461b);
                        C0025d c0025d2 = aVar.f1424b;
                        c0025d2.f1461b = iArr[c0025d2.f1461b];
                        break;
                    case 23:
                        b bVar21 = aVar.f1426d;
                        bVar21.f1442c = obtainStyledAttributes.getLayoutDimension(index2, bVar21.f1442c);
                        break;
                    case 24:
                        b bVar22 = aVar.f1426d;
                        bVar22.G = obtainStyledAttributes.getDimensionPixelSize(index2, bVar22.G);
                        break;
                    case 25:
                        b bVar23 = aVar.f1426d;
                        int resourceId9 = obtainStyledAttributes.getResourceId(index2, bVar23.f1448i);
                        if (resourceId9 == -1) {
                            resourceId9 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar23.f1448i = resourceId9;
                        break;
                    case 26:
                        b bVar24 = aVar.f1426d;
                        int resourceId10 = obtainStyledAttributes.getResourceId(index2, bVar24.f1449j);
                        if (resourceId10 == -1) {
                            resourceId10 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar24.f1449j = resourceId10;
                        break;
                    case 27:
                        b bVar25 = aVar.f1426d;
                        bVar25.F = obtainStyledAttributes.getInt(index2, bVar25.F);
                        break;
                    case 28:
                        b bVar26 = aVar.f1426d;
                        bVar26.H = obtainStyledAttributes.getDimensionPixelSize(index2, bVar26.H);
                        break;
                    case 29:
                        b bVar27 = aVar.f1426d;
                        int resourceId11 = obtainStyledAttributes.getResourceId(index2, bVar27.k);
                        if (resourceId11 == -1) {
                            resourceId11 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar27.k = resourceId11;
                        break;
                    case 30:
                        b bVar28 = aVar.f1426d;
                        int resourceId12 = obtainStyledAttributes.getResourceId(index2, bVar28.l);
                        if (resourceId12 == -1) {
                            resourceId12 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar28.l = resourceId12;
                        break;
                    case 31:
                        b bVar29 = aVar.f1426d;
                        bVar29.L = obtainStyledAttributes.getDimensionPixelSize(index2, bVar29.L);
                        break;
                    case 32:
                        b bVar30 = aVar.f1426d;
                        int resourceId13 = obtainStyledAttributes.getResourceId(index2, bVar30.t);
                        if (resourceId13 == -1) {
                            resourceId13 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar30.t = resourceId13;
                        break;
                    case 33:
                        b bVar31 = aVar.f1426d;
                        int resourceId14 = obtainStyledAttributes.getResourceId(index2, bVar31.u);
                        if (resourceId14 == -1) {
                            resourceId14 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar31.u = resourceId14;
                        break;
                    case 34:
                        b bVar32 = aVar.f1426d;
                        bVar32.I = obtainStyledAttributes.getDimensionPixelSize(index2, bVar32.I);
                        break;
                    case 35:
                        b bVar33 = aVar.f1426d;
                        int resourceId15 = obtainStyledAttributes.getResourceId(index2, bVar33.n);
                        if (resourceId15 == -1) {
                            resourceId15 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar33.n = resourceId15;
                        break;
                    case 36:
                        b bVar34 = aVar.f1426d;
                        int resourceId16 = obtainStyledAttributes.getResourceId(index2, bVar34.m);
                        if (resourceId16 == -1) {
                            resourceId16 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar34.m = resourceId16;
                        break;
                    case 37:
                        b bVar35 = aVar.f1426d;
                        bVar35.y = obtainStyledAttributes.getFloat(index2, bVar35.y);
                        break;
                    case 38:
                        aVar.f1423a = obtainStyledAttributes.getResourceId(index2, aVar.f1423a);
                        break;
                    case 39:
                        b bVar36 = aVar.f1426d;
                        bVar36.V = obtainStyledAttributes.getFloat(index2, bVar36.V);
                        break;
                    case 40:
                        b bVar37 = aVar.f1426d;
                        bVar37.U = obtainStyledAttributes.getFloat(index2, bVar37.U);
                        break;
                    case 41:
                        b bVar38 = aVar.f1426d;
                        bVar38.W = obtainStyledAttributes.getInt(index2, bVar38.W);
                        break;
                    case 42:
                        b bVar39 = aVar.f1426d;
                        bVar39.X = obtainStyledAttributes.getInt(index2, bVar39.X);
                        break;
                    case 43:
                        C0025d c0025d3 = aVar.f1424b;
                        c0025d3.f1463d = obtainStyledAttributes.getFloat(index2, c0025d3.f1463d);
                        break;
                    case 44:
                        e eVar = aVar.f1427e;
                        eVar.m = true;
                        eVar.n = obtainStyledAttributes.getDimension(index2, eVar.n);
                        break;
                    case 45:
                        e eVar2 = aVar.f1427e;
                        eVar2.f1467c = obtainStyledAttributes.getFloat(index2, eVar2.f1467c);
                        break;
                    case 46:
                        e eVar3 = aVar.f1427e;
                        eVar3.f1468d = obtainStyledAttributes.getFloat(index2, eVar3.f1468d);
                        break;
                    case 47:
                        e eVar4 = aVar.f1427e;
                        eVar4.f1469e = obtainStyledAttributes.getFloat(index2, eVar4.f1469e);
                        break;
                    case 48:
                        e eVar5 = aVar.f1427e;
                        eVar5.f1470f = obtainStyledAttributes.getFloat(index2, eVar5.f1470f);
                        break;
                    case 49:
                        e eVar6 = aVar.f1427e;
                        eVar6.f1471g = obtainStyledAttributes.getDimension(index2, eVar6.f1471g);
                        break;
                    case 50:
                        e eVar7 = aVar.f1427e;
                        eVar7.f1472h = obtainStyledAttributes.getDimension(index2, eVar7.f1472h);
                        break;
                    case 51:
                        e eVar8 = aVar.f1427e;
                        eVar8.f1474j = obtainStyledAttributes.getDimension(index2, eVar8.f1474j);
                        break;
                    case 52:
                        e eVar9 = aVar.f1427e;
                        eVar9.k = obtainStyledAttributes.getDimension(index2, eVar9.k);
                        break;
                    case 53:
                        e eVar10 = aVar.f1427e;
                        eVar10.l = obtainStyledAttributes.getDimension(index2, eVar10.l);
                        break;
                    case 54:
                        b bVar40 = aVar.f1426d;
                        bVar40.Y = obtainStyledAttributes.getInt(index2, bVar40.Y);
                        break;
                    case 55:
                        b bVar41 = aVar.f1426d;
                        bVar41.Z = obtainStyledAttributes.getInt(index2, bVar41.Z);
                        break;
                    case 56:
                        b bVar42 = aVar.f1426d;
                        bVar42.a0 = obtainStyledAttributes.getDimensionPixelSize(index2, bVar42.a0);
                        break;
                    case 57:
                        b bVar43 = aVar.f1426d;
                        bVar43.b0 = obtainStyledAttributes.getDimensionPixelSize(index2, bVar43.b0);
                        break;
                    case 58:
                        b bVar44 = aVar.f1426d;
                        bVar44.c0 = obtainStyledAttributes.getDimensionPixelSize(index2, bVar44.c0);
                        break;
                    case 59:
                        b bVar45 = aVar.f1426d;
                        bVar45.d0 = obtainStyledAttributes.getDimensionPixelSize(index2, bVar45.d0);
                        break;
                    case 60:
                        e eVar11 = aVar.f1427e;
                        eVar11.f1466b = obtainStyledAttributes.getFloat(index2, eVar11.f1466b);
                        break;
                    case 61:
                        b bVar46 = aVar.f1426d;
                        int resourceId17 = obtainStyledAttributes.getResourceId(index2, bVar46.A);
                        if (resourceId17 == -1) {
                            resourceId17 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar46.A = resourceId17;
                        break;
                    case 62:
                        b bVar47 = aVar.f1426d;
                        bVar47.B = obtainStyledAttributes.getDimensionPixelSize(index2, bVar47.B);
                        break;
                    case 63:
                        b bVar48 = aVar.f1426d;
                        bVar48.C = obtainStyledAttributes.getFloat(index2, bVar48.C);
                        break;
                    case 64:
                        c cVar3 = aVar.f1425c;
                        int resourceId18 = obtainStyledAttributes.getResourceId(index2, cVar3.f1451b);
                        if (resourceId18 == -1) {
                            resourceId18 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        cVar3.f1451b = resourceId18;
                        break;
                    case 65:
                        if (obtainStyledAttributes.peekValue(index2).type == 3) {
                            aVar.f1425c.f1453d = obtainStyledAttributes.getString(index2);
                            break;
                        } else {
                            aVar.f1425c.f1453d = strArr[obtainStyledAttributes.getInteger(index2, 0)];
                            break;
                        }
                    case 66:
                        aVar.f1425c.f1455f = obtainStyledAttributes.getInt(index2, 0);
                        break;
                    case 67:
                        c cVar4 = aVar.f1425c;
                        cVar4.f1458i = obtainStyledAttributes.getFloat(index2, cVar4.f1458i);
                        break;
                    case 68:
                        C0025d c0025d4 = aVar.f1424b;
                        c0025d4.f1464e = obtainStyledAttributes.getFloat(index2, c0025d4.f1464e);
                        break;
                    case 69:
                        aVar.f1426d.e0 = obtainStyledAttributes.getFloat(index2, 1.0f);
                        break;
                    case 70:
                        aVar.f1426d.f0 = obtainStyledAttributes.getFloat(index2, 1.0f);
                        break;
                    case 71:
                        Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                        break;
                    case 72:
                        b bVar49 = aVar.f1426d;
                        bVar49.g0 = obtainStyledAttributes.getInt(index2, bVar49.g0);
                        break;
                    case 73:
                        b bVar50 = aVar.f1426d;
                        bVar50.h0 = obtainStyledAttributes.getDimensionPixelSize(index2, bVar50.h0);
                        break;
                    case 74:
                        aVar.f1426d.k0 = obtainStyledAttributes.getString(index2);
                        break;
                    case 75:
                        b bVar51 = aVar.f1426d;
                        bVar51.o0 = obtainStyledAttributes.getBoolean(index2, bVar51.o0);
                        break;
                    case 76:
                        c cVar5 = aVar.f1425c;
                        cVar5.f1454e = obtainStyledAttributes.getInt(index2, cVar5.f1454e);
                        break;
                    case 77:
                        aVar.f1426d.l0 = obtainStyledAttributes.getString(index2);
                        break;
                    case 78:
                        C0025d c0025d5 = aVar.f1424b;
                        c0025d5.f1462c = obtainStyledAttributes.getInt(index2, c0025d5.f1462c);
                        break;
                    case 79:
                        c cVar6 = aVar.f1425c;
                        cVar6.f1456g = obtainStyledAttributes.getFloat(index2, cVar6.f1456g);
                        break;
                    case 80:
                        b bVar52 = aVar.f1426d;
                        bVar52.m0 = obtainStyledAttributes.getBoolean(index2, bVar52.m0);
                        break;
                    case 81:
                        b bVar53 = aVar.f1426d;
                        bVar53.n0 = obtainStyledAttributes.getBoolean(index2, bVar53.n0);
                        break;
                    case 82:
                        c cVar7 = aVar.f1425c;
                        cVar7.f1452c = obtainStyledAttributes.getInteger(index2, cVar7.f1452c);
                        break;
                    case 83:
                        e eVar12 = aVar.f1427e;
                        int resourceId19 = obtainStyledAttributes.getResourceId(index2, eVar12.f1473i);
                        if (resourceId19 == -1) {
                            resourceId19 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        eVar12.f1473i = resourceId19;
                        break;
                    case 84:
                        c cVar8 = aVar.f1425c;
                        cVar8.k = obtainStyledAttributes.getInteger(index2, cVar8.k);
                        break;
                    case 85:
                        c cVar9 = aVar.f1425c;
                        cVar9.f1459j = obtainStyledAttributes.getFloat(index2, cVar9.f1459j);
                        break;
                    case 86:
                        int i6 = obtainStyledAttributes.peekValue(index2).type;
                        if (i6 == 1) {
                            aVar.f1425c.n = obtainStyledAttributes.getResourceId(index2, -1);
                            c cVar10 = aVar.f1425c;
                            if (cVar10.n != -1) {
                                cVar10.m = -2;
                                break;
                            } else {
                                break;
                            }
                        } else if (i6 == 3) {
                            aVar.f1425c.l = obtainStyledAttributes.getString(index2);
                            if (aVar.f1425c.l.indexOf("/") > 0) {
                                aVar.f1425c.n = obtainStyledAttributes.getResourceId(index2, -1);
                                aVar.f1425c.m = -2;
                                break;
                            } else {
                                aVar.f1425c.m = -1;
                                break;
                            }
                        } else {
                            c cVar11 = aVar.f1425c;
                            cVar11.m = obtainStyledAttributes.getInteger(index2, cVar11.n);
                            break;
                        }
                    case 87:
                        StringBuilder n3 = c.a.a.a.a.n("unused attribute 0x");
                        n3.append(Integer.toHexString(index2));
                        n3.append("   ");
                        n3.append(f1418e.get(index2));
                        Log.w("ConstraintSet", n3.toString());
                        break;
                    case 88:
                    case 89:
                    case 90:
                    default:
                        StringBuilder n4 = c.a.a.a.a.n("Unknown attribute 0x");
                        n4.append(Integer.toHexString(index2));
                        n4.append("   ");
                        n4.append(f1418e.get(index2));
                        Log.w("ConstraintSet", n4.toString());
                        break;
                    case 91:
                        b bVar54 = aVar.f1426d;
                        int resourceId20 = obtainStyledAttributes.getResourceId(index2, bVar54.r);
                        if (resourceId20 == -1) {
                            resourceId20 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar54.r = resourceId20;
                        break;
                    case 92:
                        b bVar55 = aVar.f1426d;
                        int resourceId21 = obtainStyledAttributes.getResourceId(index2, bVar55.s);
                        if (resourceId21 == -1) {
                            resourceId21 = obtainStyledAttributes.getInt(index2, -1);
                        }
                        bVar55.s = resourceId21;
                        break;
                    case 93:
                        b bVar56 = aVar.f1426d;
                        bVar56.M = obtainStyledAttributes.getDimensionPixelSize(index2, bVar56.M);
                        break;
                    case 94:
                        b bVar57 = aVar.f1426d;
                        bVar57.T = obtainStyledAttributes.getDimensionPixelSize(index2, bVar57.T);
                        break;
                    case 95:
                        g(aVar.f1426d, obtainStyledAttributes, index2, 0);
                        break;
                    case 96:
                        g(aVar.f1426d, obtainStyledAttributes, index2, 1);
                        break;
                    case 97:
                        b bVar58 = aVar.f1426d;
                        bVar58.p0 = obtainStyledAttributes.getInt(index2, bVar58.p0);
                        break;
                }
            }
            b bVar59 = aVar.f1426d;
            if (bVar59.k0 != null) {
                bVar59.j0 = null;
            }
        }
        obtainStyledAttributes.recycle();
        return aVar;
    }

    public void f(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    a e2 = e(context, Xml.asAttributeSet(xml), false);
                    if (name.equalsIgnoreCase("Guideline")) {
                        e2.f1426d.f1440a = true;
                    }
                    this.f1422c.put(Integer.valueOf(e2.f1423a), e2);
                }
            }
        } catch (IOException e3) {
            e3.printStackTrace();
        } catch (XmlPullParserException e4) {
            e4.printStackTrace();
        }
    }
}
