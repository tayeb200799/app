package b.f.c;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import androidx.constraintlayout.widget.ConstraintLayout;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\k.smali */
public abstract class k extends b {
    public boolean l;
    public boolean m;

    @Override // b.f.c.b
    public void g(ConstraintLayout constraintLayout) {
        f(constraintLayout);
    }

    @Override // b.f.c.b
    public void i(AttributeSet attributeSet) {
        super.i(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1477b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 6) {
                    this.l = true;
                } else if (index == 22) {
                    this.m = true;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void o() {
    }

    @Override // b.f.c.b, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.l || this.m) {
            ViewParent parent = getParent();
            if (parent instanceof ConstraintLayout) {
                ConstraintLayout constraintLayout = (ConstraintLayout) parent;
                int visibility = getVisibility();
                float elevation = getElevation();
                for (int i2 = 0; i2 < this.f1393e; i2++) {
                    View d2 = constraintLayout.d(this.f1392d[i2]);
                    if (d2 != null) {
                        if (this.l) {
                            d2.setVisibility(visibility);
                        }
                        if (this.m && elevation > 0.0f) {
                            d2.setTranslationZ(d2.getTranslationZ() + elevation);
                        }
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        f((ConstraintLayout) parent);
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        f((ConstraintLayout) parent);
    }
}
