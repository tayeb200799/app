package b.f.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\c.smali */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public final ConstraintLayout f1402a;

    /* renamed from: b, reason: collision with root package name */
    public int f1403b = -1;

    /* renamed from: c, reason: collision with root package name */
    public int f1404c = -1;

    /* renamed from: d, reason: collision with root package name */
    public SparseArray<a> f1405d = new SparseArray<>();

    /* renamed from: e, reason: collision with root package name */
    public SparseArray<d> f1406e = new SparseArray<>();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\c$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public int f1407a;

        /* renamed from: b, reason: collision with root package name */
        public ArrayList<b> f1408b = new ArrayList<>();

        /* renamed from: c, reason: collision with root package name */
        public int f1409c;

        /* renamed from: d, reason: collision with root package name */
        public d f1410d;

        public a(Context context, XmlPullParser xmlPullParser) {
            this.f1409c = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), i.f1488j);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 0) {
                    this.f1407a = obtainStyledAttributes.getResourceId(index, this.f1407a);
                } else if (index == 1) {
                    this.f1409c = obtainStyledAttributes.getResourceId(index, this.f1409c);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1409c);
                    context.getResources().getResourceName(this.f1409c);
                    if ("layout".equals(resourceTypeName)) {
                        d dVar = new d();
                        this.f1410d = dVar;
                        dVar.c((ConstraintLayout) LayoutInflater.from(context).inflate(this.f1409c, (ViewGroup) null));
                    }
                }
            }
            obtainStyledAttributes.recycle();
        }

        public int a(float f2, float f3) {
            for (int i2 = 0; i2 < this.f1408b.size(); i2++) {
                if (this.f1408b.get(i2).a(f2, f3)) {
                    return i2;
                }
            }
            return -1;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\c$b.smali */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public float f1411a;

        /* renamed from: b, reason: collision with root package name */
        public float f1412b;

        /* renamed from: c, reason: collision with root package name */
        public float f1413c;

        /* renamed from: d, reason: collision with root package name */
        public float f1414d;

        /* renamed from: e, reason: collision with root package name */
        public int f1415e;

        /* renamed from: f, reason: collision with root package name */
        public d f1416f;

        public b(Context context, XmlPullParser xmlPullParser) {
            this.f1411a = Float.NaN;
            this.f1412b = Float.NaN;
            this.f1413c = Float.NaN;
            this.f1414d = Float.NaN;
            this.f1415e = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), i.l);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 0) {
                    this.f1415e = obtainStyledAttributes.getResourceId(index, this.f1415e);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1415e);
                    context.getResources().getResourceName(this.f1415e);
                    if ("layout".equals(resourceTypeName)) {
                        d dVar = new d();
                        this.f1416f = dVar;
                        dVar.c((ConstraintLayout) LayoutInflater.from(context).inflate(this.f1415e, (ViewGroup) null));
                    }
                } else if (index == 1) {
                    this.f1414d = obtainStyledAttributes.getDimension(index, this.f1414d);
                } else if (index == 2) {
                    this.f1412b = obtainStyledAttributes.getDimension(index, this.f1412b);
                } else if (index == 3) {
                    this.f1413c = obtainStyledAttributes.getDimension(index, this.f1413c);
                } else if (index == 4) {
                    this.f1411a = obtainStyledAttributes.getDimension(index, this.f1411a);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            obtainStyledAttributes.recycle();
        }

        public boolean a(float f2, float f3) {
            if (!Float.isNaN(this.f1411a) && f2 < this.f1411a) {
                return false;
            }
            if (!Float.isNaN(this.f1412b) && f3 < this.f1412b) {
                return false;
            }
            if (Float.isNaN(this.f1413c) || f2 <= this.f1413c) {
                return Float.isNaN(this.f1414d) || f3 <= this.f1414d;
            }
            return false;
        }
    }

    public c(Context context, ConstraintLayout constraintLayout, int i2) {
        this.f1402a = constraintLayout;
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            int eventType = xml.getEventType();
            a aVar = null;
            while (true) {
                char c2 = 1;
                if (eventType == 1) {
                    return;
                }
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    switch (name.hashCode()) {
                        case -1349929691:
                            if (name.equals("ConstraintSet")) {
                                c2 = 4;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 80204913:
                            if (name.equals("State")) {
                                c2 = 2;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 1382829617:
                            if (name.equals("StateSet")) {
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 1657696882:
                            if (name.equals("layoutDescription")) {
                                c2 = 0;
                                break;
                            }
                            c2 = 65535;
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                c2 = 3;
                                break;
                            }
                            c2 = 65535;
                            break;
                        default:
                            c2 = 65535;
                            break;
                    }
                    if (c2 == 2) {
                        a aVar2 = new a(context, xml);
                        this.f1405d.put(aVar2.f1407a, aVar2);
                        aVar = aVar2;
                    } else if (c2 == 3) {
                        b bVar = new b(context, xml);
                        if (aVar != null) {
                            aVar.f1408b.add(bVar);
                        }
                    } else if (c2 == 4) {
                        a(context, xml);
                    }
                }
                eventType = xml.next();
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:97:0x0228, code lost:
    
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(android.content.Context r12, org.xmlpull.v1.XmlPullParser r13) {
        /*
            Method dump skipped, instructions count: 662
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.c.c.a(android.content.Context, org.xmlpull.v1.XmlPullParser):void");
    }
}
