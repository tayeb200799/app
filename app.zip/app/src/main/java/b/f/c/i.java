package b.g.b;

import b.e.h;
import b.h.j.d;
import b.h.j.e;
import java.util.ArrayList;
import java.util.HashSet;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\g\b\a.smali */
public final class a<T> {

    /* renamed from: a, reason: collision with root package name */
    public final d<ArrayList<T>> f1488a = new e(10);

    /* renamed from: b, reason: collision with root package name */
    public final h<T, ArrayList<T>> f1489b = new h<>();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList<T> f1490c = new ArrayList<>();

    /* renamed from: d, reason: collision with root package name */
    public final HashSet<T> f1491d = new HashSet<>();

    public void a(T t) {
        if (this.f1489b.e(t) >= 0) {
            return;
        }
        this.f1489b.put(t, null);
    }

    public final void b(T t, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (arrayList.contains(t)) {
            return;
        }
        if (hashSet.contains(t)) {
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
        hashSet.add(t);
        ArrayList<T> orDefault = this.f1489b.getOrDefault(t, null);
        if (orDefault != null) {
            int size = orDefault.size();
            for (int i2 = 0; i2 < size; i2++) {
                b(orDefault.get(i2), arrayList, hashSet);
            }
        }
        hashSet.remove(t);
        arrayList.add(t);
    }
}
