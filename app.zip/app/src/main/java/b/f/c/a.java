package b.f.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\a.smali */
public class a {

    /* renamed from: a, reason: collision with root package name */
    public boolean f1380a;

    /* renamed from: b, reason: collision with root package name */
    public String f1381b;

    /* renamed from: c, reason: collision with root package name */
    public EnumC0023a f1382c;

    /* renamed from: d, reason: collision with root package name */
    public int f1383d;

    /* renamed from: e, reason: collision with root package name */
    public float f1384e;

    /* renamed from: f, reason: collision with root package name */
    public String f1385f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1386g;

    /* renamed from: h, reason: collision with root package name */
    public int f1387h;

    /* renamed from: b.f.c.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\a$a.smali */
    public enum EnumC0023a {
        INT_TYPE,
        FLOAT_TYPE,
        COLOR_TYPE,
        COLOR_DRAWABLE_TYPE,
        STRING_TYPE,
        BOOLEAN_TYPE,
        DIMENSION_TYPE,
        REFERENCE_TYPE
    }

    public a(a aVar, Object obj) {
        this.f1380a = false;
        this.f1381b = aVar.f1381b;
        this.f1382c = aVar.f1382c;
        c(obj);
    }

    public a(String str, EnumC0023a enumC0023a, Object obj, boolean z) {
        this.f1380a = false;
        this.f1381b = str;
        this.f1382c = enumC0023a;
        this.f1380a = z;
        c(obj);
    }

    public static void a(Context context, XmlPullParser xmlPullParser, HashMap<String, a> hashMap) {
        EnumC0023a enumC0023a;
        Object valueOf;
        EnumC0023a enumC0023a2 = EnumC0023a.DIMENSION_TYPE;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), i.f1483e);
        int indexCount = obtainStyledAttributes.getIndexCount();
        String str = null;
        Object obj = null;
        EnumC0023a enumC0023a3 = null;
        boolean z = false;
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = obtainStyledAttributes.getIndex(i2);
            if (index == 0) {
                str = obtainStyledAttributes.getString(index);
                if (str != null && str.length() > 0) {
                    str = Character.toUpperCase(str.charAt(0)) + str.substring(1);
                }
            } else if (index == 10) {
                str = obtainStyledAttributes.getString(index);
                z = true;
            } else if (index == 1) {
                obj = Boolean.valueOf(obtainStyledAttributes.getBoolean(index, false));
                enumC0023a3 = EnumC0023a.BOOLEAN_TYPE;
            } else {
                if (index == 3) {
                    enumC0023a = EnumC0023a.COLOR_TYPE;
                    valueOf = Integer.valueOf(obtainStyledAttributes.getColor(index, 0));
                } else if (index == 2) {
                    enumC0023a = EnumC0023a.COLOR_DRAWABLE_TYPE;
                    valueOf = Integer.valueOf(obtainStyledAttributes.getColor(index, 0));
                } else {
                    if (index == 7) {
                        obj = Float.valueOf(TypedValue.applyDimension(1, obtainStyledAttributes.getDimension(index, 0.0f), context.getResources().getDisplayMetrics()));
                    } else if (index == 4) {
                        obj = Float.valueOf(obtainStyledAttributes.getDimension(index, 0.0f));
                    } else if (index == 5) {
                        enumC0023a = EnumC0023a.FLOAT_TYPE;
                        valueOf = Float.valueOf(obtainStyledAttributes.getFloat(index, Float.NaN));
                    } else if (index == 6) {
                        enumC0023a = EnumC0023a.INT_TYPE;
                        valueOf = Integer.valueOf(obtainStyledAttributes.getInteger(index, -1));
                    } else if (index == 9) {
                        enumC0023a = EnumC0023a.STRING_TYPE;
                        valueOf = obtainStyledAttributes.getString(index);
                    } else if (index == 8) {
                        enumC0023a = EnumC0023a.REFERENCE_TYPE;
                        int resourceId = obtainStyledAttributes.getResourceId(index, -1);
                        if (resourceId == -1) {
                            resourceId = obtainStyledAttributes.getInt(index, -1);
                        }
                        valueOf = Integer.valueOf(resourceId);
                    }
                    enumC0023a3 = enumC0023a2;
                }
                Object obj2 = valueOf;
                enumC0023a3 = enumC0023a;
                obj = obj2;
            }
        }
        if (str != null && obj != null) {
            hashMap.put(str, new a(str, enumC0023a3, obj, z));
        }
        obtainStyledAttributes.recycle();
    }

    public static void b(View view, HashMap<String, a> hashMap) {
        Class<?> cls = view.getClass();
        for (String str : hashMap.keySet()) {
            a aVar = hashMap.get(str);
            String f2 = !aVar.f1380a ? c.a.a.a.a.f("set", str) : str;
            try {
                switch (aVar.f1382c.ordinal()) {
                    case 0:
                        cls.getMethod(f2, Integer.TYPE).invoke(view, Integer.valueOf(aVar.f1383d));
                        break;
                    case 1:
                        cls.getMethod(f2, Float.TYPE).invoke(view, Float.valueOf(aVar.f1384e));
                        break;
                    case 2:
                        cls.getMethod(f2, Integer.TYPE).invoke(view, Integer.valueOf(aVar.f1387h));
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        Method method = cls.getMethod(f2, Drawable.class);
                        ColorDrawable colorDrawable = new ColorDrawable();
                        colorDrawable.setColor(aVar.f1387h);
                        method.invoke(view, colorDrawable);
                        break;
                    case 4:
                        cls.getMethod(f2, CharSequence.class).invoke(view, aVar.f1385f);
                        break;
                    case 5:
                        cls.getMethod(f2, Boolean.TYPE).invoke(view, Boolean.valueOf(aVar.f1386g));
                        break;
                    case 6:
                        cls.getMethod(f2, Float.TYPE).invoke(view, Float.valueOf(aVar.f1384e));
                        break;
                    case 7:
                        cls.getMethod(f2, Integer.TYPE).invoke(view, Integer.valueOf(aVar.f1383d));
                        break;
                }
            } catch (IllegalAccessException e2) {
                Log.e("TransitionLayout", " Custom Attribute \"" + str + "\" not found on " + cls.getName());
                e2.printStackTrace();
            } catch (NoSuchMethodException e3) {
                Log.e("TransitionLayout", e3.getMessage());
                Log.e("TransitionLayout", " Custom Attribute \"" + str + "\" not found on " + cls.getName());
                StringBuilder sb = new StringBuilder();
                sb.append(cls.getName());
                sb.append(" must have a method ");
                sb.append(f2);
                Log.e("TransitionLayout", sb.toString());
            } catch (InvocationTargetException e4) {
                Log.e("TransitionLayout", " Custom Attribute \"" + str + "\" not found on " + cls.getName());
                e4.printStackTrace();
            }
        }
    }

    public void c(Object obj) {
        switch (this.f1382c.ordinal()) {
            case 0:
            case 7:
                this.f1383d = ((Integer) obj).intValue();
                break;
            case 1:
                this.f1384e = ((Float) obj).floatValue();
                break;
            case 2:
            case ModuleDescriptor.MODULE_VERSION /* 3 */:
                this.f1387h = ((Integer) obj).intValue();
                break;
            case 4:
                this.f1385f = (String) obj;
                break;
            case 5:
                this.f1386g = ((Boolean) obj).booleanValue();
                break;
            case 6:
                this.f1384e = ((Float) obj).floatValue();
                break;
        }
    }
}
