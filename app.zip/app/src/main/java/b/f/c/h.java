package b.g;

import android.R;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\g\a.smali */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f1486a = {2130969082, 2130969419};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f1487b = {R.attr.layout_gravity, 2130969091, 2130969092, 2130969093, 2130969142, 2130969152, 2130969153};
}
