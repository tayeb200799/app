package b.f.b.a;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import b.f.b.a.c;
import b.f.c.i;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\b\a\b.smali */
public class b extends b.f.c.b implements c.InterfaceC0022c {
    public boolean l;
    public boolean m;
    public float n;
    public View[] o;

    @Override // b.f.b.a.c.InterfaceC0022c
    public void a(c cVar, int i2, int i3, float f2) {
    }

    @Override // b.f.b.a.c.InterfaceC0022c
    public void b(c cVar, int i2, int i3) {
    }

    public float getProgress() {
        return this.n;
    }

    @Override // b.f.c.b
    public void i(AttributeSet attributeSet) {
        super.i(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1486h);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 1) {
                    this.l = obtainStyledAttributes.getBoolean(index, this.l);
                } else if (index == 0) {
                    this.m = obtainStyledAttributes.getBoolean(index, this.m);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void o() {
    }

    public void setProgress(float f2) {
        this.n = f2;
        int i2 = 0;
        if (this.f1396e <= 0) {
            ViewGroup viewGroup = (ViewGroup) getParent();
            int childCount = viewGroup.getChildCount();
            while (i2 < childCount) {
                if (!(viewGroup.getChildAt(i2) instanceof b)) {
                    o();
                }
                i2++;
            }
            return;
        }
        ConstraintLayout constraintLayout = (ConstraintLayout) getParent();
        View[] viewArr = this.f1401j;
        if (viewArr == null || viewArr.length != this.f1396e) {
            this.f1401j = new View[this.f1396e];
        }
        for (int i3 = 0; i3 < this.f1396e; i3++) {
            this.f1401j[i3] = constraintLayout.d(this.f1395d[i3]);
        }
        this.o = this.f1401j;
        while (i2 < this.f1396e) {
            View view = this.o[i2];
            o();
            i2++;
        }
    }
}
