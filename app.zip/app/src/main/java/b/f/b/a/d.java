package b.f.c;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Arrays;
import java.util.HashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\f\c\b.smali */
public abstract class b extends View {

    /* renamed from: d, reason: collision with root package name */
    public int[] f1392d;

    /* renamed from: e, reason: collision with root package name */
    public int f1393e;

    /* renamed from: f, reason: collision with root package name */
    public Context f1394f;

    /* renamed from: g, reason: collision with root package name */
    public b.f.a.i.g f1395g;

    /* renamed from: h, reason: collision with root package name */
    public String f1396h;

    /* renamed from: i, reason: collision with root package name */
    public String f1397i;

    /* renamed from: j, reason: collision with root package name */
    public View[] f1398j;
    public HashMap<Integer, String> k;

    public b(Context context) {
        super(context);
        this.f1392d = new int[32];
        this.f1398j = null;
        this.k = new HashMap<>();
        this.f1394f = context;
        i(null);
    }

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1392d = new int[32];
        this.f1398j = null;
        this.k = new HashMap<>();
        this.f1394f = context;
        i(attributeSet);
    }

    public final void c(String str) {
        if (str == null || str.length() == 0 || this.f1394f == null) {
            return;
        }
        String trim = str.trim();
        if (getParent() instanceof ConstraintLayout) {
        }
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int i2 = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object c2 = constraintLayout.c(0, trim);
            if (c2 instanceof Integer) {
                i2 = ((Integer) c2).intValue();
            }
        }
        if (i2 == 0 && constraintLayout != null) {
            i2 = h(constraintLayout, trim);
        }
        if (i2 == 0) {
            try {
                i2 = h.class.getField(trim).getInt(null);
            } catch (Exception unused) {
            }
        }
        if (i2 == 0) {
            i2 = this.f1394f.getResources().getIdentifier(trim, "id", this.f1394f.getPackageName());
        }
        if (i2 != 0) {
            this.k.put(Integer.valueOf(i2), trim);
            d(i2);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
    }

    public final void d(int i2) {
        if (i2 == getId()) {
            return;
        }
        int i3 = this.f1393e + 1;
        int[] iArr = this.f1392d;
        if (i3 > iArr.length) {
            this.f1392d = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f1392d;
        int i4 = this.f1393e;
        iArr2[i4] = i2;
        this.f1393e = i4 + 1;
    }

    public final void e(String str) {
        if (str == null || str.length() == 0 || this.f1394f == null) {
            return;
        }
        String trim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.a) && trim.equals(((ConstraintLayout.a) layoutParams).Y)) {
                if (childAt.getId() == -1) {
                    StringBuilder n = c.a.a.a.a.n("to use ConstraintTag view ");
                    n.append(childAt.getClass().getSimpleName());
                    n.append(" must have an ID");
                    Log.w("ConstraintHelper", n.toString());
                } else {
                    d(childAt.getId());
                }
            }
        }
    }

    public void f(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i2 = 0; i2 < this.f1393e; i2++) {
            View d2 = constraintLayout.d(this.f1392d[i2]);
            if (d2 != null) {
                d2.setVisibility(visibility);
                if (elevation > 0.0f) {
                    d2.setTranslationZ(d2.getTranslationZ() + elevation);
                }
            }
        }
    }

    public void g(ConstraintLayout constraintLayout) {
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f1392d, this.f1393e);
    }

    public final int h(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        if (str == null || constraintLayout == null || (resources = this.f1394f.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            if (childAt.getId() != -1) {
                String str2 = null;
                try {
                    str2 = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                }
                if (str.equals(str2)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    public void i(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1477b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 35) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1396h = string;
                    setIds(string);
                } else if (index == 36) {
                    String string2 = obtainStyledAttributes.getString(index);
                    this.f1397i = string2;
                    setReferenceTags(string2);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void j(b.f.a.i.d dVar, boolean z) {
    }

    public void k() {
    }

    public void l() {
    }

    public void m() {
    }

    public void n() {
        if (this.f1395g == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.a) {
            ((ConstraintLayout.a) layoutParams).q0 = (b.f.a.i.d) this.f1395g;
        }
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1396h;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f1397i;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        setMeasuredDimension(0, 0);
    }

    public void setIds(String str) {
        this.f1396h = str;
        if (str == null) {
            return;
        }
        int i2 = 0;
        this.f1393e = 0;
        while (true) {
            int indexOf = str.indexOf(44, i2);
            if (indexOf == -1) {
                c(str.substring(i2));
                return;
            } else {
                c(str.substring(i2, indexOf));
                i2 = indexOf + 1;
            }
        }
    }

    public void setReferenceTags(String str) {
        this.f1397i = str;
        if (str == null) {
            return;
        }
        int i2 = 0;
        this.f1393e = 0;
        while (true) {
            int indexOf = str.indexOf(44, i2);
            if (indexOf == -1) {
                e(str.substring(i2));
                return;
            } else {
                e(str.substring(i2, indexOf));
                i2 = indexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f1396h = null;
        this.f1393e = 0;
        for (int i2 : iArr) {
            d(i2);
        }
    }

    @Override // android.view.View
    public void setTag(int i2, Object obj) {
        super.setTag(i2, obj);
        if (obj == null && this.f1396h == null) {
            d(i2);
        }
    }
}
