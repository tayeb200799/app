package b.a0;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import java.lang.reflect.Method;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\a0\c.smali */
public class c extends b {

    /* renamed from: d, reason: collision with root package name */
    public final SparseIntArray f571d;

    /* renamed from: e, reason: collision with root package name */
    public final Parcel f572e;

    /* renamed from: f, reason: collision with root package name */
    public final int f573f;

    /* renamed from: g, reason: collision with root package name */
    public final int f574g;

    /* renamed from: h, reason: collision with root package name */
    public final String f575h;

    /* renamed from: i, reason: collision with root package name */
    public int f576i;

    /* renamed from: j, reason: collision with root package name */
    public int f577j;
    public int k;

    public c(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new b.e.a(), new b.e.a(), new b.e.a());
    }

    public c(Parcel parcel, int i2, int i3, String str, b.e.a<String, Method> aVar, b.e.a<String, Method> aVar2, b.e.a<String, Class> aVar3) {
        super(aVar, aVar2, aVar3);
        this.f571d = new SparseIntArray();
        this.f576i = -1;
        this.f577j = 0;
        this.k = -1;
        this.f572e = parcel;
        this.f573f = i2;
        this.f574g = i3;
        this.f577j = i2;
        this.f575h = str;
    }

    @Override // b.a0.b
    public void a() {
        int i2 = this.f576i;
        if (i2 >= 0) {
            int i3 = this.f571d.get(i2);
            int dataPosition = this.f572e.dataPosition();
            this.f572e.setDataPosition(i3);
            this.f572e.writeInt(dataPosition - i3);
            this.f572e.setDataPosition(dataPosition);
        }
    }

    @Override // b.a0.b
    public b b() {
        Parcel parcel = this.f572e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f577j;
        if (i2 == this.f573f) {
            i2 = this.f574g;
        }
        return new c(parcel, dataPosition, i2, this.f575h + "  ", this.f568a, this.f569b, this.f570c);
    }

    @Override // b.a0.b
    public boolean f() {
        return this.f572e.readInt() != 0;
    }

    @Override // b.a0.b
    public byte[] g() {
        int readInt = this.f572e.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f572e.readByteArray(bArr);
        return bArr;
    }

    @Override // b.a0.b
    public CharSequence h() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f572e);
    }

    @Override // b.a0.b
    public boolean i(int i2) {
        while (this.f577j < this.f574g) {
            int i3 = this.k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            this.f572e.setDataPosition(this.f577j);
            int readInt = this.f572e.readInt();
            this.k = this.f572e.readInt();
            this.f577j += readInt;
        }
        return this.k == i2;
    }

    @Override // b.a0.b
    public int j() {
        return this.f572e.readInt();
    }

    @Override // b.a0.b
    public <T extends Parcelable> T l() {
        return (T) this.f572e.readParcelable(c.class.getClassLoader());
    }

    @Override // b.a0.b
    public String n() {
        return this.f572e.readString();
    }

    @Override // b.a0.b
    public void p(int i2) {
        a();
        this.f576i = i2;
        this.f571d.put(i2, this.f572e.dataPosition());
        this.f572e.writeInt(0);
        this.f572e.writeInt(i2);
    }

    @Override // b.a0.b
    public void q(boolean z) {
        this.f572e.writeInt(z ? 1 : 0);
    }

    @Override // b.a0.b
    public void r(byte[] bArr) {
        if (bArr == null) {
            this.f572e.writeInt(-1);
        } else {
            this.f572e.writeInt(bArr.length);
            this.f572e.writeByteArray(bArr);
        }
    }

    @Override // b.a0.b
    public void s(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f572e, 0);
    }

    @Override // b.a0.b
    public void t(int i2) {
        this.f572e.writeInt(i2);
    }

    @Override // b.a0.b
    public void u(Parcelable parcelable) {
        this.f572e.writeParcelable(parcelable, 0);
    }

    @Override // b.a0.b
    public void v(String str) {
        this.f572e.writeString(str);
    }
}
