package b.n.c;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\j.smali */
public class j extends AnimationSet implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final ViewGroup f2017d;

    /* renamed from: e, reason: collision with root package name */
    public final View f2018e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2019f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2020g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f2021h;

    public j(Animation animation, ViewGroup viewGroup, View view) {
        super(false);
        this.f2021h = true;
        this.f2017d = viewGroup;
        this.f2018e = view;
        addAnimation(animation);
        viewGroup.post(this);
    }

    @Override // android.view.animation.AnimationSet, android.view.animation.Animation
    public boolean getTransformation(long j2, Transformation transformation) {
        this.f2021h = true;
        if (this.f2019f) {
            return !this.f2020g;
        }
        if (!super.getTransformation(j2, transformation)) {
            this.f2019f = true;
            b.h.k.k.a(this.f2017d, this);
        }
        return true;
    }

    @Override // android.view.animation.Animation
    public boolean getTransformation(long j2, Transformation transformation, float f2) {
        this.f2021h = true;
        if (this.f2019f) {
            return !this.f2020g;
        }
        if (!super.getTransformation(j2, transformation, f2)) {
            this.f2019f = true;
            b.h.k.k.a(this.f2017d, this);
        }
        return true;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.f2019f || !this.f2021h) {
            this.f2017d.endViewTransition(this.f2018e);
            this.f2020g = true;
        } else {
            this.f2021h = false;
            this.f2017d.post(this);
        }
    }
}
