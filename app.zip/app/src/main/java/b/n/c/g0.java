package b.n.c;

import android.view.View;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\i0.smali */
public class i0 {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f2005a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* renamed from: b, reason: collision with root package name */
    public static final n0 f2006b = new j0();

    /* renamed from: c, reason: collision with root package name */
    public static final n0 f2007c;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\i0$a.smali */
    public interface a {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\i0$b.smali */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public Fragment f2008a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f2009b;

        /* renamed from: c, reason: collision with root package name */
        public b.n.c.a f2010c;

        /* renamed from: d, reason: collision with root package name */
        public Fragment f2011d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f2012e;

        /* renamed from: f, reason: collision with root package name */
        public b.n.c.a f2013f;
    }

    static {
        n0 n0Var;
        try {
            n0Var = (n0) Class.forName("b.y.d").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            n0Var = null;
        }
        f2007c = n0Var;
    }

    public static void a(ArrayList<View> arrayList, b.e.a<String, View> aVar, Collection<String> collection) {
        for (int i2 = aVar.f1197f - 1; i2 >= 0; i2--) {
            View l = aVar.l(i2);
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            if (collection.contains(l.getTransitionName())) {
                arrayList.add(l);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:104:0x0088, code lost:
    
        if (r0.B == false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0038, code lost:
    
        if (r0.n != false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x008a, code lost:
    
        r9 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x0076, code lost:
    
        r9 = true;
     */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00ad A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00cd A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00d5  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00e6 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:60:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void b(b.n.c.a r8, b.n.c.b0.a r9, android.util.SparseArray<b.n.c.i0.b> r10, boolean r11, boolean r12) {
        /*
            Method dump skipped, instructions count: 241
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.n.c.i0.b(b.n.c.a, b.n.c.b0$a, android.util.SparseArray, boolean, boolean):void");
    }

    public static void c(Fragment fragment, Fragment fragment2, boolean z, b.e.a<String, View> aVar, boolean z2) {
        if (z) {
            fragment2.B();
        } else {
            fragment.B();
        }
    }

    public static boolean d(n0 n0Var, List<Object> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!n0Var.e(list.get(i2))) {
                return false;
            }
        }
        return true;
    }

    public static b.e.a<String, View> e(n0 n0Var, b.e.a<String, String> aVar, Object obj, b bVar) {
        ArrayList<String> arrayList;
        Fragment fragment = bVar.f2008a;
        View view = fragment.H;
        if (aVar.isEmpty() || obj == null || view == null) {
            aVar.clear();
            return null;
        }
        b.e.a<String, View> aVar2 = new b.e.a<>();
        n0Var.i(aVar2, view);
        b.n.c.a aVar3 = bVar.f2010c;
        if (bVar.f2009b) {
            arrayList = aVar3.m;
        } else {
            fragment.B();
            arrayList = aVar3.n;
        }
        if (arrayList != null) {
            b.e.g.k(aVar2, arrayList);
            b.e.g.k(aVar2, aVar.values());
        }
        int i2 = aVar.f1197f;
        while (true) {
            i2--;
            if (i2 < 0) {
                return aVar2;
            }
            if (!aVar2.containsKey(aVar.l(i2))) {
                aVar.j(i2);
            }
        }
    }

    public static b.e.a<String, View> f(n0 n0Var, b.e.a<String, String> aVar, Object obj, b bVar) {
        ArrayList<String> arrayList;
        if (aVar.isEmpty() || obj == null) {
            aVar.clear();
            return null;
        }
        Fragment fragment = bVar.f2011d;
        b.e.a<String, View> aVar2 = new b.e.a<>();
        n0Var.i(aVar2, fragment.r0());
        b.n.c.a aVar3 = bVar.f2013f;
        if (bVar.f2012e) {
            fragment.B();
            arrayList = aVar3.n;
        } else {
            arrayList = aVar3.m;
        }
        if (arrayList != null) {
            b.e.g.k(aVar2, arrayList);
        }
        b.e.g.k(aVar, aVar2.keySet());
        return aVar2;
    }

    public static n0 g(Fragment fragment, Fragment fragment2) {
        ArrayList arrayList = new ArrayList();
        if (fragment != null) {
            fragment.C();
            Object H = fragment.H();
            if (H != null) {
                arrayList.add(H);
            }
            Object J = fragment.J();
            if (J != null) {
                arrayList.add(J);
            }
        }
        if (fragment2 != null) {
            fragment2.A();
            Object F = fragment2.F();
            if (F != null) {
                arrayList.add(F);
            }
            fragment2.I();
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        n0 n0Var = f2006b;
        if (d(n0Var, arrayList)) {
            return n0Var;
        }
        n0 n0Var2 = f2007c;
        if (n0Var2 == null || !d(n0Var2, arrayList)) {
            throw new IllegalArgumentException("Invalid Transition types");
        }
        return n0Var2;
    }

    public static ArrayList<View> h(n0 n0Var, Object obj, Fragment fragment, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View view2 = fragment.H;
        if (view2 != null) {
            n0Var.f(arrayList2, view2);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        n0Var.b(obj, arrayList2);
        return arrayList2;
    }

    public static Object i(n0 n0Var, Fragment fragment, boolean z) {
        Object obj = null;
        if (fragment == null) {
            return null;
        }
        if (z) {
            obj = fragment.F();
        } else {
            fragment.A();
        }
        return n0Var.g(obj);
    }

    public static Object j(n0 n0Var, Fragment fragment, boolean z) {
        Object obj = null;
        if (fragment == null) {
            return null;
        }
        if (z) {
            obj = fragment.H();
        } else {
            fragment.C();
        }
        return n0Var.g(obj);
    }

    public static View k(b.e.a<String, View> aVar, b bVar, Object obj, boolean z) {
        ArrayList<String> arrayList;
        b.n.c.a aVar2 = bVar.f2010c;
        if (obj == null || aVar == null || (arrayList = aVar2.m) == null || arrayList.isEmpty()) {
            return null;
        }
        return aVar.get(z ? aVar2.m.get(0) : aVar2.n.get(0));
    }

    public static Object l(n0 n0Var, Fragment fragment, Fragment fragment2, boolean z) {
        Object obj;
        if (z) {
            obj = fragment2.J();
        } else {
            fragment.I();
            obj = null;
        }
        return n0Var.v(n0Var.g(obj));
    }

    public static void m(n0 n0Var, Object obj, Object obj2, b.e.a<String, View> aVar, boolean z, b.n.c.a aVar2) {
        ArrayList<String> arrayList = aVar2.m;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        View view = aVar.get(z ? aVar2.n.get(0) : aVar2.m.get(0));
        n0Var.r(obj, view);
        if (obj2 != null) {
            n0Var.r(obj2, view);
        }
    }

    public static void n(ArrayList<View> arrayList, int i2) {
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            arrayList.get(size).setVisibility(i2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:182:0x0441  */
    /* JADX WARN: Removed duplicated region for block: B:184:0x0482 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x023a  */
    /* JADX WARN: Type inference failed for: r13v4, types: [b.e.h] */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void o(b.n.c.r r38, java.util.ArrayList<b.n.c.a> r39, java.util.ArrayList<java.lang.Boolean> r40, int r41, int r42, boolean r43, b.n.c.i0.a r44) {
        /*
            Method dump skipped, instructions count: 1175
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.n.c.i0.o(b.n.c.r, java.util.ArrayList, java.util.ArrayList, int, int, boolean, b.n.c.i0$a):void");
    }
}
