package b.n.c;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b.p.g;
import java.util.ArrayList;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\z.smali */
public abstract class z extends b.b0.a.a {

    /* renamed from: c, reason: collision with root package name */
    public final r f2101c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2102d;

    /* renamed from: e, reason: collision with root package name */
    public b0 f2103e = null;

    /* renamed from: f, reason: collision with root package name */
    public ArrayList<Fragment.d> f2104f = new ArrayList<>();

    /* renamed from: g, reason: collision with root package name */
    public ArrayList<Fragment> f2105g = new ArrayList<>();

    /* renamed from: h, reason: collision with root package name */
    public Fragment f2106h = null;

    public z(r rVar, int i2) {
        this.f2101c = rVar;
        this.f2102d = i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    @Override // b.b0.a.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void c(android.view.ViewGroup r5, int r6, java.lang.Object r7) {
        /*
            r4 = this;
            androidx.fragment.app.Fragment r7 = (androidx.fragment.app.Fragment) r7
            b.n.c.b0 r5 = r4.f2103e
            if (r5 != 0) goto Lf
            b.n.c.r r5 = r4.f2101c
            b.n.c.a r0 = new b.n.c.a
            r0.<init>(r5)
            r4.f2103e = r0
        Lf:
            java.util.ArrayList<androidx.fragment.app.Fragment$d> r5 = r4.f2104f
            int r5 = r5.size()
            r0 = 0
            if (r5 > r6) goto L1e
            java.util.ArrayList<androidx.fragment.app.Fragment$d> r5 = r4.f2104f
            r5.add(r0)
            goto Lf
        L1e:
            java.util.ArrayList<androidx.fragment.app.Fragment$d> r5 = r4.f2104f
            boolean r1 = r7.O()
            if (r1 == 0) goto L62
            b.n.c.r r1 = r4.f2101c
            b.n.c.a0 r2 = r1.f2055c
            java.lang.String r3 = r7.f317h
            java.util.HashMap<java.lang.String, b.n.c.y> r2 = r2.f1932b
            java.lang.Object r2 = r2.get(r3)
            b.n.c.y r2 = (b.n.c.y) r2
            if (r2 == 0) goto L51
            androidx.fragment.app.Fragment r3 = r2.f2099b
            boolean r3 = r3.equals(r7)
            if (r3 == 0) goto L51
            androidx.fragment.app.Fragment r1 = r2.f2099b
            int r1 = r1.f313d
            r3 = -1
            if (r1 <= r3) goto L62
            android.os.Bundle r1 = r2.b()
            if (r1 == 0) goto L62
            androidx.fragment.app.Fragment$d r2 = new androidx.fragment.app.Fragment$d
            r2.<init>(r1)
            goto L63
        L51:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "Fragment "
            java.lang.String r2 = " is not currently in the FragmentManager"
            java.lang.String r6 = c.a.a.a.a.e(r6, r7, r2)
            r5.<init>(r6)
            r1.k0(r5)
            throw r0
        L62:
            r2 = r0
        L63:
            r5.set(r6, r2)
            java.util.ArrayList<androidx.fragment.app.Fragment> r5 = r4.f2105g
            r5.set(r6, r0)
            b.n.c.b0 r5 = r4.f2103e
            r5.f(r7)
            androidx.fragment.app.Fragment r5 = r4.f2106h
            boolean r5 = r7.equals(r5)
            if (r5 == 0) goto L7a
            r4.f2106h = r0
        L7a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.n.c.z.c(android.view.ViewGroup, int, java.lang.Object):void");
    }

    @Override // b.b0.a.a
    public void d(ViewGroup viewGroup) {
        b0 b0Var = this.f2103e;
        if (b0Var != null) {
            try {
                b0Var.d();
            } catch (IllegalStateException unused) {
                this.f2103e.c();
            }
            this.f2103e = null;
        }
    }

    @Override // b.b0.a.a
    public Object g(ViewGroup viewGroup, int i2) {
        Fragment.d dVar;
        Fragment fragment;
        if (this.f2105g.size() > i2 && (fragment = this.f2105g.get(i2)) != null) {
            return fragment;
        }
        if (this.f2103e == null) {
            this.f2103e = new a(this.f2101c);
        }
        Fragment n = n(i2);
        if (this.f2104f.size() > i2 && (dVar = this.f2104f.get(i2)) != null) {
            if (n.u != null) {
                throw new IllegalStateException("Fragment already added");
            }
            Bundle bundle = dVar.f331d;
            if (bundle == null) {
                bundle = null;
            }
            n.f314e = bundle;
        }
        while (this.f2105g.size() <= i2) {
            this.f2105g.add(null);
        }
        n.w0(false);
        if (this.f2102d == 0) {
            n.A0(false);
        }
        this.f2105g.set(i2, n);
        this.f2103e.e(viewGroup.getId(), n, null, 1);
        if (this.f2102d == 1) {
            this.f2103e.g(n, g.b.STARTED);
        }
        return n;
    }

    @Override // b.b0.a.a
    public boolean h(View view, Object obj) {
        return ((Fragment) obj).H == view;
    }

    @Override // b.b0.a.a
    public void j(Parcelable parcelable, ClassLoader classLoader) {
        Fragment e2;
        if (parcelable != null) {
            Bundle bundle = (Bundle) parcelable;
            bundle.setClassLoader(classLoader);
            Parcelable[] parcelableArray = bundle.getParcelableArray("states");
            this.f2104f.clear();
            this.f2105g.clear();
            if (parcelableArray != null) {
                for (Parcelable parcelable2 : parcelableArray) {
                    this.f2104f.add((Fragment.d) parcelable2);
                }
            }
            for (String str : bundle.keySet()) {
                if (str.startsWith("f")) {
                    int parseInt = Integer.parseInt(str.substring(1));
                    r rVar = this.f2101c;
                    Objects.requireNonNull(rVar);
                    String string = bundle.getString(str);
                    if (string == null) {
                        e2 = null;
                    } else {
                        e2 = rVar.f2055c.e(string);
                        if (e2 == null) {
                            rVar.k0(new IllegalStateException("Fragment no longer exists for key " + str + ": unique id " + string));
                            throw null;
                        }
                    }
                    if (e2 != null) {
                        while (this.f2105g.size() <= parseInt) {
                            this.f2105g.add(null);
                        }
                        e2.w0(false);
                        this.f2105g.set(parseInt, e2);
                    } else {
                        Log.w("FragmentStatePagerAdapt", "Bad fragment at key " + str);
                    }
                }
            }
        }
    }

    @Override // b.b0.a.a
    public Parcelable k() {
        Bundle bundle;
        if (this.f2104f.size() > 0) {
            bundle = new Bundle();
            Fragment.d[] dVarArr = new Fragment.d[this.f2104f.size()];
            this.f2104f.toArray(dVarArr);
            bundle.putParcelableArray("states", dVarArr);
        } else {
            bundle = null;
        }
        for (int i2 = 0; i2 < this.f2105g.size(); i2++) {
            Fragment fragment = this.f2105g.get(i2);
            if (fragment != null && fragment.O()) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                String c2 = c.a.a.a.a.c("f", i2);
                r rVar = this.f2101c;
                Objects.requireNonNull(rVar);
                if (fragment.u != rVar) {
                    rVar.k0(new IllegalStateException(c.a.a.a.a.e("Fragment ", fragment, " is not currently in the FragmentManager")));
                    throw null;
                }
                bundle.putString(c2, fragment.f317h);
            }
        }
        return bundle;
    }

    @Override // b.b0.a.a
    public void l(ViewGroup viewGroup, int i2, Object obj) {
        Fragment fragment = (Fragment) obj;
        Fragment fragment2 = this.f2106h;
        if (fragment != fragment2) {
            if (fragment2 != null) {
                fragment2.w0(false);
                if (this.f2102d == 1) {
                    if (this.f2103e == null) {
                        this.f2103e = new a(this.f2101c);
                    }
                    this.f2103e.g(this.f2106h, g.b.STARTED);
                } else {
                    this.f2106h.A0(false);
                }
            }
            fragment.w0(true);
            if (this.f2102d == 1) {
                if (this.f2103e == null) {
                    this.f2103e = new a(this.f2101c);
                }
                this.f2103e.g(fragment, g.b.RESUMED);
            } else {
                fragment.A0(true);
            }
            this.f2106h = fragment;
        }
    }

    @Override // b.b0.a.a
    public void m(ViewGroup viewGroup) {
        if (viewGroup.getId() != -1) {
            return;
        }
        throw new IllegalStateException("ViewPager with adapter " + this + " requires a view id");
    }

    public abstract Fragment n(int i2);
}
