package b.n.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b.n.c.i0;
import b.n.c.r;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\h.smali */
public final class h extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f1991a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f1992b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Fragment f1993c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ i0.a f1994d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ b.h.g.a f1995e;

    public h(ViewGroup viewGroup, View view, Fragment fragment, i0.a aVar, b.h.g.a aVar2) {
        this.f1991a = viewGroup;
        this.f1992b = view;
        this.f1993c = fragment;
        this.f1994d = aVar;
        this.f1995e = aVar2;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f1991a.endViewTransition(this.f1992b);
        Fragment fragment = this.f1993c;
        Fragment.a aVar = fragment.K;
        Animator animator2 = aVar == null ? null : aVar.f322b;
        fragment.t0(null);
        if (animator2 == null || this.f1991a.indexOfChild(this.f1992b) >= 0) {
            return;
        }
        ((r.b) this.f1994d).a(this.f1993c, this.f1995e);
    }
}
