package b.n.c;

import android.graphics.Rect;
import android.view.View;
import androidx.fragment.app.Fragment;
import b.n.c.i0;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\h0.smali */
public final class h0 implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ n0 f1996d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ b.e.a f1997e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1998f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ i0.b f1999g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ ArrayList f2000h;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ View f2001i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Fragment f2002j;
    public final /* synthetic */ Fragment k;
    public final /* synthetic */ boolean l;
    public final /* synthetic */ ArrayList m;
    public final /* synthetic */ Object n;
    public final /* synthetic */ Rect o;

    public h0(n0 n0Var, b.e.a aVar, Object obj, i0.b bVar, ArrayList arrayList, View view, Fragment fragment, Fragment fragment2, boolean z, ArrayList arrayList2, Object obj2, Rect rect) {
        this.f1996d = n0Var;
        this.f1997e = aVar;
        this.f1998f = obj;
        this.f1999g = bVar;
        this.f2000h = arrayList;
        this.f2001i = view;
        this.f2002j = fragment;
        this.k = fragment2;
        this.l = z;
        this.m = arrayList2;
        this.n = obj2;
        this.o = rect;
    }

    @Override // java.lang.Runnable
    public void run() {
        b.e.a<String, View> e2 = i0.e(this.f1996d, this.f1997e, this.f1998f, this.f1999g);
        if (e2 != null) {
            this.f2000h.addAll(e2.values());
            this.f2000h.add(this.f2001i);
        }
        i0.c(this.f2002j, this.k, this.l, e2, false);
        Object obj = this.f1998f;
        if (obj != null) {
            this.f1996d.u(obj, this.m, this.f2000h);
            View k = i0.k(e2, this.f1999g, this.n, this.l);
            if (k != null) {
                this.f1996d.j(k, this.o);
            }
        }
    }
}
