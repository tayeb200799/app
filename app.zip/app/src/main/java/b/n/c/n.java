package b.n.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\p.smali */
public class p implements LayoutInflater.Factory2 {

    /* renamed from: d, reason: collision with root package name */
    public final r f2050d;

    public p(r rVar) {
        this.f2050d = rVar;
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z;
        if (l.class.getName().equals(str)) {
            return new l(context, attributeSet, this.f2050d);
        }
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.n.b.f1929a);
        if (attributeValue == null) {
            attributeValue = obtainStyledAttributes.getString(0);
        }
        int resourceId = obtainStyledAttributes.getResourceId(1, -1);
        String string = obtainStyledAttributes.getString(2);
        obtainStyledAttributes.recycle();
        if (attributeValue != null) {
            ClassLoader classLoader = context.getClassLoader();
            b.e.h<String, Class<?>> hVar = n.f2044a;
            try {
                z = Fragment.class.isAssignableFrom(n.b(classLoader, attributeValue));
            } catch (ClassNotFoundException unused) {
                z = false;
            }
            if (z) {
                int id = view != null ? view.getId() : 0;
                if (id == -1 && resourceId == -1 && string == null) {
                    throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
                }
                Fragment F = resourceId != -1 ? this.f2050d.F(resourceId) : null;
                if (F == null && string != null) {
                    F = this.f2050d.G(string);
                }
                if (F == null && id != -1) {
                    F = this.f2050d.F(id);
                }
                if (r.M(2)) {
                    StringBuilder n = c.a.a.a.a.n("onCreateView: id=0x");
                    n.append(Integer.toHexString(resourceId));
                    n.append(" fname=");
                    n.append(attributeValue);
                    n.append(" existing=");
                    n.append(F);
                    Log.v("FragmentManager", n.toString());
                }
                if (F == null) {
                    F = this.f2050d.J().a(context.getClassLoader(), attributeValue);
                    F.p = true;
                    F.y = resourceId != 0 ? resourceId : id;
                    F.z = id;
                    F.A = string;
                    F.q = true;
                    r rVar = this.f2050d;
                    F.u = rVar;
                    o<?> oVar = rVar.n;
                    F.v = oVar;
                    Context context2 = oVar.f2046e;
                    F.c0(attributeSet, F.f314e);
                    this.f2050d.b(F);
                    r rVar2 = this.f2050d;
                    rVar2.T(F, rVar2.m);
                } else {
                    if (F.q) {
                        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
                    }
                    F.q = true;
                    o<?> oVar2 = this.f2050d.n;
                    F.v = oVar2;
                    Context context3 = oVar2.f2046e;
                    F.c0(attributeSet, F.f314e);
                }
                r rVar3 = this.f2050d;
                int i2 = rVar3.m;
                if (i2 >= 1 || !F.p) {
                    rVar3.T(F, i2);
                } else {
                    rVar3.T(F, 1);
                }
                View view2 = F.H;
                if (view2 == null) {
                    throw new IllegalStateException(c.a.a.a.a.g("Fragment ", attributeValue, " did not create a view."));
                }
                if (resourceId != 0) {
                    view2.setId(resourceId);
                }
                if (F.H.getTag() == null) {
                    F.H.setTag(string);
                }
                return F.H;
            }
        }
        return null;
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
