package b.n.c;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import androidx.fragment.app.Fragment;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\o.smali */
public abstract class o<E> extends k {

    /* renamed from: d, reason: collision with root package name */
    public final Activity f2045d;

    /* renamed from: e, reason: collision with root package name */
    public final Context f2046e;

    /* renamed from: f, reason: collision with root package name */
    public final Handler f2047f;

    /* renamed from: g, reason: collision with root package name */
    public final r f2048g;

    public o(e eVar) {
        Handler handler = new Handler();
        this.f2048g = new t();
        this.f2045d = eVar;
        b.h.a.g(eVar, "context == null");
        this.f2046e = eVar;
        b.h.a.g(handler, "handler == null");
        this.f2047f = handler;
    }

    public abstract void f(Fragment fragment);

    public abstract void g(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract E h();

    public abstract LayoutInflater i();

    public abstract void j(Fragment fragment, String[] strArr, int i2);

    public abstract boolean k(Fragment fragment);

    public abstract void l(@SuppressLint({"UnknownNullness"}) Fragment fragment, Intent intent, int i2, Bundle bundle);

    public abstract void m();
}
