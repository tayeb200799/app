package b.n.c;

import androidx.fragment.app.Fragment;
import b.n.c.i0;
import b.n.c.r;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\e0.smali */
public final class e0 implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ i0.a f1968d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Fragment f1969e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ b.h.g.a f1970f;

    public e0(i0.a aVar, Fragment fragment, b.h.g.a aVar2) {
        this.f1968d = aVar;
        this.f1969e = fragment;
        this.f1970f = aVar2;
    }

    @Override // java.lang.Runnable
    public void run() {
        ((r.b) this.f1968d).a(this.f1969e, this.f1970f);
    }
}
