package b.n.c;

import android.util.AndroidRuntimeException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\p0.smali */
public final class p0 extends AndroidRuntimeException {
    public p0(String str) {
        super(str);
    }
}
