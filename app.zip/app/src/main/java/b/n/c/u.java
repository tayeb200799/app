package b.n.c;

import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b.n.c.b0;
import b.p.g;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\w.smali */
public abstract class w extends b.b0.a.a {

    /* renamed from: c, reason: collision with root package name */
    public final r f2087c;

    /* renamed from: d, reason: collision with root package name */
    public final int f2088d;

    /* renamed from: e, reason: collision with root package name */
    public b0 f2089e = null;

    /* renamed from: f, reason: collision with root package name */
    public Fragment f2090f = null;

    public w(r rVar, int i2) {
        this.f2087c = rVar;
        this.f2088d = i2;
    }

    public static String n(int i2, long j2) {
        return "android:switcher:" + i2 + ":" + j2;
    }

    @Override // b.b0.a.a
    public void c(ViewGroup viewGroup, int i2, Object obj) {
        Fragment fragment = (Fragment) obj;
        if (this.f2089e == null) {
            this.f2089e = new a(this.f2087c);
        }
        a aVar = (a) this.f2089e;
        Objects.requireNonNull(aVar);
        r rVar = fragment.u;
        if (rVar != null && rVar != aVar.p) {
            StringBuilder n = c.a.a.a.a.n("Cannot detach Fragment attached to a different FragmentManager. Fragment ");
            n.append(fragment.toString());
            n.append(" is already attached to a FragmentManager.");
            throw new IllegalStateException(n.toString());
        }
        aVar.b(new b0.a(6, fragment));
        if (fragment.equals(this.f2090f)) {
            this.f2090f = null;
        }
    }

    @Override // b.b0.a.a
    public void d(ViewGroup viewGroup) {
        b0 b0Var = this.f2089e;
        if (b0Var != null) {
            try {
                b0Var.d();
            } catch (IllegalStateException unused) {
                this.f2089e.c();
            }
            this.f2089e = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:9:0x008d  */
    @Override // b.b0.a.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object g(android.view.ViewGroup r9, int r10) {
        /*
            r8 = this;
            b.n.c.b0 r0 = r8.f2089e
            if (r0 != 0) goto Ld
            b.n.c.r r0 = r8.f2087c
            b.n.c.a r1 = new b.n.c.a
            r1.<init>(r0)
            r8.f2089e = r1
        Ld:
            long r0 = (long) r10
            int r2 = r9.getId()
            java.lang.String r2 = n(r2, r0)
            b.n.c.r r3 = r8.f2087c
            androidx.fragment.app.Fragment r2 = r3.G(r2)
            r3 = 1
            if (r2 == 0) goto L2b
            b.n.c.b0 r9 = r8.f2089e
            b.n.c.b0$a r10 = new b.n.c.b0$a
            r0 = 7
            r10.<init>(r0, r2)
            r9.b(r10)
            goto L89
        L2b:
            r2 = r8
            c.c.b.h.b.i.a r2 = (c.c.b.h.b.i.a) r2
            c.c.b.h.e.r0 r4 = new c.c.b.h.e.r0
            r4.<init>()
            if (r10 < 0) goto L77
            java.util.List<c.c.b.h.b.i.b> r5 = r2.f3998g
            int r5 = r5.size()
            if (r10 >= r5) goto L77
            java.util.List<c.c.b.h.b.i.b> r5 = r2.f3998g     // Catch: java.lang.Exception -> L73
            java.lang.Object r5 = r5.get(r10)     // Catch: java.lang.Exception -> L73
            c.c.b.h.b.i.b r5 = (c.c.b.h.b.i.b) r5     // Catch: java.lang.Exception -> L73
            java.lang.Class r5 = r5.f4003e     // Catch: java.lang.Exception -> L73
            java.lang.Object r5 = r5.newInstance()     // Catch: java.lang.Exception -> L73
            c.c.b.h.e.r0 r5 = (c.c.b.h.e.r0) r5     // Catch: java.lang.Exception -> L73
            boolean r4 = r5 instanceof c.c.b.d.j     // Catch: java.lang.Exception -> L70
            if (r4 == 0) goto L6e
            r4 = r5
            c.c.b.d.j r4 = (c.c.b.d.j) r4     // Catch: java.lang.Exception -> L70
            java.util.List<c.c.b.h.b.i.b> r6 = r2.f3998g     // Catch: java.lang.Exception -> L70
            java.lang.Object r6 = r6.get(r10)     // Catch: java.lang.Exception -> L70
            c.c.b.h.b.i.b r6 = (c.c.b.h.b.i.b) r6     // Catch: java.lang.Exception -> L70
            java.lang.String r6 = r6.f4002d     // Catch: java.lang.Exception -> L70
            r7 = 0
            r4.u(r6, r7)     // Catch: java.lang.Exception -> L70
            java.util.List<c.c.b.h.b.i.b> r2 = r2.f3998g     // Catch: java.lang.Exception -> L70
            java.lang.Object r10 = r2.get(r10)     // Catch: java.lang.Exception -> L70
            c.c.b.h.b.i.b r10 = (c.c.b.h.b.i.b) r10     // Catch: java.lang.Exception -> L70
            java.lang.String r2 = ""
            r10.f4002d = r2     // Catch: java.lang.Exception -> L70
        L6e:
            r2 = r5
            goto L78
        L70:
            r10 = move-exception
            r4 = r5
            goto L74
        L73:
            r10 = move-exception
        L74:
            r10.printStackTrace()
        L77:
            r2 = r4
        L78:
            b.n.c.b0 r10 = r8.f2089e
            int r4 = r9.getId()
            int r9 = r9.getId()
            java.lang.String r9 = n(r9, r0)
            r10.e(r4, r2, r9, r3)
        L89:
            androidx.fragment.app.Fragment r9 = r8.f2090f
            if (r2 == r9) goto La0
            r9 = 0
            r2.w0(r9)
            int r10 = r8.f2088d
            if (r10 != r3) goto L9d
            b.n.c.b0 r9 = r8.f2089e
            b.p.g$b r10 = b.p.g.b.STARTED
            r9.g(r2, r10)
            goto La0
        L9d:
            r2.A0(r9)
        La0:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: b.n.c.w.g(android.view.ViewGroup, int):java.lang.Object");
    }

    @Override // b.b0.a.a
    public boolean h(View view, Object obj) {
        return ((Fragment) obj).H == view;
    }

    @Override // b.b0.a.a
    public void j(Parcelable parcelable, ClassLoader classLoader) {
    }

    @Override // b.b0.a.a
    public Parcelable k() {
        return null;
    }

    @Override // b.b0.a.a
    public void l(ViewGroup viewGroup, int i2, Object obj) {
        Fragment fragment = (Fragment) obj;
        Fragment fragment2 = this.f2090f;
        if (fragment != fragment2) {
            if (fragment2 != null) {
                fragment2.w0(false);
                if (this.f2088d == 1) {
                    if (this.f2089e == null) {
                        this.f2089e = new a(this.f2087c);
                    }
                    this.f2089e.g(this.f2090f, g.b.STARTED);
                } else {
                    this.f2090f.A0(false);
                }
            }
            fragment.w0(true);
            if (this.f2088d == 1) {
                if (this.f2089e == null) {
                    this.f2089e = new a(this.f2087c);
                }
                this.f2089e.g(fragment, g.b.RESUMED);
            } else {
                fragment.A0(true);
            }
            this.f2090f = fragment;
        }
    }

    @Override // b.b0.a.a
    public void m(ViewGroup viewGroup) {
        if (viewGroup.getId() != -1) {
            return;
        }
        throw new IllegalStateException("ViewPager with adapter " + this + " requires a view id");
    }
}
