package b.n.c;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;
import b.n.c.r.f;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\c.smali */
public class c extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    public Handler X;
    public Runnable Y = new a();
    public DialogInterface.OnCancelListener Z = new b();
    public DialogInterface.OnDismissListener a0 = new DialogInterfaceOnDismissListenerC0043c();
    public int b0 = 0;
    public int c0 = 0;
    public boolean d0 = true;
    public boolean e0 = true;
    public int f0 = -1;
    public Dialog g0;
    public boolean h0;
    public boolean i0;
    public boolean j0;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\c$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            c cVar = c.this;
            cVar.a0.onDismiss(cVar.g0);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\c$b.smali */
    public class b implements DialogInterface.OnCancelListener {
        public b() {
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialogInterface) {
            c cVar = c.this;
            Dialog dialog = cVar.g0;
            if (dialog != null) {
                cVar.onCancel(dialog);
            }
        }
    }

    /* renamed from: b.n.c.c$c, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\c$c.smali */
    public class DialogInterfaceOnDismissListenerC0043c implements DialogInterface.OnDismissListener {
        public DialogInterfaceOnDismissListenerC0043c() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            c cVar = c.this;
            Dialog dialog = cVar.g0;
            if (dialog != null) {
                cVar.onDismiss(dialog);
            }
        }
    }

    public void C0(boolean z, boolean z2) {
        if (this.i0) {
            return;
        }
        this.i0 = true;
        this.j0 = false;
        Dialog dialog = this.g0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.g0.dismiss();
            if (!z2) {
                if (Looper.myLooper() == this.X.getLooper()) {
                    onDismiss(this.g0);
                } else {
                    this.X.post(this.Y);
                }
            }
        }
        this.h0 = true;
        if (this.f0 >= 0) {
            r E = E();
            int i2 = this.f0;
            if (i2 < 0) {
                throw new IllegalArgumentException(c.a.a.a.a.c("Bad id: ", i2));
            }
            E.z(E.new f(null, i2, 1), false);
            this.f0 = -1;
            return;
        }
        b.n.c.a aVar = new b.n.c.a(E());
        aVar.f(this);
        if (z) {
            aVar.c();
        } else {
            aVar.i(false);
        }
    }

    public Dialog D0(Bundle bundle) {
        throw null;
    }

    public void E0(Dialog dialog, int i2) {
        if (i2 != 1 && i2 != 2) {
            if (i2 != 3) {
                return;
            } else {
                dialog.getWindow().addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    public void F0(r rVar, String str) {
        this.i0 = false;
        this.j0 = true;
        b.n.c.a aVar = new b.n.c.a(rVar);
        aVar.e(0, this, str, 1);
        aVar.i(false);
    }

    @Override // androidx.fragment.app.Fragment
    public void T(Bundle bundle) {
        Bundle bundle2;
        this.F = true;
        if (this.e0) {
            View view = this.H;
            if (view != null) {
                if (view.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
                this.g0.setContentView(view);
            }
            e w = w();
            if (w != null) {
                this.g0.setOwnerActivity(w);
            }
            this.g0.setCancelable(this.d0);
            this.g0.setOnCancelListener(this.Z);
            this.g0.setOnDismissListener(this.a0);
            if (bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
                return;
            }
            this.g0.onRestoreInstanceState(bundle2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void V(Context context) {
        super.V(context);
        if (this.j0) {
            return;
        }
        this.i0 = false;
    }

    @Override // androidx.fragment.app.Fragment
    public void W(Bundle bundle) {
        super.W(bundle);
        this.X = new Handler();
        this.e0 = this.z == 0;
        if (bundle != null) {
            this.b0 = bundle.getInt("android:style", 0);
            this.c0 = bundle.getInt("android:theme", 0);
            this.d0 = bundle.getBoolean("android:cancelable", true);
            this.e0 = bundle.getBoolean("android:showsDialog", this.e0);
            this.f0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void Z() {
        this.F = true;
        Dialog dialog = this.g0;
        if (dialog != null) {
            this.h0 = true;
            dialog.setOnDismissListener(null);
            this.g0.dismiss();
            if (!this.i0) {
                onDismiss(this.g0);
            }
            this.g0 = null;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void a0() {
        this.F = true;
        if (this.j0 || this.i0) {
            return;
        }
        this.i0 = true;
    }

    @Override // androidx.fragment.app.Fragment
    public LayoutInflater b0(Bundle bundle) {
        if (!this.e0) {
            return super.b0(bundle);
        }
        Dialog D0 = D0(bundle);
        this.g0 = D0;
        if (D0 == null) {
            return (LayoutInflater) this.v.f2046e.getSystemService("layout_inflater");
        }
        E0(D0, this.b0);
        return (LayoutInflater) this.g0.getContext().getSystemService("layout_inflater");
    }

    @Override // androidx.fragment.app.Fragment
    public void g0(Bundle bundle) {
        Bundle onSaveInstanceState;
        Dialog dialog = this.g0;
        if (dialog != null && (onSaveInstanceState = dialog.onSaveInstanceState()) != null) {
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i2 = this.b0;
        if (i2 != 0) {
            bundle.putInt("android:style", i2);
        }
        int i3 = this.c0;
        if (i3 != 0) {
            bundle.putInt("android:theme", i3);
        }
        boolean z = this.d0;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.e0;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i4 = this.f0;
        if (i4 != -1) {
            bundle.putInt("android:backStackId", i4);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void h0() {
        this.F = true;
        Dialog dialog = this.g0;
        if (dialog != null) {
            this.h0 = false;
            dialog.show();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void i0() {
        this.F = true;
        Dialog dialog = this.g0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.h0) {
            return;
        }
        C0(true, true);
    }
}
