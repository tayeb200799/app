package b.n.c;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\o0.smali */
public class o0 implements b.p.k {

    /* renamed from: d, reason: collision with root package name */
    public b.p.l f2049d = null;

    @Override // b.p.k
    public b.p.g a() {
        if (this.f2049d == null) {
            this.f2049d = new b.p.l(this);
        }
        return this.f2049d;
    }
}
