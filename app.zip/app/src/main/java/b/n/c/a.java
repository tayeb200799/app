package b.n.c;

import androidx.fragment.app.Fragment;
import b.p.g;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\b0.smali */
public abstract class b0 {

    /* renamed from: b, reason: collision with root package name */
    public int f1941b;

    /* renamed from: c, reason: collision with root package name */
    public int f1942c;

    /* renamed from: d, reason: collision with root package name */
    public int f1943d;

    /* renamed from: e, reason: collision with root package name */
    public int f1944e;

    /* renamed from: f, reason: collision with root package name */
    public int f1945f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1946g;

    /* renamed from: h, reason: collision with root package name */
    public String f1947h;

    /* renamed from: i, reason: collision with root package name */
    public int f1948i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f1949j;
    public int k;
    public CharSequence l;
    public ArrayList<String> m;
    public ArrayList<String> n;

    /* renamed from: a, reason: collision with root package name */
    public ArrayList<a> f1940a = new ArrayList<>();
    public boolean o = false;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\b0$a.smali */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public int f1950a;

        /* renamed from: b, reason: collision with root package name */
        public Fragment f1951b;

        /* renamed from: c, reason: collision with root package name */
        public int f1952c;

        /* renamed from: d, reason: collision with root package name */
        public int f1953d;

        /* renamed from: e, reason: collision with root package name */
        public int f1954e;

        /* renamed from: f, reason: collision with root package name */
        public int f1955f;

        /* renamed from: g, reason: collision with root package name */
        public g.b f1956g;

        /* renamed from: h, reason: collision with root package name */
        public g.b f1957h;

        public a() {
        }

        public a(int i2, Fragment fragment) {
            this.f1950a = i2;
            this.f1951b = fragment;
            g.b bVar = g.b.RESUMED;
            this.f1956g = bVar;
            this.f1957h = bVar;
        }

        public a(int i2, Fragment fragment, g.b bVar) {
            this.f1950a = i2;
            this.f1951b = fragment;
            this.f1956g = fragment.Q;
            this.f1957h = bVar;
        }
    }

    public b0(n nVar, ClassLoader classLoader) {
    }

    public void b(a aVar) {
        this.f1940a.add(aVar);
        aVar.f1952c = this.f1941b;
        aVar.f1953d = this.f1942c;
        aVar.f1954e = this.f1943d;
        aVar.f1955f = this.f1944e;
    }

    public abstract int c();

    public abstract void d();

    public abstract void e(int i2, Fragment fragment, String str, int i3);

    public abstract b0 f(Fragment fragment);

    public abstract b0 g(Fragment fragment, g.b bVar);
}
