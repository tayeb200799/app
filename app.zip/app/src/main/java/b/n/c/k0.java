package b.n.c;

import android.view.View;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\m0.smali */
public class m0 implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ ArrayList f2042d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Map f2043e;

    public m0(n0 n0Var, ArrayList arrayList, Map map) {
        this.f2042d = arrayList;
        this.f2043e = map;
    }

    @Override // java.lang.Runnable
    public void run() {
        int size = this.f2042d.size();
        for (int i2 = 0; i2 < size; i2++) {
            View view = (View) this.f2042d.get(i2);
            AtomicInteger atomicInteger = b.h.k.q.f1738a;
            view.setTransitionName((String) this.f2043e.get(view.getTransitionName()));
        }
    }
}
