package b.n.c;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\m.smali */
public class m {

    /* renamed from: a, reason: collision with root package name */
    public final o<?> f2041a;

    public m(o<?> oVar) {
        this.f2041a = oVar;
    }

    public void a() {
        this.f2041a.f2048g.U();
    }
}
