package b.n.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b.n.c.i0;
import b.n.c.r;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\h.smali */
public final class h extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f1994a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f1995b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Fragment f1996c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ i0.a f1997d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ b.h.g.a f1998e;

    public h(ViewGroup viewGroup, View view, Fragment fragment, i0.a aVar, b.h.g.a aVar2) {
        this.f1994a = viewGroup;
        this.f1995b = view;
        this.f1996c = fragment;
        this.f1997d = aVar;
        this.f1998e = aVar2;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f1994a.endViewTransition(this.f1995b);
        Fragment fragment = this.f1996c;
        Fragment.a aVar = fragment.K;
        Animator animator2 = aVar == null ? null : aVar.f324b;
        fragment.t0(null);
        if (animator2 == null || this.f1994a.indexOfChild(this.f1995b) >= 0) {
            return;
        }
        ((r.b) this.f1997d).a(this.f1996c, this.f1998e);
    }
}
