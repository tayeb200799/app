package b.n.c;

import android.view.View;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\f0.smali */
public final class f0 implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1972d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ n0 f1973e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ View f1974f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Fragment f1975g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ ArrayList f1976h;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ ArrayList f1977i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ ArrayList f1978j;
    public final /* synthetic */ Object k;

    public f0(Object obj, n0 n0Var, View view, Fragment fragment, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
        this.f1972d = obj;
        this.f1973e = n0Var;
        this.f1974f = view;
        this.f1975g = fragment;
        this.f1976h = arrayList;
        this.f1977i = arrayList2;
        this.f1978j = arrayList3;
        this.k = obj2;
    }

    @Override // java.lang.Runnable
    public void run() {
        Object obj = this.f1972d;
        if (obj != null) {
            this.f1973e.m(obj, this.f1974f);
            this.f1977i.addAll(i0.h(this.f1973e, this.f1972d, this.f1975g, this.f1976h, this.f1974f));
        }
        if (this.f1978j != null) {
            if (this.k != null) {
                ArrayList<View> arrayList = new ArrayList<>();
                arrayList.add(this.f1974f);
                this.f1973e.n(this.k, this.f1978j, arrayList);
            }
            this.f1978j.clear();
            this.f1978j.add(this.f1974f);
        }
    }
}
