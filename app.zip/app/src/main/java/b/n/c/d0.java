package b.n.c;

import android.view.View;
import androidx.fragment.app.Fragment;
import b.h.g.a;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\f.smali */
public final class f implements a.InterfaceC0029a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Fragment f1971a;

    public f(Fragment fragment) {
        this.f1971a = fragment;
    }

    public void a() {
        if (this.f1971a.x() != null) {
            View x = this.f1971a.x();
            this.f1971a.s0(null);
            x.clearAnimation();
        }
        this.f1971a.t0(null);
    }
}
