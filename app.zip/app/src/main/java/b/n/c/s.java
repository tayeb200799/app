package b.n.c;

import android.util.Log;
import androidx.fragment.app.Fragment;
import b.p.y;
import java.util.HashMap;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\v.smali */
public final class v extends b.p.x {

    /* renamed from: h, reason: collision with root package name */
    public static final y.b f2081h = new a();

    /* renamed from: f, reason: collision with root package name */
    public final boolean f2085f;

    /* renamed from: c, reason: collision with root package name */
    public final HashMap<String, Fragment> f2082c = new HashMap<>();

    /* renamed from: d, reason: collision with root package name */
    public final HashMap<String, v> f2083d = new HashMap<>();

    /* renamed from: e, reason: collision with root package name */
    public final HashMap<String, b.p.z> f2084e = new HashMap<>();

    /* renamed from: g, reason: collision with root package name */
    public boolean f2086g = false;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\v$a.smali */
    public static class a implements y.b {
        @Override // b.p.y.b
        public <T extends b.p.x> T a(Class<T> cls) {
            return new v(true);
        }
    }

    public v(boolean z) {
        this.f2085f = z;
    }

    @Override // b.p.x
    public void d() {
        if (r.M(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f2086g = true;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || v.class != obj.getClass()) {
            return false;
        }
        v vVar = (v) obj;
        return this.f2082c.equals(vVar.f2082c) && this.f2083d.equals(vVar.f2083d) && this.f2084e.equals(vVar.f2084e);
    }

    public boolean f(Fragment fragment) {
        if (this.f2082c.containsKey(fragment.f317h) && this.f2085f) {
            return this.f2086g;
        }
        return true;
    }

    public int hashCode() {
        return this.f2084e.hashCode() + ((this.f2083d.hashCode() + (this.f2082c.hashCode() * 31)) * 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<Fragment> it = this.f2082c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.f2083d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.f2084e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
