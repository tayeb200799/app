package b.n.c;

import android.graphics.Rect;
import android.view.View;
import androidx.fragment.app.Fragment;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\g0.smali */
public final class g0 implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Fragment f1984d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Fragment f1985e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ boolean f1986f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ b.e.a f1987g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ View f1988h;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ n0 f1989i;

    /* renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Rect f1990j;

    public g0(Fragment fragment, Fragment fragment2, boolean z, b.e.a aVar, View view, n0 n0Var, Rect rect) {
        this.f1984d = fragment;
        this.f1985e = fragment2;
        this.f1986f = z;
        this.f1987g = aVar;
        this.f1988h = view;
        this.f1989i = n0Var;
        this.f1990j = rect;
    }

    @Override // java.lang.Runnable
    public void run() {
        i0.c(this.f1984d, this.f1985e, this.f1986f, this.f1987g, false);
        View view = this.f1988h;
        if (view != null) {
            this.f1989i.j(view, this.f1990j);
        }
    }
}
