package b.n.c;

import androidx.fragment.app.Fragment;
import b.n.c.i0;
import b.n.c.r;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\c0.smali */
public final class c0 implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ i0.a f1964d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Fragment f1965e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ b.h.g.a f1966f;

    public c0(i0.a aVar, Fragment fragment, b.h.g.a aVar2) {
        this.f1964d = aVar;
        this.f1965e = fragment;
        this.f1966f = aVar2;
    }

    @Override // java.lang.Runnable
    public void run() {
        ((r.b) this.f1964d).a(this.f1965e, this.f1966f);
    }
}
