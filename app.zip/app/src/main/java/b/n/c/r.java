package b.n.c;

import android.animation.Animator;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcher.LifecycleOnBackPressedCancellable;
import androidx.fragment.app.Fragment;
import b.h.g.a;
import b.n.c.b0;
import b.n.c.i0;
import b.n.c.v;
import b.p.g;
import b.p.y;
import b.q.a.b;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r.smali */
public abstract class r {
    public ArrayList<g> A;
    public v B;

    /* renamed from: b, reason: collision with root package name */
    public boolean f2057b;

    /* renamed from: d, reason: collision with root package name */
    public ArrayList<b.n.c.a> f2059d;

    /* renamed from: e, reason: collision with root package name */
    public ArrayList<Fragment> f2060e;

    /* renamed from: g, reason: collision with root package name */
    public OnBackPressedDispatcher f2062g;
    public o<?> n;
    public k o;
    public Fragment p;
    public Fragment q;
    public boolean s;
    public boolean t;
    public boolean u;
    public boolean v;
    public boolean w;
    public ArrayList<b.n.c.a> x;
    public ArrayList<Boolean> y;
    public ArrayList<Fragment> z;

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList<e> f2056a = new ArrayList<>();

    /* renamed from: c, reason: collision with root package name */
    public final a0 f2058c = new a0();

    /* renamed from: f, reason: collision with root package name */
    public final p f2061f = new p(this);

    /* renamed from: h, reason: collision with root package name */
    public final b.a.b f2063h = new a(false);

    /* renamed from: i, reason: collision with root package name */
    public final AtomicInteger f2064i = new AtomicInteger();

    /* renamed from: j, reason: collision with root package name */
    public ConcurrentHashMap<Fragment, HashSet<b.h.g.a>> f2065j = new ConcurrentHashMap<>();
    public final i0.a k = new b();
    public final q l = new q(this);
    public int m = -1;
    public n r = new c();
    public Runnable C = new d();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$a.smali */
    public class a extends b.a.b {
        public a(boolean z) {
            super(z);
        }

        @Override // b.a.b
        public void a() {
            r rVar = r.this;
            rVar.B(true);
            if (rVar.f2063h.f568a) {
                rVar.W();
            } else {
                rVar.f2062g.a();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$b.smali */
    public class b implements i0.a {
        public b() {
        }

        public void a(Fragment fragment, b.h.g.a aVar) {
            boolean z;
            synchronized (aVar) {
                z = aVar.f1638a;
            }
            if (z) {
                return;
            }
            r rVar = r.this;
            HashSet<b.h.g.a> hashSet = rVar.f2065j.get(fragment);
            if (hashSet != null && hashSet.remove(aVar) && hashSet.isEmpty()) {
                rVar.f2065j.remove(fragment);
                if (fragment.f315d < 3) {
                    rVar.h(fragment);
                    rVar.T(fragment, fragment.K());
                }
            }
        }

        public void b(Fragment fragment, b.h.g.a aVar) {
            r rVar = r.this;
            if (rVar.f2065j.get(fragment) == null) {
                rVar.f2065j.put(fragment, new HashSet<>());
            }
            rVar.f2065j.get(fragment).add(aVar);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$c.smali */
    public class c extends n {
        public c() {
        }

        @Override // b.n.c.n
        public Fragment a(ClassLoader classLoader, String str) {
            o<?> oVar = r.this.n;
            Context context = oVar.f2049e;
            Objects.requireNonNull(oVar);
            Object obj = Fragment.W;
            try {
                return n.c(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            } catch (IllegalAccessException e2) {
                throw new Fragment.b(c.a.a.a.a.g("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e2);
            } catch (InstantiationException e3) {
                throw new Fragment.b(c.a.a.a.a.g("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e3);
            } catch (NoSuchMethodException e4) {
                throw new Fragment.b(c.a.a.a.a.g("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e4);
            } catch (InvocationTargetException e5) {
                throw new Fragment.b(c.a.a.a.a.g("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e5);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$d.smali */
    public class d implements Runnable {
        public d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            r.this.B(true);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$e.smali */
    public interface e {
        boolean a(ArrayList<b.n.c.a> arrayList, ArrayList<Boolean> arrayList2);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$f.smali */
    public class f implements e {

        /* renamed from: a, reason: collision with root package name */
        public final int f2070a;

        /* renamed from: b, reason: collision with root package name */
        public final int f2071b;

        public f(String str, int i2, int i3) {
            this.f2070a = i2;
            this.f2071b = i3;
        }

        @Override // b.n.c.r.e
        public boolean a(ArrayList<b.n.c.a> arrayList, ArrayList<Boolean> arrayList2) {
            Fragment fragment = r.this.q;
            if (fragment == null || this.f2070a >= 0 || !fragment.y().W()) {
                return r.this.X(arrayList, arrayList2, null, this.f2070a, this.f2071b);
            }
            return false;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\r$g.smali */
    public static class g implements Fragment.c {

        /* renamed from: a, reason: collision with root package name */
        public final boolean f2073a;

        /* renamed from: b, reason: collision with root package name */
        public final b.n.c.a f2074b;

        /* renamed from: c, reason: collision with root package name */
        public int f2075c;

        public g(b.n.c.a aVar, boolean z) {
            this.f2073a = z;
            this.f2074b = aVar;
        }

        public void a() {
            boolean z = this.f2075c > 0;
            Iterator<Fragment> it = this.f2074b.p.K().iterator();
            while (it.hasNext()) {
                it.next().y0(null);
            }
            b.n.c.a aVar = this.f2074b;
            aVar.p.g(aVar, this.f2073a, !z, true);
        }
    }

    public static boolean M(int i2) {
        return Log.isLoggable("FragmentManager", i2);
    }

    public final void A(boolean z) {
        if (this.f2057b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.n == null) {
            if (!this.v) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        }
        if (Looper.myLooper() != this.n.f2050f.getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z && P()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.x == null) {
            this.x = new ArrayList<>();
            this.y = new ArrayList<>();
        }
        this.f2057b = true;
        try {
            D(null, null);
        } finally {
            this.f2057b = false;
        }
    }

    public boolean B(boolean z) {
        boolean z2;
        A(z);
        boolean z3 = false;
        while (true) {
            ArrayList<b.n.c.a> arrayList = this.x;
            ArrayList<Boolean> arrayList2 = this.y;
            synchronized (this.f2056a) {
                if (this.f2056a.isEmpty()) {
                    z2 = false;
                } else {
                    int size = this.f2056a.size();
                    z2 = false;
                    for (int i2 = 0; i2 < size; i2++) {
                        z2 |= this.f2056a.get(i2).a(arrayList, arrayList2);
                    }
                    this.f2056a.clear();
                    this.n.f2050f.removeCallbacks(this.C);
                }
            }
            if (!z2) {
                l0();
                w();
                this.f2058c.b();
                return z3;
            }
            this.f2057b = true;
            try {
                Z(this.x, this.y);
                f();
                z3 = true;
            } catch (Throwable th) {
                f();
                throw th;
            }
        }
    }

    public final void C(ArrayList<b.n.c.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        int i4;
        int i5;
        boolean z;
        int i6;
        int i7;
        ArrayList<Boolean> arrayList3 = arrayList2;
        boolean z2 = arrayList.get(i2).o;
        ArrayList<Fragment> arrayList4 = this.z;
        if (arrayList4 == null) {
            this.z = new ArrayList<>();
        } else {
            arrayList4.clear();
        }
        this.z.addAll(this.f2058c.g());
        Fragment fragment = this.q;
        int i8 = i2;
        boolean z3 = false;
        while (true) {
            int i9 = 1;
            if (i8 >= i3) {
                this.z.clear();
                if (!z2) {
                    i0.o(this, arrayList, arrayList2, i2, i3, false, this.k);
                }
                int i10 = i2;
                while (i10 < i3) {
                    b.n.c.a aVar = arrayList.get(i10);
                    if (arrayList2.get(i10).booleanValue()) {
                        aVar.h(-1);
                        aVar.l(i10 == i3 + (-1));
                    } else {
                        aVar.h(1);
                        aVar.k();
                    }
                    i10++;
                }
                if (z2) {
                    b.e.c<Fragment> cVar = new b.e.c<>(0);
                    a(cVar);
                    i4 = i2;
                    int i11 = i3;
                    for (int i12 = i3 - 1; i12 >= i4; i12--) {
                        b.n.c.a aVar2 = arrayList.get(i12);
                        boolean booleanValue = arrayList2.get(i12).booleanValue();
                        int i13 = 0;
                        while (true) {
                            if (i13 >= aVar2.f1943a.size()) {
                                z = false;
                            } else if (b.n.c.a.o(aVar2.f1943a.get(i13))) {
                                z = true;
                            } else {
                                i13++;
                            }
                        }
                        if (z && !aVar2.n(arrayList, i12 + 1, i3)) {
                            if (this.A == null) {
                                this.A = new ArrayList<>();
                            }
                            g gVar = new g(aVar2, booleanValue);
                            this.A.add(gVar);
                            for (int i14 = 0; i14 < aVar2.f1943a.size(); i14++) {
                                b0.a aVar3 = aVar2.f1943a.get(i14);
                                if (b.n.c.a.o(aVar3)) {
                                    aVar3.f1954b.y0(gVar);
                                }
                            }
                            if (booleanValue) {
                                aVar2.k();
                            } else {
                                aVar2.l(false);
                            }
                            i11--;
                            if (i12 != i11) {
                                arrayList.remove(i12);
                                arrayList.add(i11, aVar2);
                            }
                            a(cVar);
                        }
                    }
                    int i15 = cVar.f1162f;
                    for (int i16 = 0; i16 < i15; i16++) {
                        Fragment fragment2 = (Fragment) cVar.f1161e[i16];
                        if (!fragment2.n) {
                            View r0 = fragment2.r0();
                            fragment2.N = r0.getAlpha();
                            r0.setAlpha(0.0f);
                        }
                    }
                    i5 = i11;
                } else {
                    i4 = i2;
                    i5 = i3;
                }
                if (i5 != i4 && z2) {
                    i0.o(this, arrayList, arrayList2, i2, i5, true, this.k);
                    S(this.m, true);
                }
                while (i4 < i3) {
                    b.n.c.a aVar4 = arrayList.get(i4);
                    if (arrayList2.get(i4).booleanValue() && aVar4.r >= 0) {
                        aVar4.r = -1;
                    }
                    Objects.requireNonNull(aVar4);
                    i4++;
                }
                return;
            }
            b.n.c.a aVar5 = arrayList.get(i8);
            int i17 = 3;
            if (arrayList3.get(i8).booleanValue()) {
                int i18 = 1;
                ArrayList<Fragment> arrayList5 = this.z;
                int size = aVar5.f1943a.size() - 1;
                while (size >= 0) {
                    b0.a aVar6 = aVar5.f1943a.get(size);
                    int i19 = aVar6.f1953a;
                    if (i19 != i18) {
                        if (i19 != 3) {
                            switch (i19) {
                                case 8:
                                    fragment = null;
                                    break;
                                case 9:
                                    fragment = aVar6.f1954b;
                                    break;
                                case 10:
                                    aVar6.f1960h = aVar6.f1959g;
                                    break;
                            }
                            size--;
                            i18 = 1;
                        }
                        arrayList5.add(aVar6.f1954b);
                        size--;
                        i18 = 1;
                    }
                    arrayList5.remove(aVar6.f1954b);
                    size--;
                    i18 = 1;
                }
            } else {
                ArrayList<Fragment> arrayList6 = this.z;
                int i20 = 0;
                while (i20 < aVar5.f1943a.size()) {
                    b0.a aVar7 = aVar5.f1943a.get(i20);
                    int i21 = aVar7.f1953a;
                    if (i21 != i9) {
                        if (i21 == 2) {
                            Fragment fragment3 = aVar7.f1954b;
                            int i22 = fragment3.z;
                            int size2 = arrayList6.size() - 1;
                            boolean z4 = false;
                            while (size2 >= 0) {
                                Fragment fragment4 = arrayList6.get(size2);
                                if (fragment4.z != i22) {
                                    i7 = i22;
                                } else if (fragment4 == fragment3) {
                                    i7 = i22;
                                    z4 = true;
                                } else {
                                    if (fragment4 == fragment) {
                                        i7 = i22;
                                        aVar5.f1943a.add(i20, new b0.a(9, fragment4));
                                        i20++;
                                        fragment = null;
                                    } else {
                                        i7 = i22;
                                    }
                                    b0.a aVar8 = new b0.a(3, fragment4);
                                    aVar8.f1955c = aVar7.f1955c;
                                    aVar8.f1957e = aVar7.f1957e;
                                    aVar8.f1956d = aVar7.f1956d;
                                    aVar8.f1958f = aVar7.f1958f;
                                    aVar5.f1943a.add(i20, aVar8);
                                    arrayList6.remove(fragment4);
                                    i20++;
                                }
                                size2--;
                                i22 = i7;
                            }
                            if (z4) {
                                aVar5.f1943a.remove(i20);
                                i20--;
                            } else {
                                i6 = 1;
                                aVar7.f1953a = 1;
                                arrayList6.add(fragment3);
                                i20 += i6;
                                i17 = 3;
                                i9 = 1;
                            }
                        } else if (i21 == i17 || i21 == 6) {
                            arrayList6.remove(aVar7.f1954b);
                            Fragment fragment5 = aVar7.f1954b;
                            if (fragment5 == fragment) {
                                aVar5.f1943a.add(i20, new b0.a(9, fragment5));
                                i20++;
                                fragment = null;
                            }
                        } else if (i21 != 7) {
                            if (i21 == 8) {
                                aVar5.f1943a.add(i20, new b0.a(9, fragment));
                                i20++;
                                fragment = aVar7.f1954b;
                            }
                        }
                        i6 = 1;
                        i20 += i6;
                        i17 = 3;
                        i9 = 1;
                    }
                    i6 = 1;
                    arrayList6.add(aVar7.f1954b);
                    i20 += i6;
                    i17 = 3;
                    i9 = 1;
                }
            }
            z3 = z3 || aVar5.f1949g;
            i8++;
            arrayList3 = arrayList2;
        }
    }

    public final void D(ArrayList<b.n.c.a> arrayList, ArrayList<Boolean> arrayList2) {
        int indexOf;
        int indexOf2;
        ArrayList<g> arrayList3 = this.A;
        int size = arrayList3 == null ? 0 : arrayList3.size();
        int i2 = 0;
        while (i2 < size) {
            g gVar = this.A.get(i2);
            if (arrayList == null || gVar.f2073a || (indexOf2 = arrayList.indexOf(gVar.f2074b)) == -1 || arrayList2 == null || !arrayList2.get(indexOf2).booleanValue()) {
                if ((gVar.f2075c == 0) || (arrayList != null && gVar.f2074b.n(arrayList, 0, arrayList.size()))) {
                    this.A.remove(i2);
                    i2--;
                    size--;
                    if (arrayList == null || gVar.f2073a || (indexOf = arrayList.indexOf(gVar.f2074b)) == -1 || arrayList2 == null || !arrayList2.get(indexOf).booleanValue()) {
                        gVar.a();
                    } else {
                        b.n.c.a aVar = gVar.f2074b;
                        aVar.p.g(aVar, gVar.f2073a, false, false);
                    }
                }
            } else {
                this.A.remove(i2);
                i2--;
                size--;
                b.n.c.a aVar2 = gVar.f2074b;
                aVar2.p.g(aVar2, gVar.f2073a, false, false);
            }
            i2++;
        }
    }

    public Fragment E(String str) {
        return this.f2058c.e(str);
    }

    public Fragment F(int i2) {
        a0 a0Var = this.f2058c;
        int size = a0Var.f1934a.size();
        while (true) {
            size--;
            if (size < 0) {
                for (y yVar : a0Var.f1935b.values()) {
                    if (yVar != null) {
                        Fragment fragment = yVar.f2102b;
                        if (fragment.y == i2) {
                            return fragment;
                        }
                    }
                }
                return null;
            }
            Fragment fragment2 = a0Var.f1934a.get(size);
            if (fragment2 != null && fragment2.y == i2) {
                return fragment2;
            }
        }
    }

    public Fragment G(String str) {
        a0 a0Var = this.f2058c;
        Objects.requireNonNull(a0Var);
        if (str != null) {
            int size = a0Var.f1934a.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                }
                Fragment fragment = a0Var.f1934a.get(size);
                if (fragment != null && str.equals(fragment.A)) {
                    return fragment;
                }
            }
        }
        if (str != null) {
            for (y yVar : a0Var.f1935b.values()) {
                if (yVar != null) {
                    Fragment fragment2 = yVar.f2102b;
                    if (str.equals(fragment2.A)) {
                        return fragment2;
                    }
                }
            }
        }
        return null;
    }

    public Fragment H(String str) {
        for (y yVar : this.f2058c.f1935b.values()) {
            if (yVar != null) {
                Fragment fragment = yVar.f2102b;
                if (!str.equals(fragment.f319h)) {
                    fragment = fragment.w.H(str);
                }
                if (fragment != null) {
                    return fragment;
                }
            }
        }
        return null;
    }

    public final ViewGroup I(Fragment fragment) {
        if (fragment.z > 0 && this.o.e()) {
            View b2 = this.o.b(fragment.z);
            if (b2 instanceof ViewGroup) {
                return (ViewGroup) b2;
            }
        }
        return null;
    }

    public n J() {
        Fragment fragment = this.p;
        return fragment != null ? fragment.u.J() : this.r;
    }

    public List<Fragment> K() {
        return this.f2058c.g();
    }

    public void L(Fragment fragment) {
        if (M(2)) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (fragment.B) {
            return;
        }
        fragment.B = true;
        fragment.M = true ^ fragment.M;
        h0(fragment);
    }

    public final boolean N(Fragment fragment) {
        r rVar = fragment.w;
        Iterator it = ((ArrayList) rVar.f2058c.f()).iterator();
        boolean z = false;
        while (it.hasNext()) {
            Fragment fragment2 = (Fragment) it.next();
            if (fragment2 != null) {
                z = rVar.N(fragment2);
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    public boolean O(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        r rVar = fragment.u;
        return fragment.equals(rVar.q) && O(rVar.p);
    }

    public boolean P() {
        return this.t || this.u;
    }

    public void Q(Fragment fragment) {
        if (this.f2058c.c(fragment.f319h)) {
            return;
        }
        y yVar = new y(this.l, fragment);
        yVar.a(this.n.f2049e.getClassLoader());
        this.f2058c.f1935b.put(yVar.f2102b.f319h, yVar);
        yVar.f2103c = this.m;
        if (M(2)) {
            Log.v("FragmentManager", "Added fragment to active set " + fragment);
        }
    }

    public void R(Fragment fragment) {
        Animator animator;
        if (!this.f2058c.c(fragment.f319h)) {
            if (M(3)) {
                Log.d("FragmentManager", "Ignoring moving " + fragment + " to state " + this.m + "since it is not added to " + this);
                return;
            }
            return;
        }
        T(fragment, this.m);
        if (fragment.H != null) {
            a0 a0Var = this.f2058c;
            Objects.requireNonNull(a0Var);
            ViewGroup viewGroup = fragment.G;
            View view = fragment.H;
            Fragment fragment2 = null;
            if (viewGroup != null && view != null) {
                int indexOf = a0Var.f1934a.indexOf(fragment);
                while (true) {
                    indexOf--;
                    if (indexOf < 0) {
                        break;
                    }
                    Fragment fragment3 = a0Var.f1934a.get(indexOf);
                    if (fragment3.G == viewGroup && fragment3.H != null) {
                        fragment2 = fragment3;
                        break;
                    }
                }
            }
            if (fragment2 != null) {
                View view2 = fragment2.H;
                ViewGroup viewGroup2 = fragment.G;
                int indexOfChild = viewGroup2.indexOfChild(view2);
                int indexOfChild2 = viewGroup2.indexOfChild(fragment.H);
                if (indexOfChild2 < indexOfChild) {
                    viewGroup2.removeViewAt(indexOfChild2);
                    viewGroup2.addView(fragment.H, indexOfChild);
                }
            }
            if (fragment.L && fragment.G != null) {
                float f2 = fragment.N;
                if (f2 > 0.0f) {
                    fragment.H.setAlpha(f2);
                }
                fragment.N = 0.0f;
                fragment.L = false;
                i g0 = b.n.a.g0(this.n.f2049e, this.o, fragment, true);
                if (g0 != null) {
                    Animation animation = g0.f2006a;
                    if (animation != null) {
                        fragment.H.startAnimation(animation);
                    } else {
                        g0.f2007b.setTarget(fragment.H);
                        g0.f2007b.start();
                    }
                }
            }
        }
        if (fragment.M) {
            if (fragment.H != null) {
                i g02 = b.n.a.g0(this.n.f2049e, this.o, fragment, !fragment.B);
                if (g02 == null || (animator = g02.f2007b) == null) {
                    if (g02 != null) {
                        fragment.H.startAnimation(g02.f2006a);
                        g02.f2006a.start();
                    }
                    fragment.H.setVisibility((!fragment.B || fragment.P()) ? 0 : 8);
                    if (fragment.P()) {
                        fragment.v0(false);
                    }
                } else {
                    animator.setTarget(fragment.H);
                    if (!fragment.B) {
                        fragment.H.setVisibility(0);
                    } else if (fragment.P()) {
                        fragment.v0(false);
                    } else {
                        ViewGroup viewGroup3 = fragment.G;
                        View view3 = fragment.H;
                        viewGroup3.startViewTransition(view3);
                        g02.f2007b.addListener(new s(this, viewGroup3, view3, fragment));
                    }
                    g02.f2007b.start();
                }
            }
            if (fragment.n && N(fragment)) {
                this.s = true;
            }
            fragment.M = false;
        }
    }

    public void S(int i2, boolean z) {
        o<?> oVar;
        if (this.n == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z || i2 != this.m) {
            this.m = i2;
            Iterator<Fragment> it = this.f2058c.g().iterator();
            while (it.hasNext()) {
                R(it.next());
            }
            Iterator it2 = ((ArrayList) this.f2058c.f()).iterator();
            while (it2.hasNext()) {
                Fragment fragment = (Fragment) it2.next();
                if (fragment != null && !fragment.L) {
                    R(fragment);
                }
            }
            j0();
            if (this.s && (oVar = this.n) != null && this.m == 4) {
                oVar.m();
                this.s = false;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:40:0x009b, code lost:
    
        if (r2 != 3) goto L385;
     */
    /* JADX WARN: Removed duplicated region for block: B:42:0x043d  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x03e0  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x020a  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x0264  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void T(androidx.fragment.app.Fragment r14, int r15) {
        /*
            Method dump skipped, instructions count: 2228
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.n.c.r.T(androidx.fragment.app.Fragment, int):void");
    }

    public void U() {
        this.t = false;
        this.u = false;
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                fragment.w.U();
            }
        }
    }

    public void V(Fragment fragment) {
        if (fragment.I) {
            if (this.f2057b) {
                this.w = true;
            } else {
                fragment.I = false;
                T(fragment, this.m);
            }
        }
    }

    public boolean W() {
        B(false);
        A(true);
        Fragment fragment = this.q;
        if (fragment != null && fragment.y().W()) {
            return true;
        }
        boolean X = X(this.x, this.y, null, -1, 0);
        if (X) {
            this.f2057b = true;
            try {
                Z(this.x, this.y);
            } finally {
                f();
            }
        }
        l0();
        w();
        this.f2058c.b();
        return X;
    }

    public boolean X(ArrayList<b.n.c.a> arrayList, ArrayList<Boolean> arrayList2, String str, int i2, int i3) {
        Boolean bool = Boolean.TRUE;
        ArrayList<b.n.c.a> arrayList3 = this.f2059d;
        if (arrayList3 == null) {
            return false;
        }
        if (str == null && i2 < 0 && (i3 & 1) == 0) {
            int size = arrayList3.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.f2059d.remove(size));
            arrayList2.add(bool);
        } else {
            int i4 = -1;
            if (str != null || i2 >= 0) {
                int size2 = arrayList3.size() - 1;
                while (size2 >= 0) {
                    b.n.c.a aVar = this.f2059d.get(size2);
                    if ((str != null && str.equals(aVar.f1950h)) || (i2 >= 0 && i2 == aVar.r)) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    return false;
                }
                if ((i3 & 1) != 0) {
                    while (true) {
                        size2--;
                        if (size2 < 0) {
                            break;
                        }
                        b.n.c.a aVar2 = this.f2059d.get(size2);
                        if (str == null || !str.equals(aVar2.f1950h)) {
                            if (i2 < 0 || i2 != aVar2.r) {
                                break;
                            }
                        }
                    }
                }
                i4 = size2;
            }
            if (i4 == this.f2059d.size() - 1) {
                return false;
            }
            for (int size3 = this.f2059d.size() - 1; size3 > i4; size3--) {
                arrayList.add(this.f2059d.remove(size3));
                arrayList2.add(bool);
            }
        }
        return true;
    }

    public void Y(Fragment fragment) {
        if (M(2)) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.t);
        }
        boolean z = !fragment.Q();
        if (!fragment.C || z) {
            this.f2058c.h(fragment);
            if (N(fragment)) {
                this.s = true;
            }
            fragment.o = true;
            h0(fragment);
        }
    }

    public final void Z(ArrayList<b.n.c.a> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        D(arrayList, arrayList2);
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            if (!arrayList.get(i2).o) {
                if (i3 != i2) {
                    C(arrayList, arrayList2, i3, i2);
                }
                i3 = i2 + 1;
                if (arrayList2.get(i2).booleanValue()) {
                    while (i3 < size && arrayList2.get(i3).booleanValue() && !arrayList.get(i3).o) {
                        i3++;
                    }
                }
                C(arrayList, arrayList2, i2, i3);
                i2 = i3 - 1;
            }
            i2++;
        }
        if (i3 != size) {
            C(arrayList, arrayList2, i3, size);
        }
    }

    public final void a(b.e.c<Fragment> cVar) {
        int i2 = this.m;
        if (i2 < 1) {
            return;
        }
        int min = Math.min(i2, 3);
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment.f315d < min) {
                T(fragment, min);
                if (fragment.H != null && !fragment.B && fragment.L) {
                    cVar.add(fragment);
                }
            }
        }
    }

    public void a0(Fragment fragment) {
        if (P()) {
            if (M(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
                return;
            }
            return;
        }
        if ((this.B.f2085c.remove(fragment.f319h) != null) && M(2)) {
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    public void b(Fragment fragment) {
        if (M(2)) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        Q(fragment);
        if (fragment.C) {
            return;
        }
        this.f2058c.a(fragment);
        fragment.o = false;
        if (fragment.H == null) {
            fragment.M = false;
        }
        if (N(fragment)) {
            this.s = true;
        }
    }

    public void b0(Parcelable parcelable) {
        y yVar;
        if (parcelable == null) {
            return;
        }
        u uVar = (u) parcelable;
        if (uVar.f2079d == null) {
            return;
        }
        this.f2058c.f1935b.clear();
        Iterator<x> it = uVar.f2079d.iterator();
        while (it.hasNext()) {
            x next = it.next();
            if (next != null) {
                Fragment fragment = this.B.f2085c.get(next.f2095e);
                if (fragment != null) {
                    if (M(2)) {
                        Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + fragment);
                    }
                    yVar = new y(this.l, fragment, next);
                } else {
                    yVar = new y(this.l, this.n.f2049e.getClassLoader(), J(), next);
                }
                Fragment fragment2 = yVar.f2102b;
                fragment2.u = this;
                if (M(2)) {
                    StringBuilder n = c.a.a.a.a.n("restoreSaveState: active (");
                    n.append(fragment2.f319h);
                    n.append("): ");
                    n.append(fragment2);
                    Log.v("FragmentManager", n.toString());
                }
                yVar.a(this.n.f2049e.getClassLoader());
                this.f2058c.f1935b.put(yVar.f2102b.f319h, yVar);
                yVar.f2103c = this.m;
            }
        }
        for (Fragment fragment3 : this.B.f2085c.values()) {
            if (!this.f2058c.c(fragment3.f319h)) {
                if (M(2)) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + fragment3 + " that was not found in the set of active Fragments " + uVar.f2079d);
                }
                T(fragment3, 1);
                fragment3.o = true;
                T(fragment3, -1);
            }
        }
        a0 a0Var = this.f2058c;
        ArrayList<String> arrayList = uVar.f2080e;
        a0Var.f1934a.clear();
        if (arrayList != null) {
            for (String str : arrayList) {
                Fragment e2 = a0Var.e(str);
                if (e2 == null) {
                    throw new IllegalStateException(c.a.a.a.a.g("No instantiated fragment for (", str, ")"));
                }
                if (M(2)) {
                    Log.v("FragmentManager", "restoreSaveState: added (" + str + "): " + e2);
                }
                a0Var.a(e2);
            }
        }
        Fragment fragment4 = null;
        if (uVar.f2081f != null) {
            this.f2059d = new ArrayList<>(uVar.f2081f.length);
            int i2 = 0;
            while (true) {
                b.n.c.b[] bVarArr = uVar.f2081f;
                if (i2 >= bVarArr.length) {
                    break;
                }
                b.n.c.b bVar = bVarArr[i2];
                Objects.requireNonNull(bVar);
                b.n.c.a aVar = new b.n.c.a(this);
                int i3 = 0;
                int i4 = 0;
                while (true) {
                    int[] iArr = bVar.f1936d;
                    if (i3 >= iArr.length) {
                        break;
                    }
                    b0.a aVar2 = new b0.a();
                    int i5 = i3 + 1;
                    aVar2.f1953a = iArr[i3];
                    if (M(2)) {
                        Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i4 + " base fragment #" + bVar.f1936d[i5]);
                    }
                    String str2 = bVar.f1937e.get(i4);
                    if (str2 != null) {
                        aVar2.f1954b = this.f2058c.e(str2);
                    } else {
                        aVar2.f1954b = fragment4;
                    }
                    aVar2.f1959g = g.b.values()[bVar.f1938f[i4]];
                    aVar2.f1960h = g.b.values()[bVar.f1939g[i4]];
                    int[] iArr2 = bVar.f1936d;
                    int i6 = i5 + 1;
                    int i7 = iArr2[i5];
                    aVar2.f1955c = i7;
                    int i8 = i6 + 1;
                    int i9 = iArr2[i6];
                    aVar2.f1956d = i9;
                    int i10 = i8 + 1;
                    int i11 = iArr2[i8];
                    aVar2.f1957e = i11;
                    int i12 = iArr2[i10];
                    aVar2.f1958f = i12;
                    aVar.f1944b = i7;
                    aVar.f1945c = i9;
                    aVar.f1946d = i11;
                    aVar.f1947e = i12;
                    aVar.b(aVar2);
                    i4++;
                    fragment4 = null;
                    i3 = i10 + 1;
                }
                aVar.f1948f = bVar.f1940h;
                aVar.f1950h = bVar.f1941i;
                aVar.r = bVar.f1942j;
                aVar.f1949g = true;
                aVar.f1951i = bVar.k;
                aVar.f1952j = bVar.l;
                aVar.k = bVar.m;
                aVar.l = bVar.n;
                aVar.m = bVar.o;
                aVar.n = bVar.p;
                aVar.o = bVar.q;
                aVar.h(1);
                if (M(2)) {
                    Log.v("FragmentManager", "restoreAllState: back stack #" + i2 + " (index " + aVar.r + "): " + aVar);
                    PrintWriter printWriter = new PrintWriter(new b.h.j.b("FragmentManager"));
                    aVar.j("  ", printWriter, false);
                    printWriter.close();
                }
                this.f2059d.add(aVar);
                i2++;
                fragment4 = null;
            }
        } else {
            this.f2059d = null;
        }
        this.f2064i.set(uVar.f2082g);
        String str3 = uVar.f2083h;
        if (str3 != null) {
            Fragment e3 = this.f2058c.e(str3);
            this.q = e3;
            s(e3);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void c(o<?> oVar, k kVar, Fragment fragment) {
        if (this.n != null) {
            throw new IllegalStateException("Already attached");
        }
        this.n = oVar;
        this.o = kVar;
        this.p = fragment;
        if (fragment != null) {
            l0();
        }
        if (oVar instanceof b.a.c) {
            b.a.c cVar = (b.a.c) oVar;
            OnBackPressedDispatcher c2 = cVar.c();
            this.f2062g = c2;
            Fragment fragment2 = cVar;
            if (fragment != null) {
                fragment2 = fragment;
            }
            b.a.b bVar = this.f2063h;
            Objects.requireNonNull(c2);
            b.p.g a2 = fragment2.a();
            if (((b.p.l) a2).f2130b != g.b.DESTROYED) {
                bVar.f569b.add(c2.new LifecycleOnBackPressedCancellable(a2, bVar));
            }
        }
        if (fragment != null) {
            v vVar = fragment.u.B;
            v vVar2 = vVar.f2086d.get(fragment.f319h);
            if (vVar2 == null) {
                vVar2 = new v(vVar.f2088f);
                vVar.f2086d.put(fragment.f319h, vVar2);
            }
            this.B = vVar2;
            return;
        }
        if (!(oVar instanceof b.p.a0)) {
            this.B = new v(false);
            return;
        }
        b.p.z q = ((b.p.a0) oVar).q();
        Object obj = v.f2084h;
        String canonicalName = v.class.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        String f2 = c.a.a.a.a.f("androidx.lifecycle.ViewModelProvider.DefaultKey:", canonicalName);
        b.p.x xVar = q.f2168a.get(f2);
        if (!v.class.isInstance(xVar)) {
            xVar = obj instanceof y.c ? ((y.c) obj).c(f2, v.class) : ((v.a) obj).a(v.class);
            b.p.x put = q.f2168a.put(f2, xVar);
            if (put != null) {
                put.d();
            }
        } else if (obj instanceof y.e) {
            ((y.e) obj).b(xVar);
        }
        this.B = (v) xVar;
    }

    public Parcelable c0() {
        ArrayList<String> arrayList;
        int size;
        if (this.A != null) {
            while (!this.A.isEmpty()) {
                this.A.remove(0).a();
            }
        }
        y();
        B(true);
        this.t = true;
        a0 a0Var = this.f2058c;
        Objects.requireNonNull(a0Var);
        ArrayList<x> arrayList2 = new ArrayList<>(a0Var.f1935b.size());
        for (y yVar : a0Var.f1935b.values()) {
            if (yVar != null) {
                Fragment fragment = yVar.f2102b;
                x xVar = new x(fragment);
                Fragment fragment2 = yVar.f2102b;
                if (fragment2.f315d <= -1 || xVar.p != null) {
                    xVar.p = fragment2.f316e;
                } else {
                    Bundle b2 = yVar.b();
                    xVar.p = b2;
                    if (yVar.f2102b.k != null) {
                        if (b2 == null) {
                            xVar.p = new Bundle();
                        }
                        xVar.p.putString("android:target_state", yVar.f2102b.k);
                        int i2 = yVar.f2102b.l;
                        if (i2 != 0) {
                            xVar.p.putInt("android:target_req_state", i2);
                        }
                    }
                }
                arrayList2.add(xVar);
                if (M(2)) {
                    Log.v("FragmentManager", "Saved state of " + fragment + ": " + xVar.p);
                }
            }
        }
        b.n.c.b[] bVarArr = null;
        if (arrayList2.isEmpty()) {
            if (M(2)) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        a0 a0Var2 = this.f2058c;
        synchronized (a0Var2.f1934a) {
            if (a0Var2.f1934a.isEmpty()) {
                arrayList = null;
            } else {
                arrayList = new ArrayList<>(a0Var2.f1934a.size());
                Iterator<Fragment> it = a0Var2.f1934a.iterator();
                while (it.hasNext()) {
                    Fragment next = it.next();
                    arrayList.add(next.f319h);
                    if (M(2)) {
                        Log.v("FragmentManager", "saveAllState: adding fragment (" + next.f319h + "): " + next);
                    }
                }
            }
        }
        ArrayList<b.n.c.a> arrayList3 = this.f2059d;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            bVarArr = new b.n.c.b[size];
            for (int i3 = 0; i3 < size; i3++) {
                bVarArr[i3] = new b.n.c.b(this.f2059d.get(i3));
                if (M(2)) {
                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i3 + ": " + this.f2059d.get(i3));
                }
            }
        }
        u uVar = new u();
        uVar.f2079d = arrayList2;
        uVar.f2080e = arrayList;
        uVar.f2081f = bVarArr;
        uVar.f2082g = this.f2064i.get();
        Fragment fragment3 = this.q;
        if (fragment3 != null) {
            uVar.f2083h = fragment3.f319h;
        }
        return uVar;
    }

    public void d(Fragment fragment) {
        if (M(2)) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.C) {
            fragment.C = false;
            if (fragment.n) {
                return;
            }
            this.f2058c.a(fragment);
            if (M(2)) {
                Log.v("FragmentManager", "add from attach: " + fragment);
            }
            if (N(fragment)) {
                this.s = true;
            }
        }
    }

    public void d0() {
        synchronized (this.f2056a) {
            ArrayList<g> arrayList = this.A;
            boolean z = (arrayList == null || arrayList.isEmpty()) ? false : true;
            boolean z2 = this.f2056a.size() == 1;
            if (z || z2) {
                this.n.f2050f.removeCallbacks(this.C);
                this.n.f2050f.post(this.C);
                l0();
            }
        }
    }

    public final void e(Fragment fragment) {
        HashSet<b.h.g.a> hashSet = this.f2065j.get(fragment);
        if (hashSet != null) {
            Iterator<b.h.g.a> it = hashSet.iterator();
            while (it.hasNext()) {
                b.h.g.a next = it.next();
                synchronized (next) {
                    if (!next.f1638a) {
                        next.f1638a = true;
                        next.f1640c = true;
                        a.InterfaceC0029a interfaceC0029a = next.f1639b;
                        if (interfaceC0029a != null) {
                            try {
                                ((b.n.c.f) interfaceC0029a).a();
                            } catch (Throwable th) {
                                synchronized (next) {
                                    next.f1640c = false;
                                    next.notifyAll();
                                    throw th;
                                }
                            }
                        }
                        synchronized (next) {
                            next.f1640c = false;
                            next.notifyAll();
                        }
                    }
                }
            }
            hashSet.clear();
            h(fragment);
            this.f2065j.remove(fragment);
        }
    }

    public void e0(Fragment fragment, boolean z) {
        ViewGroup I = I(fragment);
        if (I == null || !(I instanceof l)) {
            return;
        }
        ((l) I).setDrawDisappearingViewsLast(!z);
    }

    public final void f() {
        this.f2057b = false;
        this.y.clear();
        this.x.clear();
    }

    public void f0(Fragment fragment, g.b bVar) {
        if (fragment.equals(E(fragment.f319h)) && (fragment.v == null || fragment.u == this)) {
            fragment.Q = bVar;
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    public void g(b.n.c.a aVar, boolean z, boolean z2, boolean z3) {
        if (z) {
            aVar.l(z3);
        } else {
            aVar.k();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(aVar);
        arrayList2.add(Boolean.valueOf(z));
        if (z2) {
            i0.o(this, arrayList, arrayList2, 0, 1, true, this.k);
        }
        if (z3) {
            S(this.m, true);
        }
        Iterator it = ((ArrayList) this.f2058c.f()).iterator();
        while (it.hasNext()) {
            Fragment fragment = (Fragment) it.next();
            if (fragment != null && fragment.H != null && fragment.L && aVar.m(fragment.z)) {
                float f2 = fragment.N;
                if (f2 > 0.0f) {
                    fragment.H.setAlpha(f2);
                }
                if (z3) {
                    fragment.N = 0.0f;
                } else {
                    fragment.N = -1.0f;
                    fragment.L = false;
                }
            }
        }
    }

    public void g0(Fragment fragment) {
        if (fragment == null || (fragment.equals(E(fragment.f319h)) && (fragment.v == null || fragment.u == this))) {
            Fragment fragment2 = this.q;
            this.q = fragment;
            s(fragment2);
            s(this.q);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    public final void h(Fragment fragment) {
        fragment.w.v(1);
        if (fragment.H != null) {
            o0 o0Var = fragment.S;
            o0Var.f2052d.d(g.a.ON_DESTROY);
        }
        fragment.f315d = 1;
        fragment.F = false;
        fragment.Z();
        if (!fragment.F) {
            throw new p0(c.a.a.a.a.e("Fragment ", fragment, " did not call through to super.onDestroyView()"));
        }
        b.C0045b c0045b = ((b.q.a.b) b.q.a.a.b(fragment)).f2170b;
        int k = c0045b.f2172c.k();
        for (int i2 = 0; i2 < k; i2++) {
            Objects.requireNonNull(c0045b.f2172c.l(i2));
        }
        fragment.s = false;
        this.l.n(fragment, false);
        fragment.G = null;
        fragment.H = null;
        fragment.S = null;
        fragment.T.i(null);
        fragment.q = false;
    }

    public final void h0(Fragment fragment) {
        ViewGroup I = I(fragment);
        if (I != null) {
            if (I.getTag(2131362627) == null) {
                I.setTag(2131362627, fragment);
            }
            ((Fragment) I.getTag(2131362627)).x0(fragment.D());
        }
    }

    public void i(Fragment fragment) {
        if (M(2)) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (fragment.C) {
            return;
        }
        fragment.C = true;
        if (fragment.n) {
            if (M(2)) {
                Log.v("FragmentManager", "remove from detach: " + fragment);
            }
            this.f2058c.h(fragment);
            if (N(fragment)) {
                this.s = true;
            }
            h0(fragment);
        }
    }

    public void i0(Fragment fragment) {
        if (M(2)) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.B) {
            fragment.B = false;
            fragment.M = !fragment.M;
        }
    }

    public void j(Configuration configuration) {
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                fragment.F = true;
                fragment.w.j(configuration);
            }
        }
    }

    public final void j0() {
        Iterator it = ((ArrayList) this.f2058c.f()).iterator();
        while (it.hasNext()) {
            Fragment fragment = (Fragment) it.next();
            if (fragment != null) {
                V(fragment);
            }
        }
    }

    public boolean k(MenuItem menuItem) {
        if (this.m < 1) {
            return false;
        }
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                if (!fragment.B && fragment.w.k(menuItem)) {
                    return true;
                }
            }
        }
        return false;
    }

    public final void k0(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new b.h.j.b("FragmentManager"));
        o<?> oVar = this.n;
        if (oVar != null) {
            try {
                oVar.g("  ", null, printWriter, new String[0]);
                throw runtimeException;
            } catch (Exception e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
                throw runtimeException;
            }
        }
        try {
            x("  ", null, printWriter, new String[0]);
            throw runtimeException;
        } catch (Exception e3) {
            Log.e("FragmentManager", "Failed dumping state", e3);
            throw runtimeException;
        }
    }

    public void l() {
        this.t = false;
        this.u = false;
        v(1);
    }

    public final void l0() {
        synchronized (this.f2056a) {
            if (!this.f2056a.isEmpty()) {
                this.f2063h.f568a = true;
                return;
            }
            b.a.b bVar = this.f2063h;
            ArrayList<b.n.c.a> arrayList = this.f2059d;
            bVar.f568a = (arrayList != null ? arrayList.size() : 0) > 0 && O(this.p);
        }
    }

    public boolean m(Menu menu, MenuInflater menuInflater) {
        if (this.m < 1) {
            return false;
        }
        ArrayList<Fragment> arrayList = null;
        boolean z = false;
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                if (!fragment.B ? fragment.w.m(menu, menuInflater) | false : false) {
                    if (arrayList == null) {
                        arrayList = new ArrayList<>();
                    }
                    arrayList.add(fragment);
                    z = true;
                }
            }
        }
        if (this.f2060e != null) {
            for (int i2 = 0; i2 < this.f2060e.size(); i2++) {
                Fragment fragment2 = this.f2060e.get(i2);
                if (arrayList == null || !arrayList.contains(fragment2)) {
                    Objects.requireNonNull(fragment2);
                }
            }
        }
        this.f2060e = arrayList;
        return z;
    }

    public void n() {
        this.v = true;
        B(true);
        y();
        v(-1);
        this.n = null;
        this.o = null;
        this.p = null;
        if (this.f2062g != null) {
            Iterator<b.a.a> it = this.f2063h.f569b.iterator();
            while (it.hasNext()) {
                it.next().cancel();
            }
            this.f2062g = null;
        }
    }

    public void o() {
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                fragment.m0();
            }
        }
    }

    public void p(boolean z) {
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                fragment.w.p(z);
            }
        }
    }

    public boolean q(MenuItem menuItem) {
        if (this.m < 1) {
            return false;
        }
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                if (!fragment.B && fragment.w.q(menuItem)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void r(Menu menu) {
        if (this.m < 1) {
            return;
        }
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null && !fragment.B) {
                fragment.w.r(menu);
            }
        }
    }

    public final void s(Fragment fragment) {
        if (fragment == null || !fragment.equals(E(fragment.f319h))) {
            return;
        }
        boolean O = fragment.u.O(fragment);
        Boolean bool = fragment.m;
        if (bool == null || bool.booleanValue() != O) {
            fragment.m = Boolean.valueOf(O);
            r rVar = fragment.w;
            rVar.l0();
            rVar.s(rVar.q);
        }
    }

    public void t(boolean z) {
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null) {
                fragment.w.t(z);
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Fragment fragment = this.p;
        if (fragment != null) {
            sb.append(fragment.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.p)));
            sb.append("}");
        } else {
            sb.append(this.n.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.n)));
            sb.append("}");
        }
        sb.append("}}");
        return sb.toString();
    }

    public boolean u(Menu menu) {
        boolean z = false;
        if (this.m < 1) {
            return false;
        }
        for (Fragment fragment : this.f2058c.g()) {
            if (fragment != null && fragment.n0(menu)) {
                z = true;
            }
        }
        return z;
    }

    public final void v(int i2) {
        try {
            this.f2057b = true;
            this.f2058c.d(i2);
            S(i2, false);
            this.f2057b = false;
            B(true);
        } catch (Throwable th) {
            this.f2057b = false;
            throw th;
        }
    }

    public final void w() {
        if (this.w) {
            this.w = false;
            j0();
        }
    }

    public void x(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String f2 = c.a.a.a.a.f(str, "    ");
        a0 a0Var = this.f2058c;
        Objects.requireNonNull(a0Var);
        String str2 = str + "    ";
        if (!a0Var.f1935b.isEmpty()) {
            printWriter.print(str);
            printWriter.print("Active Fragments:");
            for (y yVar : a0Var.f1935b.values()) {
                printWriter.print(str);
                if (yVar != null) {
                    Fragment fragment = yVar.f2102b;
                    printWriter.println(fragment);
                    fragment.n(str2, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size3 = a0Var.f1934a.size();
        if (size3 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size3; i2++) {
                Fragment fragment2 = a0Var.f1934a.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment2.toString());
            }
        }
        ArrayList<Fragment> arrayList = this.f2060e;
        if (arrayList != null && (size2 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i3 = 0; i3 < size2; i3++) {
                Fragment fragment3 = this.f2060e.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(fragment3.toString());
            }
        }
        ArrayList<b.n.c.a> arrayList2 = this.f2059d;
        if (arrayList2 != null && (size = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i4 = 0; i4 < size; i4++) {
                b.n.c.a aVar = this.f2059d.get(i4);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i4);
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.j(f2, printWriter, true);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f2064i.get());
        synchronized (this.f2056a) {
            int size4 = this.f2056a.size();
            if (size4 > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                for (int i5 = 0; i5 < size4; i5++) {
                    Object obj = (e) this.f2056a.get(i5);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i5);
                    printWriter.print(": ");
                    printWriter.println(obj);
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.n);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.o);
        if (this.p != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.p);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.m);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.t);
        printWriter.print(" mStopped=");
        printWriter.print(this.u);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.v);
        if (this.s) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.s);
        }
    }

    public final void y() {
        if (this.f2065j.isEmpty()) {
            return;
        }
        for (Fragment fragment : this.f2065j.keySet()) {
            e(fragment);
            T(fragment, fragment.K());
        }
    }

    public void z(e eVar, boolean z) {
        if (!z) {
            if (this.n == null) {
                if (!this.v) {
                    throw new IllegalStateException("FragmentManager has not been attached to a host.");
                }
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            if (P()) {
                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
            }
        }
        synchronized (this.f2056a) {
            if (this.n == null) {
                if (!z) {
                    throw new IllegalStateException("Activity has been destroyed");
                }
            } else {
                this.f2056a.add(eVar);
                d0();
            }
        }
    }
}
