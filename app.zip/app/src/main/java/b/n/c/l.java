package b.n.c;

import androidx.fragment.app.Fragment;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\n.smali */
public class n {

    /* renamed from: a, reason: collision with root package name */
    public static final b.e.h<String, Class<?>> f2044a = new b.e.h<>();

    public static Class<?> b(ClassLoader classLoader, String str) {
        b.e.h<String, Class<?>> hVar = f2044a;
        Class<?> orDefault = hVar.getOrDefault(str, null);
        if (orDefault != null) {
            return orDefault;
        }
        Class<?> cls = Class.forName(str, false, classLoader);
        hVar.put(str, cls);
        return cls;
    }

    public static Class<? extends Fragment> c(ClassLoader classLoader, String str) {
        try {
            return b(classLoader, str);
        } catch (ClassCastException e2) {
            throw new Fragment.b(c.a.a.a.a.g("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e2);
        } catch (ClassNotFoundException e3) {
            throw new Fragment.b(c.a.a.a.a.g("Unable to instantiate fragment ", str, ": make sure class name exists"), e3);
        }
    }

    public Fragment a(ClassLoader classLoader, String str) {
        throw null;
    }
}
