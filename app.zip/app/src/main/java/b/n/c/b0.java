package b.n.c;

import androidx.fragment.app.Fragment;
import b.p.g;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\b0.smali */
public abstract class b0 {

    /* renamed from: b, reason: collision with root package name */
    public int f1944b;

    /* renamed from: c, reason: collision with root package name */
    public int f1945c;

    /* renamed from: d, reason: collision with root package name */
    public int f1946d;

    /* renamed from: e, reason: collision with root package name */
    public int f1947e;

    /* renamed from: f, reason: collision with root package name */
    public int f1948f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1949g;

    /* renamed from: h, reason: collision with root package name */
    public String f1950h;

    /* renamed from: i, reason: collision with root package name */
    public int f1951i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f1952j;
    public int k;
    public CharSequence l;
    public ArrayList<String> m;
    public ArrayList<String> n;

    /* renamed from: a, reason: collision with root package name */
    public ArrayList<a> f1943a = new ArrayList<>();
    public boolean o = false;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\b0$a.smali */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public int f1953a;

        /* renamed from: b, reason: collision with root package name */
        public Fragment f1954b;

        /* renamed from: c, reason: collision with root package name */
        public int f1955c;

        /* renamed from: d, reason: collision with root package name */
        public int f1956d;

        /* renamed from: e, reason: collision with root package name */
        public int f1957e;

        /* renamed from: f, reason: collision with root package name */
        public int f1958f;

        /* renamed from: g, reason: collision with root package name */
        public g.b f1959g;

        /* renamed from: h, reason: collision with root package name */
        public g.b f1960h;

        public a() {
        }

        public a(int i2, Fragment fragment) {
            this.f1953a = i2;
            this.f1954b = fragment;
            g.b bVar = g.b.RESUMED;
            this.f1959g = bVar;
            this.f1960h = bVar;
        }

        public a(int i2, Fragment fragment, g.b bVar) {
            this.f1953a = i2;
            this.f1954b = fragment;
            this.f1959g = fragment.Q;
            this.f1960h = bVar;
        }
    }

    public b0(n nVar, ClassLoader classLoader) {
    }

    public void b(a aVar) {
        this.f1943a.add(aVar);
        aVar.f1955c = this.f1944b;
        aVar.f1956d = this.f1945c;
        aVar.f1957e = this.f1946d;
        aVar.f1958f = this.f1947e;
    }

    public abstract int c();

    public abstract void d();

    public abstract void e(int i2, Fragment fragment, String str, int i3);

    public abstract b0 f(Fragment fragment);

    public abstract b0 g(Fragment fragment, g.b bVar);
}
