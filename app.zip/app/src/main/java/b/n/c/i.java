package b.n.c;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\j.smali */
public class j extends AnimationSet implements Runnable {

    /* renamed from: d, reason: collision with root package name */
    public final ViewGroup f2014d;

    /* renamed from: e, reason: collision with root package name */
    public final View f2015e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f2016f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f2017g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f2018h;

    public j(Animation animation, ViewGroup viewGroup, View view) {
        super(false);
        this.f2018h = true;
        this.f2014d = viewGroup;
        this.f2015e = view;
        addAnimation(animation);
        viewGroup.post(this);
    }

    @Override // android.view.animation.AnimationSet, android.view.animation.Animation
    public boolean getTransformation(long j2, Transformation transformation) {
        this.f2018h = true;
        if (this.f2016f) {
            return !this.f2017g;
        }
        if (!super.getTransformation(j2, transformation)) {
            this.f2016f = true;
            b.h.k.k.a(this.f2014d, this);
        }
        return true;
    }

    @Override // android.view.animation.Animation
    public boolean getTransformation(long j2, Transformation transformation, float f2) {
        this.f2018h = true;
        if (this.f2016f) {
            return !this.f2017g;
        }
        if (!super.getTransformation(j2, transformation, f2)) {
            this.f2016f = true;
            b.h.k.k.a(this.f2014d, this);
        }
        return true;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.f2016f || !this.f2018h) {
            this.f2014d.endViewTransition(this.f2015e);
            this.f2017g = true;
        } else {
            this.f2018h = false;
            this.f2014d.post(this);
        }
    }
}
