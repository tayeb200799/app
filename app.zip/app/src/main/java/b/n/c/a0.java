package b.n.c;

import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\a0.smali */
public class a0 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList<Fragment> f1934a = new ArrayList<>();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap<String, y> f1935b = new HashMap<>();

    public void a(Fragment fragment) {
        if (this.f1934a.contains(fragment)) {
            throw new IllegalStateException("Fragment already added: " + fragment);
        }
        synchronized (this.f1934a) {
            this.f1934a.add(fragment);
        }
        fragment.n = true;
    }

    public void b() {
        this.f1935b.values().removeAll(Collections.singleton(null));
    }

    public boolean c(String str) {
        return this.f1935b.containsKey(str);
    }

    public void d(int i2) {
        Iterator<Fragment> it = this.f1934a.iterator();
        while (it.hasNext()) {
            y yVar = this.f1935b.get(it.next().f319h);
            if (yVar != null) {
                yVar.f2103c = i2;
            }
        }
        for (y yVar2 : this.f1935b.values()) {
            if (yVar2 != null) {
                yVar2.f2103c = i2;
            }
        }
    }

    public Fragment e(String str) {
        y yVar = this.f1935b.get(str);
        if (yVar != null) {
            return yVar.f2102b;
        }
        return null;
    }

    public List<Fragment> f() {
        ArrayList arrayList = new ArrayList();
        for (y yVar : this.f1935b.values()) {
            if (yVar != null) {
                arrayList.add(yVar.f2102b);
            } else {
                arrayList.add(null);
            }
        }
        return arrayList;
    }

    public List<Fragment> g() {
        ArrayList arrayList;
        if (this.f1934a.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f1934a) {
            arrayList = new ArrayList(this.f1934a);
        }
        return arrayList;
    }

    public void h(Fragment fragment) {
        synchronized (this.f1934a) {
            this.f1934a.remove(fragment);
        }
        fragment.n = false;
    }
}
