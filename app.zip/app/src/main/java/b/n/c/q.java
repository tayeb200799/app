package b.n.c;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\q.smali */
public class q {

    /* renamed from: a, reason: collision with root package name */
    public final CopyOnWriteArrayList<a> f2054a = new CopyOnWriteArrayList<>();

    /* renamed from: b, reason: collision with root package name */
    public final r f2055b;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\q$a.smali */
    public static final class a {
    }

    public q(r rVar) {
        this.f2055b = rVar;
    }

    public void a(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.a(fragment, bundle, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void b(Fragment fragment, Context context, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.b(fragment, context, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void c(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.c(fragment, bundle, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void d(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.d(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void e(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.e(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void f(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.f(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void g(Fragment fragment, Context context, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.g(fragment, context, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void h(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.h(fragment, bundle, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void i(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.i(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void j(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.j(fragment, bundle, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void k(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.k(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void l(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.l(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void m(Fragment fragment, View view, Bundle bundle, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.m(fragment, view, bundle, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }

    public void n(Fragment fragment, boolean z) {
        Fragment fragment2 = this.f2055b.p;
        if (fragment2 != null) {
            fragment2.E().l.n(fragment, true);
        }
        Iterator<a> it = this.f2054a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z) {
                Objects.requireNonNull(next);
                throw null;
            }
            Objects.requireNonNull(next);
        }
    }
}
