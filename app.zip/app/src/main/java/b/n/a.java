package b.n.c;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.fragment.app.Fragment;
import b.n.c.b0;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\b.smali */
public final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();

    /* renamed from: d, reason: collision with root package name */
    public final int[] f1933d;

    /* renamed from: e, reason: collision with root package name */
    public final ArrayList<String> f1934e;

    /* renamed from: f, reason: collision with root package name */
    public final int[] f1935f;

    /* renamed from: g, reason: collision with root package name */
    public final int[] f1936g;

    /* renamed from: h, reason: collision with root package name */
    public final int f1937h;

    /* renamed from: i, reason: collision with root package name */
    public final String f1938i;

    /* renamed from: j, reason: collision with root package name */
    public final int f1939j;
    public final int k;
    public final CharSequence l;
    public final int m;
    public final CharSequence n;
    public final ArrayList<String> o;
    public final ArrayList<String> p;
    public final boolean q;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\b$a.smali */
    public static class a implements Parcelable.Creator<b> {
        @Override // android.os.Parcelable.Creator
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public b[] newArray(int i2) {
            return new b[i2];
        }
    }

    public b(Parcel parcel) {
        this.f1933d = parcel.createIntArray();
        this.f1934e = parcel.createStringArrayList();
        this.f1935f = parcel.createIntArray();
        this.f1936g = parcel.createIntArray();
        this.f1937h = parcel.readInt();
        this.f1938i = parcel.readString();
        this.f1939j = parcel.readInt();
        this.k = parcel.readInt();
        this.l = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.m = parcel.readInt();
        this.n = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.o = parcel.createStringArrayList();
        this.p = parcel.createStringArrayList();
        this.q = parcel.readInt() != 0;
    }

    public b(b.n.c.a aVar) {
        int size = aVar.f1940a.size();
        this.f1933d = new int[size * 5];
        if (!aVar.f1946g) {
            throw new IllegalStateException("Not on back stack");
        }
        this.f1934e = new ArrayList<>(size);
        this.f1935f = new int[size];
        this.f1936g = new int[size];
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            b0.a aVar2 = aVar.f1940a.get(i2);
            int i4 = i3 + 1;
            this.f1933d[i3] = aVar2.f1950a;
            ArrayList<String> arrayList = this.f1934e;
            Fragment fragment = aVar2.f1951b;
            arrayList.add(fragment != null ? fragment.f317h : null);
            int[] iArr = this.f1933d;
            int i5 = i4 + 1;
            iArr[i4] = aVar2.f1952c;
            int i6 = i5 + 1;
            iArr[i5] = aVar2.f1953d;
            int i7 = i6 + 1;
            iArr[i6] = aVar2.f1954e;
            iArr[i7] = aVar2.f1955f;
            this.f1935f[i2] = aVar2.f1956g.ordinal();
            this.f1936g[i2] = aVar2.f1957h.ordinal();
            i2++;
            i3 = i7 + 1;
        }
        this.f1937h = aVar.f1945f;
        this.f1938i = aVar.f1947h;
        this.f1939j = aVar.r;
        this.k = aVar.f1948i;
        this.l = aVar.f1949j;
        this.m = aVar.k;
        this.n = aVar.l;
        this.o = aVar.m;
        this.p = aVar.n;
        this.q = aVar.o;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f1933d);
        parcel.writeStringList(this.f1934e);
        parcel.writeIntArray(this.f1935f);
        parcel.writeIntArray(this.f1936g);
        parcel.writeInt(this.f1937h);
        parcel.writeString(this.f1938i);
        parcel.writeInt(this.f1939j);
        parcel.writeInt(this.k);
        TextUtils.writeToParcel(this.l, parcel, 0);
        parcel.writeInt(this.m);
        TextUtils.writeToParcel(this.n, parcel, 0);
        parcel.writeStringList(this.o);
        parcel.writeStringList(this.p);
        parcel.writeInt(this.q ? 1 : 0);
    }
}
