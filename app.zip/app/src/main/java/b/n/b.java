package b.n;

import android.R;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\b.smali */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f1932a = {R.attr.name, R.attr.id, R.attr.tag};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f1933b = {R.attr.name, R.attr.tag};
}
