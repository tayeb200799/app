package b.c.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b.smali */
public class b<K, V> implements Iterable<Map.Entry<K, V>> {

    /* renamed from: d, reason: collision with root package name */
    public c<K, V> f1127d;

    /* renamed from: e, reason: collision with root package name */
    public c<K, V> f1128e;

    /* renamed from: f, reason: collision with root package name */
    public WeakHashMap<f<K, V>, Boolean> f1129f = new WeakHashMap<>();

    /* renamed from: g, reason: collision with root package name */
    public int f1130g = 0;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b$a.smali */
    public static class a<K, V> extends e<K, V> {
        public a(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        @Override // b.c.a.b.b.e
        public c<K, V> b(c<K, V> cVar) {
            return cVar.f1134g;
        }

        @Override // b.c.a.b.b.e
        public c<K, V> c(c<K, V> cVar) {
            return cVar.f1133f;
        }
    }

    /* renamed from: b.c.a.b.b$b, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b$b.smali */
    public static class C0019b<K, V> extends e<K, V> {
        public C0019b(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        @Override // b.c.a.b.b.e
        public c<K, V> b(c<K, V> cVar) {
            return cVar.f1133f;
        }

        @Override // b.c.a.b.b.e
        public c<K, V> c(c<K, V> cVar) {
            return cVar.f1134g;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b$c.smali */
    public static class c<K, V> implements Map.Entry<K, V> {

        /* renamed from: d, reason: collision with root package name */
        public final K f1131d;

        /* renamed from: e, reason: collision with root package name */
        public final V f1132e;

        /* renamed from: f, reason: collision with root package name */
        public c<K, V> f1133f;

        /* renamed from: g, reason: collision with root package name */
        public c<K, V> f1134g;

        public c(K k, V v) {
            this.f1131d = k;
            this.f1132e = v;
        }

        @Override // java.util.Map.Entry
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.f1131d.equals(cVar.f1131d) && this.f1132e.equals(cVar.f1132e);
        }

        @Override // java.util.Map.Entry
        public K getKey() {
            return this.f1131d;
        }

        @Override // java.util.Map.Entry
        public V getValue() {
            return this.f1132e;
        }

        @Override // java.util.Map.Entry
        public int hashCode() {
            return this.f1131d.hashCode() ^ this.f1132e.hashCode();
        }

        @Override // java.util.Map.Entry
        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            return this.f1131d + "=" + this.f1132e;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b$d.smali */
    public class d implements Iterator<Map.Entry<K, V>>, f<K, V> {

        /* renamed from: d, reason: collision with root package name */
        public c<K, V> f1135d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f1136e = true;

        public d() {
        }

        @Override // b.c.a.b.b.f
        public void a(c<K, V> cVar) {
            c<K, V> cVar2 = this.f1135d;
            if (cVar == cVar2) {
                c<K, V> cVar3 = cVar2.f1134g;
                this.f1135d = cVar3;
                this.f1136e = cVar3 == null;
            }
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            if (this.f1136e) {
                return b.this.f1127d != null;
            }
            c<K, V> cVar = this.f1135d;
            return (cVar == null || cVar.f1133f == null) ? false : true;
        }

        @Override // java.util.Iterator
        public Object next() {
            if (this.f1136e) {
                this.f1136e = false;
                this.f1135d = b.this.f1127d;
            } else {
                c<K, V> cVar = this.f1135d;
                this.f1135d = cVar != null ? cVar.f1133f : null;
            }
            return this.f1135d;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b$e.smali */
    public static abstract class e<K, V> implements Iterator<Map.Entry<K, V>>, f<K, V> {

        /* renamed from: d, reason: collision with root package name */
        public c<K, V> f1138d;

        /* renamed from: e, reason: collision with root package name */
        public c<K, V> f1139e;

        public e(c<K, V> cVar, c<K, V> cVar2) {
            this.f1138d = cVar2;
            this.f1139e = cVar;
        }

        @Override // b.c.a.b.b.f
        public void a(c<K, V> cVar) {
            c<K, V> cVar2 = null;
            if (this.f1138d == cVar && cVar == this.f1139e) {
                this.f1139e = null;
                this.f1138d = null;
            }
            c<K, V> cVar3 = this.f1138d;
            if (cVar3 == cVar) {
                this.f1138d = b(cVar3);
            }
            c<K, V> cVar4 = this.f1139e;
            if (cVar4 == cVar) {
                c<K, V> cVar5 = this.f1138d;
                if (cVar4 != cVar5 && cVar5 != null) {
                    cVar2 = c(cVar4);
                }
                this.f1139e = cVar2;
            }
        }

        public abstract c<K, V> b(c<K, V> cVar);

        public abstract c<K, V> c(c<K, V> cVar);

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f1139e != null;
        }

        @Override // java.util.Iterator
        public Object next() {
            c<K, V> cVar = this.f1139e;
            c<K, V> cVar2 = this.f1138d;
            this.f1139e = (cVar == cVar2 || cVar2 == null) ? null : c(cVar);
            return cVar;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\b$f.smali */
    public interface f<K, V> {
        void a(c<K, V> cVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0048, code lost:
    
        if (r3.hasNext() != false) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0050, code lost:
    
        if (((b.c.a.b.b.e) r7).hasNext() != false) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:?, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0053, code lost:
    
        return false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean equals(java.lang.Object r7) {
        /*
            r6 = this;
            r0 = 1
            if (r7 != r6) goto L4
            return r0
        L4:
            boolean r1 = r7 instanceof b.c.a.b.b
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            b.c.a.b.b r7 = (b.c.a.b.b) r7
            int r1 = r6.f1130g
            int r3 = r7.f1130g
            if (r1 == r3) goto L13
            return r2
        L13:
            java.util.Iterator r1 = r6.iterator()
            java.util.Iterator r7 = r7.iterator()
        L1b:
            r3 = r1
            b.c.a.b.b$e r3 = (b.c.a.b.b.e) r3
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L44
            r4 = r7
            b.c.a.b.b$e r4 = (b.c.a.b.b.e) r4
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L44
            java.lang.Object r3 = r3.next()
            java.util.Map$Entry r3 = (java.util.Map.Entry) r3
            java.lang.Object r4 = r4.next()
            if (r3 != 0) goto L3b
            if (r4 != 0) goto L43
        L3b:
            if (r3 == 0) goto L1b
            boolean r3 = r3.equals(r4)
            if (r3 != 0) goto L1b
        L43:
            return r2
        L44:
            boolean r1 = r3.hasNext()
            if (r1 != 0) goto L53
            b.c.a.b.b$e r7 = (b.c.a.b.b.e) r7
            boolean r7 = r7.hasNext()
            if (r7 != 0) goto L53
            goto L54
        L53:
            r0 = 0
        L54:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b.c.a.b.b.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        Iterator<Map.Entry<K, V>> it = iterator();
        int i2 = 0;
        while (true) {
            e eVar = (e) it;
            if (!eVar.hasNext()) {
                return i2;
            }
            i2 += ((Map.Entry) eVar.next()).hashCode();
        }
    }

    @Override // java.lang.Iterable
    public Iterator<Map.Entry<K, V>> iterator() {
        a aVar = new a(this.f1127d, this.f1128e);
        this.f1129f.put(aVar, Boolean.FALSE);
        return aVar;
    }

    public c<K, V> o(K k) {
        c<K, V> cVar = this.f1127d;
        while (cVar != null && !cVar.f1131d.equals(k)) {
            cVar = cVar.f1133f;
        }
        return cVar;
    }

    public b<K, V>.d p() {
        b<K, V>.d dVar = new d();
        this.f1129f.put(dVar, Boolean.FALSE);
        return dVar;
    }

    public c<K, V> q(K k, V v) {
        c<K, V> cVar = new c<>(k, v);
        this.f1130g++;
        c<K, V> cVar2 = this.f1128e;
        if (cVar2 == null) {
            this.f1127d = cVar;
            this.f1128e = cVar;
            return cVar;
        }
        cVar2.f1133f = cVar;
        cVar.f1134g = cVar2;
        this.f1128e = cVar;
        return cVar;
    }

    public V r(K k, V v) {
        c<K, V> o = o(k);
        if (o != null) {
            return o.f1132e;
        }
        q(k, v);
        return null;
    }

    public V s(K k) {
        c<K, V> o = o(k);
        if (o == null) {
            return null;
        }
        this.f1130g--;
        if (!this.f1129f.isEmpty()) {
            Iterator<f<K, V>> it = this.f1129f.keySet().iterator();
            while (it.hasNext()) {
                it.next().a(o);
            }
        }
        c<K, V> cVar = o.f1134g;
        if (cVar != null) {
            cVar.f1133f = o.f1133f;
        } else {
            this.f1127d = o.f1133f;
        }
        c<K, V> cVar2 = o.f1133f;
        if (cVar2 != null) {
            cVar2.f1134g = cVar;
        } else {
            this.f1128e = cVar;
        }
        o.f1133f = null;
        o.f1134g = null;
        return o.f1132e;
    }

    public String toString() {
        StringBuilder n = c.a.a.a.a.n("[");
        Iterator<Map.Entry<K, V>> it = iterator();
        while (true) {
            e eVar = (e) it;
            if (!eVar.hasNext()) {
                n.append("]");
                return n.toString();
            }
            n.append(((Map.Entry) eVar.next()).toString());
            if (eVar.hasNext()) {
                n.append(", ");
            }
        }
    }
}
