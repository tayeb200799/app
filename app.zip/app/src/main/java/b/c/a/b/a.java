package b.c.a.b;

import b.c.a.b.b;
import java.util.HashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\c\a\b\a.smali */
public class a<K, V> extends b<K, V> {

    /* renamed from: h, reason: collision with root package name */
    public HashMap<K, b.c<K, V>> f1129h = new HashMap<>();

    public boolean contains(K k) {
        return this.f1129h.containsKey(k);
    }

    @Override // b.c.a.b.b
    public b.c<K, V> o(K k) {
        return this.f1129h.get(k);
    }

    @Override // b.c.a.b.b
    public V r(K k, V v) {
        b.c<K, V> cVar = this.f1129h.get(k);
        if (cVar != null) {
            return cVar.f1135e;
        }
        this.f1129h.put(k, q(k, v));
        return null;
    }

    @Override // b.c.a.b.b
    public V s(K k) {
        V v = (V) super.s(k);
        this.f1129h.remove(k);
        return v;
    }
}
