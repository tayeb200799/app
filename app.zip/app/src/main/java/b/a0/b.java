package b.b;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import b.b.i.c1;
import b.b.i.y0;
import java.lang.reflect.Field;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\a.smali */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static Field f578a;

    /* renamed from: b, reason: collision with root package name */
    public static boolean f579b;

    /* renamed from: c, reason: collision with root package name */
    public static Class<?> f580c;

    /* renamed from: d, reason: collision with root package name */
    public static boolean f581d;

    /* renamed from: e, reason: collision with root package name */
    public static Field f582e;

    /* renamed from: f, reason: collision with root package name */
    public static boolean f583f;

    /* renamed from: g, reason: collision with root package name */
    public static Field f584g;

    /* renamed from: h, reason: collision with root package name */
    public static boolean f585h;

    public static void a(Object obj) {
        if (!f581d) {
            try {
                f580c = Class.forName("android.content.res.ThemedResourceCache");
            } catch (ClassNotFoundException e2) {
                Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", e2);
            }
            f581d = true;
        }
        Class<?> cls = f580c;
        if (cls == null) {
            return;
        }
        if (!f583f) {
            try {
                Field declaredField = cls.getDeclaredField("mUnthemedEntries");
                f582e = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e3) {
                Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", e3);
            }
            f583f = true;
        }
        Field field = f582e;
        if (field == null) {
            return;
        }
        LongSparseArray longSparseArray = null;
        try {
            longSparseArray = (LongSparseArray) field.get(obj);
        } catch (IllegalAccessException e4) {
            Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", e4);
        }
        if (longSparseArray != null) {
            longSparseArray.clear();
        }
    }

    public static InputConnection b(InputConnection inputConnection, EditorInfo editorInfo, View view) {
        if (inputConnection != null && editorInfo.hintText == null) {
            ViewParent parent = view.getParent();
            while (true) {
                if (!(parent instanceof View)) {
                    break;
                }
                if (parent instanceof c1) {
                    editorInfo.hintText = ((c1) parent).a();
                    break;
                }
                parent = parent.getParent();
            }
        }
        return inputConnection;
    }

    public static void c(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setTooltipText(charSequence);
            return;
        }
        y0 y0Var = y0.m;
        if (y0Var != null && y0Var.f1094d == view) {
            y0.c(null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new y0(view, charSequence);
            return;
        }
        y0 y0Var2 = y0.n;
        if (y0Var2 != null && y0Var2.f1094d == view) {
            y0Var2.b();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }
}
