package b.b.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\a.smali */
public abstract class a {

    /* renamed from: b.b.c.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\a$a.smali */
    public static class C0010a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a, reason: collision with root package name */
        public int f596a;

        public C0010a(int i2, int i3) {
            super(i2, i3);
            this.f596a = 0;
            this.f596a = 8388627;
        }

        public C0010a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f596a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.b.b.f587b);
            this.f596a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public C0010a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f596a = 0;
        }

        public C0010a(C0010a c0010a) {
            super((ViewGroup.MarginLayoutParams) c0010a);
            this.f596a = 0;
            this.f596a = c0010a.f596a;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\a$b.smali */
    public interface b {
        void a(boolean z);
    }

    @Deprecated
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\b\c\a$c.smali */
    public static abstract class c {
        public abstract void a();
    }

    public abstract void a(boolean z);

    public abstract Context b();

    public abstract void c(boolean z);
}
