package b.e;

import b.e.g.b;
import b.e.g.c;
import b.e.g.e;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\e\a.smali */
public class a<K, V> extends h<K, V> implements Map<K, V> {
    public g<K, V> k;

    /* renamed from: b.e.a$a */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\e\a$a.smali */
    public class C0020a extends g<K, V> {
        public C0020a() {
        }

        @Override // b.e.g
        public void a() {
            a.this.clear();
        }

        @Override // b.e.g
        public Object b(int i2, int i3) {
            return a.this.f1196e[(i2 << 1) + i3];
        }

        @Override // b.e.g
        public Map<K, V> c() {
            return a.this;
        }

        @Override // b.e.g
        public int d() {
            return a.this.f1197f;
        }

        @Override // b.e.g
        public int e(Object obj) {
            return a.this.e(obj);
        }

        @Override // b.e.g
        public int f(Object obj) {
            return a.this.g(obj);
        }

        @Override // b.e.g
        public void g(K k, V v) {
            a.this.put(k, v);
        }

        @Override // b.e.g
        public void h(int i2) {
            a.this.j(i2);
        }

        @Override // b.e.g
        public V i(int i2, V v) {
            return a.this.k(i2, v);
        }
    }

    public a() {
    }

    public a(int i2) {
        super(i2);
    }

    public a(h hVar) {
        if (hVar != null) {
            i(hVar);
        }
    }

    @Override // java.util.Map
    public Set<Map.Entry<K, V>> entrySet() {
        g<K, V> m = m();
        if (m.f1176a == null) {
            m.f1176a = m.new b();
        }
        return m.f1176a;
    }

    @Override // java.util.Map
    public Set<K> keySet() {
        g<K, V> m = m();
        if (m.f1177b == null) {
            m.f1177b = m.new c();
        }
        return m.f1177b;
    }

    public final g<K, V> m() {
        if (this.k == null) {
            this.k = new C0020a();
        }
        return this.k;
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> map) {
        b(map.size() + this.f1197f);
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map
    public Collection<V> values() {
        g<K, V> m = m();
        if (m.f1178c == null) {
            m.f1178c = m.new e();
        }
        return m.f1178c;
    }
}
