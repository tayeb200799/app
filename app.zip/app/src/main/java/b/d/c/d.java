package b.e;

import java.util.Map;

/* JADX INFO: Add missing generic type declarations: [E] */
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\e\b.smali */
public class b<E> extends g<E, E> {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ c f1153d;

    public b(c cVar) {
        this.f1153d = cVar;
    }

    @Override // b.e.g
    public void a() {
        this.f1153d.clear();
    }

    @Override // b.e.g
    public Object b(int i2, int i3) {
        return this.f1153d.f1158e[i2];
    }

    @Override // b.e.g
    public Map<E, E> c() {
        throw new UnsupportedOperationException("not a map");
    }

    @Override // b.e.g
    public int d() {
        return this.f1153d.f1159f;
    }

    @Override // b.e.g
    public int e(Object obj) {
        return this.f1153d.indexOf(obj);
    }

    @Override // b.e.g
    public int f(Object obj) {
        return this.f1153d.indexOf(obj);
    }

    @Override // b.e.g
    public void g(E e2, E e3) {
        this.f1153d.add(e2);
    }

    @Override // b.e.g
    public void h(int i2) {
        this.f1153d.s(i2);
    }

    @Override // b.e.g
    public E i(int i2, E e2) {
        throw new UnsupportedOperationException("not a map");
    }
}
