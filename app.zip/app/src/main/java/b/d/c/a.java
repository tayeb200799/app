package b.d.c;

import android.graphics.drawable.Drawable;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\d\c\e.smali */
public class e extends Drawable {

    /* renamed from: a, reason: collision with root package name */
    public static final double f1151a = Math.cos(Math.toRadians(45.0d));

    public static float a(float f2, float f3, boolean z) {
        if (!z) {
            return f2;
        }
        return (float) (((1.0d - f1151a) * f3) + f2);
    }

    public static float b(float f2, float f3, boolean z) {
        if (!z) {
            return f2 * 1.5f;
        }
        return (float) (((1.0d - f1151a) * f3) + (f2 * 1.5f));
    }
}
