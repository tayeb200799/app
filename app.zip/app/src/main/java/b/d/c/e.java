package b.e;

import b.e.g;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\e\c.smali */
public final class c<E> implements Collection<E>, Set<E> {

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f1154h = new int[0];

    /* renamed from: i, reason: collision with root package name */
    public static final Object[] f1155i = new Object[0];

    /* renamed from: j, reason: collision with root package name */
    public static Object[] f1156j;
    public static int k;
    public static Object[] l;
    public static int m;

    /* renamed from: d, reason: collision with root package name */
    public int[] f1157d;

    /* renamed from: e, reason: collision with root package name */
    public Object[] f1158e;

    /* renamed from: f, reason: collision with root package name */
    public int f1159f;

    /* renamed from: g, reason: collision with root package name */
    public g<E, E> f1160g;

    public c() {
        this(0);
    }

    public c(int i2) {
        if (i2 == 0) {
            this.f1157d = f1154h;
            this.f1158e = f1155i;
        } else {
            o(i2);
        }
        this.f1159f = 0;
    }

    public static void p(int[] iArr, Object[] objArr, int i2) {
        if (iArr.length == 8) {
            synchronized (c.class) {
                if (m < 10) {
                    objArr[0] = l;
                    objArr[1] = iArr;
                    for (int i3 = i2 - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    l = objArr;
                    m++;
                }
            }
            return;
        }
        if (iArr.length == 4) {
            synchronized (c.class) {
                if (k < 10) {
                    objArr[0] = f1156j;
                    objArr[1] = iArr;
                    for (int i4 = i2 - 1; i4 >= 2; i4--) {
                        objArr[i4] = null;
                    }
                    f1156j = objArr;
                    k++;
                }
            }
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean add(E e2) {
        int i2;
        int q;
        if (e2 == null) {
            q = r();
            i2 = 0;
        } else {
            int hashCode = e2.hashCode();
            i2 = hashCode;
            q = q(e2, hashCode);
        }
        if (q >= 0) {
            return false;
        }
        int i3 = ~q;
        int i4 = this.f1159f;
        int[] iArr = this.f1157d;
        if (i4 >= iArr.length) {
            int i5 = 4;
            if (i4 >= 8) {
                i5 = (i4 >> 1) + i4;
            } else if (i4 >= 4) {
                i5 = 8;
            }
            Object[] objArr = this.f1158e;
            o(i5);
            int[] iArr2 = this.f1157d;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.f1158e, 0, objArr.length);
            }
            p(iArr, objArr, this.f1159f);
        }
        int i6 = this.f1159f;
        if (i3 < i6) {
            int[] iArr3 = this.f1157d;
            int i7 = i3 + 1;
            System.arraycopy(iArr3, i3, iArr3, i7, i6 - i3);
            Object[] objArr2 = this.f1158e;
            System.arraycopy(objArr2, i3, objArr2, i7, this.f1159f - i3);
        }
        this.f1157d[i3] = i2;
        this.f1158e[i3] = e2;
        this.f1159f++;
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean addAll(Collection<? extends E> collection) {
        int size = collection.size() + this.f1159f;
        int[] iArr = this.f1157d;
        boolean z = false;
        if (iArr.length < size) {
            Object[] objArr = this.f1158e;
            o(size);
            int i2 = this.f1159f;
            if (i2 > 0) {
                System.arraycopy(iArr, 0, this.f1157d, 0, i2);
                System.arraycopy(objArr, 0, this.f1158e, 0, this.f1159f);
            }
            p(iArr, objArr, this.f1159f);
        }
        Iterator<? extends E> it = collection.iterator();
        while (it.hasNext()) {
            z |= add(it.next());
        }
        return z;
    }

    @Override // java.util.Collection, java.util.Set
    public void clear() {
        int i2 = this.f1159f;
        if (i2 != 0) {
            p(this.f1157d, this.f1158e, i2);
            this.f1157d = f1154h;
            this.f1158e = f1155i;
            this.f1159f = 0;
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean containsAll(Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (this.f1159f != set.size()) {
                return false;
            }
            for (int i2 = 0; i2 < this.f1159f; i2++) {
                try {
                    if (!set.contains(this.f1158e[i2])) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    @Override // java.util.Collection, java.util.Set
    public int hashCode() {
        int[] iArr = this.f1157d;
        int i2 = this.f1159f;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            i3 += iArr[i4];
        }
        return i3;
    }

    public int indexOf(Object obj) {
        return obj == null ? r() : q(obj, obj.hashCode());
    }

    @Override // java.util.Collection, java.util.Set
    public boolean isEmpty() {
        return this.f1159f <= 0;
    }

    @Override // java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator<E> iterator() {
        if (this.f1160g == null) {
            this.f1160g = new b(this);
        }
        g<E, E> gVar = this.f1160g;
        if (gVar.f1177b == null) {
            gVar.f1177b = new g.c();
        }
        return gVar.f1177b.iterator();
    }

    public final void o(int i2) {
        if (i2 == 8) {
            synchronized (c.class) {
                Object[] objArr = l;
                if (objArr != null) {
                    this.f1158e = objArr;
                    l = (Object[]) objArr[0];
                    this.f1157d = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    m--;
                    return;
                }
            }
        } else if (i2 == 4) {
            synchronized (c.class) {
                Object[] objArr2 = f1156j;
                if (objArr2 != null) {
                    this.f1158e = objArr2;
                    f1156j = (Object[]) objArr2[0];
                    this.f1157d = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    k--;
                    return;
                }
            }
        }
        this.f1157d = new int[i2];
        this.f1158e = new Object[i2];
    }

    public final int q(Object obj, int i2) {
        int i3 = this.f1159f;
        if (i3 == 0) {
            return -1;
        }
        int a2 = d.a(this.f1157d, i3, i2);
        if (a2 < 0 || obj.equals(this.f1158e[a2])) {
            return a2;
        }
        int i4 = a2 + 1;
        while (i4 < i3 && this.f1157d[i4] == i2) {
            if (obj.equals(this.f1158e[i4])) {
                return i4;
            }
            i4++;
        }
        for (int i5 = a2 - 1; i5 >= 0 && this.f1157d[i5] == i2; i5--) {
            if (obj.equals(this.f1158e[i5])) {
                return i5;
            }
        }
        return ~i4;
    }

    public final int r() {
        int i2 = this.f1159f;
        if (i2 == 0) {
            return -1;
        }
        int a2 = d.a(this.f1157d, i2, 0);
        if (a2 < 0 || this.f1158e[a2] == null) {
            return a2;
        }
        int i3 = a2 + 1;
        while (i3 < i2 && this.f1157d[i3] == 0) {
            if (this.f1158e[i3] == null) {
                return i3;
            }
            i3++;
        }
        for (int i4 = a2 - 1; i4 >= 0 && this.f1157d[i4] == 0; i4--) {
            if (this.f1158e[i4] == null) {
                return i4;
            }
        }
        return ~i3;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf < 0) {
            return false;
        }
        s(indexOf);
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean removeAll(Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        boolean z = false;
        while (it.hasNext()) {
            z |= remove(it.next());
        }
        return z;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean retainAll(Collection<?> collection) {
        boolean z = false;
        for (int i2 = this.f1159f - 1; i2 >= 0; i2--) {
            if (!collection.contains(this.f1158e[i2])) {
                s(i2);
                z = true;
            }
        }
        return z;
    }

    public E s(int i2) {
        Object[] objArr = this.f1158e;
        E e2 = (E) objArr[i2];
        int i3 = this.f1159f;
        if (i3 <= 1) {
            p(this.f1157d, objArr, i3);
            this.f1157d = f1154h;
            this.f1158e = f1155i;
            this.f1159f = 0;
        } else {
            int[] iArr = this.f1157d;
            if (iArr.length <= 8 || i3 >= iArr.length / 3) {
                int i4 = i3 - 1;
                this.f1159f = i4;
                if (i2 < i4) {
                    int i5 = i2 + 1;
                    System.arraycopy(iArr, i5, iArr, i2, i4 - i2);
                    Object[] objArr2 = this.f1158e;
                    System.arraycopy(objArr2, i5, objArr2, i2, this.f1159f - i2);
                }
                this.f1158e[this.f1159f] = null;
            } else {
                o(i3 > 8 ? i3 + (i3 >> 1) : 8);
                this.f1159f--;
                if (i2 > 0) {
                    System.arraycopy(iArr, 0, this.f1157d, 0, i2);
                    System.arraycopy(objArr, 0, this.f1158e, 0, i2);
                }
                int i6 = this.f1159f;
                if (i2 < i6) {
                    int i7 = i2 + 1;
                    System.arraycopy(iArr, i7, this.f1157d, i2, i6 - i2);
                    System.arraycopy(objArr, i7, this.f1158e, i2, this.f1159f - i2);
                }
            }
        }
        return e2;
    }

    @Override // java.util.Collection, java.util.Set
    public int size() {
        return this.f1159f;
    }

    @Override // java.util.Collection, java.util.Set
    public Object[] toArray() {
        int i2 = this.f1159f;
        Object[] objArr = new Object[i2];
        System.arraycopy(this.f1158e, 0, objArr, 0, i2);
        return objArr;
    }

    @Override // java.util.Collection, java.util.Set
    public <T> T[] toArray(T[] tArr) {
        if (tArr.length < this.f1159f) {
            tArr = (T[]) ((Object[]) Array.newInstance(tArr.getClass().getComponentType(), this.f1159f));
        }
        System.arraycopy(this.f1158e, 0, tArr, 0, this.f1159f);
        int length = tArr.length;
        int i2 = this.f1159f;
        if (length > i2) {
            tArr[i2] = null;
        }
        return tArr;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1159f * 14);
        sb.append('{');
        for (int i2 = 0; i2 < this.f1159f; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            Object obj = this.f1158e[i2];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
