package b.m.a;

import android.content.res.AssetManager;
import android.media.MediaDataSource;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.system.OsConstants;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a.smali */
public class a {
    public static SimpleDateFormat F;
    public static SimpleDateFormat G;
    public static final String[] H;
    public static final int[] I;
    public static final byte[] J;
    public static final d[] K;
    public static final d[] L;
    public static final d[] M;
    public static final d[] N;
    public static final d[] O;
    public static final d P;
    public static final d[] Q;
    public static final d[] R;
    public static final d[] S;
    public static final d[] T;
    public static final d[][] U;
    public static final d[] V;
    public static final HashMap<Integer, d>[] W;
    public static final HashMap<String, d>[] X;
    public static final HashSet<String> Y;
    public static final HashMap<Integer, Integer> Z;
    public static final Charset a0;
    public static final byte[] b0;
    public static final byte[] c0;

    /* renamed from: a, reason: collision with root package name */
    public FileDescriptor f1904a;

    /* renamed from: b, reason: collision with root package name */
    public AssetManager.AssetInputStream f1905b;

    /* renamed from: c, reason: collision with root package name */
    public int f1906c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1907d;

    /* renamed from: e, reason: collision with root package name */
    public final HashMap<String, c>[] f1908e;

    /* renamed from: f, reason: collision with root package name */
    public Set<Integer> f1909f;

    /* renamed from: g, reason: collision with root package name */
    public ByteOrder f1910g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1911h;

    /* renamed from: i, reason: collision with root package name */
    public int f1912i;

    /* renamed from: j, reason: collision with root package name */
    public int f1913j;
    public int k;
    public int l;
    public int m;
    public static final boolean n = Log.isLoggable("ExifInterface", 3);
    public static final List<Integer> o = Arrays.asList(1, 6, 3, 8);
    public static final List<Integer> p = Arrays.asList(2, 7, 4, 5);
    public static final int[] q = {8, 8, 8};
    public static final int[] r = {8};
    public static final byte[] s = {-1, -40, -1};
    public static final byte[] t = {102, 116, 121, 112};
    public static final byte[] u = {109, 105, 102, 49};
    public static final byte[] v = {104, 101, 105, 99};
    public static final byte[] w = {79, 76, 89, 77, 80, 0};
    public static final byte[] x = {79, 76, 89, 77, 80, 85, 83, 0, 73, 73};
    public static final byte[] y = {-119, 80, 78, 71, 13, 10, 26, 10};
    public static final byte[] z = {101, 88, 73, 102};
    public static final byte[] A = {73, 72, 68, 82};
    public static final byte[] B = {73, 69, 78, 68};
    public static final byte[] C = {82, 73, 70, 70};
    public static final byte[] D = {87, 69, 66, 80};
    public static final byte[] E = {69, 88, 73, 70};

    /* renamed from: b.m.a.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a$a.smali */
    public class C0042a extends MediaDataSource {

        /* renamed from: d, reason: collision with root package name */
        public long f1914d;

        /* renamed from: e, reason: collision with root package name */
        public final /* synthetic */ f f1915e;

        public C0042a(a aVar, f fVar) {
            this.f1915e = fVar;
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
        }

        @Override // android.media.MediaDataSource
        public long getSize() {
            return -1L;
        }

        @Override // android.media.MediaDataSource
        public int readAt(long j2, byte[] bArr, int i2, int i3) {
            if (i3 == 0) {
                return 0;
            }
            if (j2 < 0) {
                return -1;
            }
            try {
                long j3 = this.f1914d;
                if (j3 != j2) {
                    if (j3 >= 0 && j2 >= j3 + this.f1915e.available()) {
                        return -1;
                    }
                    this.f1915e.q(j2);
                    this.f1914d = j2;
                }
                if (i3 > this.f1915e.available()) {
                    i3 = this.f1915e.available();
                }
                f fVar = this.f1915e;
                int read = fVar.f1918d.read(bArr, i2, i3);
                fVar.f1920f += read;
                if (read >= 0) {
                    this.f1914d += read;
                    return read;
                }
            } catch (IOException unused) {
            }
            this.f1914d = -1L;
            return -1;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a$b.smali */
    public static class b extends InputStream implements DataInput {

        /* renamed from: h, reason: collision with root package name */
        public static final ByteOrder f1916h = ByteOrder.LITTLE_ENDIAN;

        /* renamed from: i, reason: collision with root package name */
        public static final ByteOrder f1917i = ByteOrder.BIG_ENDIAN;

        /* renamed from: d, reason: collision with root package name */
        public final DataInputStream f1918d;

        /* renamed from: e, reason: collision with root package name */
        public ByteOrder f1919e;

        /* renamed from: f, reason: collision with root package name */
        public int f1920f;

        /* renamed from: g, reason: collision with root package name */
        public byte[] f1921g;

        public b(InputStream inputStream, ByteOrder byteOrder) {
            this.f1919e = ByteOrder.BIG_ENDIAN;
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            this.f1918d = dataInputStream;
            dataInputStream.mark(0);
            this.f1920f = 0;
            this.f1919e = byteOrder;
        }

        public b(byte[] bArr) {
            this(new ByteArrayInputStream(bArr), ByteOrder.BIG_ENDIAN);
        }

        public long a() {
            return readInt() & 4294967295L;
        }

        @Override // java.io.InputStream
        public int available() {
            return this.f1918d.available();
        }

        public void j(int i2) {
            int i3 = 0;
            while (i3 < i2) {
                int i4 = i2 - i3;
                int skip = (int) this.f1918d.skip(i4);
                if (skip <= 0) {
                    if (this.f1921g == null) {
                        this.f1921g = new byte[8192];
                    }
                    skip = this.f1918d.read(this.f1921g, 0, Math.min(8192, i4));
                    if (skip == -1) {
                        throw new EOFException("Reached EOF while skipping " + i2 + " bytes.");
                    }
                }
                i3 += skip;
            }
            this.f1920f += i3;
        }

        @Override // java.io.InputStream
        public void mark(int i2) {
            throw new UnsupportedOperationException("Mark is currently unsupported");
        }

        @Override // java.io.InputStream
        public int read() {
            this.f1920f++;
            return this.f1918d.read();
        }

        @Override // java.io.InputStream
        public int read(byte[] bArr, int i2, int i3) {
            int read = this.f1918d.read(bArr, i2, i3);
            this.f1920f += read;
            return read;
        }

        @Override // java.io.DataInput
        public boolean readBoolean() {
            this.f1920f++;
            return this.f1918d.readBoolean();
        }

        @Override // java.io.DataInput
        public byte readByte() {
            this.f1920f++;
            int read = this.f1918d.read();
            if (read >= 0) {
                return (byte) read;
            }
            throw new EOFException();
        }

        @Override // java.io.DataInput
        public char readChar() {
            this.f1920f += 2;
            return this.f1918d.readChar();
        }

        @Override // java.io.DataInput
        public double readDouble() {
            return Double.longBitsToDouble(readLong());
        }

        @Override // java.io.DataInput
        public float readFloat() {
            return Float.intBitsToFloat(readInt());
        }

        @Override // java.io.DataInput
        public void readFully(byte[] bArr) {
            this.f1920f += bArr.length;
            this.f1918d.readFully(bArr);
        }

        @Override // java.io.DataInput
        public void readFully(byte[] bArr, int i2, int i3) {
            this.f1920f += i3;
            this.f1918d.readFully(bArr, i2, i3);
        }

        @Override // java.io.DataInput
        public int readInt() {
            this.f1920f += 4;
            int read = this.f1918d.read();
            int read2 = this.f1918d.read();
            int read3 = this.f1918d.read();
            int read4 = this.f1918d.read();
            if ((read | read2 | read3 | read4) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.f1919e;
            if (byteOrder == f1916h) {
                return (read4 << 24) + (read3 << 16) + (read2 << 8) + read;
            }
            if (byteOrder == f1917i) {
                return (read << 24) + (read2 << 16) + (read3 << 8) + read4;
            }
            StringBuilder n = c.a.a.a.a.n("Invalid byte order: ");
            n.append(this.f1919e);
            throw new IOException(n.toString());
        }

        @Override // java.io.DataInput
        public String readLine() {
            Log.d("ExifInterface", "Currently unsupported");
            return null;
        }

        @Override // java.io.DataInput
        public long readLong() {
            this.f1920f += 8;
            int read = this.f1918d.read();
            int read2 = this.f1918d.read();
            int read3 = this.f1918d.read();
            int read4 = this.f1918d.read();
            int read5 = this.f1918d.read();
            int read6 = this.f1918d.read();
            int read7 = this.f1918d.read();
            int read8 = this.f1918d.read();
            if ((read | read2 | read3 | read4 | read5 | read6 | read7 | read8) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.f1919e;
            if (byteOrder == f1916h) {
                return (read8 << 56) + (read7 << 48) + (read6 << 40) + (read5 << 32) + (read4 << 24) + (read3 << 16) + (read2 << 8) + read;
            }
            if (byteOrder == f1917i) {
                return (read << 56) + (read2 << 48) + (read3 << 40) + (read4 << 32) + (read5 << 24) + (read6 << 16) + (read7 << 8) + read8;
            }
            StringBuilder n = c.a.a.a.a.n("Invalid byte order: ");
            n.append(this.f1919e);
            throw new IOException(n.toString());
        }

        @Override // java.io.DataInput
        public short readShort() {
            this.f1920f += 2;
            int read = this.f1918d.read();
            int read2 = this.f1918d.read();
            if ((read | read2) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.f1919e;
            if (byteOrder == f1916h) {
                return (short) ((read2 << 8) + read);
            }
            if (byteOrder == f1917i) {
                return (short) ((read << 8) + read2);
            }
            StringBuilder n = c.a.a.a.a.n("Invalid byte order: ");
            n.append(this.f1919e);
            throw new IOException(n.toString());
        }

        @Override // java.io.DataInput
        public String readUTF() {
            this.f1920f += 2;
            return this.f1918d.readUTF();
        }

        @Override // java.io.DataInput
        public int readUnsignedByte() {
            this.f1920f++;
            return this.f1918d.readUnsignedByte();
        }

        @Override // java.io.DataInput
        public int readUnsignedShort() {
            this.f1920f += 2;
            int read = this.f1918d.read();
            int read2 = this.f1918d.read();
            if ((read | read2) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.f1919e;
            if (byteOrder == f1916h) {
                return (read2 << 8) + read;
            }
            if (byteOrder == f1917i) {
                return (read << 8) + read2;
            }
            StringBuilder n = c.a.a.a.a.n("Invalid byte order: ");
            n.append(this.f1919e);
            throw new IOException(n.toString());
        }

        @Override // java.io.InputStream
        public void reset() {
            throw new UnsupportedOperationException("Reset is currently unsupported");
        }

        @Override // java.io.DataInput
        public int skipBytes(int i2) {
            throw new UnsupportedOperationException("skipBytes is currently unsupported");
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a$c.smali */
    public static class c {

        /* renamed from: a, reason: collision with root package name */
        public final int f1922a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1923b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1924c;

        /* renamed from: d, reason: collision with root package name */
        public final byte[] f1925d;

        public c(int i2, int i3, long j2, byte[] bArr) {
            this.f1922a = i2;
            this.f1923b = i3;
            this.f1924c = j2;
            this.f1925d = bArr;
        }

        public c(int i2, int i3, byte[] bArr) {
            this.f1922a = i2;
            this.f1923b = i3;
            this.f1924c = -1L;
            this.f1925d = bArr;
        }

        public static c a(String str) {
            byte[] bytes = c.a.a.a.a.C(str, (char) 0).getBytes(a.a0);
            return new c(2, bytes.length, bytes);
        }

        public static c b(long j2, ByteOrder byteOrder) {
            long[] jArr = {j2};
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.I[4] * 1]);
            wrap.order(byteOrder);
            for (int i2 = 0; i2 < 1; i2++) {
                wrap.putInt((int) jArr[i2]);
            }
            return new c(4, 1, wrap.array());
        }

        public static c c(e eVar, ByteOrder byteOrder) {
            e[] eVarArr = {eVar};
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.I[5] * 1]);
            wrap.order(byteOrder);
            for (int i2 = 0; i2 < 1; i2++) {
                e eVar2 = eVarArr[i2];
                wrap.putInt((int) eVar2.f1930a);
                wrap.putInt((int) eVar2.f1931b);
            }
            return new c(5, 1, wrap.array());
        }

        public static c d(int i2, ByteOrder byteOrder) {
            int[] iArr = {i2};
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.I[3] * 1]);
            wrap.order(byteOrder);
            for (int i3 = 0; i3 < 1; i3++) {
                wrap.putShort((short) iArr[i3]);
            }
            return new c(3, 1, wrap.array());
        }

        public double e(ByteOrder byteOrder) {
            Object h2 = h(byteOrder);
            if (h2 == null) {
                throw new NumberFormatException("NULL can't be converted to a double value");
            }
            if (h2 instanceof String) {
                return Double.parseDouble((String) h2);
            }
            if (h2 instanceof long[]) {
                if (((long[]) h2).length == 1) {
                    return r5[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (h2 instanceof int[]) {
                if (((int[]) h2).length == 1) {
                    return r5[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (h2 instanceof double[]) {
                double[] dArr = (double[]) h2;
                if (dArr.length == 1) {
                    return dArr[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (!(h2 instanceof e[])) {
                throw new NumberFormatException("Couldn't find a double value");
            }
            e[] eVarArr = (e[]) h2;
            if (eVarArr.length != 1) {
                throw new NumberFormatException("There are more than one component");
            }
            e eVar = eVarArr[0];
            return eVar.f1930a / eVar.f1931b;
        }

        public int f(ByteOrder byteOrder) {
            Object h2 = h(byteOrder);
            if (h2 == null) {
                throw new NumberFormatException("NULL can't be converted to a integer value");
            }
            if (h2 instanceof String) {
                return Integer.parseInt((String) h2);
            }
            if (h2 instanceof long[]) {
                long[] jArr = (long[]) h2;
                if (jArr.length == 1) {
                    return (int) jArr[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (!(h2 instanceof int[])) {
                throw new NumberFormatException("Couldn't find a integer value");
            }
            int[] iArr = (int[]) h2;
            if (iArr.length == 1) {
                return iArr[0];
            }
            throw new NumberFormatException("There are more than one component");
        }

        public String g(ByteOrder byteOrder) {
            Object h2 = h(byteOrder);
            if (h2 == null) {
                return null;
            }
            if (h2 instanceof String) {
                return (String) h2;
            }
            StringBuilder sb = new StringBuilder();
            int i2 = 0;
            if (h2 instanceof long[]) {
                long[] jArr = (long[]) h2;
                while (i2 < jArr.length) {
                    sb.append(jArr[i2]);
                    i2++;
                    if (i2 != jArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
            if (h2 instanceof int[]) {
                int[] iArr = (int[]) h2;
                while (i2 < iArr.length) {
                    sb.append(iArr[i2]);
                    i2++;
                    if (i2 != iArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
            if (h2 instanceof double[]) {
                double[] dArr = (double[]) h2;
                while (i2 < dArr.length) {
                    sb.append(dArr[i2]);
                    i2++;
                    if (i2 != dArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
            if (!(h2 instanceof e[])) {
                return null;
            }
            e[] eVarArr = (e[]) h2;
            while (i2 < eVarArr.length) {
                sb.append(eVarArr[i2].f1930a);
                sb.append('/');
                sb.append(eVarArr[i2].f1931b);
                i2++;
                if (i2 != eVarArr.length) {
                    sb.append(",");
                }
            }
            return sb.toString();
        }

        /* JADX WARN: Not initialized variable reg: 3, insn: 0x019f: MOVE (r2 I:??[OBJECT, ARRAY]) = (r3 I:??[OBJECT, ARRAY]), block:B:169:0x019f */
        /* JADX WARN: Removed duplicated region for block: B:172:0x01a2 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.lang.Object h(java.nio.ByteOrder r11) {
            /*
                Method dump skipped, instructions count: 456
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: b.m.a.a.c.h(java.nio.ByteOrder):java.lang.Object");
        }

        public String toString() {
            StringBuilder n = c.a.a.a.a.n("(");
            n.append(a.H[this.f1922a]);
            n.append(", data length:");
            n.append(this.f1925d.length);
            n.append(")");
            return n.toString();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a$d.smali */
    public static class d {

        /* renamed from: a, reason: collision with root package name */
        public final int f1926a;

        /* renamed from: b, reason: collision with root package name */
        public final String f1927b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1928c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1929d;

        public d(String str, int i2, int i3) {
            this.f1927b = str;
            this.f1926a = i2;
            this.f1928c = i3;
            this.f1929d = -1;
        }

        public d(String str, int i2, int i3, int i4) {
            this.f1927b = str;
            this.f1926a = i2;
            this.f1928c = i3;
            this.f1929d = i4;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a$e.smali */
    public static class e {

        /* renamed from: a, reason: collision with root package name */
        public final long f1930a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1931b;

        public e(long j2, long j3) {
            if (j3 == 0) {
                this.f1930a = 0L;
                this.f1931b = 1L;
            } else {
                this.f1930a = j2;
                this.f1931b = j3;
            }
        }

        public String toString() {
            return this.f1930a + "/" + this.f1931b;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\m\a\a$f.smali */
    public static class f extends b {
        public f(InputStream inputStream) {
            super(inputStream, ByteOrder.BIG_ENDIAN);
            if (!inputStream.markSupported()) {
                throw new IllegalArgumentException("Cannot create SeekableByteOrderedDataInputStream with stream that does not support mark/reset");
            }
            this.f1918d.mark(Integer.MAX_VALUE);
        }

        public f(byte[] bArr) {
            super(bArr);
            this.f1918d.mark(Integer.MAX_VALUE);
        }

        public void q(long j2) {
            int i2 = this.f1920f;
            if (i2 > j2) {
                this.f1920f = 0;
                this.f1918d.reset();
            } else {
                j2 -= i2;
            }
            j((int) j2);
        }
    }

    static {
        "VP8X".getBytes(Charset.defaultCharset());
        "VP8L".getBytes(Charset.defaultCharset());
        "VP8 ".getBytes(Charset.defaultCharset());
        "ANIM".getBytes(Charset.defaultCharset());
        "ANMF".getBytes(Charset.defaultCharset());
        H = new String[]{"", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", "SRATIONAL", "SINGLE", "DOUBLE", "IFD"};
        I = new int[]{0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 1};
        J = new byte[]{65, 83, 67, 73, 73, 0, 0, 0};
        d[] dVarArr = {new d("NewSubfileType", 254, 4), new d("SubfileType", 255, 4), new d("ImageWidth", 256, 3, 4), new d("ImageLength", 257, 3, 4), new d("BitsPerSample", 258, 3), new d("Compression", 259, 3), new d("PhotometricInterpretation", 262, 3), new d("ImageDescription", 270, 2), new d("Make", 271, 2), new d("Model", 272, 2), new d("StripOffsets", 273, 3, 4), new d("Orientation", 274, 3), new d("SamplesPerPixel", 277, 3), new d("RowsPerStrip", 278, 3, 4), new d("StripByteCounts", 279, 3, 4), new d("XResolution", 282, 5), new d("YResolution", 283, 5), new d("PlanarConfiguration", 284, 3), new d("ResolutionUnit", 296, 3), new d("TransferFunction", 301, 3), new d("Software", 305, 2), new d("DateTime", 306, 2), new d("Artist", 315, 2), new d("WhitePoint", 318, 5), new d("PrimaryChromaticities", 319, 5), new d("SubIFDPointer", 330, 4), new d("JPEGInterchangeFormat", 513, 4), new d("JPEGInterchangeFormatLength", 514, 4), new d("YCbCrCoefficients", 529, 5), new d("YCbCrSubSampling", 530, 3), new d("YCbCrPositioning", 531, 3), new d("ReferenceBlackWhite", 532, 5), new d("Copyright", 33432, 2), new d("ExifIFDPointer", 34665, 4), new d("GPSInfoIFDPointer", 34853, 4), new d("SensorTopBorder", 4, 4), new d("SensorLeftBorder", 5, 4), new d("SensorBottomBorder", 6, 4), new d("SensorRightBorder", 7, 4), new d("ISO", 23, 3), new d("JpgFromRaw", 46, 7), new d("Xmp", 700, 1)};
        K = dVarArr;
        d[] dVarArr2 = {new d("ExposureTime", 33434, 5), new d("FNumber", 33437, 5), new d("ExposureProgram", 34850, 3), new d("SpectralSensitivity", 34852, 2), new d("PhotographicSensitivity", 34855, 3), new d("OECF", 34856, 7), new d("SensitivityType", 34864, 3), new d("StandardOutputSensitivity", 34865, 4), new d("RecommendedExposureIndex", 34866, 4), new d("ISOSpeed", 34867, 4), new d("ISOSpeedLatitudeyyy", 34868, 4), new d("ISOSpeedLatitudezzz", 34869, 4), new d("ExifVersion", 36864, 2), new d("DateTimeOriginal", 36867, 2), new d("DateTimeDigitized", 36868, 2), new d("OffsetTime", 36880, 2), new d("OffsetTimeOriginal", 36881, 2), new d("OffsetTimeDigitized", 36882, 2), new d("ComponentsConfiguration", 37121, 7), new d("CompressedBitsPerPixel", 37122, 5), new d("ShutterSpeedValue", 37377, 10), new d("ApertureValue", 37378, 5), new d("BrightnessValue", 37379, 10), new d("ExposureBiasValue", 37380, 10), new d("MaxApertureValue", 37381, 5), new d("SubjectDistance", 37382, 5), new d("MeteringMode", 37383, 3), new d("LightSource", 37384, 3), new d("Flash", 37385, 3), new d("FocalLength", 37386, 5), new d("SubjectArea", 37396, 3), new d("MakerNote", 37500, 7), new d("UserComment", 37510, 7), new d("SubSecTime", 37520, 2), new d("SubSecTimeOriginal", 37521, 2), new d("SubSecTimeDigitized", 37522, 2), new d("FlashpixVersion", 40960, 7), new d("ColorSpace", 40961, 3), new d("PixelXDimension", 40962, 3, 4), new d("PixelYDimension", 40963, 3, 4), new d("RelatedSoundFile", 40964, 2), new d("InteroperabilityIFDPointer", 40965, 4), new d("FlashEnergy", 41483, 5), new d("SpatialFrequencyResponse", 41484, 7), new d("FocalPlaneXResolution", 41486, 5), new d("FocalPlaneYResolution", 41487, 5), new d("FocalPlaneResolutionUnit", 41488, 3), new d("SubjectLocation", 41492, 3), new d("ExposureIndex", 41493, 5), new d("SensingMethod", 41495, 3), new d("FileSource", 41728, 7), new d("SceneType", 41729, 7), new d("CFAPattern", 41730, 7), new d("CustomRendered", 41985, 3), new d("ExposureMode", 41986, 3), new d("WhiteBalance", 41987, 3), new d("DigitalZoomRatio", 41988, 5), new d("FocalLengthIn35mmFilm", 41989, 3), new d("SceneCaptureType", 41990, 3), new d("GainControl", 41991, 3), new d("Contrast", 41992, 3), new d("Saturation", 41993, 3), new d("Sharpness", 41994, 3), new d("DeviceSettingDescription", 41995, 7), new d("SubjectDistanceRange", 41996, 3), new d("ImageUniqueID", 42016, 2), new d("CameraOwnerName", 42032, 2), new d("BodySerialNumber", 42033, 2), new d("LensSpecification", 42034, 5), new d("LensMake", 42035, 2), new d("LensModel", 42036, 2), new d("Gamma", 42240, 5), new d("DNGVersion", 50706, 1), new d("DefaultCropSize", 50720, 3, 4)};
        L = dVarArr2;
        d[] dVarArr3 = {new d("GPSVersionID", 0, 1), new d("GPSLatitudeRef", 1, 2), new d("GPSLatitude", 2, 5, 10), new d("GPSLongitudeRef", 3, 2), new d("GPSLongitude", 4, 5, 10), new d("GPSAltitudeRef", 5, 1), new d("GPSAltitude", 6, 5), new d("GPSTimeStamp", 7, 5), new d("GPSSatellites", 8, 2), new d("GPSStatus", 9, 2), new d("GPSMeasureMode", 10, 2), new d("GPSDOP", 11, 5), new d("GPSSpeedRef", 12, 2), new d("GPSSpeed", 13, 5), new d("GPSTrackRef", 14, 2), new d("GPSTrack", 15, 5), new d("GPSImgDirectionRef", 16, 2), new d("GPSImgDirection", 17, 5), new d("GPSMapDatum", 18, 2), new d("GPSDestLatitudeRef", 19, 2), new d("GPSDestLatitude", 20, 5), new d("GPSDestLongitudeRef", 21, 2), new d("GPSDestLongitude", 22, 5), new d("GPSDestBearingRef", 23, 2), new d("GPSDestBearing", 24, 5), new d("GPSDestDistanceRef", 25, 2), new d("GPSDestDistance", 26, 5), new d("GPSProcessingMethod", 27, 7), new d("GPSAreaInformation", 28, 7), new d("GPSDateStamp", 29, 2), new d("GPSDifferential", 30, 3), new d("GPSHPositioningError", 31, 5)};
        M = dVarArr3;
        d[] dVarArr4 = {new d("InteroperabilityIndex", 1, 2)};
        N = dVarArr4;
        d[] dVarArr5 = {new d("NewSubfileType", 254, 4), new d("SubfileType", 255, 4), new d("ThumbnailImageWidth", 256, 3, 4), new d("ThumbnailImageLength", 257, 3, 4), new d("BitsPerSample", 258, 3), new d("Compression", 259, 3), new d("PhotometricInterpretation", 262, 3), new d("ImageDescription", 270, 2), new d("Make", 271, 2), new d("Model", 272, 2), new d("StripOffsets", 273, 3, 4), new d("ThumbnailOrientation", 274, 3), new d("SamplesPerPixel", 277, 3), new d("RowsPerStrip", 278, 3, 4), new d("StripByteCounts", 279, 3, 4), new d("XResolution", 282, 5), new d("YResolution", 283, 5), new d("PlanarConfiguration", 284, 3), new d("ResolutionUnit", 296, 3), new d("TransferFunction", 301, 3), new d("Software", 305, 2), new d("DateTime", 306, 2), new d("Artist", 315, 2), new d("WhitePoint", 318, 5), new d("PrimaryChromaticities", 319, 5), new d("SubIFDPointer", 330, 4), new d("JPEGInterchangeFormat", 513, 4), new d("JPEGInterchangeFormatLength", 514, 4), new d("YCbCrCoefficients", 529, 5), new d("YCbCrSubSampling", 530, 3), new d("YCbCrPositioning", 531, 3), new d("ReferenceBlackWhite", 532, 5), new d("Xmp", 700, 1), new d("Copyright", 33432, 2), new d("ExifIFDPointer", 34665, 4), new d("GPSInfoIFDPointer", 34853, 4), new d("DNGVersion", 50706, 1), new d("DefaultCropSize", 50720, 3, 4)};
        O = dVarArr5;
        P = new d("StripOffsets", 273, 3);
        d[] dVarArr6 = {new d("ThumbnailImage", 256, 7), new d("CameraSettingsIFDPointer", 8224, 4), new d("ImageProcessingIFDPointer", 8256, 4)};
        Q = dVarArr6;
        d[] dVarArr7 = {new d("PreviewImageStart", 257, 4), new d("PreviewImageLength", 258, 4)};
        R = dVarArr7;
        d[] dVarArr8 = {new d("AspectFrame", 4371, 3)};
        S = dVarArr8;
        d[] dVarArr9 = {new d("ColorSpace", 55, 3)};
        T = dVarArr9;
        d[][] dVarArr10 = {dVarArr, dVarArr2, dVarArr3, dVarArr4, dVarArr5, dVarArr, dVarArr6, dVarArr7, dVarArr8, dVarArr9};
        U = dVarArr10;
        V = new d[]{new d("SubIFDPointer", 330, 4), new d("ExifIFDPointer", 34665, 4), new d("GPSInfoIFDPointer", 34853, 4), new d("InteroperabilityIFDPointer", 40965, 4), new d("CameraSettingsIFDPointer", 8224, 1), new d("ImageProcessingIFDPointer", 8256, 1)};
        W = new HashMap[dVarArr10.length];
        X = new HashMap[dVarArr10.length];
        Y = new HashSet<>(Arrays.asList("FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp"));
        Z = new HashMap<>();
        Charset forName = Charset.forName("US-ASCII");
        a0 = forName;
        b0 = "Exif\u0000\u0000".getBytes(forName);
        c0 = "http://ns.adobe.com/xap/1.0/\u0000".getBytes(forName);
        Locale locale = Locale.US;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", locale);
        F = simpleDateFormat;
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale);
        G = simpleDateFormat2;
        simpleDateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        int i2 = 0;
        while (true) {
            d[][] dVarArr11 = U;
            if (i2 >= dVarArr11.length) {
                HashMap<Integer, Integer> hashMap = Z;
                d[] dVarArr12 = V;
                hashMap.put(Integer.valueOf(dVarArr12[0].f1926a), 5);
                hashMap.put(Integer.valueOf(dVarArr12[1].f1926a), 1);
                hashMap.put(Integer.valueOf(dVarArr12[2].f1926a), 2);
                hashMap.put(Integer.valueOf(dVarArr12[3].f1926a), 3);
                hashMap.put(Integer.valueOf(dVarArr12[4].f1926a), 7);
                hashMap.put(Integer.valueOf(dVarArr12[5].f1926a), 8);
                Pattern.compile(".*[1-9].*");
                Pattern.compile("^(\\d{2}):(\\d{2}):(\\d{2})$");
                Pattern.compile("^(\\d{4}):(\\d{2}):(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$");
                Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$");
                return;
            }
            W[i2] = new HashMap<>();
            X[i2] = new HashMap<>();
            for (d dVar : dVarArr11[i2]) {
                W[i2].put(Integer.valueOf(dVar.f1926a), dVar);
                X[i2].put(dVar.f1927b, dVar);
            }
            i2++;
        }
    }

    public a(InputStream inputStream) {
        boolean z2;
        d[][] dVarArr = U;
        this.f1908e = new HashMap[dVarArr.length];
        this.f1909f = new HashSet(dVarArr.length);
        this.f1910g = ByteOrder.BIG_ENDIAN;
        Objects.requireNonNull(inputStream, "inputStream cannot be null");
        if (inputStream instanceof AssetManager.AssetInputStream) {
            this.f1905b = (AssetManager.AssetInputStream) inputStream;
            this.f1904a = null;
        } else {
            if (inputStream instanceof FileInputStream) {
                FileInputStream fileInputStream = (FileInputStream) inputStream;
                try {
                    b.m.a.b.c(fileInputStream.getFD(), 0L, OsConstants.SEEK_CUR);
                    z2 = true;
                } catch (Exception unused) {
                    if (n) {
                        Log.d("ExifInterface", "The file descriptor for the given input is not seekable");
                    }
                    z2 = false;
                }
                if (z2) {
                    this.f1905b = null;
                    this.f1904a = fileInputStream.getFD();
                }
            }
            this.f1905b = null;
            this.f1904a = null;
        }
        for (int i2 = 0; i2 < U.length; i2++) {
            try {
                try {
                    this.f1908e[i2] = new HashMap<>();
                } catch (IOException | UnsupportedOperationException e2) {
                    boolean z3 = n;
                    if (z3) {
                        Log.w("ExifInterface", "Invalid image: ExifInterface got an unsupported image format file(ExifInterface supports JPEG and some RAW image formats only) or a corrupted JPEG file to ExifInterface.", e2);
                    }
                    a();
                    if (!z3) {
                        return;
                    }
                }
            } finally {
                a();
                if (n) {
                    r();
                }
            }
        }
        if (!this.f1907d) {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream, 5000);
            this.f1906c = g(bufferedInputStream);
            inputStream = bufferedInputStream;
        }
        int i3 = this.f1906c;
        if ((i3 == 4 || i3 == 9 || i3 == 13 || i3 == 14) ? false : true) {
            f fVar = new f(inputStream);
            if (this.f1907d) {
                m(fVar);
            } else {
                int i4 = this.f1906c;
                if (i4 == 12) {
                    e(fVar);
                } else if (i4 == 7) {
                    h(fVar);
                } else if (i4 == 10) {
                    l(fVar);
                } else {
                    k(fVar);
                }
            }
            fVar.q(this.f1913j);
            w(fVar);
        } else {
            b bVar = new b(inputStream, ByteOrder.BIG_ENDIAN);
            int i5 = this.f1906c;
            if (i5 == 4) {
                f(bVar, 0, 0);
            } else if (i5 == 13) {
                i(bVar);
            } else if (i5 == 9) {
                j(bVar);
            } else if (i5 == 14) {
                n(bVar);
            }
        }
    }

    public final void a() {
        String b2 = b("DateTimeOriginal");
        if (b2 != null && b("DateTime") == null) {
            this.f1908e[0].put("DateTime", c.a(b2));
        }
        if (b("ImageWidth") == null) {
            this.f1908e[0].put("ImageWidth", c.b(0L, this.f1910g));
        }
        if (b("ImageLength") == null) {
            this.f1908e[0].put("ImageLength", c.b(0L, this.f1910g));
        }
        if (b("Orientation") == null) {
            this.f1908e[0].put("Orientation", c.b(0L, this.f1910g));
        }
        if (b("LightSource") == null) {
            this.f1908e[1].put("LightSource", c.b(0L, this.f1910g));
        }
    }

    public String b(String str) {
        c d2 = d(str);
        if (d2 != null) {
            if (!Y.contains(str)) {
                return d2.g(this.f1910g);
            }
            if (str.equals("GPSTimeStamp")) {
                int i2 = d2.f1922a;
                if (i2 != 5 && i2 != 10) {
                    StringBuilder n2 = c.a.a.a.a.n("GPS Timestamp format is not rational. format=");
                    n2.append(d2.f1922a);
                    Log.w("ExifInterface", n2.toString());
                    return null;
                }
                e[] eVarArr = (e[]) d2.h(this.f1910g);
                if (eVarArr != null && eVarArr.length == 3) {
                    return String.format("%02d:%02d:%02d", Integer.valueOf((int) (eVarArr[0].f1930a / eVarArr[0].f1931b)), Integer.valueOf((int) (eVarArr[1].f1930a / eVarArr[1].f1931b)), Integer.valueOf((int) (eVarArr[2].f1930a / eVarArr[2].f1931b)));
                }
                StringBuilder n3 = c.a.a.a.a.n("Invalid GPS Timestamp array. array=");
                n3.append(Arrays.toString(eVarArr));
                Log.w("ExifInterface", n3.toString());
                return null;
            }
            try {
                return Double.toString(d2.e(this.f1910g));
            } catch (NumberFormatException unused) {
            }
        }
        return null;
    }

    public int c(String str, int i2) {
        c d2 = d(str);
        if (d2 == null) {
            return i2;
        }
        try {
            return d2.f(this.f1910g);
        } catch (NumberFormatException unused) {
            return i2;
        }
    }

    public final c d(String str) {
        if ("ISOSpeedRatings".equals(str)) {
            if (n) {
                Log.d("ExifInterface", "getExifAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY.");
            }
            str = "PhotographicSensitivity";
        }
        for (int i2 = 0; i2 < U.length; i2++) {
            c cVar = this.f1908e[i2].get(str);
            if (cVar != null) {
                return cVar;
            }
        }
        return null;
    }

    public final void e(f fVar) {
        String str;
        String str2;
        if (Build.VERSION.SDK_INT < 28) {
            throw new UnsupportedOperationException("Reading EXIF from HEIF files is supported from SDK 28 and above");
        }
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            try {
                b.m.a.c.a(mediaMetadataRetriever, new C0042a(this, fVar));
                String extractMetadata = mediaMetadataRetriever.extractMetadata(33);
                String extractMetadata2 = mediaMetadataRetriever.extractMetadata(34);
                String extractMetadata3 = mediaMetadataRetriever.extractMetadata(26);
                String extractMetadata4 = mediaMetadataRetriever.extractMetadata(17);
                String str3 = null;
                if ("yes".equals(extractMetadata3)) {
                    str3 = mediaMetadataRetriever.extractMetadata(29);
                    str = mediaMetadataRetriever.extractMetadata(30);
                    str2 = mediaMetadataRetriever.extractMetadata(31);
                } else if ("yes".equals(extractMetadata4)) {
                    str3 = mediaMetadataRetriever.extractMetadata(18);
                    str = mediaMetadataRetriever.extractMetadata(19);
                    str2 = mediaMetadataRetriever.extractMetadata(24);
                } else {
                    str = null;
                    str2 = null;
                }
                if (str3 != null) {
                    this.f1908e[0].put("ImageWidth", c.d(Integer.parseInt(str3), this.f1910g));
                }
                if (str != null) {
                    this.f1908e[0].put("ImageLength", c.d(Integer.parseInt(str), this.f1910g));
                }
                if (str2 != null) {
                    int i2 = 1;
                    int parseInt = Integer.parseInt(str2);
                    if (parseInt == 90) {
                        i2 = 6;
                    } else if (parseInt == 180) {
                        i2 = 3;
                    } else if (parseInt == 270) {
                        i2 = 8;
                    }
                    this.f1908e[0].put("Orientation", c.d(i2, this.f1910g));
                }
                if (extractMetadata != null && extractMetadata2 != null) {
                    int parseInt2 = Integer.parseInt(extractMetadata);
                    int parseInt3 = Integer.parseInt(extractMetadata2);
                    if (parseInt3 <= 6) {
                        throw new IOException("Invalid exif length");
                    }
                    fVar.q(parseInt2);
                    byte[] bArr = new byte[6];
                    if (fVar.read(bArr) != 6) {
                        throw new IOException("Can't read identifier");
                    }
                    int i3 = parseInt2 + 6;
                    int i4 = parseInt3 - 6;
                    if (!Arrays.equals(bArr, b0)) {
                        throw new IOException("Invalid identifier");
                    }
                    byte[] bArr2 = new byte[i4];
                    if (fVar.read(bArr2) != i4) {
                        throw new IOException("Can't read exif");
                    }
                    this.f1913j = i3;
                    t(bArr2, 0);
                }
                if (n) {
                    Log.d("ExifInterface", "Heif meta: " + str3 + "x" + str + ", rotation " + str2);
                }
            } catch (RuntimeException unused) {
                throw new UnsupportedOperationException("Failed to read EXIF from HEIF file. Given stream is either malformed or unsupported.");
            }
        } finally {
            mediaMetadataRetriever.release();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:70:0x018f, code lost:
    
        r19.f1919e = r18.f1910g;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0193, code lost:
    
        return;
     */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00ae A[FALL_THROUGH] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void f(b.m.a.a.b r19, int r20, int r21) {
        /*
            Method dump skipped, instructions count: 518
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.m.a.a.f(b.m.a.a$b, int, int):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:162:0x00ce, code lost:
    
        if (r8 != null) goto L71;
     */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0190  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0110 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0112 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0144 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0147  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int g(java.io.BufferedInputStream r18) {
        /*
            Method dump skipped, instructions count: 404
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.m.a.a.g(java.io.BufferedInputStream):int");
    }

    public final void h(f fVar) {
        k(fVar);
        c cVar = this.f1908e[1].get("MakerNote");
        if (cVar != null) {
            f fVar2 = new f(cVar.f1925d);
            fVar2.f1919e = this.f1910g;
            byte[] bArr = w;
            int length = bArr.length;
            byte[] bArr2 = new byte[length];
            fVar2.f1920f += length;
            fVar2.f1918d.readFully(bArr2);
            fVar2.q(0L);
            byte[] bArr3 = x;
            int length2 = bArr3.length;
            byte[] bArr4 = new byte[length2];
            fVar2.f1920f += length2;
            fVar2.f1918d.readFully(bArr4);
            if (Arrays.equals(bArr2, bArr)) {
                fVar2.q(8L);
            } else if (Arrays.equals(bArr4, bArr3)) {
                fVar2.q(12L);
            }
            u(fVar2, 6);
            c cVar2 = this.f1908e[7].get("PreviewImageStart");
            c cVar3 = this.f1908e[7].get("PreviewImageLength");
            if (cVar2 != null && cVar3 != null) {
                this.f1908e[5].put("JPEGInterchangeFormat", cVar2);
                this.f1908e[5].put("JPEGInterchangeFormatLength", cVar3);
            }
            c cVar4 = this.f1908e[8].get("AspectFrame");
            if (cVar4 != null) {
                int[] iArr = (int[]) cVar4.h(this.f1910g);
                if (iArr == null || iArr.length != 4) {
                    StringBuilder n2 = c.a.a.a.a.n("Invalid aspect frame values. frame=");
                    n2.append(Arrays.toString(iArr));
                    Log.w("ExifInterface", n2.toString());
                } else {
                    if (iArr[2] <= iArr[0] || iArr[3] <= iArr[1]) {
                        return;
                    }
                    int i2 = (iArr[2] - iArr[0]) + 1;
                    int i3 = (iArr[3] - iArr[1]) + 1;
                    if (i2 < i3) {
                        int i4 = i2 + i3;
                        i3 = i4 - i3;
                        i2 = i4 - i3;
                    }
                    c d2 = c.d(i2, this.f1910g);
                    c d3 = c.d(i3, this.f1910g);
                    this.f1908e[0].put("ImageWidth", d2);
                    this.f1908e[0].put("ImageLength", d3);
                }
            }
        }
    }

    public final void i(b bVar) {
        if (n) {
            Log.d("ExifInterface", "getPngAttributes starting with: " + bVar);
        }
        bVar.f1919e = ByteOrder.BIG_ENDIAN;
        byte[] bArr = y;
        bVar.j(bArr.length);
        int length = bArr.length + 0;
        while (true) {
            try {
                int readInt = bVar.readInt();
                int i2 = length + 4;
                byte[] bArr2 = new byte[4];
                if (bVar.read(bArr2) != 4) {
                    throw new IOException("Encountered invalid length while parsing PNG chunktype");
                }
                int i3 = i2 + 4;
                if (i3 == 16 && !Arrays.equals(bArr2, A)) {
                    throw new IOException("Encountered invalid PNG file--IHDR chunk should appearas the first chunk");
                }
                if (Arrays.equals(bArr2, B)) {
                    return;
                }
                if (Arrays.equals(bArr2, z)) {
                    byte[] bArr3 = new byte[readInt];
                    if (bVar.read(bArr3) != readInt) {
                        throw new IOException("Failed to read given length for given PNG chunk type: " + b.h.a.d(bArr2));
                    }
                    int readInt2 = bVar.readInt();
                    CRC32 crc32 = new CRC32();
                    crc32.update(bArr2);
                    crc32.update(bArr3);
                    if (((int) crc32.getValue()) == readInt2) {
                        this.f1913j = i3;
                        t(bArr3, 0);
                        z();
                        w(new b(bArr3));
                        return;
                    }
                    throw new IOException("Encountered invalid CRC value for PNG-EXIF chunk.\n recorded CRC value: " + readInt2 + ", calculated CRC value: " + crc32.getValue());
                }
                int i4 = readInt + 4;
                bVar.j(i4);
                length = i3 + i4;
            } catch (EOFException unused) {
                throw new IOException("Encountered corrupt PNG file.");
            }
        }
    }

    public final void j(b bVar) {
        boolean z2 = n;
        if (z2) {
            Log.d("ExifInterface", "getRafAttributes starting with: " + bVar);
        }
        bVar.j(84);
        byte[] bArr = new byte[4];
        byte[] bArr2 = new byte[4];
        byte[] bArr3 = new byte[4];
        bVar.read(bArr);
        bVar.read(bArr2);
        bVar.read(bArr3);
        int i2 = ByteBuffer.wrap(bArr).getInt();
        int i3 = ByteBuffer.wrap(bArr2).getInt();
        int i4 = ByteBuffer.wrap(bArr3).getInt();
        byte[] bArr4 = new byte[i3];
        bVar.j(i2 - bVar.f1920f);
        bVar.read(bArr4);
        f(new b(bArr4), i2, 5);
        bVar.j(i4 - bVar.f1920f);
        bVar.f1919e = ByteOrder.BIG_ENDIAN;
        int readInt = bVar.readInt();
        if (z2) {
            Log.d("ExifInterface", "numberOfDirectoryEntry: " + readInt);
        }
        for (int i5 = 0; i5 < readInt; i5++) {
            int readUnsignedShort = bVar.readUnsignedShort();
            int readUnsignedShort2 = bVar.readUnsignedShort();
            if (readUnsignedShort == P.f1926a) {
                short readShort = bVar.readShort();
                short readShort2 = bVar.readShort();
                c d2 = c.d(readShort, this.f1910g);
                c d3 = c.d(readShort2, this.f1910g);
                this.f1908e[0].put("ImageLength", d2);
                this.f1908e[0].put("ImageWidth", d3);
                if (n) {
                    Log.d("ExifInterface", "Updated to length: " + ((int) readShort) + ", width: " + ((int) readShort2));
                    return;
                }
                return;
            }
            bVar.j(readUnsignedShort2);
        }
    }

    public final void k(f fVar) {
        c cVar;
        q(fVar);
        u(fVar, 0);
        y(fVar, 0);
        y(fVar, 5);
        y(fVar, 4);
        z();
        if (this.f1906c != 8 || (cVar = this.f1908e[1].get("MakerNote")) == null) {
            return;
        }
        f fVar2 = new f(cVar.f1925d);
        fVar2.f1919e = this.f1910g;
        fVar2.j(6);
        u(fVar2, 9);
        c cVar2 = this.f1908e[9].get("ColorSpace");
        if (cVar2 != null) {
            this.f1908e[1].put("ColorSpace", cVar2);
        }
    }

    public final void l(f fVar) {
        if (n) {
            Log.d("ExifInterface", "getRw2Attributes starting with: " + fVar);
        }
        k(fVar);
        c cVar = this.f1908e[0].get("JpgFromRaw");
        if (cVar != null) {
            f(new b(cVar.f1925d), (int) cVar.f1924c, 5);
        }
        c cVar2 = this.f1908e[0].get("ISO");
        c cVar3 = this.f1908e[1].get("PhotographicSensitivity");
        if (cVar2 == null || cVar3 != null) {
            return;
        }
        this.f1908e[1].put("PhotographicSensitivity", cVar2);
    }

    public final void m(f fVar) {
        byte[] bArr = b0;
        fVar.j(bArr.length);
        int available = fVar.available();
        byte[] bArr2 = new byte[available];
        fVar.f1920f += available;
        fVar.f1918d.readFully(bArr2);
        this.f1913j = bArr.length;
        t(bArr2, 0);
    }

    public final void n(b bVar) {
        if (n) {
            Log.d("ExifInterface", "getWebpAttributes starting with: " + bVar);
        }
        bVar.f1919e = ByteOrder.LITTLE_ENDIAN;
        bVar.j(C.length);
        int readInt = bVar.readInt() + 8;
        byte[] bArr = D;
        bVar.j(bArr.length);
        int length = bArr.length + 8;
        while (true) {
            try {
                byte[] bArr2 = new byte[4];
                if (bVar.read(bArr2) != 4) {
                    throw new IOException("Encountered invalid length while parsing WebP chunktype");
                }
                int readInt2 = bVar.readInt();
                int i2 = length + 4 + 4;
                if (Arrays.equals(E, bArr2)) {
                    byte[] bArr3 = new byte[readInt2];
                    if (bVar.read(bArr3) == readInt2) {
                        this.f1913j = i2;
                        t(bArr3, 0);
                        w(new b(bArr3));
                        return;
                    } else {
                        throw new IOException("Failed to read given length for given PNG chunk type: " + b.h.a.d(bArr2));
                    }
                }
                if (readInt2 % 2 == 1) {
                    readInt2++;
                }
                length = i2 + readInt2;
                if (length == readInt) {
                    return;
                }
                if (length > readInt) {
                    throw new IOException("Encountered WebP file with invalid chunk size");
                }
                bVar.j(readInt2);
            } catch (EOFException unused) {
                throw new IOException("Encountered corrupt WebP file.");
            }
        }
    }

    public final void o(b bVar, HashMap hashMap) {
        c cVar = (c) hashMap.get("JPEGInterchangeFormat");
        c cVar2 = (c) hashMap.get("JPEGInterchangeFormatLength");
        if (cVar == null || cVar2 == null) {
            return;
        }
        int f2 = cVar.f(this.f1910g);
        int f3 = cVar2.f(this.f1910g);
        if (this.f1906c == 7) {
            f2 += this.k;
        }
        if (f2 > 0 && f3 > 0 && this.f1905b == null && this.f1904a == null) {
            bVar.skip(f2);
            bVar.read(new byte[f3]);
        }
        if (n) {
            Log.d("ExifInterface", "Setting thumbnail attributes with offset: " + f2 + ", length: " + f3);
        }
    }

    public final boolean p(HashMap hashMap) {
        c cVar = (c) hashMap.get("ImageLength");
        c cVar2 = (c) hashMap.get("ImageWidth");
        if (cVar == null || cVar2 == null) {
            return false;
        }
        return cVar.f(this.f1910g) <= 512 && cVar2.f(this.f1910g) <= 512;
    }

    public final void q(b bVar) {
        ByteOrder s2 = s(bVar);
        this.f1910g = s2;
        bVar.f1919e = s2;
        int readUnsignedShort = bVar.readUnsignedShort();
        int i2 = this.f1906c;
        if (i2 != 7 && i2 != 10 && readUnsignedShort != 42) {
            StringBuilder n2 = c.a.a.a.a.n("Invalid start code: ");
            n2.append(Integer.toHexString(readUnsignedShort));
            throw new IOException(n2.toString());
        }
        int readInt = bVar.readInt();
        if (readInt < 8) {
            throw new IOException(c.a.a.a.a.c("Invalid first Ifd offset: ", readInt));
        }
        int i3 = readInt - 8;
        if (i3 > 0) {
            bVar.j(i3);
        }
    }

    public final void r() {
        for (int i2 = 0; i2 < this.f1908e.length; i2++) {
            Log.d("ExifInterface", "The size of tag group[" + i2 + "]: " + this.f1908e[i2].size());
            for (Map.Entry<String, c> entry : this.f1908e[i2].entrySet()) {
                c value = entry.getValue();
                StringBuilder n2 = c.a.a.a.a.n("tagName: ");
                n2.append(entry.getKey());
                n2.append(", tagType: ");
                n2.append(value.toString());
                n2.append(", tagValue: '");
                n2.append(value.g(this.f1910g));
                n2.append("'");
                Log.d("ExifInterface", n2.toString());
            }
        }
    }

    public final ByteOrder s(b bVar) {
        short readShort = bVar.readShort();
        if (readShort == 18761) {
            if (n) {
                Log.d("ExifInterface", "readExifSegment: Byte Align II");
            }
            return ByteOrder.LITTLE_ENDIAN;
        }
        if (readShort == 19789) {
            if (n) {
                Log.d("ExifInterface", "readExifSegment: Byte Align MM");
            }
            return ByteOrder.BIG_ENDIAN;
        }
        StringBuilder n2 = c.a.a.a.a.n("Invalid byte order: ");
        n2.append(Integer.toHexString(readShort));
        throw new IOException(n2.toString());
    }

    public final void t(byte[] bArr, int i2) {
        f fVar = new f(bArr);
        q(fVar);
        u(fVar, i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:119:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x015f  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0164  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0246  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0264  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x02a0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void u(b.m.a.a.f r22, int r23) {
        /*
            Method dump skipped, instructions count: 955
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.m.a.a.u(b.m.a.a$f, int):void");
    }

    public final void v(int i2, String str, String str2) {
        if (this.f1908e[i2].isEmpty() || this.f1908e[i2].get(str) == null) {
            return;
        }
        HashMap[] hashMapArr = this.f1908e;
        hashMapArr[i2].put(str2, hashMapArr[i2].get(str));
        this.f1908e[i2].remove(str);
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:83:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void w(b.m.a.a.b r20) {
        /*
            Method dump skipped, instructions count: 348
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: b.m.a.a.w(b.m.a.a$b):void");
    }

    public final void x(int i2, int i3) {
        if (this.f1908e[i2].isEmpty() || this.f1908e[i3].isEmpty()) {
            if (n) {
                Log.d("ExifInterface", "Cannot perform swap since only one image data exists");
                return;
            }
            return;
        }
        c cVar = this.f1908e[i2].get("ImageLength");
        c cVar2 = this.f1908e[i2].get("ImageWidth");
        c cVar3 = this.f1908e[i3].get("ImageLength");
        c cVar4 = this.f1908e[i3].get("ImageWidth");
        if (cVar == null || cVar2 == null) {
            if (n) {
                Log.d("ExifInterface", "First image does not contain valid size information");
                return;
            }
            return;
        }
        if (cVar3 == null || cVar4 == null) {
            if (n) {
                Log.d("ExifInterface", "Second image does not contain valid size information");
                return;
            }
            return;
        }
        int f2 = cVar.f(this.f1910g);
        int f3 = cVar2.f(this.f1910g);
        int f4 = cVar3.f(this.f1910g);
        int f5 = cVar4.f(this.f1910g);
        if (f2 >= f4 || f3 >= f5) {
            return;
        }
        HashMap<String, c>[] hashMapArr = this.f1908e;
        HashMap<String, c> hashMap = hashMapArr[i2];
        hashMapArr[i2] = hashMapArr[i3];
        hashMapArr[i3] = hashMap;
    }

    public final void y(f fVar, int i2) {
        c d2;
        c d3;
        c cVar = this.f1908e[i2].get("DefaultCropSize");
        c cVar2 = this.f1908e[i2].get("SensorTopBorder");
        c cVar3 = this.f1908e[i2].get("SensorLeftBorder");
        c cVar4 = this.f1908e[i2].get("SensorBottomBorder");
        c cVar5 = this.f1908e[i2].get("SensorRightBorder");
        if (cVar != null) {
            if (cVar.f1922a == 5) {
                e[] eVarArr = (e[]) cVar.h(this.f1910g);
                if (eVarArr == null || eVarArr.length != 2) {
                    StringBuilder n2 = c.a.a.a.a.n("Invalid crop size values. cropSize=");
                    n2.append(Arrays.toString(eVarArr));
                    Log.w("ExifInterface", n2.toString());
                    return;
                }
                d2 = c.c(eVarArr[0], this.f1910g);
                d3 = c.c(eVarArr[1], this.f1910g);
            } else {
                int[] iArr = (int[]) cVar.h(this.f1910g);
                if (iArr == null || iArr.length != 2) {
                    StringBuilder n3 = c.a.a.a.a.n("Invalid crop size values. cropSize=");
                    n3.append(Arrays.toString(iArr));
                    Log.w("ExifInterface", n3.toString());
                    return;
                }
                d2 = c.d(iArr[0], this.f1910g);
                d3 = c.d(iArr[1], this.f1910g);
            }
            this.f1908e[i2].put("ImageWidth", d2);
            this.f1908e[i2].put("ImageLength", d3);
            return;
        }
        if (cVar2 != null && cVar3 != null && cVar4 != null && cVar5 != null) {
            int f2 = cVar2.f(this.f1910g);
            int f3 = cVar4.f(this.f1910g);
            int f4 = cVar5.f(this.f1910g);
            int f5 = cVar3.f(this.f1910g);
            if (f3 <= f2 || f4 <= f5) {
                return;
            }
            c d4 = c.d(f3 - f2, this.f1910g);
            c d5 = c.d(f4 - f5, this.f1910g);
            this.f1908e[i2].put("ImageLength", d4);
            this.f1908e[i2].put("ImageWidth", d5);
            return;
        }
        c cVar6 = this.f1908e[i2].get("ImageLength");
        c cVar7 = this.f1908e[i2].get("ImageWidth");
        if (cVar6 == null || cVar7 == null) {
            c cVar8 = this.f1908e[i2].get("JPEGInterchangeFormat");
            c cVar9 = this.f1908e[i2].get("JPEGInterchangeFormatLength");
            if (cVar8 == null || cVar9 == null) {
                return;
            }
            int f6 = cVar8.f(this.f1910g);
            int f7 = cVar8.f(this.f1910g);
            fVar.q(f6);
            byte[] bArr = new byte[f7];
            fVar.read(bArr);
            f(new b(bArr), f6, i2);
        }
    }

    public final void z() {
        x(0, 5);
        x(0, 4);
        x(5, 4);
        c cVar = this.f1908e[1].get("PixelXDimension");
        c cVar2 = this.f1908e[1].get("PixelYDimension");
        if (cVar != null && cVar2 != null) {
            this.f1908e[0].put("ImageWidth", cVar);
            this.f1908e[0].put("ImageLength", cVar2);
        }
        if (this.f1908e[4].isEmpty() && p(this.f1908e[5])) {
            HashMap<String, c>[] hashMapArr = this.f1908e;
            hashMapArr[4] = hashMapArr[5];
            hashMapArr[5] = new HashMap<>();
        }
        if (!p(this.f1908e[4])) {
            Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image.");
        }
        v(0, "ThumbnailOrientation", "Orientation");
        v(0, "ThumbnailImageLength", "ImageLength");
        v(0, "ThumbnailImageWidth", "ImageWidth");
        v(5, "ThumbnailOrientation", "Orientation");
        v(5, "ThumbnailImageLength", "ImageLength");
        v(5, "ThumbnailImageWidth", "ImageWidth");
        v(4, "Orientation", "ThumbnailOrientation");
        v(4, "ImageLength", "ThumbnailImageLength");
        v(4, "ImageWidth", "ThumbnailImageWidth");
    }
}
