package b.n.c;

import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\a0.smali */
public class a0 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList<Fragment> f1931a = new ArrayList<>();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap<String, y> f1932b = new HashMap<>();

    public void a(Fragment fragment) {
        if (this.f1931a.contains(fragment)) {
            throw new IllegalStateException("Fragment already added: " + fragment);
        }
        synchronized (this.f1931a) {
            this.f1931a.add(fragment);
        }
        fragment.n = true;
    }

    public void b() {
        this.f1932b.values().removeAll(Collections.singleton(null));
    }

    public boolean c(String str) {
        return this.f1932b.containsKey(str);
    }

    public void d(int i2) {
        Iterator<Fragment> it = this.f1931a.iterator();
        while (it.hasNext()) {
            y yVar = this.f1932b.get(it.next().f317h);
            if (yVar != null) {
                yVar.f2100c = i2;
            }
        }
        for (y yVar2 : this.f1932b.values()) {
            if (yVar2 != null) {
                yVar2.f2100c = i2;
            }
        }
    }

    public Fragment e(String str) {
        y yVar = this.f1932b.get(str);
        if (yVar != null) {
            return yVar.f2099b;
        }
        return null;
    }

    public List<Fragment> f() {
        ArrayList arrayList = new ArrayList();
        for (y yVar : this.f1932b.values()) {
            if (yVar != null) {
                arrayList.add(yVar.f2099b);
            } else {
                arrayList.add(null);
            }
        }
        return arrayList;
    }

    public List<Fragment> g() {
        ArrayList arrayList;
        if (this.f1931a.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f1931a) {
            arrayList = new ArrayList(this.f1931a);
        }
        return arrayList;
    }

    public void h(Fragment fragment) {
        synchronized (this.f1931a) {
            this.f1931a.remove(fragment);
        }
        fragment.n = false;
    }
}
