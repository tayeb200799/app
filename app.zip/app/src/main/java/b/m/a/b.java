package b.n.c;

import android.util.Log;
import androidx.fragment.app.Fragment;
import b.n.c.b0;
import b.n.c.r;
import b.p.g;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\n\c\a.smali */
public final class a extends b0 implements r.e {
    public final r p;
    public boolean q;
    public int r;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public a(b.n.c.r r3) {
        /*
            r2 = this;
            b.n.c.n r0 = r3.J()
            b.n.c.o<?> r1 = r3.n
            if (r1 == 0) goto Lf
            android.content.Context r1 = r1.f2046e
            java.lang.ClassLoader r1 = r1.getClassLoader()
            goto L10
        Lf:
            r1 = 0
        L10:
            r2.<init>(r0, r1)
            r0 = -1
            r2.r = r0
            r2.p = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.n.c.a.<init>(b.n.c.r):void");
    }

    public static boolean o(b0.a aVar) {
        Fragment fragment = aVar.f1951b;
        if (fragment == null || !fragment.n || fragment.H == null || fragment.C || fragment.B) {
            return false;
        }
        Fragment.a aVar2 = fragment.K;
        return false;
    }

    @Override // b.n.c.r.e
    public boolean a(ArrayList<a> arrayList, ArrayList<Boolean> arrayList2) {
        if (r.M(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f1946g) {
            return true;
        }
        r rVar = this.p;
        if (rVar.f2056d == null) {
            rVar.f2056d = new ArrayList<>();
        }
        rVar.f2056d.add(this);
        return true;
    }

    @Override // b.n.c.b0
    public int c() {
        return i(true);
    }

    @Override // b.n.c.b0
    public void d() {
        if (this.f1946g) {
            throw new IllegalStateException("This transaction is already being added to the back stack");
        }
        r rVar = this.p;
        if (rVar.n == null || rVar.v) {
            return;
        }
        rVar.A(true);
        a(rVar.x, rVar.y);
        rVar.f2054b = true;
        try {
            rVar.Z(rVar.x, rVar.y);
            rVar.f();
            rVar.l0();
            rVar.w();
            rVar.f2055c.b();
        } catch (Throwable th) {
            rVar.f();
            throw th;
        }
    }

    @Override // b.n.c.b0
    public void e(int i2, Fragment fragment, String str, int i3) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            StringBuilder n = c.a.a.a.a.n("Fragment ");
            n.append(cls.getCanonicalName());
            n.append(" must be a public static class to be  properly recreated from instance state.");
            throw new IllegalStateException(n.toString());
        }
        if (str != null) {
            String str2 = fragment.A;
            if (str2 != null && !str.equals(str2)) {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.A + " now " + str);
            }
            fragment.A = str;
        }
        if (i2 != 0) {
            if (i2 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
            int i4 = fragment.y;
            if (i4 != 0 && i4 != i2) {
                throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.y + " now " + i2);
            }
            fragment.y = i2;
            fragment.z = i2;
        }
        b(new b0.a(i3, fragment));
        fragment.u = this.p;
    }

    @Override // b.n.c.b0
    public b0 f(Fragment fragment) {
        r rVar = fragment.u;
        if (rVar == null || rVar == this.p) {
            b(new b0.a(3, fragment));
            return this;
        }
        StringBuilder n = c.a.a.a.a.n("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
        n.append(fragment.toString());
        n.append(" is already attached to a FragmentManager.");
        throw new IllegalStateException(n.toString());
    }

    @Override // b.n.c.b0
    public b0 g(Fragment fragment, g.b bVar) {
        if (fragment.u != this.p) {
            StringBuilder n = c.a.a.a.a.n("Cannot setMaxLifecycle for Fragment not attached to FragmentManager ");
            n.append(this.p);
            throw new IllegalArgumentException(n.toString());
        }
        g.b bVar2 = g.b.CREATED;
        if (bVar.compareTo(bVar2) >= 0) {
            b(new b0.a(10, fragment, bVar));
            return this;
        }
        throw new IllegalArgumentException("Cannot set maximum Lifecycle below " + bVar2);
    }

    public void h(int i2) {
        if (this.f1946g) {
            if (r.M(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            int size = this.f1940a.size();
            for (int i3 = 0; i3 < size; i3++) {
                b0.a aVar = this.f1940a.get(i3);
                Fragment fragment = aVar.f1951b;
                if (fragment != null) {
                    fragment.t += i2;
                    if (r.M(2)) {
                        StringBuilder n = c.a.a.a.a.n("Bump nesting of ");
                        n.append(aVar.f1951b);
                        n.append(" to ");
                        n.append(aVar.f1951b.t);
                        Log.v("FragmentManager", n.toString());
                    }
                }
            }
        }
    }

    public int i(boolean z) {
        if (this.q) {
            throw new IllegalStateException("commit already called");
        }
        if (r.M(2)) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new b.h.j.b("FragmentManager"));
            j("  ", printWriter, true);
            printWriter.close();
        }
        this.q = true;
        if (this.f1946g) {
            this.r = this.p.f2061i.getAndIncrement();
        } else {
            this.r = -1;
        }
        this.p.z(this, z);
        return this.r;
    }

    public void j(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f1947h);
            printWriter.print(" mIndex=");
            printWriter.print(this.r);
            printWriter.print(" mCommitted=");
            printWriter.println(this.q);
            if (this.f1945f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f1945f));
            }
            if (this.f1941b != 0 || this.f1942c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f1941b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f1942c));
            }
            if (this.f1943d != 0 || this.f1944e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f1943d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f1944e));
            }
            if (this.f1948i != 0 || this.f1949j != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f1948i));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f1949j);
            }
            if (this.k != 0 || this.l != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.k));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.l);
            }
        }
        if (this.f1940a.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = this.f1940a.size();
        for (int i2 = 0; i2 < size; i2++) {
            b0.a aVar = this.f1940a.get(i2);
            switch (aVar.f1950a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case ModuleDescriptor.MODULE_VERSION /* 3 */:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case 7:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    StringBuilder n = c.a.a.a.a.n("cmd=");
                    n.append(aVar.f1950a);
                    str2 = n.toString();
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i2);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(aVar.f1951b);
            if (z) {
                if (aVar.f1952c != 0 || aVar.f1953d != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(aVar.f1952c));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(aVar.f1953d));
                }
                if (aVar.f1954e != 0 || aVar.f1955f != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(aVar.f1954e));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(aVar.f1955f));
                }
            }
        }
    }

    public void k() {
        int size = this.f1940a.size();
        for (int i2 = 0; i2 < size; i2++) {
            b0.a aVar = this.f1940a.get(i2);
            Fragment fragment = aVar.f1951b;
            if (fragment != null) {
                int i3 = this.f1945f;
                if (fragment.K != null || i3 != 0) {
                    fragment.v();
                    fragment.K.f325e = i3;
                }
            }
            switch (aVar.f1950a) {
                case 1:
                    fragment.x0(aVar.f1952c);
                    this.p.e0(fragment, false);
                    this.p.b(fragment);
                    break;
                case 2:
                default:
                    StringBuilder n = c.a.a.a.a.n("Unknown cmd: ");
                    n.append(aVar.f1950a);
                    throw new IllegalArgumentException(n.toString());
                case ModuleDescriptor.MODULE_VERSION /* 3 */:
                    fragment.x0(aVar.f1953d);
                    this.p.Y(fragment);
                    break;
                case 4:
                    fragment.x0(aVar.f1953d);
                    this.p.L(fragment);
                    break;
                case 5:
                    fragment.x0(aVar.f1952c);
                    this.p.e0(fragment, false);
                    this.p.i0(fragment);
                    break;
                case 6:
                    fragment.x0(aVar.f1953d);
                    this.p.i(fragment);
                    break;
                case 7:
                    fragment.x0(aVar.f1952c);
                    this.p.e0(fragment, false);
                    this.p.d(fragment);
                    break;
                case 8:
                    this.p.g0(fragment);
                    break;
                case 9:
                    this.p.g0(null);
                    break;
                case 10:
                    this.p.f0(fragment, aVar.f1957h);
                    break;
            }
            if (!this.o && aVar.f1950a != 1 && fragment != null) {
                this.p.R(fragment);
            }
        }
        if (this.o) {
            return;
        }
        r rVar = this.p;
        rVar.S(rVar.m, true);
    }

    public void l(boolean z) {
        for (int size = this.f1940a.size() - 1; size >= 0; size--) {
            b0.a aVar = this.f1940a.get(size);
            Fragment fragment = aVar.f1951b;
            if (fragment != null) {
                int i2 = this.f1945f;
                int i3 = i2 != 4097 ? i2 != 4099 ? i2 != 8194 ? 0 : 4097 : 4099 : 8194;
                if (fragment.K != null || i3 != 0) {
                    fragment.v();
                    fragment.K.f325e = i3;
                }
            }
            switch (aVar.f1950a) {
                case 1:
                    fragment.x0(aVar.f1955f);
                    this.p.e0(fragment, true);
                    this.p.Y(fragment);
                    break;
                case 2:
                default:
                    StringBuilder n = c.a.a.a.a.n("Unknown cmd: ");
                    n.append(aVar.f1950a);
                    throw new IllegalArgumentException(n.toString());
                case ModuleDescriptor.MODULE_VERSION /* 3 */:
                    fragment.x0(aVar.f1954e);
                    this.p.b(fragment);
                    break;
                case 4:
                    fragment.x0(aVar.f1954e);
                    this.p.i0(fragment);
                    break;
                case 5:
                    fragment.x0(aVar.f1955f);
                    this.p.e0(fragment, true);
                    this.p.L(fragment);
                    break;
                case 6:
                    fragment.x0(aVar.f1954e);
                    this.p.d(fragment);
                    break;
                case 7:
                    fragment.x0(aVar.f1955f);
                    this.p.e0(fragment, true);
                    this.p.i(fragment);
                    break;
                case 8:
                    this.p.g0(null);
                    break;
                case 9:
                    this.p.g0(fragment);
                    break;
                case 10:
                    this.p.f0(fragment, aVar.f1956g);
                    break;
            }
            if (!this.o && aVar.f1950a != 3 && fragment != null) {
                this.p.R(fragment);
            }
        }
        if (this.o || !z) {
            return;
        }
        r rVar = this.p;
        rVar.S(rVar.m, true);
    }

    public boolean m(int i2) {
        int size = this.f1940a.size();
        for (int i3 = 0; i3 < size; i3++) {
            Fragment fragment = this.f1940a.get(i3).f1951b;
            int i4 = fragment != null ? fragment.z : 0;
            if (i4 != 0 && i4 == i2) {
                return true;
            }
        }
        return false;
    }

    public boolean n(ArrayList<a> arrayList, int i2, int i3) {
        if (i3 == i2) {
            return false;
        }
        int size = this.f1940a.size();
        int i4 = -1;
        for (int i5 = 0; i5 < size; i5++) {
            Fragment fragment = this.f1940a.get(i5).f1951b;
            int i6 = fragment != null ? fragment.z : 0;
            if (i6 != 0 && i6 != i4) {
                for (int i7 = i2; i7 < i3; i7++) {
                    a aVar = arrayList.get(i7);
                    int size2 = aVar.f1940a.size();
                    for (int i8 = 0; i8 < size2; i8++) {
                        Fragment fragment2 = aVar.f1940a.get(i8).f1951b;
                        if ((fragment2 != null ? fragment2.z : 0) == i6) {
                            return true;
                        }
                    }
                }
                i4 = i6;
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.r >= 0) {
            sb.append(" #");
            sb.append(this.r);
        }
        if (this.f1947h != null) {
            sb.append(" ");
            sb.append(this.f1947h);
        }
        sb.append("}");
        return sb.toString();
    }
}
