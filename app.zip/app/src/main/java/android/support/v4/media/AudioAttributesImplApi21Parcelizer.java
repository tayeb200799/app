package android.support.v4.media;

import androidx.media.AudioAttributesImplApi26;
import b.a0.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\AudioAttributesImplApi26Parcelizer.smali */
public final class AudioAttributesImplApi26Parcelizer extends androidx.media.AudioAttributesImplApi26Parcelizer {
    public static AudioAttributesImplApi26 read(b bVar) {
        return androidx.media.AudioAttributesImplApi26Parcelizer.read(bVar);
    }

    public static void write(AudioAttributesImplApi26 audioAttributesImplApi26, b bVar) {
        androidx.media.AudioAttributesImplApi26Parcelizer.write(audioAttributesImplApi26, bVar);
    }
}
