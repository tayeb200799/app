package android.support.v4.media.session;

import a.a.a.a.a.b;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.media.MediaDescription;
import android.media.Rating;
import android.media.session.MediaSession;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteCallbackList;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import androidx.versionedparcelable.ParcelImpl;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat.smali */
public class MediaSessionCompat {

    /* renamed from: b, reason: collision with root package name */
    public static final int f31b;

    /* renamed from: c, reason: collision with root package name */
    public static int f32c;

    /* renamed from: a, reason: collision with root package name */
    public final b f33a;

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$QueueItem.smali */
    public static final class QueueItem implements Parcelable {
        public static final Parcelable.Creator<QueueItem> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public final MediaDescriptionCompat f34d;

        /* renamed from: e, reason: collision with root package name */
        public final long f35e;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$QueueItem$a.smali */
        public class a implements Parcelable.Creator<QueueItem> {
            @Override // android.os.Parcelable.Creator
            public QueueItem createFromParcel(Parcel parcel) {
                return new QueueItem(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public QueueItem[] newArray(int i2) {
                return new QueueItem[i2];
            }
        }

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$QueueItem$b.smali */
        public static class b {
            public static MediaSession.QueueItem a(MediaDescription mediaDescription, long j2) {
                return new MediaSession.QueueItem(mediaDescription, j2);
            }

            public static MediaDescription b(MediaSession.QueueItem queueItem) {
                return queueItem.getDescription();
            }

            public static long c(MediaSession.QueueItem queueItem) {
                return queueItem.getQueueId();
            }
        }

        public QueueItem(MediaSession.QueueItem queueItem, MediaDescriptionCompat mediaDescriptionCompat, long j2) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("Description cannot be null");
            }
            if (j2 == -1) {
                throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
            }
            this.f34d = mediaDescriptionCompat;
            this.f35e = j2;
        }

        public QueueItem(Parcel parcel) {
            this.f34d = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
            this.f35e = parcel.readLong();
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder n = c.a.a.a.a.n("MediaSession.QueueItem {Description=");
            n.append(this.f34d);
            n.append(", Id=");
            n.append(this.f35e);
            n.append(" }");
            return n.toString();
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            this.f34d.writeToParcel(parcel, i2);
            parcel.writeLong(this.f35e);
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$ResultReceiverWrapper.smali */
    public static final class ResultReceiverWrapper implements Parcelable {
        public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public ResultReceiver f36d;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$ResultReceiverWrapper$a.smali */
        public class a implements Parcelable.Creator<ResultReceiverWrapper> {
            @Override // android.os.Parcelable.Creator
            public ResultReceiverWrapper createFromParcel(Parcel parcel) {
                return new ResultReceiverWrapper(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public ResultReceiverWrapper[] newArray(int i2) {
                return new ResultReceiverWrapper[i2];
            }
        }

        public ResultReceiverWrapper(Parcel parcel) {
            this.f36d = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            this.f36d.writeToParcel(parcel, i2);
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$Token.smali */
    public static final class Token implements Parcelable {
        public static final Parcelable.Creator<Token> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public final Object f37d = new Object();

        /* renamed from: e, reason: collision with root package name */
        public final Object f38e;

        /* renamed from: f, reason: collision with root package name */
        public a.a.a.a.a.b f39f;

        /* renamed from: g, reason: collision with root package name */
        public b.a0.d f40g;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$Token$a.smali */
        public class a implements Parcelable.Creator<Token> {
            @Override // android.os.Parcelable.Creator
            public Token createFromParcel(Parcel parcel) {
                return new Token(parcel.readParcelable(null), null, null);
            }

            @Override // android.os.Parcelable.Creator
            public Token[] newArray(int i2) {
                return new Token[i2];
            }
        }

        public Token(Object obj, a.a.a.a.a.b bVar, b.a0.d dVar) {
            this.f38e = obj;
            this.f39f = bVar;
            this.f40g = dVar;
        }

        public a.a.a.a.a.b a() {
            a.a.a.a.a.b bVar;
            synchronized (this.f37d) {
                bVar = this.f39f;
            }
            return bVar;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Token)) {
                return false;
            }
            Token token = (Token) obj;
            Object obj2 = this.f38e;
            if (obj2 == null) {
                return token.f38e == null;
            }
            Object obj3 = token.f38e;
            if (obj3 == null) {
                return false;
            }
            return obj2.equals(obj3);
        }

        public int hashCode() {
            Object obj = this.f38e;
            if (obj == null) {
                return 0;
            }
            return obj.hashCode();
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable((Parcelable) this.f38e, i2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$a.smali */
    public static abstract class a {

        /* renamed from: c, reason: collision with root package name */
        public boolean f43c;

        /* renamed from: e, reason: collision with root package name */
        public HandlerC0006a f45e;

        /* renamed from: a, reason: collision with root package name */
        public final Object f41a = new Object();

        /* renamed from: b, reason: collision with root package name */
        public final MediaSession.Callback f42b = new b();

        /* renamed from: d, reason: collision with root package name */
        public WeakReference<b> f44d = new WeakReference<>(null);

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$a$a, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$a$a.smali */
        public class HandlerC0006a extends Handler {
            public HandlerC0006a(Looper looper) {
                super(looper);
            }

            @Override // android.os.Handler
            public void handleMessage(Message message) {
                b bVar;
                a aVar;
                HandlerC0006a handlerC0006a;
                if (message.what == 1) {
                    synchronized (a.this.f41a) {
                        bVar = a.this.f44d.get();
                        aVar = a.this;
                        handlerC0006a = aVar.f45e;
                    }
                    if (bVar == null || aVar != bVar.e() || handlerC0006a == null) {
                        return;
                    }
                    bVar.b((b.s.a) message.obj);
                    a.this.a(bVar, handlerC0006a);
                    bVar.b(null);
                }
            }
        }

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$a$b.smali */
        public class b extends MediaSession.Callback {
            public b() {
            }

            public final c a() {
                c cVar;
                a aVar;
                synchronized (a.this.f41a) {
                    cVar = (c) a.this.f44d.get();
                }
                if (cVar != null) {
                    a aVar2 = a.this;
                    synchronized (cVar.f50c) {
                        aVar = cVar.f53f;
                    }
                    if (aVar2 == aVar) {
                        return cVar;
                    }
                }
                return null;
            }

            public final void b(b bVar) {
                if (Build.VERSION.SDK_INT >= 28) {
                    return;
                }
                String i2 = ((c) bVar).i();
                if (TextUtils.isEmpty(i2)) {
                    i2 = "android.media.session.MediaController";
                }
                bVar.b(new b.s.a(i2, -1, -1));
            }

            @Override // android.media.session.MediaSession.Callback
            public void onCommand(String str, Bundle bundle, ResultReceiver resultReceiver) {
                b.a0.d dVar;
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                try {
                    if (str.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER")) {
                        Bundle bundle2 = new Bundle();
                        Token token = a2.f49b;
                        a.a.a.a.a.b a3 = token.a();
                        bundle2.putBinder("android.support.v4.media.session.EXTRA_BINDER", a3 == null ? null : a3.asBinder());
                        synchronized (token.f37d) {
                            dVar = token.f40g;
                        }
                        if (dVar != null) {
                            Bundle bundle3 = new Bundle();
                            bundle3.putParcelable("a", new ParcelImpl(dVar));
                            bundle2.putParcelable("android.support.v4.media.session.SESSION_TOKEN2", bundle3);
                        }
                        resultReceiver.send(0, bundle2);
                    } else if (str.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM")) {
                        a aVar = a.this;
                        Objects.requireNonNull(aVar);
                    } else if (str.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT")) {
                        a aVar2 = a.this;
                        bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX");
                        Objects.requireNonNull(aVar2);
                    } else if (str.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM")) {
                        a aVar3 = a.this;
                        Objects.requireNonNull(aVar3);
                    } else if (!str.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT")) {
                        Objects.requireNonNull(a.this);
                    }
                } catch (BadParcelableException unused) {
                    Log.e("MediaSessionCompat", "Could not unparcel the extra data.");
                }
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onCustomAction(String str, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                try {
                    if (str.equals("android.support.v4.media.session.action.PLAY_FROM_URI")) {
                        MediaSessionCompat.a(bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS"));
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE")) {
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
                        bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
                        MediaSessionCompat.a(bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS"));
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
                        bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
                        MediaSessionCompat.a(bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS"));
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
                        MediaSessionCompat.a(bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS"));
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
                        bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED");
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
                        bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE");
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
                        bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE");
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.SET_RATING")) {
                        MediaSessionCompat.a(bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS"));
                        Objects.requireNonNull(a.this);
                    } else if (str.equals("android.support.v4.media.session.action.SET_PLAYBACK_SPEED")) {
                        bundle.getFloat("android.support.v4.media.session.action.ARGUMENT_PLAYBACK_SPEED", 1.0f);
                        Objects.requireNonNull(a.this);
                    } else {
                        Objects.requireNonNull(a.this);
                    }
                } catch (BadParcelableException unused) {
                    Log.e("MediaSessionCompat", "Could not unparcel the data.");
                }
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onFastForward() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public boolean onMediaButtonEvent(Intent intent) {
                c a2 = a();
                if (a2 == null) {
                    return false;
                }
                b(a2);
                boolean b2 = a.this.b(intent);
                a2.b(null);
                return b2 || super.onMediaButtonEvent(intent);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPause() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlay() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlayFromMediaId(String str, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlayFromSearch(String str, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlayFromUri(Uri uri, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepare() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepareFromMediaId(String str, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepareFromSearch(String str, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepareFromUri(Uri uri, Bundle bundle) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onRewind() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSeekTo(long j2) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSetPlaybackSpeed(float f2) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSetRating(Rating rating) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                a aVar = a.this;
                RatingCompat.a(rating);
                Objects.requireNonNull(aVar);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSkipToNext() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSkipToPrevious() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSkipToQueueItem(long j2) {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onStop() {
                c a2 = a();
                if (a2 == null) {
                    return;
                }
                b(a2);
                Objects.requireNonNull(a.this);
                a2.b(null);
            }
        }

        public void a(b bVar, Handler handler) {
            if (this.f43c) {
                this.f43c = false;
                handler.removeMessages(1);
                PlaybackStateCompat d2 = bVar.d();
                long j2 = d2 == null ? 0L : d2.f65h;
                if (d2 != null) {
                    int i2 = d2.f61d;
                }
                int i3 = ((516 & j2) > 0L ? 1 : ((516 & j2) == 0L ? 0 : -1));
                int i4 = ((514 & j2) > 0L ? 1 : ((514 & j2) == 0L ? 0 : -1));
            }
        }

        public boolean b(Intent intent) {
            b bVar;
            HandlerC0006a handlerC0006a;
            KeyEvent keyEvent;
            if (Build.VERSION.SDK_INT >= 27) {
                return false;
            }
            synchronized (this.f41a) {
                bVar = this.f44d.get();
                handlerC0006a = this.f45e;
            }
            if (bVar == null || handlerC0006a == null || (keyEvent = (KeyEvent) intent.getParcelableExtra("android.intent.extra.KEY_EVENT")) == null || keyEvent.getAction() != 0) {
                return false;
            }
            b.s.a g2 = bVar.g();
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 79 && keyCode != 85) {
                a(bVar, handlerC0006a);
                return false;
            }
            if (keyEvent.getRepeatCount() != 0) {
                a(bVar, handlerC0006a);
            } else if (this.f43c) {
                handlerC0006a.removeMessages(1);
                this.f43c = false;
                PlaybackStateCompat d2 = bVar.d();
                int i2 = (((d2 == null ? 0L : d2.f65h) & 32) > 0L ? 1 : (((d2 == null ? 0L : d2.f65h) & 32) == 0L ? 0 : -1));
            } else {
                this.f43c = true;
                handlerC0006a.sendMessageDelayed(handlerC0006a.obtainMessage(1, g2), ViewConfiguration.getDoubleTapTimeout());
            }
            return true;
        }

        public void c(b bVar, Handler handler) {
            synchronized (this.f41a) {
                this.f44d = new WeakReference<>(bVar);
                HandlerC0006a handlerC0006a = this.f45e;
                HandlerC0006a handlerC0006a2 = null;
                if (handlerC0006a != null) {
                    handlerC0006a.removeCallbacksAndMessages(null);
                }
                if (bVar != null && handler != null) {
                    handlerC0006a2 = new HandlerC0006a(handler.getLooper());
                }
                this.f45e = handlerC0006a2;
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$b.smali */
    public interface b {
        Token a();

        void b(b.s.a aVar);

        void c(a aVar, Handler handler);

        PlaybackStateCompat d();

        a e();

        void f(PendingIntent pendingIntent);

        b.s.a g();
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$c.smali */
    public static class c implements b {

        /* renamed from: a, reason: collision with root package name */
        public final MediaSession f48a;

        /* renamed from: b, reason: collision with root package name */
        public final Token f49b;

        /* renamed from: d, reason: collision with root package name */
        public Bundle f51d;

        /* renamed from: f, reason: collision with root package name */
        public a f53f;

        /* renamed from: g, reason: collision with root package name */
        public b.s.a f54g;

        /* renamed from: c, reason: collision with root package name */
        public final Object f50c = new Object();

        /* renamed from: e, reason: collision with root package name */
        public final RemoteCallbackList<a.a.a.a.a.a> f52e = new RemoteCallbackList<>();

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$c$a.smali */
        public class a extends b.a {
            public a() {
            }

            @Override // a.a.a.a.a.b
            public PendingIntent A() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public int B() {
                Objects.requireNonNull(c.this);
                return 0;
            }

            @Override // a.a.a.a.a.b
            public void C(int i2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public int D() {
                Objects.requireNonNull(c.this);
                return 0;
            }

            @Override // a.a.a.a.a.b
            public void F(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public boolean G() {
                Objects.requireNonNull(c.this);
                return false;
            }

            @Override // a.a.a.a.a.b
            public void L(String str, Bundle bundle, ResultReceiverWrapper resultReceiverWrapper) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public List<QueueItem> M() {
                return null;
            }

            @Override // a.a.a.a.a.b
            public void O(int i2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void P() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public CharSequence Q() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public MediaMetadataCompat R() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void S(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public Bundle T() {
                if (c.this.f51d == null) {
                    return null;
                }
                return new Bundle(c.this.f51d);
            }

            @Override // a.a.a.a.a.b
            public void U(a.a.a.a.a.a aVar) {
                c.this.f52e.unregister(aVar);
            }

            @Override // a.a.a.a.a.b
            public void W(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public long X() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public int Y() {
                Objects.requireNonNull(c.this);
                return 0;
            }

            @Override // a.a.a.a.a.b
            public void Z(long j2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void a0(boolean z) {
            }

            @Override // a.a.a.a.a.b
            public void b0(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public ParcelableVolumeInfo c0() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public PlaybackStateCompat d() {
                Objects.requireNonNull(c.this);
                Objects.requireNonNull(c.this);
                return MediaSessionCompat.b(null, null);
            }

            @Override // a.a.a.a.a.b
            public void d0() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void f() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public Bundle f0() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public String g() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void g0(Uri uri, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void h() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void h0(long j2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void i() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void i0(int i2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public String j0() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void k(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void k0(float f2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void l(int i2, int i3, String str) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void m(a.a.a.a.a.a aVar) {
                Objects.requireNonNull(c.this);
                c.this.f52e.register(aVar, new b.s.a("android.media.session.MediaController", Binder.getCallingPid(), Binder.getCallingUid()));
            }

            @Override // a.a.a.a.a.b
            public boolean m0(KeyEvent keyEvent) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void n(RatingCompat ratingCompat, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void next() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void p(MediaDescriptionCompat mediaDescriptionCompat, int i2) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void previous() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public boolean r() {
                return false;
            }

            @Override // a.a.a.a.a.b
            public void s(boolean z) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void stop() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void t(RatingCompat ratingCompat) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void u(int i2, int i3, String str) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void v(Uri uri, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void x(MediaDescriptionCompat mediaDescriptionCompat) {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public boolean y() {
                throw new AssertionError();
            }

            @Override // a.a.a.a.a.b
            public void z(MediaDescriptionCompat mediaDescriptionCompat) {
                throw new AssertionError();
            }
        }

        public c(Context context, String str, b.a0.d dVar, Bundle bundle) {
            MediaSession h2 = h(context, str, bundle);
            this.f48a = h2;
            this.f49b = new Token(h2.getSessionToken(), new a(), dVar);
            this.f51d = bundle;
            h2.setFlags(3);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public Token a() {
            return this.f49b;
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void b(b.s.a aVar) {
            synchronized (this.f50c) {
                this.f54g = aVar;
            }
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void c(a aVar, Handler handler) {
            synchronized (this.f50c) {
                this.f53f = aVar;
                this.f48a.setCallback(aVar == null ? null : aVar.f42b, handler);
                if (aVar != null) {
                    aVar.c(this, handler);
                }
            }
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public PlaybackStateCompat d() {
            return null;
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public a e() {
            a aVar;
            synchronized (this.f50c) {
                aVar = this.f53f;
            }
            return aVar;
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void f(PendingIntent pendingIntent) {
            this.f48a.setMediaButtonReceiver(pendingIntent);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public b.s.a g() {
            b.s.a aVar;
            synchronized (this.f50c) {
                aVar = this.f54g;
            }
            return aVar;
        }

        public MediaSession h(Context context, String str, Bundle bundle) {
            return new MediaSession(context, str);
        }

        public String i() {
            if (Build.VERSION.SDK_INT < 24) {
                return null;
            }
            try {
                return (String) this.f48a.getClass().getMethod("getCallingPackage", new Class[0]).invoke(this.f48a, new Object[0]);
            } catch (Exception e2) {
                Log.e("MediaSessionCompat", "Cannot execute MediaSession.getCallingPackage()", e2);
                return null;
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$d.smali */
    public static class d extends c {
        public d(Context context, String str, b.a0.d dVar, Bundle bundle) {
            super(context, str, dVar, bundle);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$e.smali */
    public static class e extends d {
        public e(Context context, String str, b.a0.d dVar, Bundle bundle) {
            super(context, str, dVar, bundle);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c, android.support.v4.media.session.MediaSessionCompat.b
        public void b(b.s.a aVar) {
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c, android.support.v4.media.session.MediaSessionCompat.b
        public final b.s.a g() {
            return new b.s.a(this.f48a.getCurrentControllerInfo());
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaSessionCompat$f.smali */
    public static class f extends e {
        public f(Context context, String str, b.a0.d dVar, Bundle bundle) {
            super(context, str, dVar, bundle);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public MediaSession h(Context context, String str, Bundle bundle) {
            return new MediaSession(context, str, bundle);
        }
    }

    static {
        boolean z = true;
        if (Build.VERSION.SDK_INT < 31) {
            String str = Build.VERSION.CODENAME;
            if (!(!"REL".equals(str) && str.compareTo("S") >= 0)) {
                z = false;
            }
        }
        f31b = z ? 33554432 : 0;
    }

    public MediaSessionCompat(Context context, String str) {
        ComponentName componentName;
        PendingIntent pendingIntent;
        int i2 = Build.VERSION.SDK_INT;
        new ArrayList();
        if (context == null) {
            throw new IllegalArgumentException("context must not be null");
        }
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("tag must not be null or empty");
        }
        int i3 = b.s.e.a.f2193a;
        Intent intent = new Intent("android.intent.action.MEDIA_BUTTON");
        intent.setPackage(context.getPackageName());
        List<ResolveInfo> queryBroadcastReceivers = context.getPackageManager().queryBroadcastReceivers(intent, 0);
        if (queryBroadcastReceivers.size() == 1) {
            ActivityInfo activityInfo = queryBroadcastReceivers.get(0).activityInfo;
            componentName = new ComponentName(activityInfo.packageName, activityInfo.name);
        } else {
            if (queryBroadcastReceivers.size() > 1) {
                Log.w("MediaButtonReceiver", "More than one BroadcastReceiver that handles android.intent.action.MEDIA_BUTTON was found, returning null.");
            }
            componentName = null;
        }
        if (componentName == null) {
            Log.w("MediaSessionCompat", "Couldn't find a unique registered media button receiver in the given context.");
        }
        if (componentName != null) {
            Intent intent2 = new Intent("android.intent.action.MEDIA_BUTTON");
            intent2.setComponent(componentName);
            pendingIntent = PendingIntent.getBroadcast(context, 0, intent2, f31b);
        } else {
            pendingIntent = null;
        }
        if (i2 >= 29) {
            this.f33a = new f(context, str, null, null);
        } else if (i2 >= 28) {
            this.f33a = new e(context, str, null, null);
        } else if (i2 >= 22) {
            this.f33a = new d(context, str, null, null);
        } else {
            this.f33a = new c(context, str, null, null);
        }
        this.f33a.c(new a.a.a.a.a.e(this), new Handler(Looper.myLooper() != null ? Looper.myLooper() : Looper.getMainLooper()));
        this.f33a.f(pendingIntent);
        new ConcurrentHashMap();
        Token a2 = this.f33a.a();
        if (i2 >= 29) {
            new a.a.a.a.a.d(context, a2);
        } else {
            new MediaControllerCompat$MediaControllerImplApi21(context, a2);
        }
        if (f32c == 0) {
            f32c = (int) (TypedValue.applyDimension(1, 320.0f, context.getResources().getDisplayMetrics()) + 0.5f);
        }
    }

    public static void a(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
        }
    }

    public static PlaybackStateCompat b(PlaybackStateCompat playbackStateCompat, MediaMetadataCompat mediaMetadataCompat) {
        return null;
    }

    public static Bundle c(Bundle bundle) {
        a(bundle);
        try {
            bundle.isEmpty();
            return bundle;
        } catch (BadParcelableException unused) {
            Log.e("MediaSessionCompat", "Could not unparcel the data.");
            return null;
        }
    }
}
