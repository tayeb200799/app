package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\PlaybackStateCompat.smali */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();

    /* renamed from: d, reason: collision with root package name */
    public final int f61d;

    /* renamed from: e, reason: collision with root package name */
    public final long f62e;

    /* renamed from: f, reason: collision with root package name */
    public final long f63f;

    /* renamed from: g, reason: collision with root package name */
    public final float f64g;

    /* renamed from: h, reason: collision with root package name */
    public final long f65h;

    /* renamed from: i, reason: collision with root package name */
    public final int f66i;

    /* renamed from: j, reason: collision with root package name */
    public final CharSequence f67j;
    public final long k;
    public List<CustomAction> l;
    public final long m;
    public final Bundle n;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\PlaybackStateCompat$CustomAction.smali */
    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public final String f68d;

        /* renamed from: e, reason: collision with root package name */
        public final CharSequence f69e;

        /* renamed from: f, reason: collision with root package name */
        public final int f70f;

        /* renamed from: g, reason: collision with root package name */
        public final Bundle f71g;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\PlaybackStateCompat$CustomAction$a.smali */
        public class a implements Parcelable.Creator<CustomAction> {
            @Override // android.os.Parcelable.Creator
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public CustomAction[] newArray(int i2) {
                return new CustomAction[i2];
            }
        }

        public CustomAction(Parcel parcel) {
            this.f68d = parcel.readString();
            this.f69e = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f70f = parcel.readInt();
            this.f71g = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        public CustomAction(String str, CharSequence charSequence, int i2, Bundle bundle) {
            this.f68d = str;
            this.f69e = charSequence;
            this.f70f = i2;
            this.f71g = bundle;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder n = c.a.a.a.a.n("Action:mName='");
            n.append((Object) this.f69e);
            n.append(", mIcon=");
            n.append(this.f70f);
            n.append(", mExtras=");
            n.append(this.f71g);
            return n.toString();
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeString(this.f68d);
            TextUtils.writeToParcel(this.f69e, parcel, i2);
            parcel.writeInt(this.f70f);
            parcel.writeBundle(this.f71g);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\PlaybackStateCompat$a.smali */
    public class a implements Parcelable.Creator<PlaybackStateCompat> {
        @Override // android.os.Parcelable.Creator
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public PlaybackStateCompat[] newArray(int i2) {
            return new PlaybackStateCompat[i2];
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\PlaybackStateCompat$b.smali */
    public static class b {
        public static void a(PlaybackState.Builder builder, PlaybackState.CustomAction customAction) {
            builder.addCustomAction(customAction);
        }

        public static PlaybackState.CustomAction b(PlaybackState.CustomAction.Builder builder) {
            return builder.build();
        }

        public static PlaybackState c(PlaybackState.Builder builder) {
            return builder.build();
        }

        public static PlaybackState.Builder d() {
            return new PlaybackState.Builder();
        }

        public static PlaybackState.CustomAction.Builder e(String str, CharSequence charSequence, int i2) {
            return new PlaybackState.CustomAction.Builder(str, charSequence, i2);
        }

        public static String f(PlaybackState.CustomAction customAction) {
            return customAction.getAction();
        }

        public static long g(PlaybackState playbackState) {
            return playbackState.getActions();
        }

        public static long h(PlaybackState playbackState) {
            return playbackState.getActiveQueueItemId();
        }

        public static long i(PlaybackState playbackState) {
            return playbackState.getBufferedPosition();
        }

        public static List<PlaybackState.CustomAction> j(PlaybackState playbackState) {
            return playbackState.getCustomActions();
        }

        public static CharSequence k(PlaybackState playbackState) {
            return playbackState.getErrorMessage();
        }

        public static Bundle l(PlaybackState.CustomAction customAction) {
            return customAction.getExtras();
        }

        public static int m(PlaybackState.CustomAction customAction) {
            return customAction.getIcon();
        }

        public static long n(PlaybackState playbackState) {
            return playbackState.getLastPositionUpdateTime();
        }

        public static CharSequence o(PlaybackState.CustomAction customAction) {
            return customAction.getName();
        }

        public static float p(PlaybackState playbackState) {
            return playbackState.getPlaybackSpeed();
        }

        public static long q(PlaybackState playbackState) {
            return playbackState.getPosition();
        }

        public static int r(PlaybackState playbackState) {
            return playbackState.getState();
        }

        public static void s(PlaybackState.Builder builder, long j2) {
            builder.setActions(j2);
        }

        public static void t(PlaybackState.Builder builder, long j2) {
            builder.setActiveQueueItemId(j2);
        }

        public static void u(PlaybackState.Builder builder, long j2) {
            builder.setBufferedPosition(j2);
        }

        public static void v(PlaybackState.Builder builder, CharSequence charSequence) {
            builder.setErrorMessage(charSequence);
        }

        public static void w(PlaybackState.CustomAction.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }

        public static void x(PlaybackState.Builder builder, int i2, long j2, float f2, long j3) {
            builder.setState(i2, j2, f2, j3);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\PlaybackStateCompat$c.smali */
    public static class c {
        public static Bundle a(PlaybackState playbackState) {
            return playbackState.getExtras();
        }

        public static void b(PlaybackState.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }
    }

    public PlaybackStateCompat(int i2, long j2, long j3, float f2, long j4, int i3, CharSequence charSequence, long j5, List<CustomAction> list, long j6, Bundle bundle) {
        this.f61d = i2;
        this.f62e = j2;
        this.f63f = j3;
        this.f64g = f2;
        this.f65h = j4;
        this.f66i = i3;
        this.f67j = charSequence;
        this.k = j5;
        this.l = new ArrayList(list);
        this.m = j6;
        this.n = bundle;
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.f61d = parcel.readInt();
        this.f62e = parcel.readLong();
        this.f64g = parcel.readFloat();
        this.k = parcel.readLong();
        this.f63f = parcel.readLong();
        this.f65h = parcel.readLong();
        this.f67j = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.l = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.m = parcel.readLong();
        this.n = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.f66i = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "PlaybackState {state=" + this.f61d + ", position=" + this.f62e + ", buffered position=" + this.f63f + ", speed=" + this.f64g + ", updated=" + this.k + ", actions=" + this.f65h + ", error code=" + this.f66i + ", error message=" + this.f67j + ", custom actions=" + this.l + ", active item id=" + this.m + "}";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f61d);
        parcel.writeLong(this.f62e);
        parcel.writeFloat(this.f64g);
        parcel.writeLong(this.k);
        parcel.writeLong(this.f63f);
        parcel.writeLong(this.f65h);
        TextUtils.writeToParcel(this.f67j, parcel, i2);
        parcel.writeTypedList(this.l);
        parcel.writeLong(this.m);
        parcel.writeBundle(this.n);
        parcel.writeInt(this.f66i);
    }
}
