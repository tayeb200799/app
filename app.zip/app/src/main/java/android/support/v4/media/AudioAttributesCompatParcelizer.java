package android.support.v4.media;

import androidx.media.AudioAttributesImplApi21;
import b.a0.b;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\AudioAttributesImplApi21Parcelizer.smali */
public final class AudioAttributesImplApi21Parcelizer extends androidx.media.AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(b bVar) {
        return androidx.media.AudioAttributesImplApi21Parcelizer.read(bVar);
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, b bVar) {
        androidx.media.AudioAttributesImplApi21Parcelizer.write(audioAttributesImplApi21, bVar);
    }
}
