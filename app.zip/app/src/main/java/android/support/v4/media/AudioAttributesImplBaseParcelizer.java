package android.support.v4.media;

import a.a.a.b.b;
import android.os.Bundle;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\MediaBrowserCompat$CustomActionResultReceiver.smali */
public class MediaBrowserCompat$CustomActionResultReceiver extends b {
    @Override // a.a.a.b.b
    public void a(int i2, Bundle bundle) {
    }
}
