package android.support.v4.media.session;

import a.a.a.a.a.b;
import a.a.a.a.a.c;
import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;
import androidx.versionedparcelable.ParcelImpl;
import b.a0.d;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaControllerCompat$MediaControllerImplApi21.smali */
public class MediaControllerCompat$MediaControllerImplApi21 {

    /* renamed from: a, reason: collision with root package name */
    public final MediaController f25a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f26b = new Object();

    /* renamed from: c, reason: collision with root package name */
    public final List<c> f27c = new ArrayList();

    /* renamed from: d, reason: collision with root package name */
    public HashMap<c, a> f28d = new HashMap<>();

    /* renamed from: e, reason: collision with root package name */
    public final MediaSessionCompat.Token f29e;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver.smali */
    public static class ExtraBinderRequestResultReceiver extends ResultReceiver {

        /* renamed from: d, reason: collision with root package name */
        public WeakReference<MediaControllerCompat$MediaControllerImplApi21> f30d;

        public ExtraBinderRequestResultReceiver(MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21) {
            super(null);
            this.f30d = new WeakReference<>(mediaControllerCompat$MediaControllerImplApi21);
        }

        @Override // android.os.ResultReceiver
        public void onReceiveResult(int i2, Bundle bundle) {
            MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21 = this.f30d.get();
            if (mediaControllerCompat$MediaControllerImplApi21 == null || bundle == null) {
                return;
            }
            synchronized (mediaControllerCompat$MediaControllerImplApi21.f26b) {
                MediaSessionCompat.Token token = mediaControllerCompat$MediaControllerImplApi21.f29e;
                b n0 = b.a.n0(bundle.getBinder("android.support.v4.media.session.EXTRA_BINDER"));
                synchronized (token.f37d) {
                    token.f39f = n0;
                }
                MediaSessionCompat.Token token2 = mediaControllerCompat$MediaControllerImplApi21.f29e;
                d dVar = null;
                try {
                    Bundle bundle2 = (Bundle) bundle.getParcelable("android.support.v4.media.session.SESSION_TOKEN2");
                    if (bundle2 != null) {
                        bundle2.setClassLoader(b.a0.a.class.getClassLoader());
                        Parcelable parcelable = bundle2.getParcelable("a");
                        if (!(parcelable instanceof ParcelImpl)) {
                            throw new IllegalArgumentException("Invalid parcel");
                        }
                        dVar = ((ParcelImpl) parcelable).f543d;
                    }
                } catch (RuntimeException unused) {
                }
                synchronized (token2.f37d) {
                    token2.f40g = dVar;
                }
                mediaControllerCompat$MediaControllerImplApi21.a();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\android\support\v4\media\session\MediaControllerCompat$MediaControllerImplApi21$a.smali */
    public static class a extends c.b {
        public a(c cVar) {
            super(cVar);
        }

        @Override // a.a.a.a.a.c.b, a.a.a.a.a.a
        public void I(Bundle bundle) {
            throw new AssertionError();
        }

        @Override // a.a.a.a.a.c.b, a.a.a.a.a.a
        public void N(List<MediaSessionCompat.QueueItem> list) {
            throw new AssertionError();
        }

        @Override // a.a.a.a.a.c.b, a.a.a.a.a.a
        public void j(CharSequence charSequence) {
            throw new AssertionError();
        }

        @Override // a.a.a.a.a.c.b, a.a.a.a.a.a
        public void l0(ParcelableVolumeInfo parcelableVolumeInfo) {
            throw new AssertionError();
        }

        @Override // a.a.a.a.a.c.b, a.a.a.a.a.a
        public void o() {
            throw new AssertionError();
        }

        @Override // a.a.a.a.a.c.b, a.a.a.a.a.a
        public void q(MediaMetadataCompat mediaMetadataCompat) {
            throw new AssertionError();
        }
    }

    public MediaControllerCompat$MediaControllerImplApi21(Context context, MediaSessionCompat.Token token) {
        this.f29e = token;
        MediaController mediaController = new MediaController(context, (MediaSession.Token) token.f38e);
        this.f25a = mediaController;
        if (token.a() == null) {
            mediaController.sendCommand("android.support.v4.media.session.command.GET_EXTRA_BINDER", null, new ExtraBinderRequestResultReceiver(this));
        }
    }

    public void a() {
        if (this.f29e.a() == null) {
            return;
        }
        for (c cVar : this.f27c) {
            a aVar = new a(cVar);
            this.f28d.put(cVar, aVar);
            cVar.f4a = aVar;
            try {
                this.f29e.a().m(aVar);
            } catch (RemoteException e2) {
                Log.e("MediaControllerCompat", "Dead object in registerCallback.", e2);
            }
        }
        this.f27c.clear();
    }
}
