package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import b.f.a.i.c;
import b.f.a.i.e;
import b.f.a.i.f;
import b.f.a.i.l.b;
import b.f.c.c;
import b.f.c.d;
import b.f.c.g;
import b.f.c.i;
import b.f.c.j;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\constraintlayout\widget\ConstraintLayout.smali */
public class ConstraintLayout extends ViewGroup {
    public static j w;

    /* renamed from: d, reason: collision with root package name */
    public SparseArray<View> f242d;

    /* renamed from: e, reason: collision with root package name */
    public ArrayList<b.f.c.b> f243e;

    /* renamed from: f, reason: collision with root package name */
    public e f244f;

    /* renamed from: g, reason: collision with root package name */
    public int f245g;

    /* renamed from: h, reason: collision with root package name */
    public int f246h;

    /* renamed from: i, reason: collision with root package name */
    public int f247i;

    /* renamed from: j, reason: collision with root package name */
    public int f248j;
    public boolean k;
    public int l;
    public d m;
    public c n;
    public int o;
    public HashMap<String, Integer> p;
    public int q;
    public int r;
    public SparseArray<b.f.a.i.d> s;
    public b t;
    public int u;
    public int v;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\constraintlayout\widget\ConstraintLayout$a.smali */
    public static class a extends ViewGroup.MarginLayoutParams {
        public int A;
        public int B;
        public int C;
        public int D;
        public float E;
        public float F;
        public String G;
        public float H;
        public float I;
        public int J;
        public int K;
        public int L;
        public int M;
        public int N;
        public int O;
        public int P;
        public int Q;
        public float R;
        public float S;
        public int T;
        public int U;
        public int V;
        public boolean W;
        public boolean X;
        public String Y;
        public int Z;

        /* renamed from: a, reason: collision with root package name */
        public int f249a;
        public boolean a0;

        /* renamed from: b, reason: collision with root package name */
        public int f250b;
        public boolean b0;

        /* renamed from: c, reason: collision with root package name */
        public float f251c;
        public boolean c0;

        /* renamed from: d, reason: collision with root package name */
        public boolean f252d;
        public boolean d0;

        /* renamed from: e, reason: collision with root package name */
        public int f253e;
        public boolean e0;

        /* renamed from: f, reason: collision with root package name */
        public int f254f;
        public boolean f0;

        /* renamed from: g, reason: collision with root package name */
        public int f255g;
        public int g0;

        /* renamed from: h, reason: collision with root package name */
        public int f256h;
        public int h0;

        /* renamed from: i, reason: collision with root package name */
        public int f257i;
        public int i0;

        /* renamed from: j, reason: collision with root package name */
        public int f258j;
        public int j0;
        public int k;
        public int k0;
        public int l;
        public int l0;
        public int m;
        public float m0;
        public int n;
        public int n0;
        public int o;
        public int o0;
        public int p;
        public float p0;
        public int q;
        public b.f.a.i.d q0;
        public float r;
        public int s;
        public int t;
        public int u;
        public int v;
        public int w;
        public int x;
        public int y;
        public int z;

        /* renamed from: androidx.constraintlayout.widget.ConstraintLayout$a$a, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\constraintlayout\widget\ConstraintLayout$a$a.smali */
        public static class C0007a {

            /* renamed from: a, reason: collision with root package name */
            public static final SparseIntArray f259a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f259a = sparseIntArray;
                sparseIntArray.append(98, 64);
                sparseIntArray.append(75, 65);
                sparseIntArray.append(84, 8);
                sparseIntArray.append(85, 9);
                sparseIntArray.append(87, 10);
                sparseIntArray.append(88, 11);
                sparseIntArray.append(94, 12);
                sparseIntArray.append(93, 13);
                sparseIntArray.append(65, 14);
                sparseIntArray.append(64, 15);
                sparseIntArray.append(60, 16);
                sparseIntArray.append(62, 52);
                sparseIntArray.append(61, 53);
                sparseIntArray.append(66, 2);
                sparseIntArray.append(68, 3);
                sparseIntArray.append(67, 4);
                sparseIntArray.append(103, 49);
                sparseIntArray.append(104, 50);
                sparseIntArray.append(72, 5);
                sparseIntArray.append(73, 6);
                sparseIntArray.append(74, 7);
                sparseIntArray.append(55, 67);
                sparseIntArray.append(0, 1);
                sparseIntArray.append(89, 17);
                sparseIntArray.append(90, 18);
                sparseIntArray.append(71, 19);
                sparseIntArray.append(70, 20);
                sparseIntArray.append(108, 21);
                sparseIntArray.append(111, 22);
                sparseIntArray.append(109, 23);
                sparseIntArray.append(106, 24);
                sparseIntArray.append(110, 25);
                sparseIntArray.append(107, 26);
                sparseIntArray.append(105, 55);
                sparseIntArray.append(112, 54);
                sparseIntArray.append(80, 29);
                sparseIntArray.append(95, 30);
                sparseIntArray.append(69, 44);
                sparseIntArray.append(82, 45);
                sparseIntArray.append(97, 46);
                sparseIntArray.append(81, 47);
                sparseIntArray.append(96, 48);
                sparseIntArray.append(58, 27);
                sparseIntArray.append(57, 28);
                sparseIntArray.append(99, 31);
                sparseIntArray.append(76, 32);
                sparseIntArray.append(101, 33);
                sparseIntArray.append(100, 34);
                sparseIntArray.append(102, 35);
                sparseIntArray.append(78, 36);
                sparseIntArray.append(77, 37);
                sparseIntArray.append(79, 38);
                sparseIntArray.append(83, 39);
                sparseIntArray.append(92, 40);
                sparseIntArray.append(86, 41);
                sparseIntArray.append(63, 42);
                sparseIntArray.append(59, 43);
                sparseIntArray.append(91, 51);
                sparseIntArray.append(114, 66);
            }
        }

        public a(int i2, int i3) {
            super(i2, i3);
            this.f249a = -1;
            this.f250b = -1;
            this.f251c = -1.0f;
            this.f252d = true;
            this.f253e = -1;
            this.f254f = -1;
            this.f255g = -1;
            this.f256h = -1;
            this.f257i = -1;
            this.f258j = -1;
            this.k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = 0;
            this.r = 0.0f;
            this.s = -1;
            this.t = -1;
            this.u = -1;
            this.v = -1;
            this.w = Integer.MIN_VALUE;
            this.x = Integer.MIN_VALUE;
            this.y = Integer.MIN_VALUE;
            this.z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = 0.5f;
            this.F = 0.5f;
            this.G = null;
            this.H = -1.0f;
            this.I = -1.0f;
            this.J = 0;
            this.K = 0;
            this.L = 0;
            this.M = 0;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 1.0f;
            this.S = 1.0f;
            this.T = -1;
            this.U = -1;
            this.V = -1;
            this.W = false;
            this.X = false;
            this.Y = null;
            this.Z = 0;
            this.a0 = true;
            this.b0 = true;
            this.c0 = false;
            this.d0 = false;
            this.e0 = false;
            this.f0 = false;
            this.g0 = -1;
            this.h0 = -1;
            this.i0 = -1;
            this.j0 = -1;
            this.k0 = Integer.MIN_VALUE;
            this.l0 = Integer.MIN_VALUE;
            this.m0 = 0.5f;
            this.q0 = new b.f.a.i.d();
        }

        public a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f249a = -1;
            this.f250b = -1;
            this.f251c = -1.0f;
            this.f252d = true;
            this.f253e = -1;
            this.f254f = -1;
            this.f255g = -1;
            this.f256h = -1;
            this.f257i = -1;
            this.f258j = -1;
            this.k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = 0;
            this.r = 0.0f;
            this.s = -1;
            this.t = -1;
            this.u = -1;
            this.v = -1;
            this.w = Integer.MIN_VALUE;
            this.x = Integer.MIN_VALUE;
            this.y = Integer.MIN_VALUE;
            this.z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = 0.5f;
            this.F = 0.5f;
            this.G = null;
            this.H = -1.0f;
            this.I = -1.0f;
            this.J = 0;
            this.K = 0;
            this.L = 0;
            this.M = 0;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 1.0f;
            this.S = 1.0f;
            this.T = -1;
            this.U = -1;
            this.V = -1;
            this.W = false;
            this.X = false;
            this.Y = null;
            this.Z = 0;
            this.a0 = true;
            this.b0 = true;
            this.c0 = false;
            this.d0 = false;
            this.e0 = false;
            this.f0 = false;
            this.g0 = -1;
            this.h0 = -1;
            this.i0 = -1;
            this.j0 = -1;
            this.k0 = Integer.MIN_VALUE;
            this.l0 = Integer.MIN_VALUE;
            this.m0 = 0.5f;
            this.q0 = new b.f.a.i.d();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.f1480b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                int i3 = C0007a.f259a.get(index);
                switch (i3) {
                    case 1:
                        this.V = obtainStyledAttributes.getInt(index, this.V);
                        break;
                    case 2:
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.p);
                        this.p = resourceId;
                        if (resourceId == -1) {
                            this.p = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case ModuleDescriptor.MODULE_VERSION /* 3 */:
                        this.q = obtainStyledAttributes.getDimensionPixelSize(index, this.q);
                        break;
                    case 4:
                        float f2 = obtainStyledAttributes.getFloat(index, this.r) % 360.0f;
                        this.r = f2;
                        if (f2 < 0.0f) {
                            this.r = (360.0f - f2) % 360.0f;
                            break;
                        } else {
                            break;
                        }
                    case 5:
                        this.f249a = obtainStyledAttributes.getDimensionPixelOffset(index, this.f249a);
                        break;
                    case 6:
                        this.f250b = obtainStyledAttributes.getDimensionPixelOffset(index, this.f250b);
                        break;
                    case 7:
                        this.f251c = obtainStyledAttributes.getFloat(index, this.f251c);
                        break;
                    case 8:
                        int resourceId2 = obtainStyledAttributes.getResourceId(index, this.f253e);
                        this.f253e = resourceId2;
                        if (resourceId2 == -1) {
                            this.f253e = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 9:
                        int resourceId3 = obtainStyledAttributes.getResourceId(index, this.f254f);
                        this.f254f = resourceId3;
                        if (resourceId3 == -1) {
                            this.f254f = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 10:
                        int resourceId4 = obtainStyledAttributes.getResourceId(index, this.f255g);
                        this.f255g = resourceId4;
                        if (resourceId4 == -1) {
                            this.f255g = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 11:
                        int resourceId5 = obtainStyledAttributes.getResourceId(index, this.f256h);
                        this.f256h = resourceId5;
                        if (resourceId5 == -1) {
                            this.f256h = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 12:
                        int resourceId6 = obtainStyledAttributes.getResourceId(index, this.f257i);
                        this.f257i = resourceId6;
                        if (resourceId6 == -1) {
                            this.f257i = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 13:
                        int resourceId7 = obtainStyledAttributes.getResourceId(index, this.f258j);
                        this.f258j = resourceId7;
                        if (resourceId7 == -1) {
                            this.f258j = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 14:
                        int resourceId8 = obtainStyledAttributes.getResourceId(index, this.k);
                        this.k = resourceId8;
                        if (resourceId8 == -1) {
                            this.k = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 15:
                        int resourceId9 = obtainStyledAttributes.getResourceId(index, this.l);
                        this.l = resourceId9;
                        if (resourceId9 == -1) {
                            this.l = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 16:
                        int resourceId10 = obtainStyledAttributes.getResourceId(index, this.m);
                        this.m = resourceId10;
                        if (resourceId10 == -1) {
                            this.m = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 17:
                        int resourceId11 = obtainStyledAttributes.getResourceId(index, this.s);
                        this.s = resourceId11;
                        if (resourceId11 == -1) {
                            this.s = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 18:
                        int resourceId12 = obtainStyledAttributes.getResourceId(index, this.t);
                        this.t = resourceId12;
                        if (resourceId12 == -1) {
                            this.t = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 19:
                        int resourceId13 = obtainStyledAttributes.getResourceId(index, this.u);
                        this.u = resourceId13;
                        if (resourceId13 == -1) {
                            this.u = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 20:
                        int resourceId14 = obtainStyledAttributes.getResourceId(index, this.v);
                        this.v = resourceId14;
                        if (resourceId14 == -1) {
                            this.v = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 21:
                        this.w = obtainStyledAttributes.getDimensionPixelSize(index, this.w);
                        break;
                    case 22:
                        this.x = obtainStyledAttributes.getDimensionPixelSize(index, this.x);
                        break;
                    case 23:
                        this.y = obtainStyledAttributes.getDimensionPixelSize(index, this.y);
                        break;
                    case 24:
                        this.z = obtainStyledAttributes.getDimensionPixelSize(index, this.z);
                        break;
                    case 25:
                        this.A = obtainStyledAttributes.getDimensionPixelSize(index, this.A);
                        break;
                    case 26:
                        this.B = obtainStyledAttributes.getDimensionPixelSize(index, this.B);
                        break;
                    case 27:
                        this.W = obtainStyledAttributes.getBoolean(index, this.W);
                        break;
                    case 28:
                        this.X = obtainStyledAttributes.getBoolean(index, this.X);
                        break;
                    case 29:
                        this.E = obtainStyledAttributes.getFloat(index, this.E);
                        break;
                    case 30:
                        this.F = obtainStyledAttributes.getFloat(index, this.F);
                        break;
                    case 31:
                        int i4 = obtainStyledAttributes.getInt(index, 0);
                        this.L = i4;
                        if (i4 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                            break;
                        } else {
                            break;
                        }
                    case 32:
                        int i5 = obtainStyledAttributes.getInt(index, 0);
                        this.M = i5;
                        if (i5 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                            break;
                        } else {
                            break;
                        }
                    case 33:
                        try {
                            this.N = obtainStyledAttributes.getDimensionPixelSize(index, this.N);
                            break;
                        } catch (Exception unused) {
                            if (obtainStyledAttributes.getInt(index, this.N) == -2) {
                                this.N = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 34:
                        try {
                            this.P = obtainStyledAttributes.getDimensionPixelSize(index, this.P);
                            break;
                        } catch (Exception unused2) {
                            if (obtainStyledAttributes.getInt(index, this.P) == -2) {
                                this.P = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 35:
                        this.R = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.R));
                        this.L = 2;
                        break;
                    case 36:
                        try {
                            this.O = obtainStyledAttributes.getDimensionPixelSize(index, this.O);
                            break;
                        } catch (Exception unused3) {
                            if (obtainStyledAttributes.getInt(index, this.O) == -2) {
                                this.O = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 37:
                        try {
                            this.Q = obtainStyledAttributes.getDimensionPixelSize(index, this.Q);
                            break;
                        } catch (Exception unused4) {
                            if (obtainStyledAttributes.getInt(index, this.Q) == -2) {
                                this.Q = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 38:
                        this.S = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.S));
                        this.M = 2;
                        break;
                    default:
                        switch (i3) {
                            case 44:
                                d.h(this, obtainStyledAttributes.getString(index));
                                break;
                            case 45:
                                this.H = obtainStyledAttributes.getFloat(index, this.H);
                                break;
                            case 46:
                                this.I = obtainStyledAttributes.getFloat(index, this.I);
                                break;
                            case 47:
                                this.J = obtainStyledAttributes.getInt(index, 0);
                                break;
                            case 48:
                                this.K = obtainStyledAttributes.getInt(index, 0);
                                break;
                            case 49:
                                this.T = obtainStyledAttributes.getDimensionPixelOffset(index, this.T);
                                break;
                            case 50:
                                this.U = obtainStyledAttributes.getDimensionPixelOffset(index, this.U);
                                break;
                            case 51:
                                this.Y = obtainStyledAttributes.getString(index);
                                break;
                            case 52:
                                int resourceId15 = obtainStyledAttributes.getResourceId(index, this.n);
                                this.n = resourceId15;
                                if (resourceId15 == -1) {
                                    this.n = obtainStyledAttributes.getInt(index, -1);
                                    break;
                                } else {
                                    break;
                                }
                            case 53:
                                int resourceId16 = obtainStyledAttributes.getResourceId(index, this.o);
                                this.o = resourceId16;
                                if (resourceId16 == -1) {
                                    this.o = obtainStyledAttributes.getInt(index, -1);
                                    break;
                                } else {
                                    break;
                                }
                            case 54:
                                this.D = obtainStyledAttributes.getDimensionPixelSize(index, this.D);
                                break;
                            case 55:
                                this.C = obtainStyledAttributes.getDimensionPixelSize(index, this.C);
                                break;
                            default:
                                switch (i3) {
                                    case 64:
                                        d.g(this, obtainStyledAttributes, index, 0);
                                        break;
                                    case 65:
                                        d.g(this, obtainStyledAttributes, index, 1);
                                        break;
                                    case 66:
                                        this.Z = obtainStyledAttributes.getInt(index, this.Z);
                                        break;
                                    case 67:
                                        this.f252d = obtainStyledAttributes.getBoolean(index, this.f252d);
                                        break;
                                }
                        }
                }
            }
            obtainStyledAttributes.recycle();
            a();
        }

        public a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f249a = -1;
            this.f250b = -1;
            this.f251c = -1.0f;
            this.f252d = true;
            this.f253e = -1;
            this.f254f = -1;
            this.f255g = -1;
            this.f256h = -1;
            this.f257i = -1;
            this.f258j = -1;
            this.k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = 0;
            this.r = 0.0f;
            this.s = -1;
            this.t = -1;
            this.u = -1;
            this.v = -1;
            this.w = Integer.MIN_VALUE;
            this.x = Integer.MIN_VALUE;
            this.y = Integer.MIN_VALUE;
            this.z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = 0.5f;
            this.F = 0.5f;
            this.G = null;
            this.H = -1.0f;
            this.I = -1.0f;
            this.J = 0;
            this.K = 0;
            this.L = 0;
            this.M = 0;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 1.0f;
            this.S = 1.0f;
            this.T = -1;
            this.U = -1;
            this.V = -1;
            this.W = false;
            this.X = false;
            this.Y = null;
            this.Z = 0;
            this.a0 = true;
            this.b0 = true;
            this.c0 = false;
            this.d0 = false;
            this.e0 = false;
            this.f0 = false;
            this.g0 = -1;
            this.h0 = -1;
            this.i0 = -1;
            this.j0 = -1;
            this.k0 = Integer.MIN_VALUE;
            this.l0 = Integer.MIN_VALUE;
            this.m0 = 0.5f;
            this.q0 = new b.f.a.i.d();
        }

        public void a() {
            this.d0 = false;
            this.a0 = true;
            this.b0 = true;
            int i2 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i2 == -2 && this.W) {
                this.a0 = false;
                if (this.L == 0) {
                    this.L = 1;
                }
            }
            int i3 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i3 == -2 && this.X) {
                this.b0 = false;
                if (this.M == 0) {
                    this.M = 1;
                }
            }
            if (i2 == 0 || i2 == -1) {
                this.a0 = false;
                if (i2 == 0 && this.L == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.W = true;
                }
            }
            if (i3 == 0 || i3 == -1) {
                this.b0 = false;
                if (i3 == 0 && this.M == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.X = true;
                }
            }
            if (this.f251c == -1.0f && this.f249a == -1 && this.f250b == -1) {
                return;
            }
            this.d0 = true;
            this.a0 = true;
            this.b0 = true;
            if (!(this.q0 instanceof f)) {
                this.q0 = new f();
            }
            ((f) this.q0).W(this.V);
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x004e  */
        /* JADX WARN: Removed duplicated region for block: B:15:0x0055  */
        /* JADX WARN: Removed duplicated region for block: B:18:0x005c  */
        /* JADX WARN: Removed duplicated region for block: B:21:0x0062  */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0068  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x007e  */
        /* JADX WARN: Removed duplicated region for block: B:34:0x0086  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        @android.annotation.TargetApi(17)
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void resolveLayoutDirection(int r11) {
            /*
                Method dump skipped, instructions count: 263
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.a.resolveLayoutDirection(int):void");
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\constraintlayout\widget\ConstraintLayout$b.smali */
    public class b implements b.InterfaceC0021b {

        /* renamed from: a, reason: collision with root package name */
        public ConstraintLayout f260a;

        /* renamed from: b, reason: collision with root package name */
        public int f261b;

        /* renamed from: c, reason: collision with root package name */
        public int f262c;

        /* renamed from: d, reason: collision with root package name */
        public int f263d;

        /* renamed from: e, reason: collision with root package name */
        public int f264e;

        /* renamed from: f, reason: collision with root package name */
        public int f265f;

        /* renamed from: g, reason: collision with root package name */
        public int f266g;

        public b(ConstraintLayout constraintLayout) {
            this.f260a = constraintLayout;
        }

        public final boolean a(int i2, int i3, int i4) {
            if (i2 == i3) {
                return true;
            }
            int mode = View.MeasureSpec.getMode(i2);
            View.MeasureSpec.getSize(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            int size = View.MeasureSpec.getSize(i3);
            if (mode2 == 1073741824) {
                return (mode == Integer.MIN_VALUE || mode == 0) && i4 == size;
            }
            return false;
        }

        /* JADX WARN: Removed duplicated region for block: B:146:0x01c4  */
        /* JADX WARN: Removed duplicated region for block: B:147:0x01bf  */
        /* JADX WARN: Removed duplicated region for block: B:183:0x013c  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x00c1  */
        /* JADX WARN: Removed duplicated region for block: B:28:0x0149  */
        /* JADX WARN: Removed duplicated region for block: B:48:0x01a8  */
        /* JADX WARN: Removed duplicated region for block: B:53:0x01bd  */
        /* JADX WARN: Removed duplicated region for block: B:55:0x01c2  */
        /* JADX WARN: Removed duplicated region for block: B:58:0x01c9 A[ADDED_TO_REGION] */
        /* JADX WARN: Removed duplicated region for block: B:61:0x01d1 A[ADDED_TO_REGION] */
        /* JADX WARN: Removed duplicated region for block: B:65:0x01da  */
        /* JADX WARN: Removed duplicated region for block: B:69:0x01e5  */
        /* JADX WARN: Removed duplicated region for block: B:73:0x01f0 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:74:0x01f1  */
        @android.annotation.SuppressLint({"WrongCall"})
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void b(b.f.a.i.d r18, b.f.a.i.l.b.a r19) {
            /*
                Method dump skipped, instructions count: 744
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.b.b(b.f.a.i.d, b.f.a.i.l.b$a):void");
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f242d = new SparseArray<>();
        this.f243e = new ArrayList<>(4);
        this.f244f = new e();
        this.f245g = 0;
        this.f246h = 0;
        this.f247i = Integer.MAX_VALUE;
        this.f248j = Integer.MAX_VALUE;
        this.k = true;
        this.l = 257;
        this.m = null;
        this.n = null;
        this.o = -1;
        this.p = new HashMap<>();
        this.q = -1;
        this.r = -1;
        this.s = new SparseArray<>();
        this.t = new b(this);
        this.u = 0;
        this.v = 0;
        f(attributeSet, 0, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f242d = new SparseArray<>();
        this.f243e = new ArrayList<>(4);
        this.f244f = new e();
        this.f245g = 0;
        this.f246h = 0;
        this.f247i = Integer.MAX_VALUE;
        this.f248j = Integer.MAX_VALUE;
        this.k = true;
        this.l = 257;
        this.m = null;
        this.n = null;
        this.o = -1;
        this.p = new HashMap<>();
        this.q = -1;
        this.r = -1;
        this.s = new SparseArray<>();
        this.t = new b(this);
        this.u = 0;
        this.v = 0;
        f(attributeSet, i2, 0);
    }

    private int getPaddingWidth() {
        int max = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int max2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return max2 > 0 ? max2 : max;
    }

    public static j getSharedValues() {
        if (w == null) {
            w = new j();
        }
        return w;
    }

    @Override // android.view.ViewGroup
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public a generateDefaultLayoutParams() {
        return new a(-2, -2);
    }

    public Object c(int i2, Object obj) {
        if (i2 != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> hashMap = this.p;
        if (hashMap == null || !hashMap.containsKey(str)) {
            return null;
        }
        return this.p.get(str);
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof a;
    }

    public View d(int i2) {
        return this.f242d.get(i2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<b.f.c.b> arrayList = this.f243e;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i2 = 0; i2 < size; i2++) {
                this.f243e.get(i2).m();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i4 = (int) ((parseInt / 1080.0f) * width);
                        int i5 = (int) ((parseInt2 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f2 = i4;
                        float f3 = i5;
                        float f4 = i4 + ((int) ((parseInt3 / 1080.0f) * width));
                        canvas.drawLine(f2, f3, f4, f3, paint);
                        float parseInt4 = i5 + ((int) ((Integer.parseInt(split[3]) / 1920.0f) * height));
                        canvas.drawLine(f4, f3, f4, parseInt4, paint);
                        canvas.drawLine(f4, parseInt4, f2, parseInt4, paint);
                        canvas.drawLine(f2, parseInt4, f2, f3, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f2, f3, f4, parseInt4, paint);
                        canvas.drawLine(f2, parseInt4, f4, f3, paint);
                    }
                }
            }
        }
    }

    public final b.f.a.i.d e(View view) {
        if (view == this) {
            return this.f244f;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof a) {
            return ((a) view.getLayoutParams()).q0;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof a) {
            return ((a) view.getLayoutParams()).q0;
        }
        return null;
    }

    public final void f(AttributeSet attributeSet, int i2, int i3) {
        e eVar = this.f244f;
        eVar.h0 = this;
        b bVar = this.t;
        eVar.v0 = bVar;
        eVar.t0.f1320f = bVar;
        this.f242d.put(getId(), this);
        this.m = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1480b, i2, i3);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i4 = 0; i4 < indexCount; i4++) {
                int index = obtainStyledAttributes.getIndex(i4);
                if (index == 16) {
                    this.f245g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f245g);
                } else if (index == 17) {
                    this.f246h = obtainStyledAttributes.getDimensionPixelOffset(index, this.f246h);
                } else if (index == 14) {
                    this.f247i = obtainStyledAttributes.getDimensionPixelOffset(index, this.f247i);
                } else if (index == 15) {
                    this.f248j = obtainStyledAttributes.getDimensionPixelOffset(index, this.f248j);
                } else if (index == 113) {
                    this.l = obtainStyledAttributes.getInt(index, this.l);
                } else if (index == 56) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            k(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.n = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        d dVar = new d();
                        this.m = dVar;
                        dVar.f(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.m = null;
                    }
                    this.o = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f244f.g0(this.l);
    }

    @Override // android.view.View
    public void forceLayout() {
        this.k = true;
        this.q = -1;
        this.r = -1;
        super.forceLayout();
    }

    public boolean g() {
        return ((getContext().getApplicationInfo().flags & 4194304) != 0) && 1 == getLayoutDirection();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new a(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new a(layoutParams);
    }

    public int getMaxHeight() {
        return this.f248j;
    }

    public int getMaxWidth() {
        return this.f247i;
    }

    public int getMinHeight() {
        return this.f246h;
    }

    public int getMinWidth() {
        return this.f245g;
    }

    public int getOptimizationLevel() {
        return this.f244f.E0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        if (this.f244f.f1295j == null) {
            int id2 = getId();
            if (id2 != -1) {
                this.f244f.f1295j = getContext().getResources().getResourceEntryName(id2);
            } else {
                this.f244f.f1295j = "parent";
            }
        }
        e eVar = this.f244f;
        if (eVar.j0 == null) {
            eVar.j0 = eVar.f1295j;
            StringBuilder n = c.a.a.a.a.n(" setDebugName ");
            n.append(this.f244f.j0);
            Log.v("ConstraintLayout", n.toString());
        }
        Iterator<b.f.a.i.d> it = this.f244f.r0.iterator();
        while (it.hasNext()) {
            b.f.a.i.d next = it.next();
            View view = (View) next.h0;
            if (view != null) {
                if (next.f1295j == null && (id = view.getId()) != -1) {
                    next.f1295j = getContext().getResources().getResourceEntryName(id);
                }
                if (next.j0 == null) {
                    next.j0 = next.f1295j;
                    StringBuilder n2 = c.a.a.a.a.n(" setDebugName ");
                    n2.append(next.j0);
                    Log.v("ConstraintLayout", n2.toString());
                }
            }
        }
        this.f244f.q(sb);
        return sb.toString();
    }

    public void k(int i2) {
        this.n = new c(getContext(), this, i2);
    }

    public void l(int i2, int i3, int i4, int i5, boolean z, boolean z2) {
        b bVar = this.t;
        int i6 = bVar.f264e;
        int resolveSizeAndState = ViewGroup.resolveSizeAndState(i4 + bVar.f263d, i2, 0);
        int resolveSizeAndState2 = ViewGroup.resolveSizeAndState(i5 + i6, i3, 0) & 16777215;
        int min = Math.min(this.f247i, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.f248j, resolveSizeAndState2);
        if (z) {
            min |= 16777216;
        }
        if (z2) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
        this.q = min;
        this.r = min2;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        View content;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            a aVar = (a) childAt.getLayoutParams();
            b.f.a.i.d dVar = aVar.q0;
            if ((childAt.getVisibility() != 8 || aVar.d0 || aVar.e0 || isInEditMode) && !aVar.f0) {
                int v = dVar.v();
                int w2 = dVar.w();
                int u = dVar.u() + v;
                int l = dVar.l() + w2;
                childAt.layout(v, w2, u, l);
                if ((childAt instanceof g) && (content = ((g) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(v, w2, u, l);
                }
            }
        }
        int size = this.f243e.size();
        if (size > 0) {
            for (int i7 = 0; i7 < size; i7++) {
                this.f243e.get(i7).k();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:143:0x04fd  */
    /* JADX WARN: Removed duplicated region for block: B:193:0x0592  */
    /* JADX WARN: Removed duplicated region for block: B:196:0x0595  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x05ee  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x05f4  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x00e5  */
    /* JADX WARN: Removed duplicated region for block: B:318:0x05dd  */
    /* JADX WARN: Removed duplicated region for block: B:382:0x04df  */
    /* JADX WARN: Removed duplicated region for block: B:410:0x0117  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x01aa  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0218  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r31, int r32) {
        /*
            Method dump skipped, instructions count: 2000
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        b.f.a.i.d e2 = e(view);
        if ((view instanceof Guideline) && !(e2 instanceof f)) {
            a aVar = (a) view.getLayoutParams();
            f fVar = new f();
            aVar.q0 = fVar;
            aVar.d0 = true;
            fVar.W(aVar.V);
        }
        if (view instanceof b.f.c.b) {
            b.f.c.b bVar = (b.f.c.b) view;
            bVar.n();
            ((a) view.getLayoutParams()).e0 = true;
            if (!this.f243e.contains(bVar)) {
                this.f243e.add(bVar);
            }
        }
        this.f242d.put(view.getId(), view);
        this.k = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f242d.remove(view.getId());
        b.f.a.i.d e2 = e(view);
        this.f244f.r0.remove(e2);
        e2.F();
        this.f243e.remove(view);
        this.k = true;
    }

    public void p(int i2, Object obj, Object obj2) {
        if (i2 == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.p == null) {
                this.p = new HashMap<>();
            }
            String str = (String) obj;
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.p.put(str, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    public final void q(b.f.a.i.d dVar, a aVar, SparseArray<b.f.a.i.d> sparseArray, int i2, c.a aVar2) {
        View view = this.f242d.get(i2);
        b.f.a.i.d dVar2 = sparseArray.get(i2);
        if (dVar2 == null || view == null || !(view.getLayoutParams() instanceof a)) {
            return;
        }
        aVar.c0 = true;
        c.a aVar3 = c.a.BASELINE;
        if (aVar2 == aVar3) {
            a aVar4 = (a) view.getLayoutParams();
            aVar4.c0 = true;
            aVar4.q0.E = true;
        }
        dVar.i(aVar3).a(dVar2.i(aVar2), aVar.D, aVar.C, true);
        dVar.E = true;
        dVar.i(c.a.TOP).h();
        dVar.i(c.a.BOTTOM).h();
    }

    /* JADX WARN: Removed duplicated region for block: B:265:0x02f1  */
    /* JADX WARN: Removed duplicated region for block: B:270:0x0325  */
    /* JADX WARN: Removed duplicated region for block: B:275:0x0360  */
    /* JADX WARN: Removed duplicated region for block: B:280:0x039b  */
    /* JADX WARN: Removed duplicated region for block: B:284:0x03ce  */
    /* JADX WARN: Removed duplicated region for block: B:287:0x03d6  */
    /* JADX WARN: Removed duplicated region for block: B:288:0x03ac  */
    /* JADX WARN: Removed duplicated region for block: B:294:0x0379  */
    /* JADX WARN: Removed duplicated region for block: B:299:0x033e  */
    /* JADX WARN: Removed duplicated region for block: B:304:0x0308  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean r() {
        /*
            Method dump skipped, instructions count: 1415
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.r():boolean");
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        this.k = true;
        this.q = -1;
        this.r = -1;
        super.requestLayout();
    }

    public void setConstraintSet(d dVar) {
        this.m = dVar;
    }

    @Override // android.view.View
    public void setId(int i2) {
        this.f242d.remove(getId());
        super.setId(i2);
        this.f242d.put(getId(), this);
    }

    public void setMaxHeight(int i2) {
        if (i2 == this.f248j) {
            return;
        }
        this.f248j = i2;
        requestLayout();
    }

    public void setMaxWidth(int i2) {
        if (i2 == this.f247i) {
            return;
        }
        this.f247i = i2;
        requestLayout();
    }

    public void setMinHeight(int i2) {
        if (i2 == this.f246h) {
            return;
        }
        this.f246h = i2;
        requestLayout();
    }

    public void setMinWidth(int i2) {
        if (i2 == this.f245g) {
            return;
        }
        this.f245g = i2;
        requestLayout();
    }

    public void setOnConstraintsChanged(b.f.c.f fVar) {
        b.f.c.c cVar = this.n;
        if (cVar != null) {
            Objects.requireNonNull(cVar);
        }
    }

    public void setOptimizationLevel(int i2) {
        this.l = i2;
        e eVar = this.f244f;
        eVar.E0 = i2;
        b.f.a.d.p = eVar.f0(512);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
