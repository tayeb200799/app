package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import b.f.a.i.a;
import b.f.a.i.d;
import b.f.c.b;
import b.f.c.i;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\constraintlayout\widget\Barrier.smali */
public class Barrier extends b {
    public int l;
    public int m;
    public a n;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    public boolean getAllowsGoneWidget() {
        return this.n.u0;
    }

    public int getMargin() {
        return this.n.v0;
    }

    public int getType() {
        return this.l;
    }

    @Override // b.f.c.b
    public void i(AttributeSet attributeSet) {
        super.i(attributeSet);
        this.n = new a();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1480b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == 26) {
                    setType(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 25) {
                    this.n.u0 = obtainStyledAttributes.getBoolean(index, true);
                } else if (index == 27) {
                    this.n.v0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1398g = this.n;
        n();
    }

    @Override // b.f.c.b
    public void j(d dVar, boolean z) {
        int i2 = this.l;
        this.m = i2;
        if (z) {
            if (i2 == 5) {
                this.m = 1;
            } else if (i2 == 6) {
                this.m = 0;
            }
        } else if (i2 == 5) {
            this.m = 0;
        } else if (i2 == 6) {
            this.m = 1;
        }
        if (dVar instanceof a) {
            ((a) dVar).t0 = this.m;
        }
    }

    public void setAllowsGoneWidget(boolean z) {
        this.n.u0 = z;
    }

    public void setDpMargin(int i2) {
        this.n.v0 = (int) ((i2 * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i2) {
        this.n.v0 = i2;
    }

    public void setType(int i2) {
        this.l = i2;
    }
}
