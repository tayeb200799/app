package androidx.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import b.h.c.e;
import b.p.a0;
import b.p.f;
import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import b.p.u;
import b.p.w;
import b.p.y;
import b.p.z;
import b.v.c;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\activity\ComponentActivity.smali */
public class ComponentActivity extends e implements k, a0, f, c, b.a.c {

    /* renamed from: e, reason: collision with root package name */
    public final l f72e;

    /* renamed from: f, reason: collision with root package name */
    public final b.v.b f73f;

    /* renamed from: g, reason: collision with root package name */
    public z f74g;

    /* renamed from: h, reason: collision with root package name */
    public y.b f75h;

    /* renamed from: i, reason: collision with root package name */
    public final OnBackPressedDispatcher f76i;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\activity\ComponentActivity$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ComponentActivity.super.onBackPressed();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\activity\ComponentActivity$b.smali */
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public z f80a;
    }

    public ComponentActivity() {
        l lVar = new l(this);
        this.f72e = lVar;
        this.f73f = new b.v.b(this);
        this.f76i = new OnBackPressedDispatcher(new a());
        int i2 = Build.VERSION.SDK_INT;
        lVar.a(new i() { // from class: androidx.activity.ComponentActivity.2
            @Override // b.p.i
            public void d(k kVar, g.a aVar) {
                if (aVar == g.a.ON_STOP) {
                    Window window = ComponentActivity.this.getWindow();
                    View peekDecorView = window != null ? window.peekDecorView() : null;
                    if (peekDecorView != null) {
                        peekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        lVar.a(new i() { // from class: androidx.activity.ComponentActivity.3
            @Override // b.p.i
            public void d(k kVar, g.a aVar) {
                if (aVar != g.a.ON_DESTROY || ComponentActivity.this.isChangingConfigurations()) {
                    return;
                }
                ComponentActivity.this.q().a();
            }
        });
        if (i2 <= 23) {
            lVar.a(new ImmLeaksCleaner(this));
        }
    }

    @Override // b.p.k
    public g a() {
        return this.f72e;
    }

    @Override // b.a.c
    public final OnBackPressedDispatcher c() {
        return this.f76i;
    }

    @Override // b.v.c
    public final b.v.a d() {
        return this.f73f.f2437b;
    }

    @Override // b.p.f
    public y.b l() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f75h == null) {
            this.f75h = new w(getApplication(), this, getIntent() != null ? getIntent().getExtras() : null);
        }
        return this.f75h;
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        this.f76i.a();
    }

    @Override // b.h.c.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f73f.a(bundle);
        u.c(this);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        b bVar;
        z zVar = this.f74g;
        if (zVar == null && (bVar = (b) getLastNonConfigurationInstance()) != null) {
            zVar = bVar.f80a;
        }
        if (zVar == null) {
            return null;
        }
        b bVar2 = new b();
        bVar2.f80a = zVar;
        return bVar2;
    }

    @Override // b.h.c.e, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        l lVar = this.f72e;
        if (lVar instanceof l) {
            lVar.f(g.b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f73f.b(bundle);
    }

    @Override // b.p.a0
    public z q() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f74g == null) {
            b bVar = (b) getLastNonConfigurationInstance();
            if (bVar != null) {
                this.f74g = bVar.f80a;
            }
            if (this.f74g == null) {
                this.f74g = new z();
            }
        }
        return this.f74g;
    }
}
