package androidx.activity;

import b.a.b;
import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import java.util.ArrayDeque;
import java.util.Iterator;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\activity\OnBackPressedDispatcher.smali */
public final class OnBackPressedDispatcher {

    /* renamed from: a, reason: collision with root package name */
    public final Runnable f86a;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayDeque<b> f87b = new ArrayDeque<>();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\activity\OnBackPressedDispatcher$LifecycleOnBackPressedCancellable.smali */
    public class LifecycleOnBackPressedCancellable implements i, b.a.a {

        /* renamed from: a, reason: collision with root package name */
        public final g f88a;

        /* renamed from: b, reason: collision with root package name */
        public final b f89b;

        /* renamed from: c, reason: collision with root package name */
        public b.a.a f90c;

        public LifecycleOnBackPressedCancellable(g gVar, b bVar) {
            this.f88a = gVar;
            this.f89b = bVar;
            gVar.a(this);
        }

        @Override // b.a.a
        public void cancel() {
            ((l) this.f88a).f2126a.s(this);
            this.f89b.f567b.remove(this);
            b.a.a aVar = this.f90c;
            if (aVar != null) {
                aVar.cancel();
                this.f90c = null;
            }
        }

        @Override // b.p.i
        public void d(k kVar, g.a aVar) {
            if (aVar == g.a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                b bVar = this.f89b;
                onBackPressedDispatcher.f87b.add(bVar);
                a aVar2 = onBackPressedDispatcher.new a(bVar);
                bVar.f567b.add(aVar2);
                this.f90c = aVar2;
                return;
            }
            if (aVar != g.a.ON_STOP) {
                if (aVar == g.a.ON_DESTROY) {
                    cancel();
                }
            } else {
                b.a.a aVar3 = this.f90c;
                if (aVar3 != null) {
                    aVar3.cancel();
                }
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\activity\OnBackPressedDispatcher$a.smali */
    public class a implements b.a.a {

        /* renamed from: a, reason: collision with root package name */
        public final b f92a;

        public a(b bVar) {
            this.f92a = bVar;
        }

        @Override // b.a.a
        public void cancel() {
            OnBackPressedDispatcher.this.f87b.remove(this.f92a);
            this.f92a.f567b.remove(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f86a = runnable;
    }

    public void a() {
        Iterator<b> descendingIterator = this.f87b.descendingIterator();
        while (descendingIterator.hasNext()) {
            b next = descendingIterator.next();
            if (next.f566a) {
                next.a();
                return;
            }
        }
        Runnable runnable = this.f86a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
