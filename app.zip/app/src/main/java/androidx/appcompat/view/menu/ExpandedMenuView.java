package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import b.b.b;
import b.b.h.i.i;
import b.b.h.i.n;
import b.b.i.v0;
import b.h.k.q;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\view\menu\ListMenuItemView.smali */
public class ListMenuItemView extends LinearLayout implements n.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: d, reason: collision with root package name */
    public i f123d;

    /* renamed from: e, reason: collision with root package name */
    public ImageView f124e;

    /* renamed from: f, reason: collision with root package name */
    public RadioButton f125f;

    /* renamed from: g, reason: collision with root package name */
    public TextView f126g;

    /* renamed from: h, reason: collision with root package name */
    public CheckBox f127h;

    /* renamed from: i, reason: collision with root package name */
    public TextView f128i;

    /* renamed from: j, reason: collision with root package name */
    public ImageView f129j;
    public ImageView k;
    public LinearLayout l;
    public Drawable m;
    public int n;
    public Context o;
    public boolean p;
    public Drawable q;
    public boolean r;
    public LayoutInflater s;
    public boolean t;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        v0 q = v0.q(getContext(), attributeSet, b.r, 2130969172, 0);
        this.m = q.g(5);
        this.n = q.l(1, -1);
        this.p = q.a(7, false);
        this.o = context;
        this.q = q.g(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, 2130968916, 0);
        this.r = obtainStyledAttributes.hasValue(0);
        q.f1076b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.s == null) {
            this.s = LayoutInflater.from(getContext());
        }
        return this.s;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.f129j;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    public final void a() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(2131558414, (ViewGroup) this, false);
        this.f127h = checkBox;
        LinearLayout linearLayout = this.l;
        if (linearLayout != null) {
            linearLayout.addView(checkBox, -1);
        } else {
            addView(checkBox, -1);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.k;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.k.getLayoutParams();
        rect.top = this.k.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    public final void b() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(2131558417, (ViewGroup) this, false);
        this.f125f = radioButton;
        LinearLayout linearLayout = this.l;
        if (linearLayout != null) {
            linearLayout.addView(radioButton, -1);
        } else {
            addView(radioButton, -1);
        }
    }

    public void c(boolean z) {
        String sb;
        int i2 = (z && this.f123d.m()) ? 0 : 8;
        if (i2 == 0) {
            TextView textView = this.f128i;
            i iVar = this.f123d;
            char e2 = iVar.e();
            if (e2 == 0) {
                sb = "";
            } else {
                Resources resources = iVar.n.f821a.getResources();
                StringBuilder sb2 = new StringBuilder();
                if (ViewConfiguration.get(iVar.n.f821a).hasPermanentMenuKey()) {
                    sb2.append(resources.getString(2131886097));
                }
                int i3 = iVar.n.n() ? iVar.k : iVar.f842i;
                i.c(sb2, i3, 65536, resources.getString(2131886093));
                i.c(sb2, i3, 4096, resources.getString(2131886089));
                i.c(sb2, i3, 2, resources.getString(2131886088));
                i.c(sb2, i3, 1, resources.getString(2131886094));
                i.c(sb2, i3, 4, resources.getString(2131886096));
                i.c(sb2, i3, 8, resources.getString(2131886092));
                if (e2 == '\b') {
                    sb2.append(resources.getString(2131886090));
                } else if (e2 == '\n') {
                    sb2.append(resources.getString(2131886091));
                } else if (e2 != ' ') {
                    sb2.append(e2);
                } else {
                    sb2.append(resources.getString(2131886095));
                }
                sb = sb2.toString();
            }
            textView.setText(sb);
        }
        if (this.f128i.getVisibility() != i2) {
            this.f128i.setVisibility(i2);
        }
    }

    @Override // b.b.h.i.n.a
    public void d(i iVar, int i2) {
        this.f123d = iVar;
        setVisibility(iVar.isVisible() ? 0 : 8);
        setTitle(iVar.f838e);
        setCheckable(iVar.isCheckable());
        boolean m = iVar.m();
        iVar.e();
        c(m);
        setIcon(iVar.getIcon());
        setEnabled(iVar.isEnabled());
        setSubMenuArrowVisible(iVar.hasSubMenu());
        setContentDescription(iVar.q);
    }

    @Override // b.b.h.i.n.a
    public i getItemData() {
        return this.f123d;
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        Drawable drawable = this.m;
        AtomicInteger atomicInteger = q.f1738a;
        setBackground(drawable);
        TextView textView = (TextView) findViewById(2131362568);
        this.f126g = textView;
        int i2 = this.n;
        if (i2 != -1) {
            textView.setTextAppearance(this.o, i2);
        }
        this.f128i = (TextView) findViewById(2131362486);
        ImageView imageView = (ImageView) findViewById(2131362523);
        this.f129j = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.q);
        }
        this.k = (ImageView) findViewById(2131362134);
        this.l = (LinearLayout) findViewById(2131361983);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        if (this.f124e != null && this.p) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f124e.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (!z && this.f125f == null && this.f127h == null) {
            return;
        }
        if (this.f123d.h()) {
            if (this.f125f == null) {
                b();
            }
            compoundButton = this.f125f;
            compoundButton2 = this.f127h;
        } else {
            if (this.f127h == null) {
                a();
            }
            compoundButton = this.f127h;
            compoundButton2 = this.f125f;
        }
        if (z) {
            compoundButton.setChecked(this.f123d.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (compoundButton2 == null || compoundButton2.getVisibility() == 8) {
                return;
            }
            compoundButton2.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.f127h;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.f125f;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f123d.h()) {
            if (this.f125f == null) {
                b();
            }
            compoundButton = this.f125f;
        } else {
            if (this.f127h == null) {
                a();
            }
            compoundButton = this.f127h;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.t = z;
        this.p = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.k;
        if (imageView != null) {
            imageView.setVisibility((this.r || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        Objects.requireNonNull(this.f123d.n);
        boolean z = this.t;
        if (z || this.p) {
            ImageView imageView = this.f124e;
            if (imageView == null && drawable == null && !this.p) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(2131558415, (ViewGroup) this, false);
                this.f124e = imageView2;
                LinearLayout linearLayout = this.l;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.p) {
                this.f124e.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f124e;
            if (!z) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f124e.getVisibility() != 0) {
                this.f124e.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f126g.getVisibility() != 8) {
                this.f126g.setVisibility(8);
            }
        } else {
            this.f126g.setText(charSequence);
            if (this.f126g.getVisibility() != 0) {
                this.f126g.setVisibility(0);
            }
        }
    }
}
