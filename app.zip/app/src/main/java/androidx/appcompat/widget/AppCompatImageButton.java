package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;
import b.b.i.e;
import b.b.i.j;
import b.b.i.q0;
import b.b.i.s0;
import b.b.i.t0;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\AppCompatImageView.smali */
public class AppCompatImageView extends ImageView {

    /* renamed from: d, reason: collision with root package name */
    public final e f163d;

    /* renamed from: e, reason: collision with root package name */
    public final j f164e;

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        s0.a(context);
        q0.a(this, getContext());
        e eVar = new e(this);
        this.f163d = eVar;
        eVar.d(attributeSet, i2);
        j jVar = new j(this);
        this.f164e = jVar;
        jVar.b(attributeSet, i2);
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f163d;
        if (eVar != null) {
            eVar.a();
        }
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f163d;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f163d;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        t0 t0Var;
        j jVar = this.f164e;
        if (jVar == null || (t0Var = jVar.f966b) == null) {
            return null;
        }
        return t0Var.f1047a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        t0 t0Var;
        j jVar = this.f164e;
        if (jVar == null || (t0Var = jVar.f966b) == null) {
            return null;
        }
        return t0Var.f1048b;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return ((this.f164e.f965a.getBackground() instanceof RippleDrawable) ^ true) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        e eVar = this.f163d;
        if (eVar != null) {
            eVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        e eVar = this.f163d;
        if (eVar != null) {
            eVar.f(i2);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.c(i2);
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        e eVar = this.f163d;
        if (eVar != null) {
            eVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        e eVar = this.f163d;
        if (eVar != null) {
            eVar.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.d(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        j jVar = this.f164e;
        if (jVar != null) {
            jVar.e(mode);
        }
    }
}
