package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import b.b.a;
import b.b.i.e;
import b.b.i.q0;
import b.b.i.s0;
import b.b.i.t;
import b.b.i.u;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\AppCompatEditText.smali */
public class AppCompatEditText extends EditText {

    /* renamed from: d, reason: collision with root package name */
    public final e f158d;

    /* renamed from: e, reason: collision with root package name */
    public final u f159e;

    /* renamed from: f, reason: collision with root package name */
    public final t f160f;

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130968921);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatEditText(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        s0.a(context);
        q0.a(this, getContext());
        e eVar = new e(this);
        this.f158d = eVar;
        eVar.d(attributeSet, i2);
        u uVar = new u(this);
        this.f159e = uVar;
        uVar.e(attributeSet, i2);
        uVar.b();
        this.f160f = new t(this);
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f158d;
        if (eVar != null) {
            eVar.a();
        }
        u uVar = this.f159e;
        if (uVar != null) {
            uVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f158d;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f158d;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    @Override // android.widget.EditText, android.widget.TextView
    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        t tVar;
        return (Build.VERSION.SDK_INT >= 28 || (tVar = this.f160f) == null) ? super.getTextClassifier() : tVar.a();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        a.b(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        e eVar = this.f158d;
        if (eVar != null) {
            eVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        e eVar = this.f158d;
        if (eVar != null) {
            eVar.f(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(b.h.a.Y(this, callback));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        e eVar = this.f158d;
        if (eVar != null) {
            eVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        e eVar = this.f158d;
        if (eVar != null) {
            eVar.i(mode);
        }
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        u uVar = this.f159e;
        if (uVar != null) {
            uVar.f(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        t tVar;
        if (Build.VERSION.SDK_INT >= 28 || (tVar = this.f160f) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            tVar.f1046b = textClassifier;
        }
    }
}
