package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import b.b.b;
import b.b.h.i.g;
import b.b.h.i.n;
import b.b.i.b1;
import b.b.i.c;
import b.h.k.q;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarContextView.smali */
public class ActionBarContextView extends b.b.i.a {
    public CharSequence l;
    public CharSequence m;
    public View n;
    public View o;
    public LinearLayout p;
    public TextView q;
    public TextView r;
    public int s;
    public int t;
    public boolean u;
    public int v;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarContextView$a.smali */
    public class a implements View.OnClickListener {

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ b.b.h.a f137d;

        public a(ActionBarContextView actionBarContextView, b.b.h.a aVar) {
            this.f137d = aVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.f137d.c();
        }
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130968605);
        int resourceId;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.f591d, 2130968605, 0);
        Drawable drawable = (!obtainStyledAttributes.hasValue(0) || (resourceId = obtainStyledAttributes.getResourceId(0, 0)) == 0) ? obtainStyledAttributes.getDrawable(0) : b.b.d.a.a.b(context, resourceId);
        AtomicInteger atomicInteger = q.f1741a;
        setBackground(drawable);
        this.s = obtainStyledAttributes.getResourceId(5, 0);
        this.t = obtainStyledAttributes.getResourceId(4, 0);
        this.f883h = obtainStyledAttributes.getLayoutDimension(3, 0);
        this.v = obtainStyledAttributes.getResourceId(2, 2131558405);
        obtainStyledAttributes.recycle();
    }

    public void f(b.b.h.a aVar) {
        View view = this.n;
        if (view == null) {
            View inflate = LayoutInflater.from(getContext()).inflate(this.v, (ViewGroup) this, false);
            this.n = inflate;
            addView(inflate);
        } else if (view.getParent() == null) {
            addView(this.n);
        }
        this.n.findViewById(2131361859).setOnClickListener(new a(this, aVar));
        g gVar = (g) aVar.e();
        c cVar = this.f882g;
        if (cVar != null) {
            cVar.b();
        }
        c cVar2 = new c(getContext());
        this.f882g = cVar2;
        cVar2.o = true;
        cVar2.p = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        gVar.b(this.f882g, this.f880e);
        c cVar3 = this.f882g;
        n nVar = cVar3.k;
        if (nVar == null) {
            n nVar2 = (n) cVar3.f786g.inflate(cVar3.f788i, (ViewGroup) this, false);
            cVar3.k = nVar2;
            nVar2.b(cVar3.f785f);
            cVar3.f(true);
        }
        n nVar3 = cVar3.k;
        if (nVar != nVar3) {
            ((ActionMenuView) nVar3).setPresenter(cVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) nVar3;
        this.f881f = actionMenuView;
        AtomicInteger atomicInteger = q.f1741a;
        actionMenuView.setBackground(null);
        addView(this.f881f, layoutParams);
    }

    public final void g() {
        if (this.p == null) {
            LayoutInflater.from(getContext()).inflate(2131558400, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.p = linearLayout;
            this.q = (TextView) linearLayout.findViewById(2131361850);
            this.r = (TextView) this.p.findViewById(2131361849);
            if (this.s != 0) {
                this.q.setTextAppearance(getContext(), this.s);
            }
            if (this.t != 0) {
                this.r.setTextAppearance(getContext(), this.t);
            }
        }
        this.q.setText(this.l);
        this.r.setText(this.m);
        boolean z = !TextUtils.isEmpty(this.l);
        boolean z2 = !TextUtils.isEmpty(this.m);
        int i2 = 0;
        this.r.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout2 = this.p;
        if (!z && !z2) {
            i2 = 8;
        }
        linearLayout2.setVisibility(i2);
        if (this.p.getParent() == null) {
            addView(this.p);
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // b.b.i.a
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // b.b.i.a
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.m;
    }

    public CharSequence getTitle() {
        return this.l;
    }

    public void h() {
        removeAllViews();
        this.o = null;
        this.f881f = null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        c cVar = this.f882g;
        if (cVar != null) {
            cVar.g();
            this.f882g.l();
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() != 32) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            return;
        }
        accessibilityEvent.setSource(this);
        accessibilityEvent.setClassName(getClass().getName());
        accessibilityEvent.setPackageName(getContext().getPackageName());
        accessibilityEvent.setContentDescription(this.l);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        boolean b2 = b1.b(this);
        int paddingRight = b2 ? (i4 - i2) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
        View view = this.n;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.n.getLayoutParams();
            int i6 = b2 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i7 = b2 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i8 = b2 ? paddingRight - i6 : paddingRight + i6;
            int d2 = i8 + d(this.n, i8, paddingTop, paddingTop2, b2);
            paddingRight = b2 ? d2 - i7 : d2 + i7;
        }
        int i9 = paddingRight;
        LinearLayout linearLayout = this.p;
        if (linearLayout != null && this.o == null && linearLayout.getVisibility() != 8) {
            i9 += d(this.p, i9, paddingTop, paddingTop2, b2);
        }
        int i10 = i9;
        View view2 = this.o;
        if (view2 != null) {
            d(view2, i10, paddingTop, paddingTop2, b2);
        }
        int paddingLeft = b2 ? getPaddingLeft() : (i4 - i2) - getPaddingRight();
        ActionMenuView actionMenuView = this.f881f;
        if (actionMenuView != null) {
            d(actionMenuView, paddingLeft, paddingTop, paddingTop2, !b2);
        }
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        if (View.MeasureSpec.getMode(i2) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode(i3) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int size = View.MeasureSpec.getSize(i2);
        int i4 = this.f883h;
        if (i4 <= 0) {
            i4 = View.MeasureSpec.getSize(i3);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int i5 = i4 - paddingBottom;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, Integer.MIN_VALUE);
        View view = this.n;
        if (view != null) {
            int c2 = c(view, paddingLeft, makeMeasureSpec, 0);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.n.getLayoutParams();
            paddingLeft = c2 - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f881f;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = c(this.f881f, paddingLeft, makeMeasureSpec, 0);
        }
        LinearLayout linearLayout = this.p;
        if (linearLayout != null && this.o == null) {
            if (this.u) {
                this.p.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                int measuredWidth = this.p.getMeasuredWidth();
                boolean z = measuredWidth <= paddingLeft;
                if (z) {
                    paddingLeft -= measuredWidth;
                }
                this.p.setVisibility(z ? 0 : 8);
            } else {
                paddingLeft = c(linearLayout, paddingLeft, makeMeasureSpec, 0);
            }
        }
        View view2 = this.o;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i6 = layoutParams.width;
            int i7 = i6 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i6 >= 0) {
                paddingLeft = Math.min(i6, paddingLeft);
            }
            int i8 = layoutParams.height;
            int i9 = i8 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i8 >= 0) {
                i5 = Math.min(i8, i5);
            }
            this.o.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i7), View.MeasureSpec.makeMeasureSpec(i5, i9));
        }
        if (this.f883h > 0) {
            setMeasuredDimension(size, i4);
            return;
        }
        int childCount = getChildCount();
        int i10 = 0;
        for (int i11 = 0; i11 < childCount; i11++) {
            int measuredHeight = getChildAt(i11).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i10) {
                i10 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i10);
    }

    @Override // b.b.i.a
    public void setContentHeight(int i2) {
        this.f883h = i2;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.o;
        if (view2 != null) {
            removeView(view2);
        }
        this.o = view;
        if (view != null && (linearLayout = this.p) != null) {
            removeView(linearLayout);
            this.p = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.m = charSequence;
        g();
    }

    public void setTitle(CharSequence charSequence) {
        this.l = charSequence;
        g();
    }

    public void setTitleOptional(boolean z) {
        if (z != this.u) {
            requestLayout();
        }
        this.u = z;
    }

    @Override // b.b.i.a, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i2) {
        super.setVisibility(i2);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
