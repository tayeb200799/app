package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import b.b.i.q0;
import b.b.i.s0;
import b.b.i.t0;
import b.b.i.u;
import b.h.a;
import b.h.l.b;
import b.h.l.e;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\AppCompatButton.smali */
public class AppCompatButton extends Button implements b, e {

    /* renamed from: d, reason: collision with root package name */
    public final b.b.i.e f156d;

    /* renamed from: e, reason: collision with root package name */
    public final u f157e;

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130968700);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatButton(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        s0.a(context);
        q0.a(this, getContext());
        b.b.i.e eVar = new b.b.i.e(this);
        this.f156d = eVar;
        eVar.d(attributeSet, i2);
        u uVar = new u(this);
        this.f157e = uVar;
        uVar.e(attributeSet, i2);
        uVar.b();
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            eVar.a();
        }
        u uVar = this.f157e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (b.f1825a) {
            return super.getAutoSizeMaxTextSize();
        }
        u uVar = this.f157e;
        if (uVar != null) {
            return Math.round(uVar.f1059i.f1069e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (b.f1825a) {
            return super.getAutoSizeMinTextSize();
        }
        u uVar = this.f157e;
        if (uVar != null) {
            return Math.round(uVar.f1059i.f1068d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (b.f1825a) {
            return super.getAutoSizeStepGranularity();
        }
        u uVar = this.f157e;
        if (uVar != null) {
            return Math.round(uVar.f1059i.f1067c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (b.f1825a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        u uVar = this.f157e;
        return uVar != null ? uVar.f1059i.f1070f : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (b.f1825a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        u uVar = this.f157e;
        if (uVar != null) {
            return uVar.f1059i.f1065a;
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        t0 t0Var = this.f157e.f1058h;
        if (t0Var != null) {
            return t0Var.f1047a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        t0 t0Var = this.f157e.f1058h;
        if (t0Var != null) {
            return t0Var.f1048b;
        }
        return null;
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        u uVar = this.f157e;
        if (uVar == null || b.f1825a) {
            return;
        }
        uVar.f1059i.a();
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        u uVar = this.f157e;
        if (uVar == null || b.f1825a || !uVar.d()) {
            return;
        }
        this.f157e.f1059i.a();
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (b.f1825a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        u uVar = this.f157e;
        if (uVar != null) {
            uVar.g(i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (b.f1825a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        u uVar = this.f157e;
        if (uVar != null) {
            uVar.h(iArr, i2);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (b.f1825a) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        u uVar = this.f157e;
        if (uVar != null) {
            uVar.i(i2);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            eVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            eVar.f(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.Y(this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        u uVar = this.f157e;
        if (uVar != null) {
            uVar.f1051a.setAllCaps(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            eVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        b.b.i.e eVar = this.f156d;
        if (eVar != null) {
            eVar.i(mode);
        }
    }

    @Override // b.h.l.e
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f157e.j(colorStateList);
        this.f157e.b();
    }

    @Override // b.h.l.e
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f157e.k(mode);
        this.f157e.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        u uVar = this.f157e;
        if (uVar != null) {
            uVar.f(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextSize(int i2, float f2) {
        boolean z = b.f1825a;
        if (z) {
            super.setTextSize(i2, f2);
            return;
        }
        u uVar = this.f157e;
        if (uVar == null || z || uVar.d()) {
            return;
        }
        uVar.f1059i.f(i2, f2);
    }
}
