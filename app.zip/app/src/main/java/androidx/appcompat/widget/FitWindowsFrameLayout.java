package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import b.b.i.b0;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\FitWindowsLinearLayout.smali */
public class FitWindowsLinearLayout extends LinearLayout {

    /* renamed from: d, reason: collision with root package name */
    public b0 f179d;

    public FitWindowsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // android.view.View
    public boolean fitSystemWindows(Rect rect) {
        b0 b0Var = this.f179d;
        if (b0Var != null) {
            b0Var.a(rect);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(b0 b0Var) {
        this.f179d = b0Var;
    }
}
