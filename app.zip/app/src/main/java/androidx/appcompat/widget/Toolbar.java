package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import b.b.c.a;
import b.b.h.i.i;
import b.b.h.i.m;
import b.b.h.i.r;
import b.b.i.n0;
import b.b.i.v0;
import b.b.i.x0;
import b.b.i.y;
import b.h.k.q;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar.smali */
public class Toolbar extends ViewGroup {
    public CharSequence A;
    public CharSequence B;
    public ColorStateList C;
    public ColorStateList D;
    public boolean E;
    public boolean F;
    public final ArrayList<View> G;
    public final ArrayList<View> H;
    public final int[] I;
    public f J;
    public final ActionMenuView.e K;
    public x0 L;
    public b.b.i.c M;
    public d N;
    public boolean O;
    public final Runnable P;

    /* renamed from: d, reason: collision with root package name */
    public ActionMenuView f212d;

    /* renamed from: e, reason: collision with root package name */
    public TextView f213e;

    /* renamed from: f, reason: collision with root package name */
    public TextView f214f;

    /* renamed from: g, reason: collision with root package name */
    public ImageButton f215g;

    /* renamed from: h, reason: collision with root package name */
    public ImageView f216h;

    /* renamed from: i, reason: collision with root package name */
    public Drawable f217i;

    /* renamed from: j, reason: collision with root package name */
    public CharSequence f218j;
    public ImageButton k;
    public View l;
    public Context m;
    public int n;
    public int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public int u;
    public int v;
    public n0 w;
    public int x;
    public int y;
    public int z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$a.smali */
    public class a implements ActionMenuView.e {
        public a() {
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$b.smali */
    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.v();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$c.smali */
    public class c implements View.OnClickListener {
        public c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            d dVar = Toolbar.this.N;
            i iVar = dVar == null ? null : dVar.f223e;
            if (iVar != null) {
                iVar.collapseActionView();
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$d.smali */
    public class d implements m {

        /* renamed from: d, reason: collision with root package name */
        public b.b.h.i.g f222d;

        /* renamed from: e, reason: collision with root package name */
        public i f223e;

        public d() {
        }

        @Override // b.b.h.i.m
        public void a(b.b.h.i.g gVar, boolean z) {
        }

        @Override // b.b.h.i.m
        public void c(Context context, b.b.h.i.g gVar) {
            i iVar;
            b.b.h.i.g gVar2 = this.f222d;
            if (gVar2 != null && (iVar = this.f223e) != null) {
                gVar2.d(iVar);
            }
            this.f222d = gVar;
        }

        @Override // b.b.h.i.m
        public boolean e(r rVar) {
            return false;
        }

        @Override // b.b.h.i.m
        public void f(boolean z) {
            if (this.f223e != null) {
                b.b.h.i.g gVar = this.f222d;
                boolean z2 = false;
                if (gVar != null) {
                    int size = gVar.size();
                    int i2 = 0;
                    while (true) {
                        if (i2 >= size) {
                            break;
                        }
                        if (this.f222d.getItem(i2) == this.f223e) {
                            z2 = true;
                            break;
                        }
                        i2++;
                    }
                }
                if (z2) {
                    return;
                }
                i(this.f222d, this.f223e);
            }
        }

        @Override // b.b.h.i.m
        public boolean h() {
            return false;
        }

        @Override // b.b.h.i.m
        public boolean i(b.b.h.i.g gVar, i iVar) {
            KeyEvent.Callback callback = Toolbar.this.l;
            if (callback instanceof b.b.h.b) {
                ((b.b.h.b) callback).e();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.l);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.k);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.l = null;
            int size = toolbar3.H.size();
            while (true) {
                size--;
                if (size < 0) {
                    toolbar3.H.clear();
                    this.f223e = null;
                    Toolbar.this.requestLayout();
                    iVar.C = false;
                    iVar.n.q(false);
                    return true;
                }
                toolbar3.addView(toolbar3.H.get(size));
            }
        }

        @Override // b.b.h.i.m
        public boolean j(b.b.h.i.g gVar, i iVar) {
            Toolbar.this.c();
            ViewParent parent = Toolbar.this.k.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.k);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.k);
            }
            Toolbar.this.l = iVar.getActionView();
            this.f223e = iVar;
            ViewParent parent2 = Toolbar.this.l.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.l);
                }
                e generateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                generateDefaultLayoutParams.f598a = 8388611 | (toolbar4.q & 112);
                generateDefaultLayoutParams.f225b = 2;
                toolbar4.l.setLayoutParams(generateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.l);
            }
            Toolbar toolbar6 = Toolbar.this;
            int childCount = toolbar6.getChildCount();
            while (true) {
                childCount--;
                if (childCount < 0) {
                    break;
                }
                View childAt = toolbar6.getChildAt(childCount);
                if (((e) childAt.getLayoutParams()).f225b != 2 && childAt != toolbar6.f212d) {
                    toolbar6.removeViewAt(childCount);
                    toolbar6.H.add(childAt);
                }
            }
            Toolbar.this.requestLayout();
            iVar.C = true;
            iVar.n.q(false);
            KeyEvent.Callback callback = Toolbar.this.l;
            if (callback instanceof b.b.h.b) {
                ((b.b.h.b) callback).c();
            }
            return true;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$e.smali */
    public static class e extends a.C0010a {

        /* renamed from: b, reason: collision with root package name */
        public int f225b;

        public e(int i2, int i3) {
            super(i2, i3);
            this.f225b = 0;
            this.f598a = 8388627;
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f225b = 0;
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f225b = 0;
        }

        public e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f225b = 0;
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }

        public e(e eVar) {
            super((a.C0010a) eVar);
            this.f225b = 0;
            this.f225b = eVar.f225b;
        }

        public e(a.C0010a c0010a) {
            super(c0010a);
            this.f225b = 0;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$f.smali */
    public interface f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$g.smali */
    public static class g extends b.j.a.a {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: f, reason: collision with root package name */
        public int f226f;

        /* renamed from: g, reason: collision with root package name */
        public boolean f227g;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\Toolbar$g$a.smali */
        public class a implements Parcelable.ClassLoaderCreator<g> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new g(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new g[i2];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f226f = parcel.readInt();
            this.f227g = parcel.readInt() != 0;
        }

        public g(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // b.j.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.f1846d, i2);
            parcel.writeInt(this.f226f);
            parcel.writeInt(this.f227g ? 1 : 0);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130969547);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.z = 8388627;
        this.G = new ArrayList<>();
        this.H = new ArrayList<>();
        this.I = new int[2];
        this.K = new a();
        this.P = new b();
        Context context2 = getContext();
        int[] iArr = b.b.b.y;
        v0 q = v0.q(context2, attributeSet, iArr, i2, 0);
        q.s(this, context, iArr, attributeSet, q.f1079b, i2, 0);
        this.o = q.l(28, 0);
        this.p = q.l(19, 0);
        this.z = q.f1079b.getInteger(0, this.z);
        this.q = q.f1079b.getInteger(2, 48);
        int e2 = q.e(22, 0);
        e2 = q.o(27) ? q.e(27, e2) : e2;
        this.v = e2;
        this.u = e2;
        this.t = e2;
        this.s = e2;
        int e3 = q.e(25, -1);
        if (e3 >= 0) {
            this.s = e3;
        }
        int e4 = q.e(24, -1);
        if (e4 >= 0) {
            this.t = e4;
        }
        int e5 = q.e(26, -1);
        if (e5 >= 0) {
            this.u = e5;
        }
        int e6 = q.e(23, -1);
        if (e6 >= 0) {
            this.v = e6;
        }
        this.r = q.f(13, -1);
        int e7 = q.e(9, Integer.MIN_VALUE);
        int e8 = q.e(5, Integer.MIN_VALUE);
        int f2 = q.f(7, 0);
        int f3 = q.f(8, 0);
        d();
        n0 n0Var = this.w;
        n0Var.f1001h = false;
        if (f2 != Integer.MIN_VALUE) {
            n0Var.f998e = f2;
            n0Var.f994a = f2;
        }
        if (f3 != Integer.MIN_VALUE) {
            n0Var.f999f = f3;
            n0Var.f995b = f3;
        }
        if (e7 != Integer.MIN_VALUE || e8 != Integer.MIN_VALUE) {
            n0Var.a(e7, e8);
        }
        this.x = q.e(10, Integer.MIN_VALUE);
        this.y = q.e(6, Integer.MIN_VALUE);
        this.f217i = q.g(4);
        this.f218j = q.n(3);
        CharSequence n = q.n(21);
        if (!TextUtils.isEmpty(n)) {
            setTitle(n);
        }
        CharSequence n2 = q.n(18);
        if (!TextUtils.isEmpty(n2)) {
            setSubtitle(n2);
        }
        this.m = getContext();
        setPopupTheme(q.l(17, 0));
        Drawable g2 = q.g(16);
        if (g2 != null) {
            setNavigationIcon(g2);
        }
        CharSequence n3 = q.n(15);
        if (!TextUtils.isEmpty(n3)) {
            setNavigationContentDescription(n3);
        }
        Drawable g3 = q.g(11);
        if (g3 != null) {
            setLogo(g3);
        }
        CharSequence n4 = q.n(12);
        if (!TextUtils.isEmpty(n4)) {
            setLogoDescription(n4);
        }
        if (q.o(29)) {
            setTitleTextColor(q.c(29));
        }
        if (q.o(20)) {
            setSubtitleTextColor(q.c(20));
        }
        if (q.o(14)) {
            getMenuInflater().inflate(q.l(14, 0), getMenu());
        }
        q.f1079b.recycle();
    }

    private MenuInflater getMenuInflater() {
        return new b.b.h.f(getContext());
    }

    public final void a(List<View> list, int i2) {
        AtomicInteger atomicInteger = q.f1741a;
        boolean z = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        list.clear();
        if (!z) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.f225b == 0 && u(childAt) && j(eVar.f598a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            View childAt2 = getChildAt(i4);
            e eVar2 = (e) childAt2.getLayoutParams();
            if (eVar2.f225b == 0 && u(childAt2) && j(eVar2.f598a) == absoluteGravity) {
                list.add(childAt2);
            }
        }
    }

    public final void b(View view, boolean z) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        e generateDefaultLayoutParams = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (e) layoutParams;
        generateDefaultLayoutParams.f225b = 1;
        if (!z || this.l == null) {
            addView(view, generateDefaultLayoutParams);
        } else {
            view.setLayoutParams(generateDefaultLayoutParams);
            this.H.add(view);
        }
    }

    public void c() {
        if (this.k == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, 2130969546);
            this.k = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f217i);
            this.k.setContentDescription(this.f218j);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f598a = 8388611 | (this.q & 112);
            generateDefaultLayoutParams.f225b = 2;
            this.k.setLayoutParams(generateDefaultLayoutParams);
            this.k.setOnClickListener(new c());
        }
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof e);
    }

    public final void d() {
        if (this.w == null) {
            this.w = new n0();
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f212d;
        if (actionMenuView.s == null) {
            b.b.h.i.g gVar = (b.b.h.i.g) actionMenuView.getMenu();
            if (this.N == null) {
                this.N = new d();
            }
            this.f212d.setExpandedActionViewsExclusive(true);
            gVar.b(this.N, this.m);
        }
    }

    public final void f() {
        if (this.f212d == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f212d = actionMenuView;
            actionMenuView.setPopupTheme(this.n);
            this.f212d.setOnMenuItemClickListener(this.K);
            ActionMenuView actionMenuView2 = this.f212d;
            actionMenuView2.x = null;
            actionMenuView2.y = null;
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f598a = 8388613 | (this.q & 112);
            this.f212d.setLayoutParams(generateDefaultLayoutParams);
            b(this.f212d, false);
        }
    }

    public final void g() {
        if (this.f215g == null) {
            this.f215g = new AppCompatImageButton(getContext(), null, 2130969546);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f598a = 8388611 | (this.q & 112);
            this.f215g.setLayoutParams(generateDefaultLayoutParams);
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.k;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.k;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        n0 n0Var = this.w;
        if (n0Var != null) {
            return n0Var.f1000g ? n0Var.f994a : n0Var.f995b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.y;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        n0 n0Var = this.w;
        if (n0Var != null) {
            return n0Var.f994a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        n0 n0Var = this.w;
        if (n0Var != null) {
            return n0Var.f995b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        n0 n0Var = this.w;
        if (n0Var != null) {
            return n0Var.f1000g ? n0Var.f995b : n0Var.f994a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.x;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        b.b.h.i.g gVar;
        ActionMenuView actionMenuView = this.f212d;
        return actionMenuView != null && (gVar = actionMenuView.s) != null && gVar.hasVisibleItems() ? Math.max(getContentInsetEnd(), Math.max(this.y, 0)) : getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        AtomicInteger atomicInteger = q.f1741a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        AtomicInteger atomicInteger = q.f1741a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.x, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f216h;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f216h;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f212d.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.f215g;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.f215g;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public b.b.i.c getOuterActionMenuPresenter() {
        return this.M;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f212d.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.m;
    }

    public int getPopupTheme() {
        return this.n;
    }

    public CharSequence getSubtitle() {
        return this.B;
    }

    public final TextView getSubtitleTextView() {
        return this.f214f;
    }

    public CharSequence getTitle() {
        return this.A;
    }

    public int getTitleMarginBottom() {
        return this.v;
    }

    public int getTitleMarginEnd() {
        return this.t;
    }

    public int getTitleMarginStart() {
        return this.s;
    }

    public int getTitleMarginTop() {
        return this.u;
    }

    public final TextView getTitleTextView() {
        return this.f213e;
    }

    public y getWrapper() {
        if (this.L == null) {
            this.L = new x0(this, true);
        }
        return this.L;
    }

    @Override // android.view.ViewGroup
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* renamed from: i, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e ? new e((e) layoutParams) : layoutParams instanceof a.C0010a ? new e((a.C0010a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }

    public final int j(int i2) {
        AtomicInteger atomicInteger = q.f1741a;
        int layoutDirection = getLayoutDirection();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, layoutDirection) & 7;
        return (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) ? absoluteGravity : layoutDirection == 1 ? 5 : 3;
    }

    public final int k(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int i4 = eVar.f598a & 112;
        if (i4 != 16 && i4 != 48 && i4 != 80) {
            i4 = this.z & 112;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i5 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        if (i5 < i6) {
            i5 = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - i5) - paddingTop;
            int i8 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            if (i7 < i8) {
                i5 = Math.max(0, i5 - (i8 - i7));
            }
        }
        return paddingTop + i5;
    }

    public final int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    public final int m(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public void n(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public final boolean o(View view) {
        return view.getParent() == this || this.H.contains(view);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.P);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.F = false;
        }
        if (!this.F) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.F = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.F = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:111:0x01a7  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0131  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x0102  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b5  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x02a1 A[LOOP:0: B:40:0x029f->B:41:0x02a1, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x02c3 A[LOOP:1: B:44:0x02c1->B:45:0x02c3, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x02e8 A[LOOP:2: B:48:0x02e6->B:49:0x02e8, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0329  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x033a A[LOOP:3: B:57:0x0338->B:58:0x033a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x012e  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0169  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01b8  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x0227  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            Method dump skipped, instructions count: 847
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0296  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r18, int r19) {
        /*
            Method dump skipped, instructions count: 667
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onMeasure(int, int):void");
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.f1846d);
        ActionMenuView actionMenuView = this.f212d;
        b.b.h.i.g gVar2 = actionMenuView != null ? actionMenuView.s : null;
        int i2 = gVar.f226f;
        if (i2 != 0 && this.N != null && gVar2 != null && (findItem = gVar2.findItem(i2)) != null) {
            findItem.expandActionView();
        }
        if (gVar.f227g) {
            removeCallbacks(this.P);
            post(this.P);
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        d();
        n0 n0Var = this.w;
        boolean z = i2 == 1;
        if (z == n0Var.f1000g) {
            return;
        }
        n0Var.f1000g = z;
        if (!n0Var.f1001h) {
            n0Var.f994a = n0Var.f998e;
            n0Var.f995b = n0Var.f999f;
            return;
        }
        if (z) {
            int i3 = n0Var.f997d;
            if (i3 == Integer.MIN_VALUE) {
                i3 = n0Var.f998e;
            }
            n0Var.f994a = i3;
            int i4 = n0Var.f996c;
            if (i4 == Integer.MIN_VALUE) {
                i4 = n0Var.f999f;
            }
            n0Var.f995b = i4;
            return;
        }
        int i5 = n0Var.f996c;
        if (i5 == Integer.MIN_VALUE) {
            i5 = n0Var.f998e;
        }
        n0Var.f994a = i5;
        int i6 = n0Var.f997d;
        if (i6 == Integer.MIN_VALUE) {
            i6 = n0Var.f999f;
        }
        n0Var.f995b = i6;
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        i iVar;
        g gVar = new g(super.onSaveInstanceState());
        d dVar = this.N;
        if (dVar != null && (iVar = dVar.f223e) != null) {
            gVar.f226f = iVar.f836a;
        }
        gVar.f227g = p();
        return gVar;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.E = false;
        }
        if (!this.E) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.E = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.E = false;
        }
        return true;
    }

    public boolean p() {
        ActionMenuView actionMenuView = this.f212d;
        if (actionMenuView != null) {
            b.b.i.c cVar = actionMenuView.w;
            if (cVar != null && cVar.m()) {
                return true;
            }
        }
        return false;
    }

    public final int q(View view, int i2, int[] iArr, int i3) {
        e eVar = (e) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin - iArr[0];
        int max = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int k = k(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, k, max + measuredWidth, view.getMeasuredHeight() + k);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).rightMargin + max;
    }

    public final int r(View view, int i2, int[] iArr, int i3) {
        e eVar = (e) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int k = k(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, k, max, view.getMeasuredHeight() + k);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).leftMargin);
    }

    public final int s(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        ImageButton imageButton = this.k;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(b.b.d.a.a.b(getContext(), i2));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.k.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.k;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.f217i);
            }
        }
    }

    public void setCollapsible(boolean z) {
        this.O = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.y) {
            this.y = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.x) {
            this.x = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(b.b.d.a.a.b(getContext(), i2));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f216h == null) {
                this.f216h = new AppCompatImageView(getContext(), null);
            }
            if (!o(this.f216h)) {
                b(this.f216h, true);
            }
        } else {
            ImageView imageView = this.f216h;
            if (imageView != null && o(imageView)) {
                removeView(this.f216h);
                this.H.remove(this.f216h);
            }
        }
        ImageView imageView2 = this.f216h;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f216h == null) {
            this.f216h = new AppCompatImageView(getContext(), null);
        }
        ImageView imageView = this.f216h;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.f215g;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(b.b.d.a.a.b(getContext(), i2));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.f215g)) {
                b(this.f215g, true);
            }
        } else {
            ImageButton imageButton = this.f215g;
            if (imageButton != null && o(imageButton)) {
                removeView(this.f215g);
                this.H.remove(this.f215g);
            }
        }
        ImageButton imageButton2 = this.f215g;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f215g.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(f fVar) {
        this.J = fVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f212d.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.n != i2) {
            this.n = i2;
            if (i2 == 0) {
                this.m = getContext();
            } else {
                this.m = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f214f;
            if (textView != null && o(textView)) {
                removeView(this.f214f);
                this.H.remove(this.f214f);
            }
        } else {
            if (this.f214f == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, null);
                this.f214f = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f214f.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.p;
                if (i2 != 0) {
                    this.f214f.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.D;
                if (colorStateList != null) {
                    this.f214f.setTextColor(colorStateList);
                }
            }
            if (!o(this.f214f)) {
                b(this.f214f, true);
            }
        }
        TextView textView2 = this.f214f;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.B = charSequence;
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.D = colorStateList;
        TextView textView = this.f214f;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f213e;
            if (textView != null && o(textView)) {
                removeView(this.f213e);
                this.H.remove(this.f213e);
            }
        } else {
            if (this.f213e == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, null);
                this.f213e = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f213e.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.o;
                if (i2 != 0) {
                    this.f213e.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.C;
                if (colorStateList != null) {
                    this.f213e.setTextColor(colorStateList);
                }
            }
            if (!o(this.f213e)) {
                b(this.f213e, true);
            }
        }
        TextView textView2 = this.f213e;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.A = charSequence;
    }

    public void setTitleMarginBottom(int i2) {
        this.v = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.t = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.s = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.u = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.C = colorStateList;
        TextView textView = this.f213e;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public final void t(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean u(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public boolean v() {
        ActionMenuView actionMenuView = this.f212d;
        if (actionMenuView != null) {
            b.b.i.c cVar = actionMenuView.w;
            if (cVar != null && cVar.n()) {
                return true;
            }
        }
        return false;
    }
}
