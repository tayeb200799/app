package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import b.b.c.u;
import b.b.h.i.m;
import b.b.i.x;
import b.b.i.y;
import b.h.k.g;
import b.h.k.h;
import b.h.k.i;
import b.h.k.q;
import b.h.k.x;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"UnknownNullness"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarOverlayLayout.smali */
public class ActionBarOverlayLayout extends ViewGroup implements x, g, h {
    public static final int[] I = {2130968581, R.attr.windowContentOverlay};
    public b.h.k.x A;
    public d B;
    public OverScroller C;
    public ViewPropertyAnimator D;
    public final AnimatorListenerAdapter E;
    public final Runnable F;
    public final Runnable G;
    public final i H;

    /* renamed from: d, reason: collision with root package name */
    public int f138d;

    /* renamed from: e, reason: collision with root package name */
    public int f139e;

    /* renamed from: f, reason: collision with root package name */
    public ContentFrameLayout f140f;

    /* renamed from: g, reason: collision with root package name */
    public ActionBarContainer f141g;

    /* renamed from: h, reason: collision with root package name */
    public y f142h;

    /* renamed from: i, reason: collision with root package name */
    public Drawable f143i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f144j;
    public boolean k;
    public boolean l;
    public boolean m;
    public boolean n;
    public int o;
    public int p;
    public final Rect q;
    public final Rect r;
    public final Rect s;
    public final Rect t;
    public final Rect u;
    public final Rect v;
    public final Rect w;
    public b.h.k.x x;
    public b.h.k.x y;
    public b.h.k.x z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarOverlayLayout$a.smali */
    public class a extends AnimatorListenerAdapter {
        public a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = null;
            actionBarOverlayLayout.n = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = null;
            actionBarOverlayLayout.n = false;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarOverlayLayout$b.smali */
    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = actionBarOverlayLayout.f141g.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.E);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarOverlayLayout$c.smali */
    public class c implements Runnable {
        public c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = actionBarOverlayLayout.f141g.animate().translationY(-ActionBarOverlayLayout.this.f141g.getHeight()).setListener(ActionBarOverlayLayout.this.E);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarOverlayLayout$d.smali */
    public interface d {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ActionBarOverlayLayout$e.smali */
    public static class e extends ViewGroup.MarginLayoutParams {
        public e(int i2, int i3) {
            super(i2, i3);
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f139e = 0;
        this.q = new Rect();
        this.r = new Rect();
        this.s = new Rect();
        this.t = new Rect();
        this.u = new Rect();
        this.v = new Rect();
        this.w = new Rect();
        b.h.k.x xVar = b.h.k.x.f1765b;
        this.x = xVar;
        this.y = xVar;
        this.z = xVar;
        this.A = xVar;
        this.E = new a();
        this.F = new b();
        this.G = new c();
        r(context);
        this.H = new i();
    }

    @Override // b.b.i.x
    public void a(Menu menu, m.a aVar) {
        s();
        this.f142h.a(menu, aVar);
    }

    @Override // b.b.i.x
    public boolean b() {
        s();
        return this.f142h.b();
    }

    @Override // b.b.i.x
    public void c() {
        s();
        this.f142h.c();
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // b.b.i.x
    public boolean d() {
        s();
        return this.f142h.d();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.f143i == null || this.f144j) {
            return;
        }
        if (this.f141g.getVisibility() == 0) {
            i2 = (int) (this.f141g.getTranslationY() + this.f141g.getBottom() + 0.5f);
        } else {
            i2 = 0;
        }
        this.f143i.setBounds(0, i2, getWidth(), this.f143i.getIntrinsicHeight() + i2);
        this.f143i.draw(canvas);
    }

    @Override // b.b.i.x
    public boolean e() {
        s();
        return this.f142h.e();
    }

    @Override // b.b.i.x
    public boolean f() {
        s();
        return this.f142h.f();
    }

    @Override // android.view.View
    public boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // b.b.i.x
    public boolean g() {
        s();
        return this.f142h.g();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f141g;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.H.a();
    }

    public CharSequence getTitle() {
        s();
        return this.f142h.getTitle();
    }

    @Override // b.h.k.g
    public void h(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // b.h.k.g
    public void i(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // b.h.k.g
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    @Override // b.b.i.x
    public void k(int i2) {
        s();
        if (i2 == 2) {
            this.f142h.t();
        } else if (i2 == 5) {
            this.f142h.u();
        } else {
            if (i2 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // b.b.i.x
    public void l() {
        s();
        this.f142h.h();
    }

    @Override // b.h.k.h
    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // b.h.k.g
    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // b.h.k.g
    public boolean o(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        s();
        b.h.k.x j2 = b.h.k.x.j(windowInsets, null);
        boolean p = p(this.f141g, new Rect(j2.b(), j2.d(), j2.c(), j2.a()), true, true, false, true);
        Rect rect = this.q;
        AtomicInteger atomicInteger = q.f1741a;
        WindowInsets h2 = j2.h();
        if (h2 != null) {
            b.h.k.x.j(computeSystemWindowInsets(h2, rect), this);
        } else {
            rect.setEmpty();
        }
        Rect rect2 = this.q;
        b.h.k.x i2 = j2.f1766a.i(rect2.left, rect2.top, rect2.right, rect2.bottom);
        this.x = i2;
        boolean z = true;
        if (!this.y.equals(i2)) {
            this.y = this.x;
            p = true;
        }
        if (this.r.equals(this.q)) {
            z = p;
        } else {
            this.r.set(this.q);
        }
        if (z) {
            requestLayout();
        }
        return j2.f1766a.a().f1766a.c().f1766a.b().h();
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        r(getContext());
        AtomicInteger atomicInteger = q.f1741a;
        requestApplyInsets();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        q();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        int measuredHeight;
        s();
        measureChildWithMargins(this.f141g, i2, 0, i3, 0);
        e eVar = (e) this.f141g.getLayoutParams();
        int max = Math.max(0, this.f141g.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int max2 = Math.max(0, this.f141g.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f141g.getMeasuredState());
        AtomicInteger atomicInteger = q.f1741a;
        boolean z = (getWindowSystemUiVisibility() & 256) != 0;
        if (z) {
            measuredHeight = this.f138d;
            if (this.l && this.f141g.getTabContainer() != null) {
                measuredHeight += this.f138d;
            }
        } else {
            measuredHeight = this.f141g.getVisibility() != 8 ? this.f141g.getMeasuredHeight() : 0;
        }
        this.s.set(this.q);
        b.h.k.x xVar = this.x;
        this.z = xVar;
        if (this.k || z) {
            b.h.e.b a2 = b.h.e.b.a(xVar.b(), this.z.d() + measuredHeight, this.z.c(), this.z.a() + 0);
            b.h.k.x xVar2 = this.z;
            int i4 = Build.VERSION.SDK_INT;
            x.e dVar = i4 >= 30 ? new x.d(xVar2) : i4 >= 29 ? new x.c(xVar2) : new x.b(xVar2);
            dVar.c(a2);
            this.z = dVar.a();
        } else {
            Rect rect = this.s;
            rect.top += measuredHeight;
            rect.bottom += 0;
            this.z = xVar.f1766a.i(0, measuredHeight, 0, 0);
        }
        p(this.f140f, this.s, true, true, true, true);
        if (!this.A.equals(this.z)) {
            b.h.k.x xVar3 = this.z;
            this.A = xVar3;
            q.e(this.f140f, xVar3);
        }
        measureChildWithMargins(this.f140f, i2, 0, i3, 0);
        e eVar2 = (e) this.f140f.getLayoutParams();
        int max3 = Math.max(max, this.f140f.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int max4 = Math.max(max2, this.f140f.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f140f.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        if (!this.m || !z) {
            return false;
        }
        this.C.fling(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.C.getFinalY() > this.f141g.getHeight()) {
            q();
            this.G.run();
        } else {
            q();
            this.F.run();
        }
        this.n = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.o + i3;
        this.o = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        u uVar;
        b.b.h.g gVar;
        this.H.f1735a = i2;
        this.o = getActionBarHideOffset();
        q();
        d dVar = this.B;
        if (dVar == null || (gVar = (uVar = (u) dVar).t) == null) {
            return;
        }
        gVar.a();
        uVar.t = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f141g.getVisibility() != 0) {
            return false;
        }
        return this.m;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        if (this.m && !this.n) {
            if (this.o <= this.f141g.getHeight()) {
                q();
                postDelayed(this.F, 600L);
            } else {
                q();
                postDelayed(this.G, 600L);
            }
        }
        d dVar = this.B;
        if (dVar != null) {
            Objects.requireNonNull((u) dVar);
        }
    }

    @Override // android.view.View
    public void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        s();
        int i3 = this.p ^ i2;
        this.p = i2;
        boolean z = (i2 & 4) == 0;
        boolean z2 = (i2 & 256) != 0;
        d dVar = this.B;
        if (dVar != null) {
            ((u) dVar).p = !z2;
            if (z || !z2) {
                u uVar = (u) dVar;
                if (uVar.q) {
                    uVar.q = false;
                    uVar.g(true);
                }
            } else {
                u uVar2 = (u) dVar;
                if (!uVar2.q) {
                    uVar2.q = true;
                    uVar2.g(true);
                }
            }
        }
        if ((i3 & 256) == 0 || this.B == null) {
            return;
        }
        AtomicInteger atomicInteger = q.f1741a;
        requestApplyInsets();
    }

    @Override // android.view.View
    public void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.f139e = i2;
        d dVar = this.B;
        if (dVar != null) {
            ((u) dVar).o = i2;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean p(android.view.View r3, android.graphics.Rect r4, boolean r5, boolean r6, boolean r7, boolean r8) {
        /*
            r2 = this;
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.ActionBarOverlayLayout$e r3 = (androidx.appcompat.widget.ActionBarOverlayLayout.e) r3
            r0 = 1
            if (r5 == 0) goto L13
            int r5 = r3.leftMargin
            int r1 = r4.left
            if (r5 == r1) goto L13
            r3.leftMargin = r1
            r5 = 1
            goto L14
        L13:
            r5 = 0
        L14:
            if (r6 == 0) goto L1f
            int r6 = r3.topMargin
            int r1 = r4.top
            if (r6 == r1) goto L1f
            r3.topMargin = r1
            r5 = 1
        L1f:
            if (r8 == 0) goto L2a
            int r6 = r3.rightMargin
            int r8 = r4.right
            if (r6 == r8) goto L2a
            r3.rightMargin = r8
            r5 = 1
        L2a:
            if (r7 == 0) goto L35
            int r6 = r3.bottomMargin
            int r4 = r4.bottom
            if (r6 == r4) goto L35
            r3.bottomMargin = r4
            goto L36
        L35:
            r0 = r5
        L36:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.p(android.view.View, android.graphics.Rect, boolean, boolean, boolean, boolean):boolean");
    }

    public void q() {
        removeCallbacks(this.F);
        removeCallbacks(this.G);
        ViewPropertyAnimator viewPropertyAnimator = this.D;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void r(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(I);
        this.f138d = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f143i = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        this.f144j = context.getApplicationInfo().targetSdkVersion < 19;
        this.C = new OverScroller(context);
    }

    public void s() {
        y wrapper;
        if (this.f140f == null) {
            this.f140f = (ContentFrameLayout) findViewById(2131361845);
            this.f141g = (ActionBarContainer) findViewById(2131361846);
            KeyEvent.Callback findViewById = findViewById(2131361844);
            if (findViewById instanceof y) {
                wrapper = (y) findViewById;
            } else {
                if (!(findViewById instanceof Toolbar)) {
                    StringBuilder n = c.a.a.a.a.n("Can't make a decor toolbar out of ");
                    n.append(findViewById.getClass().getSimpleName());
                    throw new IllegalStateException(n.toString());
                }
                wrapper = ((Toolbar) findViewById).getWrapper();
            }
            this.f142h = wrapper;
        }
    }

    public void setActionBarHideOffset(int i2) {
        q();
        this.f141g.setTranslationY(-Math.max(0, Math.min(i2, this.f141g.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.B = dVar;
        if (getWindowToken() != null) {
            ((u) this.B).o = this.f139e;
            int i2 = this.p;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                AtomicInteger atomicInteger = q.f1741a;
                requestApplyInsets();
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.l = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.m) {
            this.m = z;
            if (z) {
                return;
            }
            q();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        s();
        this.f142h.setIcon(i2);
    }

    public void setIcon(Drawable drawable) {
        s();
        this.f142h.setIcon(drawable);
    }

    public void setLogo(int i2) {
        s();
        this.f142h.q(i2);
    }

    public void setOverlayMode(boolean z) {
        this.k = z;
        this.f144j = z && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i2) {
    }

    @Override // b.b.i.x
    public void setWindowCallback(Window.Callback callback) {
        s();
        this.f142h.setWindowCallback(callback);
    }

    @Override // b.b.i.x
    public void setWindowTitle(CharSequence charSequence) {
        s();
        this.f142h.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
