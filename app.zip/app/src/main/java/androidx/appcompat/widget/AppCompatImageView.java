package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import b.b.i.q0;
import b.b.i.s0;
import b.b.i.t;
import b.b.i.t0;
import b.b.i.u;
import b.h.a;
import b.h.e.d;
import b.h.e.k;
import b.h.i.b;
import b.h.l.b;
import b.h.l.e;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\AppCompatTextView.smali */
public class AppCompatTextView extends TextView implements e, b {

    /* renamed from: d, reason: collision with root package name */
    public final b.b.i.e f165d;

    /* renamed from: e, reason: collision with root package name */
    public final u f166e;

    /* renamed from: f, reason: collision with root package name */
    public final t f167f;

    /* renamed from: g, reason: collision with root package name */
    public Future<b.h.i.b> f168g;

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        s0.a(context);
        q0.a(this, getContext());
        b.b.i.e eVar = new b.b.i.e(this);
        this.f165d = eVar;
        eVar.d(attributeSet, i2);
        u uVar = new u(this);
        this.f166e = uVar;
        uVar.e(attributeSet, i2);
        uVar.b();
        this.f167f = new t(this);
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            eVar.a();
        }
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (b.f1825a) {
            return super.getAutoSizeMaxTextSize();
        }
        u uVar = this.f166e;
        if (uVar != null) {
            return Math.round(uVar.f1059i.f1069e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (b.f1825a) {
            return super.getAutoSizeMinTextSize();
        }
        u uVar = this.f166e;
        if (uVar != null) {
            return Math.round(uVar.f1059i.f1068d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (b.f1825a) {
            return super.getAutoSizeStepGranularity();
        }
        u uVar = this.f166e;
        if (uVar != null) {
            return Math.round(uVar.f1059i.f1067c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (b.f1825a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        u uVar = this.f166e;
        return uVar != null ? uVar.f1059i.f1070f : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (b.f1825a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        u uVar = this.f166e;
        if (uVar != null) {
            return uVar.f1059i.f1065a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        t0 t0Var = this.f166e.f1058h;
        if (t0Var != null) {
            return t0Var.f1047a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        t0 t0Var = this.f166e.f1058h;
        if (t0Var != null) {
            return t0Var.f1048b;
        }
        return null;
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        Future<b.h.i.b> future = this.f168g;
        if (future != null) {
            try {
                this.f168g = null;
                a.N(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        t tVar;
        return (Build.VERSION.SDK_INT >= 28 || (tVar = this.f167f) == null) ? super.getTextClassifier() : tVar.a();
    }

    public b.a getTextMetricsParamsCompat() {
        return a.z(this);
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        b.b.a.b(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        u uVar = this.f166e;
        if (uVar == null || b.h.l.b.f1825a) {
            return;
        }
        uVar.f1059i.a();
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i2, int i3) {
        Future<b.h.i.b> future = this.f168g;
        if (future != null) {
            try {
                this.f168g = null;
                a.N(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i2, i3);
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        u uVar = this.f166e;
        if (uVar == null || b.h.l.b.f1825a || !uVar.d()) {
            return;
        }
        this.f166e.f1059i.a();
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (b.h.l.b.f1825a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.g(i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (b.h.l.b.f1825a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.h(iArr, i2);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (b.h.l.b.f1825a) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.i(i2);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            eVar.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            eVar.f(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i2 != 0 ? b.b.d.a.a.b(context, i2) : null, i3 != 0 ? b.b.d.a.a.b(context, i3) : null, i4 != 0 ? b.b.d.a.a.b(context, i4) : null, i5 != 0 ? b.b.d.a.a.b(context, i5) : null);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i2 != 0 ? b.b.d.a.a.b(context, i2) : null, i3 != 0 ? b.b.d.a.a.b(context, i3) : null, i4 != 0 ? b.b.d.a.a.b(context, i4) : null, i5 != 0 ? b.b.d.a.a.b(context, i5) : null);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.Y(this, callback));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i2);
        } else {
            a.I(this, i2);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i2);
        } else {
            a.J(this, i2);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i2) {
        a.L(this, i2);
    }

    public void setPrecomputedText(b.h.i.b bVar) {
        a.N(this, bVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            eVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        b.b.i.e eVar = this.f165d;
        if (eVar != null) {
            eVar.i(mode);
        }
    }

    @Override // b.h.l.e
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f166e.j(colorStateList);
        this.f166e.b();
    }

    @Override // b.h.l.e
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f166e.k(mode);
        this.f166e.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        u uVar = this.f166e;
        if (uVar != null) {
            uVar.f(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        t tVar;
        if (Build.VERSION.SDK_INT >= 28 || (tVar = this.f167f) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            tVar.f1046b = textClassifier;
        }
    }

    public void setTextFuture(Future<b.h.i.b> future) {
        this.f168g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(b.a aVar) {
        int i2 = Build.VERSION.SDK_INT;
        TextDirectionHeuristic textDirectionHeuristic = aVar.f1701b;
        int i3 = 1;
        if (textDirectionHeuristic != TextDirectionHeuristics.FIRSTSTRONG_RTL && textDirectionHeuristic != TextDirectionHeuristics.FIRSTSTRONG_LTR) {
            if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
                i3 = 2;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
                i3 = 3;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
                i3 = 4;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
                i3 = 5;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
                i3 = 6;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
                i3 = 7;
            }
        }
        setTextDirection(i3);
        if (i2 >= 23) {
            getPaint().set(aVar.f1700a);
            setBreakStrategy(aVar.f1702c);
            setHyphenationFrequency(aVar.f1703d);
        } else {
            float textScaleX = aVar.f1700a.getTextScaleX();
            getPaint().set(aVar.f1700a);
            if (textScaleX == getTextScaleX()) {
                setTextScaleX((textScaleX / 2.0f) + 1.0f);
            }
            setTextScaleX(textScaleX);
        }
    }

    @Override // android.widget.TextView
    public void setTextSize(int i2, float f2) {
        boolean z = b.h.l.b.f1825a;
        if (z) {
            super.setTextSize(i2, f2);
            return;
        }
        u uVar = this.f166e;
        if (uVar == null || z || uVar.d()) {
            return;
        }
        uVar.f1059i.f(i2, f2);
    }

    @Override // android.widget.TextView
    public void setTypeface(Typeface typeface, int i2) {
        Typeface typeface2;
        if (typeface == null || i2 <= 0) {
            typeface2 = null;
        } else {
            Context context = getContext();
            k kVar = d.f1607a;
            if (context == null) {
                throw new IllegalArgumentException("Context cannot be null");
            }
            typeface2 = Typeface.create(typeface, i2);
        }
        if (typeface2 != null) {
            typeface = typeface2;
        }
        super.setTypeface(typeface, i2);
    }
}
