package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import b.b.c.k;
import b.b.c.m;
import b.b.h.i.g;
import b.b.i.x;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ContentFrameLayout.smali */
public class ContentFrameLayout extends FrameLayout {

    /* renamed from: d, reason: collision with root package name */
    public TypedValue f171d;

    /* renamed from: e, reason: collision with root package name */
    public TypedValue f172e;

    /* renamed from: f, reason: collision with root package name */
    public TypedValue f173f;

    /* renamed from: g, reason: collision with root package name */
    public TypedValue f174g;

    /* renamed from: h, reason: collision with root package name */
    public TypedValue f175h;

    /* renamed from: i, reason: collision with root package name */
    public TypedValue f176i;

    /* renamed from: j, reason: collision with root package name */
    public final Rect f177j;
    public a k;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\appcompat\widget\ContentFrameLayout$a.smali */
    public interface a {
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f177j = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f175h == null) {
            this.f175h = new TypedValue();
        }
        return this.f175h;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f176i == null) {
            this.f176i = new TypedValue();
        }
        return this.f176i;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f173f == null) {
            this.f173f = new TypedValue();
        }
        return this.f173f;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f174g == null) {
            this.f174g = new TypedValue();
        }
        return this.f174g;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f171d == null) {
            this.f171d = new TypedValue();
        }
        return this.f171d;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f172e == null) {
            this.f172e = new TypedValue();
        }
        return this.f172e;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        a aVar = this.k;
        if (aVar != null) {
            Objects.requireNonNull((m) aVar);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a aVar = this.k;
        if (aVar != null) {
            k kVar = ((m) aVar).f644a;
            x xVar = kVar.o;
            if (xVar != null) {
                xVar.l();
            }
            if (kVar.t != null) {
                kVar.f617i.getDecorView().removeCallbacks(kVar.u);
                if (kVar.t.isShowing()) {
                    try {
                        kVar.t.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                kVar.t = null;
            }
            kVar.J();
            g gVar = kVar.O(0).f639h;
            if (gVar != null) {
                gVar.c(true);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:50:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00ae  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r14, int r15) {
        /*
            Method dump skipped, instructions count: 226
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(a aVar) {
        this.k = aVar;
    }
}
