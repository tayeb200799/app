package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import b.d.c.b;
import b.d.c.c;
import b.d.c.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\cardview\widget\CardView.smali */
public class CardView extends FrameLayout {
    public static final int[] k = {R.attr.colorBackground};
    public static final c l = new b.d.c.a();

    /* renamed from: d, reason: collision with root package name */
    public boolean f231d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f232e;

    /* renamed from: f, reason: collision with root package name */
    public int f233f;

    /* renamed from: g, reason: collision with root package name */
    public int f234g;

    /* renamed from: h, reason: collision with root package name */
    public final Rect f235h;

    /* renamed from: i, reason: collision with root package name */
    public final Rect f236i;

    /* renamed from: j, reason: collision with root package name */
    public final b f237j;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\cardview\widget\CardView$a.smali */
    public class a implements b {

        /* renamed from: a, reason: collision with root package name */
        public Drawable f238a;

        public a() {
        }

        public boolean a() {
            return CardView.this.getPreventCornerOverlap();
        }

        public void b(int i2, int i3, int i4, int i5) {
            CardView.this.f236i.set(i2, i3, i4, i5);
            CardView cardView = CardView.this;
            Rect rect = cardView.f235h;
            CardView.super.setPadding(i2 + rect.left, i3 + rect.top, i4 + rect.right, i5 + rect.bottom);
        }
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130968720);
    }

    public CardView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        ColorStateList valueOf;
        Rect rect = new Rect();
        this.f235h = rect;
        this.f236i = new Rect();
        a aVar = new a();
        this.f237j = aVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.d.b.f1140a, i2, 2131951852);
        if (obtainStyledAttributes.hasValue(2)) {
            valueOf = obtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(k);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            valueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(2131099690) : getResources().getColor(2131099689));
        }
        float dimension = obtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(5, 0.0f);
        this.f231d = obtainStyledAttributes.getBoolean(7, false);
        this.f232e = obtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        this.f233f = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f234g = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        b.d.c.a aVar2 = (b.d.c.a) l;
        d dVar = new d(valueOf, dimension);
        a aVar3 = aVar;
        aVar3.f238a = dVar;
        CardView.this.setBackgroundDrawable(dVar);
        CardView cardView = CardView.this;
        cardView.setClipToOutline(true);
        cardView.setElevation(dimension2);
        aVar2.b(aVar, dimension3);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((d) ((a) this.f237j).f238a).f1148h;
    }

    public float getCardElevation() {
        return CardView.this.getElevation();
    }

    public int getContentPaddingBottom() {
        return this.f235h.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f235h.left;
    }

    public int getContentPaddingRight() {
        return this.f235h.right;
    }

    public int getContentPaddingTop() {
        return this.f235h.top;
    }

    public float getMaxCardElevation() {
        return ((d) ((a) this.f237j).f238a).f1145e;
    }

    public boolean getPreventCornerOverlap() {
        return this.f232e;
    }

    public float getRadius() {
        return ((d) ((a) this.f237j).f238a).f1141a;
    }

    public boolean getUseCompatPadding() {
        return this.f231d;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
    }

    public void setCardBackgroundColor(int i2) {
        b bVar = this.f237j;
        ColorStateList valueOf = ColorStateList.valueOf(i2);
        d dVar = (d) ((a) bVar).f238a;
        dVar.b(valueOf);
        dVar.invalidateSelf();
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        d dVar = (d) ((a) this.f237j).f238a;
        dVar.b(colorStateList);
        dVar.invalidateSelf();
    }

    public void setCardElevation(float f2) {
        CardView.this.setElevation(f2);
    }

    public void setMaxCardElevation(float f2) {
        ((b.d.c.a) l).b(this.f237j, f2);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i2) {
        this.f234g = i2;
        super.setMinimumHeight(i2);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i2) {
        this.f233f = i2;
        super.setMinimumWidth(i2);
    }

    @Override // android.view.View
    public void setPadding(int i2, int i3, int i4, int i5) {
    }

    @Override // android.view.View
    public void setPaddingRelative(int i2, int i3, int i4, int i5) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.f232e) {
            this.f232e = z;
            c cVar = l;
            b bVar = this.f237j;
            b.d.c.a aVar = (b.d.c.a) cVar;
            aVar.b(bVar, aVar.a(bVar).f1145e);
        }
    }

    public void setRadius(float f2) {
        d dVar = (d) ((a) this.f237j).f238a;
        if (f2 == dVar.f1141a) {
            return;
        }
        dVar.f1141a = f2;
        dVar.c(null);
        dVar.invalidateSelf();
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f231d != z) {
            this.f231d = z;
            c cVar = l;
            b bVar = this.f237j;
            b.d.c.a aVar = (b.d.c.a) cVar;
            aVar.b(bVar, aVar.a(bVar).f1145e);
        }
    }
}
