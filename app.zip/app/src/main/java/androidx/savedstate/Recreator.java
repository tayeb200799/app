package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import b.v.a;
import b.v.c;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@SuppressLint({"RestrictedApi"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\savedstate\Recreator.smali */
public final class Recreator implements i {

    /* renamed from: a, reason: collision with root package name */
    public final c f524a;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\savedstate\Recreator$a.smali */
    public static final class a implements a.b {

        /* renamed from: a, reason: collision with root package name */
        public final Set<String> f525a = new HashSet();

        public a(b.v.a aVar) {
            if (aVar.f2431a.r("androidx.savedstate.Restarter", this) != null) {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
        }

        @Override // b.v.a.b
        public Bundle a() {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("classes_to_restore", new ArrayList<>(this.f525a));
            return bundle;
        }
    }

    public Recreator(c cVar) {
        this.f524a = cVar;
    }

    @Override // b.p.i
    public void d(k kVar, g.a aVar) {
        if (aVar != g.a.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        ((l) kVar.a()).f2129a.s(this);
        Bundle a2 = this.f524a.d().a("androidx.savedstate.Restarter");
        if (a2 == null) {
            return;
        }
        ArrayList<String> stringArrayList = a2.getStringArrayList("classes_to_restore");
        if (stringArrayList == null) {
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        Iterator<String> it = stringArrayList.iterator();
        while (it.hasNext()) {
            String next = it.next();
            try {
                Class<? extends U> asSubclass = Class.forName(next, false, Recreator.class.getClassLoader()).asSubclass(a.InterfaceC0051a.class);
                try {
                    Constructor declaredConstructor = asSubclass.getDeclaredConstructor(new Class[0]);
                    declaredConstructor.setAccessible(true);
                    try {
                        ((a.InterfaceC0051a) declaredConstructor.newInstance(new Object[0])).a(this.f524a);
                    } catch (Exception e2) {
                        throw new RuntimeException(c.a.a.a.a.f("Failed to instantiate ", next), e2);
                    }
                } catch (NoSuchMethodException e3) {
                    StringBuilder n = c.a.a.a.a.n("Class");
                    n.append(asSubclass.getSimpleName());
                    n.append(" must have default constructor in order to be automatically recreated");
                    throw new IllegalStateException(n.toString(), e3);
                }
            } catch (ClassNotFoundException e4) {
                throw new RuntimeException(c.a.a.a.a.g("Class ", next, " wasn't found"), e4);
            }
        }
    }
}
