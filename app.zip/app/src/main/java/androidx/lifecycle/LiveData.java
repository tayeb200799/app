package androidx.lifecycle;

import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import b.p.q;
import java.util.Map;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData.smali */
public abstract class LiveData<T> {

    /* renamed from: j, reason: collision with root package name */
    public static final Object f337j = new Object();

    /* renamed from: a, reason: collision with root package name */
    public final Object f338a = new Object();

    /* renamed from: b, reason: collision with root package name */
    public b.c.a.b.b<q<? super T>, LiveData<T>.b> f339b = new b.c.a.b.b<>();

    /* renamed from: c, reason: collision with root package name */
    public int f340c = 0;

    /* renamed from: d, reason: collision with root package name */
    public volatile Object f341d;

    /* renamed from: e, reason: collision with root package name */
    public volatile Object f342e;

    /* renamed from: f, reason: collision with root package name */
    public int f343f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f344g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f345h;

    /* renamed from: i, reason: collision with root package name */
    public final Runnable f346i;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData$LifecycleBoundObserver.smali */
    public class LifecycleBoundObserver extends LiveData<T>.b implements i {

        /* renamed from: e, reason: collision with root package name */
        public final k f347e;

        public LifecycleBoundObserver(k kVar, q<? super T> qVar) {
            super(qVar);
            this.f347e = kVar;
        }

        @Override // b.p.i
        public void d(k kVar, g.a aVar) {
            if (((l) this.f347e.a()).f2130b == g.b.DESTROYED) {
                LiveData.this.h(this.f350a);
            } else {
                h(k());
            }
        }

        @Override // androidx.lifecycle.LiveData.b
        public void i() {
            ((l) this.f347e.a()).f2129a.s(this);
        }

        @Override // androidx.lifecycle.LiveData.b
        public boolean j(k kVar) {
            return this.f347e == kVar;
        }

        @Override // androidx.lifecycle.LiveData.b
        public boolean k() {
            return ((l) this.f347e.a()).f2130b.compareTo(g.b.STARTED) >= 0;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData$a.smali */
    public class a implements Runnable {
        public a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            synchronized (LiveData.this.f338a) {
                obj = LiveData.this.f342e;
                LiveData.this.f342e = LiveData.f337j;
            }
            LiveData.this.i(obj);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData$b.smali */
    public abstract class b {

        /* renamed from: a, reason: collision with root package name */
        public final q<? super T> f350a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f351b;

        /* renamed from: c, reason: collision with root package name */
        public int f352c = -1;

        public b(q<? super T> qVar) {
            this.f350a = qVar;
        }

        public void h(boolean z) {
            if (z == this.f351b) {
                return;
            }
            this.f351b = z;
            LiveData liveData = LiveData.this;
            int i2 = liveData.f340c;
            boolean z2 = i2 == 0;
            liveData.f340c = i2 + (z ? 1 : -1);
            if (z2 && z) {
                liveData.f();
            }
            LiveData liveData2 = LiveData.this;
            if (liveData2.f340c == 0 && !this.f351b) {
                liveData2.g();
            }
            if (this.f351b) {
                LiveData.this.c(this);
            }
        }

        public void i() {
        }

        public boolean j(k kVar) {
            return false;
        }

        public abstract boolean k();
    }

    public LiveData() {
        Object obj = f337j;
        this.f342e = obj;
        this.f346i = new a();
        this.f341d = obj;
        this.f343f = -1;
    }

    public static void a(String str) {
        if (!b.c.a.a.a.d().f1123a.b()) {
            throw new IllegalStateException(c.a.a.a.a.g("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(LiveData<T>.b bVar) {
        if (bVar.f351b) {
            if (!bVar.k()) {
                bVar.h(false);
                return;
            }
            int i2 = bVar.f352c;
            int i3 = this.f343f;
            if (i2 >= i3) {
                return;
            }
            bVar.f352c = i3;
            bVar.f350a.a((Object) this.f341d);
        }
    }

    public void c(LiveData<T>.b bVar) {
        if (this.f344g) {
            this.f345h = true;
            return;
        }
        this.f344g = true;
        do {
            this.f345h = false;
            if (bVar != null) {
                b(bVar);
                bVar = null;
            } else {
                b.c.a.b.b<q<? super T>, LiveData<T>.b>.d p = this.f339b.p();
                while (p.hasNext()) {
                    b((b) ((Map.Entry) p.next()).getValue());
                    if (this.f345h) {
                        break;
                    }
                }
            }
        } while (this.f345h);
        this.f344g = false;
    }

    public T d() {
        T t = (T) this.f341d;
        if (t != f337j) {
            return t;
        }
        return null;
    }

    public void e(k kVar, q<? super T> qVar) {
        a("observe");
        if (((l) kVar.a()).f2130b == g.b.DESTROYED) {
            return;
        }
        LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(kVar, qVar);
        LiveData<T>.b r = this.f339b.r(qVar, lifecycleBoundObserver);
        if (r != null && !r.j(kVar)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (r != null) {
            return;
        }
        kVar.a().a(lifecycleBoundObserver);
    }

    public void f() {
    }

    public void g() {
    }

    public void h(q<? super T> qVar) {
        a("removeObserver");
        LiveData<T>.b s = this.f339b.s(qVar);
        if (s == null) {
            return;
        }
        s.i();
        s.h(false);
    }

    public abstract void i(T t);
}
