package androidx.lifecycle;

import b.p.b;
import b.p.g;
import b.p.i;
import b.p.k;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\ReflectiveGenericLifecycleObserver.smali */
public class ReflectiveGenericLifecycleObserver implements i {

    /* renamed from: a, reason: collision with root package name */
    public final Object f352a;

    /* renamed from: b, reason: collision with root package name */
    public final b.a f353b;

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f352a = obj;
        this.f353b = b.f2112c.b(obj.getClass());
    }

    @Override // b.p.i
    public void d(k kVar, g.a aVar) {
        b.a aVar2 = this.f353b;
        Object obj = this.f352a;
        b.a.a(aVar2.f2115a.get(aVar), kVar, aVar, obj);
        b.a.a(aVar2.f2115a.get(g.a.ON_ANY), kVar, aVar, obj);
    }
}
