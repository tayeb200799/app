package androidx.lifecycle;

import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import b.p.q;
import java.util.Map;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData.smali */
public abstract class LiveData<T> {

    /* renamed from: j */
    public static final Object f335j = new Object();

    /* renamed from: a */
    public final Object f336a = new Object();

    /* renamed from: b */
    public b.c.a.b.b<q<? super T>, LiveData<T>.b> f337b = new b.c.a.b.b<>();

    /* renamed from: c */
    public int f338c = 0;

    /* renamed from: d */
    public volatile Object f339d;

    /* renamed from: e */
    public volatile Object f340e;

    /* renamed from: f */
    public int f341f;

    /* renamed from: g */
    public boolean f342g;

    /* renamed from: h */
    public boolean f343h;

    /* renamed from: i */
    public final Runnable f344i;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData$LifecycleBoundObserver.smali */
    public class LifecycleBoundObserver extends LiveData<T>.b implements i {

        /* renamed from: e */
        public final k f345e;

        public LifecycleBoundObserver(k kVar, q<? super T> qVar) {
            super(qVar);
            this.f345e = kVar;
        }

        @Override // b.p.i
        public void d(k kVar, g.a aVar) {
            if (((l) this.f345e.a()).f2127b == g.b.DESTROYED) {
                LiveData.this.h(this.f348a);
            } else {
                h(k());
            }
        }

        @Override // androidx.lifecycle.LiveData.b
        public void i() {
            ((l) this.f345e.a()).f2126a.s(this);
        }

        @Override // androidx.lifecycle.LiveData.b
        public boolean j(k kVar) {
            return this.f345e == kVar;
        }

        @Override // androidx.lifecycle.LiveData.b
        public boolean k() {
            return ((l) this.f345e.a()).f2127b.compareTo(g.b.STARTED) >= 0;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData$a.smali */
    public class a implements Runnable {
        public a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            synchronized (LiveData.this.f336a) {
                obj = LiveData.this.f340e;
                LiveData.this.f340e = LiveData.f335j;
            }
            LiveData.this.i(obj);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\LiveData$b.smali */
    public abstract class b {

        /* renamed from: a */
        public final q<? super T> f348a;

        /* renamed from: b */
        public boolean f349b;

        /* renamed from: c */
        public int f350c = -1;

        public b(q<? super T> qVar) {
            this.f348a = qVar;
        }

        public void h(boolean z) {
            if (z == this.f349b) {
                return;
            }
            this.f349b = z;
            LiveData liveData = LiveData.this;
            int i2 = liveData.f338c;
            boolean z2 = i2 == 0;
            liveData.f338c = i2 + (z ? 1 : -1);
            if (z2 && z) {
                liveData.f();
            }
            LiveData liveData2 = LiveData.this;
            if (liveData2.f338c == 0 && !this.f349b) {
                liveData2.g();
            }
            if (this.f349b) {
                LiveData.this.c(this);
            }
        }

        public void i() {
        }

        public boolean j(k kVar) {
            return false;
        }

        public abstract boolean k();
    }

    public LiveData() {
        Object obj = f335j;
        this.f340e = obj;
        this.f344i = new a();
        this.f339d = obj;
        this.f341f = -1;
    }

    public static void a(String str) {
        if (!b.c.a.a.a.d().f1120a.b()) {
            throw new IllegalStateException(c.a.a.a.a.g("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(LiveData<T>.b bVar) {
        if (bVar.f349b) {
            if (!bVar.k()) {
                bVar.h(false);
                return;
            }
            int i2 = bVar.f350c;
            int i3 = this.f341f;
            if (i2 >= i3) {
                return;
            }
            bVar.f350c = i3;
            bVar.f348a.a((Object) this.f339d);
        }
    }

    public void c(LiveData<T>.b bVar) {
        if (this.f342g) {
            this.f343h = true;
            return;
        }
        this.f342g = true;
        do {
            this.f343h = false;
            if (bVar != null) {
                b(bVar);
                bVar = null;
            } else {
                b.c.a.b.b<q<? super T>, LiveData<T>.b>.d p = this.f337b.p();
                while (p.hasNext()) {
                    b((b) ((Map.Entry) p.next()).getValue());
                    if (this.f343h) {
                        break;
                    }
                }
            }
        } while (this.f343h);
        this.f342g = false;
    }

    public T d() {
        T t = (T) this.f339d;
        if (t != f335j) {
            return t;
        }
        return null;
    }

    public void e(k kVar, q<? super T> qVar) {
        a("observe");
        if (((l) kVar.a()).f2127b == g.b.DESTROYED) {
            return;
        }
        LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(kVar, qVar);
        LiveData<T>.b r = this.f337b.r(qVar, lifecycleBoundObserver);
        if (r != null && !r.j(kVar)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (r != null) {
            return;
        }
        kVar.a().a(lifecycleBoundObserver);
    }

    public void f() {
    }

    public void g() {
    }

    public void h(q<? super T> qVar) {
        a("removeObserver");
        LiveData<T>.b s = this.f337b.s(qVar);
        if (s == null) {
            return;
        }
        s.i();
        s.h(false);
    }

    public abstract void i(T t);
}
