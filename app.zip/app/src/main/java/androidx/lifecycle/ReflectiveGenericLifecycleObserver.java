package androidx.lifecycle;

import b.p.a0;
import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import b.p.v;
import b.p.x;
import b.p.z;
import b.v.a;
import b.v.c;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\SavedStateHandleController.smali */
public final class SavedStateHandleController implements i {

    /* renamed from: a, reason: collision with root package name */
    public final String f354a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f355b = false;

    /* renamed from: c, reason: collision with root package name */
    public final v f356c;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\SavedStateHandleController$a.smali */
    public static final class a implements a.InterfaceC0051a {
        @Override // b.v.a.InterfaceC0051a
        public void a(c cVar) {
            if (!(cVar instanceof a0)) {
                throw new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
            }
            z q = ((a0) cVar).q();
            b.v.a d2 = cVar.d();
            Objects.requireNonNull(q);
            Iterator it = new HashSet(q.f2165a.keySet()).iterator();
            while (it.hasNext()) {
                SavedStateHandleController.h(q.f2165a.get((String) it.next()), d2, cVar.a());
            }
            if (new HashSet(q.f2165a.keySet()).isEmpty()) {
                return;
            }
            d2.b(a.class);
        }
    }

    public SavedStateHandleController(String str, v vVar) {
        this.f354a = str;
        this.f356c = vVar;
    }

    public static void h(x xVar, b.v.a aVar, g gVar) {
        Object obj;
        Map<String, Object> map = xVar.f2159a;
        if (map == null) {
            obj = null;
        } else {
            synchronized (map) {
                obj = xVar.f2159a.get("androidx.lifecycle.savedstate.vm.tag");
            }
        }
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) obj;
        if (savedStateHandleController == null || savedStateHandleController.f355b) {
            return;
        }
        savedStateHandleController.i(aVar, gVar);
        j(aVar, gVar);
    }

    public static void j(final b.v.a aVar, final g gVar) {
        g.b bVar = ((l) gVar).f2127b;
        if (bVar != g.b.INITIALIZED) {
            if (!(bVar.compareTo(g.b.STARTED) >= 0)) {
                gVar.a(new i() { // from class: androidx.lifecycle.SavedStateHandleController.1
                    @Override // b.p.i
                    public void d(k kVar, g.a aVar2) {
                        if (aVar2 == g.a.ON_START) {
                            ((l) g.this).f2126a.s(this);
                            aVar.b(a.class);
                        }
                    }
                });
                return;
            }
        }
        aVar.b(a.class);
    }

    @Override // b.p.i
    public void d(k kVar, g.a aVar) {
        if (aVar == g.a.ON_DESTROY) {
            this.f355b = false;
            ((l) kVar.a()).f2126a.s(this);
        }
    }

    public void i(b.v.a aVar, g gVar) {
        if (this.f355b) {
            throw new IllegalStateException("Already attached to lifecycleOwner");
        }
        this.f355b = true;
        gVar.a(this);
        if (aVar.f2426a.r(this.f354a, this.f356c.f2150b) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
        }
    }
}
