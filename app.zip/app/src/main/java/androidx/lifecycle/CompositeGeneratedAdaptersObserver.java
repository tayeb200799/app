package androidx.lifecycle;

import b.p.d;
import b.p.g;
import b.p.i;
import b.p.k;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\FullLifecycleObserverAdapter.smali */
public class FullLifecycleObserverAdapter implements i {

    /* renamed from: a, reason: collision with root package name */
    public final d f333a;

    /* renamed from: b, reason: collision with root package name */
    public final i f334b;

    public FullLifecycleObserverAdapter(d dVar, i iVar) {
        this.f333a = dVar;
        this.f334b = iVar;
    }

    @Override // b.p.i
    public void d(k kVar, g.a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                this.f333a.c(kVar);
                break;
            case 1:
                this.f333a.f(kVar);
                break;
            case 2:
                this.f333a.a(kVar);
                break;
            case ModuleDescriptor.MODULE_VERSION /* 3 */:
                this.f333a.e(kVar);
                break;
            case 4:
                this.f333a.g(kVar);
                break;
            case 5:
                this.f333a.b(kVar);
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        i iVar = this.f334b;
        if (iVar != null) {
            iVar.d(kVar, aVar);
        }
    }
}
