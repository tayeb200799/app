package androidx.media;

import android.util.SparseIntArray;
import b.a0.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesCompat.smali */
public class AudioAttributesCompat implements d {

    /* renamed from: b, reason: collision with root package name */
    public static final SparseIntArray f360b;

    /* renamed from: a, reason: collision with root package name */
    public AudioAttributesImpl f361a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f360b = sparseIntArray;
        sparseIntArray.put(5, 1);
        sparseIntArray.put(6, 2);
        sparseIntArray.put(7, 2);
        sparseIntArray.put(8, 1);
        sparseIntArray.put(9, 1);
        sparseIntArray.put(10, 1);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesCompat)) {
            return false;
        }
        AudioAttributesCompat audioAttributesCompat = (AudioAttributesCompat) obj;
        AudioAttributesImpl audioAttributesImpl = this.f361a;
        return audioAttributesImpl == null ? audioAttributesCompat.f361a == null : audioAttributesImpl.equals(audioAttributesCompat.f361a);
    }

    public int hashCode() {
        return this.f361a.hashCode();
    }

    public String toString() {
        return this.f361a.toString();
    }
}
