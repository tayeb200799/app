package androidx.lifecycle;

import b.p.g;
import b.p.i;
import b.p.k;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\lifecycle\Lifecycling$1.smali */
public final class Lifecycling$1 implements i {
    @Override // b.p.i
    public void d(k kVar, g.a aVar) {
        throw null;
    }
}
