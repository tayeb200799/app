package b.a;

import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\b\a\b.smali */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public boolean f566a;

    /* renamed from: b, reason: collision with root package name */
    public CopyOnWriteArrayList<a> f567b = new CopyOnWriteArrayList<>();

    public b(boolean z) {
        this.f566a = z;
    }

    public abstract void a();
}
