package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import c.a.a.a.a;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\core\graphics\drawable\IconCompat.smali */
public class IconCompat extends CustomVersionedParcelable {
    public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;

    /* renamed from: a, reason: collision with root package name */
    public int f293a;

    /* renamed from: b, reason: collision with root package name */
    public Object f294b;

    /* renamed from: c, reason: collision with root package name */
    public byte[] f295c;

    /* renamed from: d, reason: collision with root package name */
    public Parcelable f296d;

    /* renamed from: e, reason: collision with root package name */
    public int f297e;

    /* renamed from: f, reason: collision with root package name */
    public int f298f;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f299g;

    /* renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f300h;

    /* renamed from: i, reason: collision with root package name */
    public String f301i;

    /* renamed from: j, reason: collision with root package name */
    public String f302j;

    public IconCompat() {
        this.f293a = -1;
        this.f295c = null;
        this.f296d = null;
        this.f297e = 0;
        this.f298f = 0;
        this.f299g = null;
        this.f300h = k;
        this.f301i = null;
    }

    public IconCompat(int i2) {
        this.f293a = -1;
        this.f295c = null;
        this.f296d = null;
        this.f297e = 0;
        this.f298f = 0;
        this.f299g = null;
        this.f300h = k;
        this.f301i = null;
        this.f293a = i2;
    }

    public static Bitmap a(Bitmap bitmap, boolean z) {
        int min = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(3);
        float f2 = min;
        float f3 = 0.5f * f2;
        float f4 = 0.9166667f * f3;
        if (z) {
            float f5 = 0.010416667f * f2;
            paint.setColor(0);
            paint.setShadowLayer(f5, 0.0f, f2 * 0.020833334f, 1023410176);
            canvas.drawCircle(f3, f3, f4, paint);
            paint.setShadowLayer(f5, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f3, f3, f4, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((-(bitmap.getWidth() - min)) / 2, (-(bitmap.getHeight() - min)) / 2);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f3, f3, f4, paint);
        canvas.setBitmap(null);
        return createBitmap;
    }

    public static IconCompat b(Resources resources, String str, int i2) {
        if (str == null) {
            throw new IllegalArgumentException("Package must not be null.");
        }
        if (i2 == 0) {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f297e = i2;
        if (resources != null) {
            try {
                iconCompat.f294b = resources.getResourceName(i2);
            } catch (Resources.NotFoundException unused) {
                throw new IllegalArgumentException("Icon resource cannot be found");
            }
        } else {
            iconCompat.f294b = str;
        }
        iconCompat.f302j = str;
        return iconCompat;
    }

    public static Resources e(Context context, String str) {
        if ("android".equals(str)) {
            return Resources.getSystem();
        }
        PackageManager packageManager = context.getPackageManager();
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(str, 8192);
            if (applicationInfo != null) {
                return packageManager.getResourcesForApplication(applicationInfo);
            }
            return null;
        } catch (PackageManager.NameNotFoundException e2) {
            Log.e("IconCompat", String.format("Unable to find pkg=%s for icon", str), e2);
            return null;
        }
    }

    public int c() {
        int i2;
        int i3 = this.f293a;
        if (i3 != -1 || (i2 = Build.VERSION.SDK_INT) < 23) {
            if (i3 == 2) {
                return this.f297e;
            }
            throw new IllegalStateException("called getResId() on " + this);
        }
        Icon icon = (Icon) this.f294b;
        if (i2 >= 28) {
            return icon.getResId();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon resource", e2);
            return 0;
        } catch (NoSuchMethodException e3) {
            Log.e("IconCompat", "Unable to get icon resource", e3);
            return 0;
        } catch (InvocationTargetException e4) {
            Log.e("IconCompat", "Unable to get icon resource", e4);
            return 0;
        }
    }

    public String d() {
        int i2;
        int i3 = this.f293a;
        if (i3 != -1 || (i2 = Build.VERSION.SDK_INT) < 23) {
            if (i3 == 2) {
                return TextUtils.isEmpty(this.f302j) ? ((String) this.f294b).split(":", -1)[0] : this.f302j;
            }
            throw new IllegalStateException("called getResPackage() on " + this);
        }
        Icon icon = (Icon) this.f294b;
        if (i2 >= 28) {
            return icon.getResPackage();
        }
        try {
            return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon package", e2);
            return null;
        } catch (NoSuchMethodException e3) {
            Log.e("IconCompat", "Unable to get icon package", e3);
            return null;
        } catch (InvocationTargetException e4) {
            Log.e("IconCompat", "Unable to get icon package", e4);
            return null;
        }
    }

    public int f() {
        int i2;
        int i3 = this.f293a;
        if (i3 != -1 || (i2 = Build.VERSION.SDK_INT) < 23) {
            return i3;
        }
        Icon icon = (Icon) this.f294b;
        if (i2 >= 28) {
            return icon.getType();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon type " + icon, e2);
            return -1;
        } catch (NoSuchMethodException e3) {
            Log.e("IconCompat", "Unable to get icon type " + icon, e3);
            return -1;
        } catch (InvocationTargetException e4) {
            Log.e("IconCompat", "Unable to get icon type " + icon, e4);
            return -1;
        }
    }

    public Uri g() {
        int i2;
        int i3 = this.f293a;
        if (i3 != -1 || (i2 = Build.VERSION.SDK_INT) < 23) {
            if (i3 == 4 || i3 == 6) {
                return Uri.parse((String) this.f294b);
            }
            throw new IllegalStateException("called getUri() on " + this);
        }
        Icon icon = (Icon) this.f294b;
        if (i2 >= 28) {
            return icon.getUri();
        }
        try {
            return (Uri) icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon uri", e2);
            return null;
        } catch (NoSuchMethodException e3) {
            Log.e("IconCompat", "Unable to get icon uri", e3);
            return null;
        } catch (InvocationTargetException e4) {
            Log.e("IconCompat", "Unable to get icon uri", e4);
            return null;
        }
    }

    public InputStream h(Context context) {
        Uri g2 = g();
        String scheme = g2.getScheme();
        if ("content".equals(scheme) || "file".equals(scheme)) {
            try {
                return context.getContentResolver().openInputStream(g2);
            } catch (Exception e2) {
                Log.w("IconCompat", "Unable to load image from URI: " + g2, e2);
                return null;
            }
        }
        try {
            return new FileInputStream(new File((String) this.f294b));
        } catch (FileNotFoundException e3) {
            Log.w("IconCompat", "Unable to load image from path: " + g2, e3);
            return null;
        }
    }

    @Deprecated
    public Icon i() {
        return j(null);
    }

    public Icon j(Context context) {
        Icon createWithBitmap;
        int i2 = Build.VERSION.SDK_INT;
        switch (this.f293a) {
            case -1:
                return (Icon) this.f294b;
            case 0:
            default:
                throw new IllegalArgumentException("Unknown type");
            case 1:
                createWithBitmap = Icon.createWithBitmap((Bitmap) this.f294b);
                break;
            case 2:
                createWithBitmap = Icon.createWithResource(d(), this.f297e);
                break;
            case ModuleDescriptor.MODULE_VERSION /* 3 */:
                createWithBitmap = Icon.createWithData((byte[]) this.f294b, this.f297e, this.f298f);
                break;
            case 4:
                createWithBitmap = Icon.createWithContentUri((String) this.f294b);
                break;
            case 5:
                if (i2 < 26) {
                    createWithBitmap = Icon.createWithBitmap(a((Bitmap) this.f294b, false));
                    break;
                } else {
                    createWithBitmap = Icon.createWithAdaptiveBitmap((Bitmap) this.f294b);
                    break;
                }
            case 6:
                if (i2 >= 30) {
                    createWithBitmap = Icon.createWithAdaptiveBitmapContentUri(g());
                    break;
                } else {
                    if (context == null) {
                        StringBuilder n = a.n("Context is required to resolve the file uri of the icon: ");
                        n.append(g());
                        throw new IllegalArgumentException(n.toString());
                    }
                    InputStream h2 = h(context);
                    if (h2 == null) {
                        StringBuilder n2 = a.n("Cannot load adaptive icon from uri: ");
                        n2.append(g());
                        throw new IllegalStateException(n2.toString());
                    }
                    if (i2 < 26) {
                        createWithBitmap = Icon.createWithBitmap(a(BitmapFactory.decodeStream(h2), false));
                        break;
                    } else {
                        createWithBitmap = Icon.createWithAdaptiveBitmap(BitmapFactory.decodeStream(h2));
                        break;
                    }
                }
        }
        ColorStateList colorStateList = this.f299g;
        if (colorStateList != null) {
            createWithBitmap.setTintList(colorStateList);
        }
        PorterDuff.Mode mode = this.f300h;
        if (mode != k) {
            createWithBitmap.setTintMode(mode);
        }
        return createWithBitmap;
    }

    public String toString() {
        String str;
        if (this.f293a == -1) {
            return String.valueOf(this.f294b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f293a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case ModuleDescriptor.MODULE_VERSION /* 3 */:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f293a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f294b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f294b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f302j);
                sb.append(" id=");
                sb.append(String.format("0x%08x", Integer.valueOf(c())));
                break;
            case ModuleDescriptor.MODULE_VERSION /* 3 */:
                sb.append(" len=");
                sb.append(this.f297e);
                if (this.f298f != 0) {
                    sb.append(" off=");
                    sb.append(this.f298f);
                    break;
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f294b);
                break;
        }
        if (this.f299g != null) {
            sb.append(" tint=");
            sb.append(this.f299g);
        }
        if (this.f300h != k) {
            sb.append(" mode=");
            sb.append(this.f300h);
        }
        sb.append(")");
        return sb.toString();
    }
}
