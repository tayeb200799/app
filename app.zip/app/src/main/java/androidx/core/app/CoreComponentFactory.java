package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import b.a0.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\core\app\RemoteActionCompat.smali */
public final class RemoteActionCompat implements d {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f287a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f288b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f289c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f290d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f291e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f292f;
}
