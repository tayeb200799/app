package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import b.a0.b;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\core\app\RemoteActionCompatParcelizer.smali */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(b bVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f289a;
        if (bVar.i(1)) {
            obj = bVar.o();
        }
        remoteActionCompat.f289a = (IconCompat) obj;
        CharSequence charSequence = remoteActionCompat.f290b;
        if (bVar.i(2)) {
            charSequence = bVar.h();
        }
        remoteActionCompat.f290b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f291c;
        if (bVar.i(3)) {
            charSequence2 = bVar.h();
        }
        remoteActionCompat.f291c = charSequence2;
        remoteActionCompat.f292d = (PendingIntent) bVar.m(remoteActionCompat.f292d, 4);
        boolean z = remoteActionCompat.f293e;
        if (bVar.i(5)) {
            z = bVar.f();
        }
        remoteActionCompat.f293e = z;
        boolean z2 = remoteActionCompat.f294f;
        if (bVar.i(6)) {
            z2 = bVar.f();
        }
        remoteActionCompat.f294f = z2;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, b bVar) {
        Objects.requireNonNull(bVar);
        IconCompat iconCompat = remoteActionCompat.f289a;
        bVar.p(1);
        bVar.w(iconCompat);
        CharSequence charSequence = remoteActionCompat.f290b;
        bVar.p(2);
        bVar.s(charSequence);
        CharSequence charSequence2 = remoteActionCompat.f291c;
        bVar.p(3);
        bVar.s(charSequence2);
        PendingIntent pendingIntent = remoteActionCompat.f292d;
        bVar.p(4);
        bVar.u(pendingIntent);
        boolean z = remoteActionCompat.f293e;
        bVar.p(5);
        bVar.q(z);
        boolean z2 = remoteActionCompat.f294f;
        bVar.p(6);
        bVar.q(z2);
    }
}
