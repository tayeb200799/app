package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.recyclerview.widget.LinearLayoutManager;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\LinearLayoutManager$d$a.smali */
public class LinearLayoutManager$d$a implements Parcelable.Creator<LinearLayoutManager.d> {
    @Override // android.os.Parcelable.Creator
    public LinearLayoutManager.d createFromParcel(Parcel parcel) {
        return new LinearLayoutManager.d(parcel);
    }

    @Override // android.os.Parcelable.Creator
    public LinearLayoutManager.d[] newArray(int i2) {
        return new LinearLayoutManager.d[i2];
    }
}
