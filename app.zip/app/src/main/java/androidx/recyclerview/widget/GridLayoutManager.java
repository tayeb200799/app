package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b.h.k.y.b;
import b.t.b.n;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\GridLayoutManager.smali */
public class GridLayoutManager extends LinearLayoutManager {
    public boolean G;
    public int H;
    public int[] I;
    public View[] J;
    public final SparseIntArray K;
    public final SparseIntArray L;
    public c M;
    public final Rect N;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\GridLayoutManager$a.smali */
    public static final class a extends c {
        @Override // androidx.recyclerview.widget.GridLayoutManager.c
        public int b(int i2, int i3) {
            return i2 % i3;
        }

        @Override // androidx.recyclerview.widget.GridLayoutManager.c
        public int c(int i2) {
            return 1;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\GridLayoutManager$b.smali */
    public static class b extends RecyclerView.n {

        /* renamed from: e, reason: collision with root package name */
        public int f369e;

        /* renamed from: f, reason: collision with root package name */
        public int f370f;

        public b(int i2, int i3) {
            super(i2, i3);
            this.f369e = -1;
            this.f370f = 0;
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f369e = -1;
            this.f370f = 0;
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f369e = -1;
            this.f370f = 0;
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f369e = -1;
            this.f370f = 0;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\GridLayoutManager$c.smali */
    public static abstract class c {

        /* renamed from: a, reason: collision with root package name */
        public final SparseIntArray f371a = new SparseIntArray();

        /* renamed from: b, reason: collision with root package name */
        public final SparseIntArray f372b = new SparseIntArray();

        public int a(int i2, int i3) {
            int c2 = c(i2);
            int i4 = 0;
            int i5 = 0;
            for (int i6 = 0; i6 < i2; i6++) {
                int c3 = c(i6);
                i4 += c3;
                if (i4 == i3) {
                    i5++;
                    i4 = 0;
                } else if (i4 > i3) {
                    i5++;
                    i4 = c3;
                }
            }
            return i4 + c2 > i3 ? i5 + 1 : i5;
        }

        public int b(int i2, int i3) {
            int c2 = c(i2);
            if (c2 == i3) {
                return 0;
            }
            int i4 = 0;
            for (int i5 = 0; i5 < i2; i5++) {
                int c3 = c(i5);
                i4 += c3;
                if (i4 == i3) {
                    i4 = 0;
                } else if (i4 > i3) {
                    i4 = c3;
                }
            }
            if (c2 + i4 <= i3) {
                return i4;
            }
            return 0;
        }

        public abstract int c(int i2);
    }

    public GridLayoutManager(Context context, int i2) {
        super(1, false);
        this.G = false;
        this.H = -1;
        this.K = new SparseIntArray();
        this.L = new SparseIntArray();
        this.M = new a();
        this.N = new Rect();
        M1(i2);
    }

    public GridLayoutManager(Context context, int i2, int i3, boolean z) {
        super(i3, z);
        this.G = false;
        this.H = -1;
        this.K = new SparseIntArray();
        this.L = new SparseIntArray();
        this.M = new a();
        this.N = new Rect();
        M1(i2);
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.G = false;
        this.H = -1;
        this.K = new SparseIntArray();
        this.L = new SparseIntArray();
        this.M = new a();
        this.N = new Rect();
        M1(RecyclerView.m.R(context, attributeSet, i2, i3).f434b);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int A(RecyclerView.s sVar, RecyclerView.x xVar) {
        if (this.r == 1) {
            return this.H;
        }
        if (xVar.b() < 1) {
            return 0;
        }
        return H1(sVar, xVar, xVar.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void A1(boolean z) {
        if (z) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        d(null);
        if (this.x) {
            this.x = false;
            J0();
        }
    }

    public final void E1(int i2) {
        int i3;
        int[] iArr = this.I;
        int i4 = this.H;
        if (iArr == null || iArr.length != i4 + 1 || iArr[iArr.length - 1] != i2) {
            iArr = new int[i4 + 1];
        }
        int i5 = 0;
        iArr[0] = 0;
        int i6 = i2 / i4;
        int i7 = i2 % i4;
        int i8 = 0;
        for (int i9 = 1; i9 <= i4; i9++) {
            i5 += i7;
            if (i5 <= 0 || i4 - i5 >= i7) {
                i3 = i6;
            } else {
                i3 = i6 + 1;
                i5 -= i4;
            }
            i8 += i3;
            iArr[i9] = i8;
        }
        this.I = iArr;
    }

    public final void F1() {
        View[] viewArr = this.J;
        if (viewArr == null || viewArr.length != this.H) {
            this.J = new View[this.H];
        }
    }

    public int G1(int i2, int i3) {
        if (this.r != 1 || !r1()) {
            int[] iArr = this.I;
            return iArr[i3 + i2] - iArr[i2];
        }
        int[] iArr2 = this.I;
        int i4 = this.H;
        return iArr2[i4 - i2] - iArr2[(i4 - i2) - i3];
    }

    public final int H1(RecyclerView.s sVar, RecyclerView.x xVar, int i2) {
        if (!xVar.f478g) {
            return this.M.a(i2, this.H);
        }
        int c2 = sVar.c(i2);
        if (c2 != -1) {
            return this.M.a(c2, this.H);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i2);
        return 0;
    }

    public final int I1(RecyclerView.s sVar, RecyclerView.x xVar, int i2) {
        if (!xVar.f478g) {
            return this.M.b(i2, this.H);
        }
        int i3 = this.L.get(i2, -1);
        if (i3 != -1) {
            return i3;
        }
        int c2 = sVar.c(i2);
        if (c2 != -1) {
            return this.M.b(c2, this.H);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i2);
        return 0;
    }

    public final int J1(RecyclerView.s sVar, RecyclerView.x xVar, int i2) {
        if (!xVar.f478g) {
            return this.M.c(i2);
        }
        int i3 = this.K.get(i2, -1);
        if (i3 != -1) {
            return i3;
        }
        int c2 = sVar.c(i2);
        if (c2 != -1) {
            return this.M.c(c2);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i2);
        return 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public int K0(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        N1();
        F1();
        if (this.r == 1) {
            return 0;
        }
        return y1(i2, sVar, xVar);
    }

    public final void K1(View view, int i2, boolean z) {
        int i3;
        int i4;
        b bVar = (b) view.getLayoutParams();
        Rect rect = bVar.f438b;
        int i5 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) bVar).topMargin + ((ViewGroup.MarginLayoutParams) bVar).bottomMargin;
        int i6 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) bVar).leftMargin + ((ViewGroup.MarginLayoutParams) bVar).rightMargin;
        int G1 = G1(bVar.f369e, bVar.f370f);
        if (this.r == 1) {
            i4 = RecyclerView.m.z(G1, i2, i6, ((ViewGroup.MarginLayoutParams) bVar).width, false);
            i3 = RecyclerView.m.z(this.t.l(), this.o, i5, ((ViewGroup.MarginLayoutParams) bVar).height, true);
        } else {
            int z2 = RecyclerView.m.z(G1, i2, i5, ((ViewGroup.MarginLayoutParams) bVar).height, false);
            int z3 = RecyclerView.m.z(this.t.l(), this.n, i6, ((ViewGroup.MarginLayoutParams) bVar).width, true);
            i3 = z2;
            i4 = z3;
        }
        L1(view, i4, i3, z);
    }

    public final void L1(View view, int i2, int i3, boolean z) {
        RecyclerView.n nVar = (RecyclerView.n) view.getLayoutParams();
        if (z ? U0(view, i2, i3, nVar) : S0(view, i2, i3, nVar)) {
            view.measure(i2, i3);
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public int M0(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        N1();
        F1();
        if (this.r == 0) {
            return 0;
        }
        return y1(i2, sVar, xVar);
    }

    public void M1(int i2) {
        if (i2 == this.H) {
            return;
        }
        this.G = true;
        if (i2 < 1) {
            throw new IllegalArgumentException(c.a.a.a.a.c("Span count should be at least 1. Provided ", i2));
        }
        this.H = i2;
        this.M.f371a.clear();
        J0();
    }

    public final void N1() {
        int M;
        int P;
        if (this.r == 1) {
            M = this.p - O();
            P = N();
        } else {
            M = this.q - M();
            P = P();
        }
        E1(M - P);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void P0(Rect rect, int i2, int i3) {
        int h2;
        int h3;
        if (this.I == null) {
            super.P0(rect, i2, i3);
        }
        int O = O() + N();
        int M = M() + P();
        if (this.r == 1) {
            h3 = RecyclerView.m.h(i3, rect.height() + M, K());
            int[] iArr = this.I;
            h2 = RecyclerView.m.h(i2, iArr[iArr.length - 1] + O, L());
        } else {
            h2 = RecyclerView.m.h(i2, rect.width() + O, L());
            int[] iArr2 = this.I;
            h3 = RecyclerView.m.h(i3, iArr2[iArr2.length - 1] + M, K());
        }
        this.f422b.setMeasuredDimension(h2, h3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int S(RecyclerView.s sVar, RecyclerView.x xVar) {
        if (this.r == 0) {
            return this.H;
        }
        if (xVar.b() < 1) {
            return 0;
        }
        return H1(sVar, xVar, xVar.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public boolean X0() {
        return this.B == null && !this.G;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void Z0(RecyclerView.x xVar, LinearLayoutManager.c cVar, RecyclerView.m.c cVar2) {
        int i2 = this.H;
        for (int i3 = 0; i3 < this.H && cVar.b(xVar) && i2 > 0; i3++) {
            int i4 = cVar.f385d;
            ((n.b) cVar2).a(i4, Math.max(0, cVar.f388g));
            i2 -= this.M.c(i4);
            cVar.f385d += cVar.f386e;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean g(RecyclerView.n nVar) {
        return nVar instanceof b;
    }

    /* JADX WARN: Code restructure failed: missing block: B:67:0x00ca, code lost:
    
        if (r13 == (r2 > r15)) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x00e6, code lost:
    
        if (r13 == (r2 > r8)) goto L69;
     */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00f0  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View h0(android.view.View r23, int r24, androidx.recyclerview.widget.RecyclerView.s r25, androidx.recyclerview.widget.RecyclerView.x r26) {
        /*
            Method dump skipped, instructions count: 304
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.h0(android.view.View, int, androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$x):android.view.View");
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public int l(RecyclerView.x xVar) {
        return b1(xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void l0(RecyclerView.s sVar, RecyclerView.x xVar, View view, b.h.k.y.b bVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof b)) {
            k0(view, bVar);
            return;
        }
        b bVar2 = (b) layoutParams;
        int H1 = H1(sVar, xVar, bVar2.a());
        if (this.r == 0) {
            bVar.j(b.c.a(bVar2.f369e, bVar2.f370f, H1, 1, false, false));
        } else {
            bVar.j(b.c.a(H1, 1, bVar2.f369e, bVar2.f370f, false, false));
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public int m(RecyclerView.x xVar) {
        return c1(xVar);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public View m1(RecyclerView.s sVar, RecyclerView.x xVar, boolean z, boolean z2) {
        int i2;
        int y = y();
        int i3 = -1;
        int i4 = 1;
        if (z2) {
            i2 = y() - 1;
            i4 = -1;
        } else {
            i3 = y;
            i2 = 0;
        }
        int b2 = xVar.b();
        e1();
        int k = this.t.k();
        int g2 = this.t.g();
        View view = null;
        View view2 = null;
        while (i2 != i3) {
            View x = x(i2);
            int Q = Q(x);
            if (Q >= 0 && Q < b2 && I1(sVar, xVar, Q) == 0) {
                if (((RecyclerView.n) x.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = x;
                    }
                } else {
                    if (this.t.e(x) < g2 && this.t.b(x) >= k) {
                        return x;
                    }
                    if (view == null) {
                        view = x;
                    }
                }
            }
            i2 += i4;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void n0(RecyclerView recyclerView, int i2, int i3) {
        this.M.f371a.clear();
        this.M.f372b.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public int o(RecyclerView.x xVar) {
        return b1(xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void o0(RecyclerView recyclerView) {
        this.M.f371a.clear();
        this.M.f372b.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public int p(RecyclerView.x xVar) {
        return c1(xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void p0(RecyclerView recyclerView, int i2, int i3, int i4) {
        this.M.f371a.clear();
        this.M.f372b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void q0(RecyclerView recyclerView, int i2, int i3) {
        this.M.f371a.clear();
        this.M.f372b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void s0(RecyclerView recyclerView, int i2, int i3, Object obj) {
        this.M.f371a.clear();
        this.M.f372b.clear();
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x009f, code lost:
    
        r22.f379b = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00a1, code lost:
    
        return;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void s1(androidx.recyclerview.widget.RecyclerView.s r19, androidx.recyclerview.widget.RecyclerView.x r20, androidx.recyclerview.widget.LinearLayoutManager.c r21, androidx.recyclerview.widget.LinearLayoutManager.b r22) {
        /*
            Method dump skipped, instructions count: 630
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.s1(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$x, androidx.recyclerview.widget.LinearLayoutManager$c, androidx.recyclerview.widget.LinearLayoutManager$b):void");
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public void t0(RecyclerView.s sVar, RecyclerView.x xVar) {
        if (xVar.f478g) {
            int y = y();
            for (int i2 = 0; i2 < y; i2++) {
                b bVar = (b) x(i2).getLayoutParams();
                int a2 = bVar.a();
                this.K.put(a2, bVar.f370f);
                this.L.put(a2, bVar.f369e);
            }
        }
        super.t0(sVar, xVar);
        this.K.clear();
        this.L.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void t1(RecyclerView.s sVar, RecyclerView.x xVar, LinearLayoutManager.a aVar, int i2) {
        N1();
        if (xVar.b() > 0 && !xVar.f478g) {
            boolean z = i2 == 1;
            int I1 = I1(sVar, xVar, aVar.f374b);
            if (z) {
                while (I1 > 0) {
                    int i3 = aVar.f374b;
                    if (i3 <= 0) {
                        break;
                    }
                    int i4 = i3 - 1;
                    aVar.f374b = i4;
                    I1 = I1(sVar, xVar, i4);
                }
            } else {
                int b2 = xVar.b() - 1;
                int i5 = aVar.f374b;
                while (i5 < b2) {
                    int i6 = i5 + 1;
                    int I12 = I1(sVar, xVar, i6);
                    if (I12 <= I1) {
                        break;
                    }
                    i5 = i6;
                    I1 = I12;
                }
                aVar.f374b = i5;
            }
        }
        F1();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n u() {
        return this.r == 0 ? new b(-2, -1) : new b(-1, -2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.m
    public void u0(RecyclerView.x xVar) {
        this.B = null;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.C.d();
        this.G = false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n v(Context context, AttributeSet attributeSet) {
        return new b(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n w(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new b((ViewGroup.MarginLayoutParams) layoutParams) : new b(layoutParams);
    }
}
