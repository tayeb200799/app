package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import b.t.b.n;
import b.t.b.p;
import b.t.b.t;
import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\LinearLayoutManager.smali */
public class LinearLayoutManager extends RecyclerView.m implements RecyclerView.w.b {
    public int A;
    public d B;
    public final a C;
    public final b D;
    public int E;
    public int[] F;
    public int r;
    public c s;
    public t t;
    public boolean u;
    public boolean v;
    public boolean w;
    public boolean x;
    public boolean y;
    public int z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\LinearLayoutManager$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public t f373a;

        /* renamed from: b, reason: collision with root package name */
        public int f374b;

        /* renamed from: c, reason: collision with root package name */
        public int f375c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f376d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f377e;

        public a() {
            d();
        }

        public void a() {
            this.f375c = this.f376d ? this.f373a.g() : this.f373a.k();
        }

        public void b(View view, int i2) {
            if (this.f376d) {
                this.f375c = this.f373a.m() + this.f373a.b(view);
            } else {
                this.f375c = this.f373a.e(view);
            }
            this.f374b = i2;
        }

        public void c(View view, int i2) {
            int m = this.f373a.m();
            if (m >= 0) {
                b(view, i2);
                return;
            }
            this.f374b = i2;
            if (!this.f376d) {
                int e2 = this.f373a.e(view);
                int k = e2 - this.f373a.k();
                this.f375c = e2;
                if (k > 0) {
                    int g2 = (this.f373a.g() - Math.min(0, (this.f373a.g() - m) - this.f373a.b(view))) - (this.f373a.c(view) + e2);
                    if (g2 < 0) {
                        this.f375c -= Math.min(k, -g2);
                        return;
                    }
                    return;
                }
                return;
            }
            int g3 = (this.f373a.g() - m) - this.f373a.b(view);
            this.f375c = this.f373a.g() - g3;
            if (g3 > 0) {
                int c2 = this.f375c - this.f373a.c(view);
                int k2 = this.f373a.k();
                int min = c2 - (Math.min(this.f373a.e(view) - k2, 0) + k2);
                if (min < 0) {
                    this.f375c = Math.min(g3, -min) + this.f375c;
                }
            }
        }

        public void d() {
            this.f374b = -1;
            this.f375c = Integer.MIN_VALUE;
            this.f376d = false;
            this.f377e = false;
        }

        public String toString() {
            StringBuilder n = c.a.a.a.a.n("AnchorInfo{mPosition=");
            n.append(this.f374b);
            n.append(", mCoordinate=");
            n.append(this.f375c);
            n.append(", mLayoutFromEnd=");
            n.append(this.f376d);
            n.append(", mValid=");
            n.append(this.f377e);
            n.append('}');
            return n.toString();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\LinearLayoutManager$b.smali */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public int f378a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f379b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f380c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f381d;
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\LinearLayoutManager$c.smali */
    public static class c {

        /* renamed from: b, reason: collision with root package name */
        public int f383b;

        /* renamed from: c, reason: collision with root package name */
        public int f384c;

        /* renamed from: d, reason: collision with root package name */
        public int f385d;

        /* renamed from: e, reason: collision with root package name */
        public int f386e;

        /* renamed from: f, reason: collision with root package name */
        public int f387f;

        /* renamed from: g, reason: collision with root package name */
        public int f388g;

        /* renamed from: j, reason: collision with root package name */
        public int f391j;
        public boolean l;

        /* renamed from: a, reason: collision with root package name */
        public boolean f382a = true;

        /* renamed from: h, reason: collision with root package name */
        public int f389h = 0;

        /* renamed from: i, reason: collision with root package name */
        public int f390i = 0;
        public List<RecyclerView.a0> k = null;

        public void a(View view) {
            int a2;
            int size = this.k.size();
            View view2 = null;
            int i2 = Integer.MAX_VALUE;
            for (int i3 = 0; i3 < size; i3++) {
                View view3 = this.k.get(i3).f400d;
                RecyclerView.n nVar = (RecyclerView.n) view3.getLayoutParams();
                if (view3 != view && !nVar.c() && (a2 = (nVar.a() - this.f385d) * this.f386e) >= 0 && a2 < i2) {
                    view2 = view3;
                    if (a2 == 0) {
                        break;
                    } else {
                        i2 = a2;
                    }
                }
            }
            if (view2 == null) {
                this.f385d = -1;
            } else {
                this.f385d = ((RecyclerView.n) view2.getLayoutParams()).a();
            }
        }

        public boolean b(RecyclerView.x xVar) {
            int i2 = this.f385d;
            return i2 >= 0 && i2 < xVar.b();
        }

        public View c(RecyclerView.s sVar) {
            List<RecyclerView.a0> list = this.k;
            if (list == null) {
                View view = sVar.j(this.f385d, false, Long.MAX_VALUE).f400d;
                this.f385d += this.f386e;
                return view;
            }
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view2 = this.k.get(i2).f400d;
                RecyclerView.n nVar = (RecyclerView.n) view2.getLayoutParams();
                if (!nVar.c() && this.f385d == nVar.a()) {
                    a(view2);
                    return view2;
                }
            }
            return null;
        }
    }

    public LinearLayoutManager(int i2, boolean z) {
        this.r = 1;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = true;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.B = null;
        this.C = new a();
        this.D = new b();
        this.E = 2;
        this.F = new int[2];
        z1(i2);
        d(null);
        if (z == this.v) {
            return;
        }
        this.v = z;
        J0();
    }

    public LinearLayoutManager(Context context) {
        this(1, false);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.r = 1;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = true;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.B = null;
        this.C = new a();
        this.D = new b();
        this.E = 2;
        this.F = new int[2];
        RecyclerView.m.d R = RecyclerView.m.R(context, attributeSet, i2, i3);
        z1(R.f434a);
        boolean z = R.f436c;
        d(null);
        if (z != this.v) {
            this.v = z;
            J0();
        }
        A1(R.f437d);
    }

    public void A1(boolean z) {
        d(null);
        if (this.x == z) {
            return;
        }
        this.x = z;
        J0();
    }

    public final void B1(int i2, int i3, boolean z, RecyclerView.x xVar) {
        int k;
        this.s.l = w1();
        this.s.f387f = i2;
        int[] iArr = this.F;
        iArr[0] = 0;
        iArr[1] = 0;
        Y0(xVar, iArr);
        int max = Math.max(0, this.F[0]);
        int max2 = Math.max(0, this.F[1]);
        boolean z2 = i2 == 1;
        c cVar = this.s;
        int i4 = z2 ? max2 : max;
        cVar.f389h = i4;
        if (!z2) {
            max = max2;
        }
        cVar.f390i = max;
        if (z2) {
            cVar.f389h = this.t.h() + i4;
            View p1 = p1();
            c cVar2 = this.s;
            cVar2.f386e = this.w ? -1 : 1;
            int Q = Q(p1);
            c cVar3 = this.s;
            cVar2.f385d = Q + cVar3.f386e;
            cVar3.f383b = this.t.b(p1);
            k = this.t.b(p1) - this.t.g();
        } else {
            View q1 = q1();
            c cVar4 = this.s;
            cVar4.f389h = this.t.k() + cVar4.f389h;
            c cVar5 = this.s;
            cVar5.f386e = this.w ? 1 : -1;
            int Q2 = Q(q1);
            c cVar6 = this.s;
            cVar5.f385d = Q2 + cVar6.f386e;
            cVar6.f383b = this.t.e(q1);
            k = (-this.t.e(q1)) + this.t.k();
        }
        c cVar7 = this.s;
        cVar7.f384c = i3;
        if (z) {
            cVar7.f384c = i3 - k;
        }
        cVar7.f388g = k;
    }

    public final void C1(int i2, int i3) {
        this.s.f384c = this.t.g() - i3;
        c cVar = this.s;
        cVar.f386e = this.w ? -1 : 1;
        cVar.f385d = i2;
        cVar.f387f = 1;
        cVar.f383b = i3;
        cVar.f388g = Integer.MIN_VALUE;
    }

    public final void D1(int i2, int i3) {
        this.s.f384c = i3 - this.t.k();
        c cVar = this.s;
        cVar.f385d = i2;
        cVar.f386e = this.w ? 1 : -1;
        cVar.f387f = -1;
        cVar.f383b = i3;
        cVar.f388g = Integer.MIN_VALUE;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int K0(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        if (this.r == 1) {
            return 0;
        }
        return y1(i2, sVar, xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void L0(int i2) {
        this.z = i2;
        this.A = Integer.MIN_VALUE;
        d dVar = this.B;
        if (dVar != null) {
            dVar.d = -1;
        }
        J0();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int M0(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        if (this.r == 0) {
            return 0;
        }
        return y1(i2, sVar, xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean T0() {
        boolean z;
        if (this.o != 1073741824 && this.n != 1073741824) {
            int y = y();
            int i2 = 0;
            while (true) {
                if (i2 >= y) {
                    z = false;
                    break;
                }
                ViewGroup.LayoutParams layoutParams = x(i2).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    z = true;
                    break;
                }
                i2++;
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean V() {
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void V0(RecyclerView recyclerView, RecyclerView.x xVar, int i2) {
        p pVar = new p(recyclerView.getContext());
        pVar.f458a = i2;
        W0(pVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean X0() {
        return this.B == null && this.u == this.x;
    }

    public void Y0(RecyclerView.x xVar, int[] iArr) {
        int i2;
        int l = xVar.f473a != -1 ? this.t.l() : 0;
        if (this.s.f387f == -1) {
            i2 = 0;
        } else {
            i2 = l;
            l = 0;
        }
        iArr[0] = l;
        iArr[1] = i2;
    }

    public void Z0(RecyclerView.x xVar, c cVar, RecyclerView.m.c cVar2) {
        int i2 = cVar.f385d;
        if (i2 < 0 || i2 >= xVar.b()) {
            return;
        }
        ((n.b) cVar2).a(i2, Math.max(0, cVar.f388g));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.w.b
    public PointF a(int i2) {
        if (y() == 0) {
            return null;
        }
        int i3 = (i2 < Q(x(0))) != this.w ? -1 : 1;
        return this.r == 0 ? new PointF(i3, 0.0f) : new PointF(0.0f, i3);
    }

    public final int a1(RecyclerView.x xVar) {
        if (y() == 0) {
            return 0;
        }
        e1();
        return b.n.a.o(xVar, this.t, h1(!this.y, true), g1(!this.y, true), this, this.y);
    }

    public final int b1(RecyclerView.x xVar) {
        if (y() == 0) {
            return 0;
        }
        e1();
        return b.n.a.p(xVar, this.t, h1(!this.y, true), g1(!this.y, true), this, this.y, this.w);
    }

    public final int c1(RecyclerView.x xVar) {
        if (y() == 0) {
            return 0;
        }
        e1();
        return b.n.a.q(xVar, this.t, h1(!this.y, true), g1(!this.y, true), this, this.y);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void d(String str) {
        RecyclerView recyclerView;
        if (this.B != null || (recyclerView = this.f423b) == null) {
            return;
        }
        recyclerView.i(str);
    }

    public int d1(int i2) {
        return i2 != 1 ? i2 != 2 ? i2 != 17 ? i2 != 33 ? i2 != 66 ? (i2 == 130 && this.r == 1) ? 1 : Integer.MIN_VALUE : this.r == 0 ? 1 : Integer.MIN_VALUE : this.r == 1 ? -1 : Integer.MIN_VALUE : this.r == 0 ? -1 : Integer.MIN_VALUE : (this.r != 1 && r1()) ? -1 : 1 : (this.r != 1 && r1()) ? 1 : -1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean e() {
        return this.r == 0;
    }

    public void e1() {
        if (this.s == null) {
            this.s = new c();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean f() {
        return this.r == 1;
    }

    public int f1(RecyclerView.s sVar, c cVar, RecyclerView.x xVar, boolean z) {
        int i2 = cVar.f384c;
        int i3 = cVar.f388g;
        if (i3 != Integer.MIN_VALUE) {
            if (i2 < 0) {
                cVar.f388g = i3 + i2;
            }
            u1(sVar, cVar);
        }
        int i4 = cVar.f384c + cVar.f389h;
        b bVar = this.D;
        while (true) {
            if ((!cVar.l && i4 <= 0) || !cVar.b(xVar)) {
                break;
            }
            bVar.f378a = 0;
            bVar.f379b = false;
            bVar.f380c = false;
            bVar.f381d = false;
            s1(sVar, xVar, cVar, bVar);
            if (!bVar.f379b) {
                int i5 = cVar.f383b;
                int i6 = bVar.f378a;
                cVar.f383b = (cVar.f387f * i6) + i5;
                if (!bVar.f380c || cVar.k != null || !xVar.f479g) {
                    cVar.f384c -= i6;
                    i4 -= i6;
                }
                int i7 = cVar.f388g;
                if (i7 != Integer.MIN_VALUE) {
                    int i8 = i7 + i6;
                    cVar.f388g = i8;
                    int i9 = cVar.f384c;
                    if (i9 < 0) {
                        cVar.f388g = i8 + i9;
                    }
                    u1(sVar, cVar);
                }
                if (z && bVar.f381d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i2 - cVar.f384c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void g0(RecyclerView recyclerView, RecyclerView.s sVar) {
        f0();
    }

    public View g1(boolean z, boolean z2) {
        return this.w ? l1(0, y(), z, z2) : l1(y() - 1, -1, z, z2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public View h0(View view, int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        int d1;
        x1();
        if (y() == 0 || (d1 = d1(i2)) == Integer.MIN_VALUE) {
            return null;
        }
        e1();
        B1(d1, (int) (this.t.l() * 0.33333334f), false, xVar);
        c cVar = this.s;
        cVar.f388g = Integer.MIN_VALUE;
        cVar.f382a = false;
        f1(sVar, cVar, xVar, true);
        View k1 = d1 == -1 ? this.w ? k1(y() - 1, -1) : k1(0, y()) : this.w ? k1(0, y()) : k1(y() - 1, -1);
        View q1 = d1 == -1 ? q1() : p1();
        if (!q1.hasFocusable()) {
            return k1;
        }
        if (k1 == null) {
            return null;
        }
        return q1;
    }

    public View h1(boolean z, boolean z2) {
        return this.w ? l1(y() - 1, -1, z, z2) : l1(0, y(), z, z2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i(int i2, int i3, RecyclerView.x xVar, RecyclerView.m.c cVar) {
        if (this.r != 0) {
            i2 = i3;
        }
        if (y() == 0 || i2 == 0) {
            return;
        }
        e1();
        B1(i2 > 0 ? 1 : -1, Math.abs(i2), true, xVar);
        Z0(xVar, this.s, cVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i0(AccessibilityEvent accessibilityEvent) {
        RecyclerView.s sVar = this.f423b.f393e;
        j0(accessibilityEvent);
        if (y() > 0) {
            accessibilityEvent.setFromIndex(i1());
            accessibilityEvent.setToIndex(j1());
        }
    }

    public int i1() {
        View l1 = l1(0, y(), false, true);
        if (l1 == null) {
            return -1;
        }
        return Q(l1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void j(int i2, RecyclerView.m.c cVar) {
        boolean z;
        int i3;
        d dVar = this.B;
        if (dVar == null || !dVar.a()) {
            x1();
            z = this.w;
            i3 = this.z;
            if (i3 == -1) {
                i3 = z ? i2 - 1 : 0;
            }
        } else {
            d dVar2 = this.B;
            z = dVar2.f;
            i3 = dVar2.d;
        }
        int i4 = z ? -1 : 1;
        for (int i5 = 0; i5 < this.E && i3 >= 0 && i3 < i2; i5++) {
            ((n.b) cVar).a(i3, 0);
            i3 += i4;
        }
    }

    public int j1() {
        View l1 = l1(y() - 1, -1, false, true);
        if (l1 == null) {
            return -1;
        }
        return Q(l1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int k(RecyclerView.x xVar) {
        return a1(xVar);
    }

    public View k1(int i2, int i3) {
        int i4;
        int i5;
        e1();
        if ((i3 > i2 ? (char) 1 : i3 < i2 ? (char) 65535 : (char) 0) == 0) {
            return x(i2);
        }
        if (this.t.e(x(i2)) < this.t.k()) {
            i4 = 16644;
            i5 = 16388;
        } else {
            i4 = 4161;
            i5 = 4097;
        }
        return this.r == 0 ? this.f426e.a(i2, i3, i4, i5) : this.f427f.a(i2, i3, i4, i5);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int l(RecyclerView.x xVar) {
        return b1(xVar);
    }

    public View l1(int i2, int i3, boolean z, boolean z2) {
        e1();
        int i4 = z ? 24579 : 320;
        int i5 = z2 ? 320 : 0;
        return this.r == 0 ? this.f426e.a(i2, i3, i4, i5) : this.f427f.a(i2, i3, i4, i5);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int m(RecyclerView.x xVar) {
        return c1(xVar);
    }

    public View m1(RecyclerView.s sVar, RecyclerView.x xVar, boolean z, boolean z2) {
        int i2;
        int i3;
        e1();
        int y = y();
        int i4 = -1;
        if (z2) {
            i2 = y() - 1;
            i3 = -1;
        } else {
            i4 = y;
            i2 = 0;
            i3 = 1;
        }
        int b2 = xVar.b();
        int k = this.t.k();
        int g2 = this.t.g();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (i2 != i4) {
            View x = x(i2);
            int Q = Q(x);
            int e2 = this.t.e(x);
            int b3 = this.t.b(x);
            if (Q >= 0 && Q < b2) {
                if (!((RecyclerView.n) x.getLayoutParams()).c()) {
                    boolean z3 = b3 <= k && e2 < k;
                    boolean z4 = e2 >= g2 && b3 > g2;
                    if (!z3 && !z4) {
                        return x;
                    }
                    if (z) {
                        if (!z4) {
                            if (view != null) {
                            }
                            view = x;
                        }
                        view2 = x;
                    } else {
                        if (!z3) {
                            if (view != null) {
                            }
                            view = x;
                        }
                        view2 = x;
                    }
                } else if (view3 == null) {
                    view3 = x;
                }
            }
            i2 += i3;
        }
        return view != null ? view : view2 != null ? view2 : view3;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int n(RecyclerView.x xVar) {
        return a1(xVar);
    }

    public final int n1(int i2, RecyclerView.s sVar, RecyclerView.x xVar, boolean z) {
        int g2;
        int g3 = this.t.g() - i2;
        if (g3 <= 0) {
            return 0;
        }
        int i3 = -y1(-g3, sVar, xVar);
        int i4 = i2 + i3;
        if (!z || (g2 = this.t.g() - i4) <= 0) {
            return i3;
        }
        this.t.p(g2);
        return g2 + i3;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int o(RecyclerView.x xVar) {
        return b1(xVar);
    }

    public final int o1(int i2, RecyclerView.s sVar, RecyclerView.x xVar, boolean z) {
        int k;
        int k2 = i2 - this.t.k();
        if (k2 <= 0) {
            return 0;
        }
        int i3 = -y1(k2, sVar, xVar);
        int i4 = i2 + i3;
        if (!z || (k = i4 - this.t.k()) <= 0) {
            return i3;
        }
        this.t.p(-k);
        return i3 - k;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int p(RecyclerView.x xVar) {
        return c1(xVar);
    }

    public final View p1() {
        return x(this.w ? 0 : y() - 1);
    }

    public final View q1() {
        return x(this.w ? y() - 1 : 0);
    }

    public boolean r1() {
        return J() == 1;
    }

    public void s1(RecyclerView.s sVar, RecyclerView.x xVar, c cVar, b bVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        int d2;
        View c2 = cVar.c(sVar);
        if (c2 == null) {
            bVar.f379b = true;
            return;
        }
        RecyclerView.n nVar = (RecyclerView.n) c2.getLayoutParams();
        if (cVar.k == null) {
            if (this.w == (cVar.f387f == -1)) {
                c(c2, -1, false);
            } else {
                c(c2, 0, false);
            }
        } else {
            if (this.w == (cVar.f387f == -1)) {
                c(c2, -1, true);
            } else {
                c(c2, 0, true);
            }
        }
        RecyclerView.n nVar2 = (RecyclerView.n) c2.getLayoutParams();
        Rect M = this.f423b.M(c2);
        int i6 = M.left + M.right + 0;
        int i7 = M.top + M.bottom + 0;
        int z = RecyclerView.m.z(this.p, this.n, O() + N() + ((ViewGroup.MarginLayoutParams) nVar2).leftMargin + ((ViewGroup.MarginLayoutParams) nVar2).rightMargin + i6, ((ViewGroup.MarginLayoutParams) nVar2).width, e());
        int z2 = RecyclerView.m.z(this.q, this.o, M() + P() + ((ViewGroup.MarginLayoutParams) nVar2).topMargin + ((ViewGroup.MarginLayoutParams) nVar2).bottomMargin + i7, ((ViewGroup.MarginLayoutParams) nVar2).height, f());
        if (S0(c2, z, z2, nVar2)) {
            c2.measure(z, z2);
        }
        bVar.f378a = this.t.c(c2);
        if (this.r == 1) {
            if (r1()) {
                d2 = this.p - O();
                i5 = d2 - this.t.d(c2);
            } else {
                i5 = N();
                d2 = this.t.d(c2) + i5;
            }
            if (cVar.f387f == -1) {
                int i8 = cVar.f383b;
                i4 = i8;
                i3 = d2;
                i2 = i8 - bVar.f378a;
            } else {
                int i9 = cVar.f383b;
                i2 = i9;
                i3 = d2;
                i4 = bVar.f378a + i9;
            }
        } else {
            int P = P();
            int d3 = this.t.d(c2) + P;
            if (cVar.f387f == -1) {
                int i10 = cVar.f383b;
                i3 = i10;
                i2 = P;
                i4 = d3;
                i5 = i10 - bVar.f378a;
            } else {
                int i11 = cVar.f383b;
                i2 = P;
                i3 = bVar.f378a + i11;
                i4 = d3;
                i5 = i11;
            }
        }
        Z(c2, i5, i2, i3, i4);
        if (nVar.c() || nVar.b()) {
            bVar.f380c = true;
        }
        bVar.f381d = c2.hasFocusable();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public View t(int i2) {
        int y = y();
        if (y == 0) {
            return null;
        }
        int Q = i2 - Q(x(0));
        if (Q >= 0 && Q < y) {
            View x = x(Q);
            if (Q(x) == i2) {
                return x;
            }
        }
        return super.t(i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:128:0x0180  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x020e  */
    @Override // androidx.recyclerview.widget.RecyclerView.m
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void t0(androidx.recyclerview.widget.RecyclerView.s r17, androidx.recyclerview.widget.RecyclerView.x r18) {
        /*
            Method dump skipped, instructions count: 1060
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.t0(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$x):void");
    }

    public void t1(RecyclerView.s sVar, RecyclerView.x xVar, a aVar, int i2) {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n u() {
        return new RecyclerView.n(-2, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void u0(RecyclerView.x xVar) {
        this.B = null;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.C.d();
    }

    public final void u1(RecyclerView.s sVar, c cVar) {
        if (!cVar.f382a || cVar.l) {
            return;
        }
        int i2 = cVar.f388g;
        int i3 = cVar.f390i;
        if (cVar.f387f == -1) {
            int y = y();
            if (i2 < 0) {
                return;
            }
            int f2 = (this.t.f() - i2) + i3;
            if (this.w) {
                for (int i4 = 0; i4 < y; i4++) {
                    View x = x(i4);
                    if (this.t.e(x) < f2 || this.t.o(x) < f2) {
                        v1(sVar, 0, i4);
                        return;
                    }
                }
                return;
            }
            int i5 = y - 1;
            for (int i6 = i5; i6 >= 0; i6--) {
                View x2 = x(i6);
                if (this.t.e(x2) < f2 || this.t.o(x2) < f2) {
                    v1(sVar, i5, i6);
                    return;
                }
            }
            return;
        }
        if (i2 < 0) {
            return;
        }
        int i7 = i2 - i3;
        int y2 = y();
        if (!this.w) {
            for (int i8 = 0; i8 < y2; i8++) {
                View x3 = x(i8);
                if (this.t.b(x3) > i7 || this.t.n(x3) > i7) {
                    v1(sVar, 0, i8);
                    return;
                }
            }
            return;
        }
        int i9 = y2 - 1;
        for (int i10 = i9; i10 >= 0; i10--) {
            View x4 = x(i10);
            if (this.t.b(x4) > i7 || this.t.n(x4) > i7) {
                v1(sVar, i9, i10);
                return;
            }
        }
    }

    public final void v1(RecyclerView.s sVar, int i2, int i3) {
        if (i2 == i3) {
            return;
        }
        if (i3 <= i2) {
            while (i2 > i3) {
                G0(i2, sVar);
                i2--;
            }
        } else {
            for (int i4 = i3 - 1; i4 >= i2; i4--) {
                G0(i4, sVar);
            }
        }
    }

    public boolean w1() {
        return this.t.i() == 0 && this.t.f() == 0;
    }

    public final void x1() {
        if (this.r == 1 || !r1()) {
            this.w = this.v;
        } else {
            this.w = !this.v;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void y0(Parcelable parcelable) {
        if (parcelable instanceof d) {
            d dVar = (d) parcelable;
            this.B = dVar;
            if (this.z != -1) {
                dVar.d = -1;
            }
            J0();
        }
    }

    public int y1(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        if (y() == 0 || i2 == 0) {
            return 0;
        }
        e1();
        this.s.f382a = true;
        int i3 = i2 > 0 ? 1 : -1;
        int abs = Math.abs(i2);
        B1(i3, abs, true, xVar);
        c cVar = this.s;
        int f1 = f1(sVar, cVar, xVar, false) + cVar.f388g;
        if (f1 < 0) {
            return 0;
        }
        if (abs > f1) {
            i2 = i3 * f1;
        }
        this.t.p(-i2);
        this.s.f391j = i2;
        return i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public Parcelable z0() {
        d dVar = this.B;
        if (dVar != null) {
            return new d(dVar);
        }
        d dVar2 = new d();
        if (y() > 0) {
            e1();
            boolean z = this.u ^ this.w;
            dVar2.f = z;
            if (z) {
                View p1 = p1();
                dVar2.e = this.t.g() - this.t.b(p1);
                dVar2.d = Q(p1);
            } else {
                View q1 = q1();
                dVar2.d = Q(q1);
                dVar2.e = this.t.e(q1) - this.t.k();
            }
        } else {
            dVar2.d = -1;
        }
        return dVar2;
    }

    public void z1(int i2) {
        if (i2 != 0 && i2 != 1) {
            throw new IllegalArgumentException(c.a.a.a.a.c("invalid orientation:", i2));
        }
        d(null);
        if (i2 != this.r || this.t == null) {
            t a2 = t.a(this, i2);
            this.t = a2;
            this.C.f373a = a2;
            this.r = i2;
            J0();
        }
    }
}
