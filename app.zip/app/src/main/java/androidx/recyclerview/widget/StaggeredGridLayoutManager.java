package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import b.t.b.n;
import b.t.b.o;
import b.t.b.p;
import b.t.b.t;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager.smali */
public class StaggeredGridLayoutManager extends RecyclerView.m implements RecyclerView.w.b {
    public BitSet A;
    public boolean F;
    public boolean G;
    public e H;
    public int I;
    public int[] M;
    public int r;
    public f[] s;
    public t t;
    public t u;
    public int v;
    public int w;
    public final o x;
    public boolean y;
    public boolean z = false;
    public int B = -1;
    public int C = Integer.MIN_VALUE;
    public d D = new d();
    public int E = 2;
    public final Rect J = new Rect();
    public final b K = new b();
    public boolean L = true;
    public final Runnable N = new a();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$a.smali */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            StaggeredGridLayoutManager.this.Z0();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$b.smali */
    public class b {

        /* renamed from: a, reason: collision with root package name */
        public int f491a;

        /* renamed from: b, reason: collision with root package name */
        public int f492b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f493c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f494d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f495e;

        /* renamed from: f, reason: collision with root package name */
        public int[] f496f;

        public b() {
            b();
        }

        public void a() {
            this.f492b = this.f493c ? StaggeredGridLayoutManager.this.t.g() : StaggeredGridLayoutManager.this.t.k();
        }

        public void b() {
            this.f491a = -1;
            this.f492b = Integer.MIN_VALUE;
            this.f493c = false;
            this.f494d = false;
            this.f495e = false;
            int[] iArr = this.f496f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$c.smali */
    public static class c extends RecyclerView.n {

        /* renamed from: e, reason: collision with root package name */
        public f f498e;

        public c(int i2, int i3) {
            super(i2, i3);
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$d.smali */
    public static class d {

        /* renamed from: a, reason: collision with root package name */
        public int[] f499a;

        /* renamed from: b, reason: collision with root package name */
        public List<a> f500b;

        @SuppressLint({"BanParcelableUsage"})
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$d$a.smali */
        public static class a implements Parcelable {
            public static final Parcelable.Creator<a> CREATOR = new C0008a();

            /* renamed from: d, reason: collision with root package name */
            public int f501d;

            /* renamed from: e, reason: collision with root package name */
            public int f502e;

            /* renamed from: f, reason: collision with root package name */
            public int[] f503f;

            /* renamed from: g, reason: collision with root package name */
            public boolean f504g;

            /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a, reason: collision with other inner class name */
            /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$d$a$a.smali */
            public class C0008a implements Parcelable.Creator<a> {
                @Override // android.os.Parcelable.Creator
                public a createFromParcel(Parcel parcel) {
                    return new a(parcel);
                }

                @Override // android.os.Parcelable.Creator
                public a[] newArray(int i2) {
                    return new a[i2];
                }
            }

            public a() {
            }

            public a(Parcel parcel) {
                this.f501d = parcel.readInt();
                this.f502e = parcel.readInt();
                this.f504g = parcel.readInt() == 1;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    this.f503f = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            public String toString() {
                StringBuilder n = c.a.a.a.a.n("FullSpanItem{mPosition=");
                n.append(this.f501d);
                n.append(", mGapDir=");
                n.append(this.f502e);
                n.append(", mHasUnwantedGapAfter=");
                n.append(this.f504g);
                n.append(", mGapPerSpan=");
                n.append(Arrays.toString(this.f503f));
                n.append('}');
                return n.toString();
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i2) {
                parcel.writeInt(this.f501d);
                parcel.writeInt(this.f502e);
                parcel.writeInt(this.f504g ? 1 : 0);
                int[] iArr = this.f503f;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                } else {
                    parcel.writeInt(iArr.length);
                    parcel.writeIntArray(this.f503f);
                }
            }
        }

        public void a() {
            int[] iArr = this.f499a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f500b = null;
        }

        public void b(int i2) {
            int[] iArr = this.f499a;
            if (iArr == null) {
                int[] iArr2 = new int[Math.max(i2, 10) + 1];
                this.f499a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i2 >= iArr.length) {
                int length = iArr.length;
                while (length <= i2) {
                    length *= 2;
                }
                int[] iArr3 = new int[length];
                this.f499a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.f499a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        public a c(int i2) {
            List<a> list = this.f500b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f500b.get(size);
                if (aVar.f501d == i2) {
                    return aVar;
                }
            }
            return null;
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0048  */
        /* JADX WARN: Removed duplicated region for block: B:14:0x0052  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public int d(int r5) {
            /*
                r4 = this;
                int[] r0 = r4.f499a
                r1 = -1
                if (r0 != 0) goto L6
                return r1
            L6:
                int r0 = r0.length
                if (r5 < r0) goto La
                return r1
            La:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f500b
                if (r0 != 0) goto L10
            Le:
                r0 = -1
                goto L46
            L10:
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = r4.c(r5)
                if (r0 == 0) goto L1b
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r2 = r4.f500b
                r2.remove(r0)
            L1b:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f500b
                int r0 = r0.size()
                r2 = 0
            L22:
                if (r2 >= r0) goto L34
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f500b
                java.lang.Object r3 = r3.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r3 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.d.a) r3
                int r3 = r3.f501d
                if (r3 < r5) goto L31
                goto L35
            L31:
                int r2 = r2 + 1
                goto L22
            L34:
                r2 = -1
            L35:
                if (r2 == r1) goto Le
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f500b
                java.lang.Object r0 = r0.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.d.a) r0
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f500b
                r3.remove(r2)
                int r0 = r0.f501d
            L46:
                if (r0 != r1) goto L52
                int[] r0 = r4.f499a
                int r2 = r0.length
                java.util.Arrays.fill(r0, r5, r2, r1)
                int[] r5 = r4.f499a
                int r5 = r5.length
                return r5
            L52:
                int r0 = r0 + 1
                int[] r2 = r4.f499a
                int r2 = r2.length
                int r0 = java.lang.Math.min(r0, r2)
                int[] r2 = r4.f499a
                java.util.Arrays.fill(r2, r5, r0, r1)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.d.d(int):int");
        }

        public void e(int i2, int i3) {
            int[] iArr = this.f499a;
            if (iArr == null || i2 >= iArr.length) {
                return;
            }
            int i4 = i2 + i3;
            b(i4);
            int[] iArr2 = this.f499a;
            System.arraycopy(iArr2, i2, iArr2, i4, (iArr2.length - i2) - i3);
            Arrays.fill(this.f499a, i2, i4, -1);
            List<a> list = this.f500b;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f500b.get(size);
                int i5 = aVar.f501d;
                if (i5 >= i2) {
                    aVar.f501d = i5 + i3;
                }
            }
        }

        public void f(int i2, int i3) {
            int[] iArr = this.f499a;
            if (iArr == null || i2 >= iArr.length) {
                return;
            }
            int i4 = i2 + i3;
            b(i4);
            int[] iArr2 = this.f499a;
            System.arraycopy(iArr2, i4, iArr2, i2, (iArr2.length - i2) - i3);
            int[] iArr3 = this.f499a;
            Arrays.fill(iArr3, iArr3.length - i3, iArr3.length, -1);
            List<a> list = this.f500b;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f500b.get(size);
                int i5 = aVar.f501d;
                if (i5 >= i2) {
                    if (i5 < i4) {
                        this.f500b.remove(size);
                    } else {
                        aVar.f501d = i5 - i3;
                    }
                }
            }
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$e.smali */
    public static class e implements Parcelable {
        public static final Parcelable.Creator<e> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public int f505d;

        /* renamed from: e, reason: collision with root package name */
        public int f506e;

        /* renamed from: f, reason: collision with root package name */
        public int f507f;

        /* renamed from: g, reason: collision with root package name */
        public int[] f508g;

        /* renamed from: h, reason: collision with root package name */
        public int f509h;

        /* renamed from: i, reason: collision with root package name */
        public int[] f510i;

        /* renamed from: j, reason: collision with root package name */
        public List<d.a> f511j;
        public boolean k;
        public boolean l;
        public boolean m;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$e$a.smali */
        public class a implements Parcelable.Creator<e> {
            @Override // android.os.Parcelable.Creator
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public e[] newArray(int i2) {
                return new e[i2];
            }
        }

        public e() {
        }

        public e(Parcel parcel) {
            this.f505d = parcel.readInt();
            this.f506e = parcel.readInt();
            int readInt = parcel.readInt();
            this.f507f = readInt;
            if (readInt > 0) {
                int[] iArr = new int[readInt];
                this.f508g = iArr;
                parcel.readIntArray(iArr);
            }
            int readInt2 = parcel.readInt();
            this.f509h = readInt2;
            if (readInt2 > 0) {
                int[] iArr2 = new int[readInt2];
                this.f510i = iArr2;
                parcel.readIntArray(iArr2);
            }
            this.k = parcel.readInt() == 1;
            this.l = parcel.readInt() == 1;
            this.m = parcel.readInt() == 1;
            this.f511j = parcel.readArrayList(d.a.class.getClassLoader());
        }

        public e(e eVar) {
            this.f507f = eVar.f507f;
            this.f505d = eVar.f505d;
            this.f506e = eVar.f506e;
            this.f508g = eVar.f508g;
            this.f509h = eVar.f509h;
            this.f510i = eVar.f510i;
            this.k = eVar.k;
            this.l = eVar.l;
            this.m = eVar.m;
            this.f511j = eVar.f511j;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.f505d);
            parcel.writeInt(this.f506e);
            parcel.writeInt(this.f507f);
            if (this.f507f > 0) {
                parcel.writeIntArray(this.f508g);
            }
            parcel.writeInt(this.f509h);
            if (this.f509h > 0) {
                parcel.writeIntArray(this.f510i);
            }
            parcel.writeInt(this.k ? 1 : 0);
            parcel.writeInt(this.l ? 1 : 0);
            parcel.writeInt(this.m ? 1 : 0);
            parcel.writeList(this.f511j);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\recyclerview\widget\StaggeredGridLayoutManager$f.smali */
    public class f {

        /* renamed from: a, reason: collision with root package name */
        public ArrayList<View> f512a = new ArrayList<>();

        /* renamed from: b, reason: collision with root package name */
        public int f513b = Integer.MIN_VALUE;

        /* renamed from: c, reason: collision with root package name */
        public int f514c = Integer.MIN_VALUE;

        /* renamed from: d, reason: collision with root package name */
        public int f515d = 0;

        /* renamed from: e, reason: collision with root package name */
        public final int f516e;

        public f(int i2) {
            this.f516e = i2;
        }

        public void a(View view) {
            c j2 = j(view);
            j2.f498e = this;
            this.f512a.add(view);
            this.f514c = Integer.MIN_VALUE;
            if (this.f512a.size() == 1) {
                this.f513b = Integer.MIN_VALUE;
            }
            if (j2.c() || j2.b()) {
                this.f515d = StaggeredGridLayoutManager.this.t.c(view) + this.f515d;
            }
        }

        public void b() {
            View view = this.f512a.get(r0.size() - 1);
            c j2 = j(view);
            this.f514c = StaggeredGridLayoutManager.this.t.b(view);
            Objects.requireNonNull(j2);
        }

        public void c() {
            View view = this.f512a.get(0);
            c j2 = j(view);
            this.f513b = StaggeredGridLayoutManager.this.t.e(view);
            Objects.requireNonNull(j2);
        }

        public void d() {
            this.f512a.clear();
            this.f513b = Integer.MIN_VALUE;
            this.f514c = Integer.MIN_VALUE;
            this.f515d = 0;
        }

        public int e() {
            return StaggeredGridLayoutManager.this.y ? g(this.f512a.size() - 1, -1, true) : g(0, this.f512a.size(), true);
        }

        public int f() {
            return StaggeredGridLayoutManager.this.y ? g(0, this.f512a.size(), true) : g(this.f512a.size() - 1, -1, true);
        }

        public int g(int i2, int i3, boolean z) {
            int k = StaggeredGridLayoutManager.this.t.k();
            int g2 = StaggeredGridLayoutManager.this.t.g();
            int i4 = i3 > i2 ? 1 : -1;
            while (i2 != i3) {
                View view = this.f512a.get(i2);
                int e2 = StaggeredGridLayoutManager.this.t.e(view);
                int b2 = StaggeredGridLayoutManager.this.t.b(view);
                boolean z2 = false;
                boolean z3 = !z ? e2 >= g2 : e2 > g2;
                if (!z ? b2 > k : b2 >= k) {
                    z2 = true;
                }
                if (z3 && z2 && (e2 < k || b2 > g2)) {
                    return StaggeredGridLayoutManager.this.Q(view);
                }
                i2 += i4;
            }
            return -1;
        }

        public int h(int i2) {
            int i3 = this.f514c;
            if (i3 != Integer.MIN_VALUE) {
                return i3;
            }
            if (this.f512a.size() == 0) {
                return i2;
            }
            b();
            return this.f514c;
        }

        public View i(int i2, int i3) {
            View view = null;
            if (i3 != -1) {
                int size = this.f512a.size() - 1;
                while (size >= 0) {
                    View view2 = this.f512a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.y && staggeredGridLayoutManager.Q(view2) >= i2) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.y && staggeredGridLayoutManager2.Q(view2) <= i2) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.f512a.size();
                int i4 = 0;
                while (i4 < size2) {
                    View view3 = this.f512a.get(i4);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.y && staggeredGridLayoutManager3.Q(view3) <= i2) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.y && staggeredGridLayoutManager4.Q(view3) >= i2) || !view3.hasFocusable()) {
                        break;
                    }
                    i4++;
                    view = view3;
                }
            }
            return view;
        }

        public c j(View view) {
            return (c) view.getLayoutParams();
        }

        public int k(int i2) {
            int i3 = this.f513b;
            if (i3 != Integer.MIN_VALUE) {
                return i3;
            }
            if (this.f512a.size() == 0) {
                return i2;
            }
            c();
            return this.f513b;
        }

        public void l() {
            int size = this.f512a.size();
            View remove = this.f512a.remove(size - 1);
            c j2 = j(remove);
            j2.f498e = null;
            if (j2.c() || j2.b()) {
                this.f515d -= StaggeredGridLayoutManager.this.t.c(remove);
            }
            if (size == 1) {
                this.f513b = Integer.MIN_VALUE;
            }
            this.f514c = Integer.MIN_VALUE;
        }

        public void m() {
            View remove = this.f512a.remove(0);
            c j2 = j(remove);
            j2.f498e = null;
            if (this.f512a.size() == 0) {
                this.f514c = Integer.MIN_VALUE;
            }
            if (j2.c() || j2.b()) {
                this.f515d -= StaggeredGridLayoutManager.this.t.c(remove);
            }
            this.f513b = Integer.MIN_VALUE;
        }

        public void n(View view) {
            c j2 = j(view);
            j2.f498e = this;
            this.f512a.add(0, view);
            this.f513b = Integer.MIN_VALUE;
            if (this.f512a.size() == 1) {
                this.f514c = Integer.MIN_VALUE;
            }
            if (j2.c() || j2.b()) {
                this.f515d = StaggeredGridLayoutManager.this.t.c(view) + this.f515d;
            }
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.r = -1;
        this.y = false;
        RecyclerView.m.d R = RecyclerView.m.R(context, attributeSet, i2, i3);
        int i4 = R.f434a;
        if (i4 != 0 && i4 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        d(null);
        if (i4 != this.v) {
            this.v = i4;
            t tVar = this.t;
            this.t = this.u;
            this.u = tVar;
            J0();
        }
        int i5 = R.f435b;
        d(null);
        if (i5 != this.r) {
            this.D.a();
            J0();
            this.r = i5;
            this.A = new BitSet(this.r);
            this.s = new f[this.r];
            for (int i6 = 0; i6 < this.r; i6++) {
                this.s[i6] = new f(i6);
            }
            J0();
        }
        boolean z = R.f436c;
        d(null);
        e eVar = this.H;
        if (eVar != null && eVar.k != z) {
            eVar.k = z;
        }
        this.y = z;
        J0();
        this.x = new o();
        this.t = t.a(this, this.v);
        this.u = t.a(this, 1 - this.v);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void A0(int i2) {
        if (i2 == 0) {
            Z0();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0059  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void A1(int r5, androidx.recyclerview.widget.RecyclerView.x r6) {
        /*
            r4 = this;
            b.t.b.o r0 = r4.x
            r1 = 0
            r0.f2304b = r1
            r0.f2305c = r5
            androidx.recyclerview.widget.RecyclerView$w r0 = r4.f428g
            r2 = 1
            if (r0 == 0) goto L12
            boolean r0 = r0.f462e
            if (r0 == 0) goto L12
            r0 = 1
            goto L13
        L12:
            r0 = 0
        L13:
            if (r0 == 0) goto L33
            int r6 = r6.f473a
            r0 = -1
            if (r6 == r0) goto L33
            boolean r0 = r4.z
            if (r6 >= r5) goto L20
            r5 = 1
            goto L21
        L20:
            r5 = 0
        L21:
            if (r0 != r5) goto L2a
            b.t.b.t r5 = r4.t
            int r5 = r5.l()
            goto L34
        L2a:
            b.t.b.t r5 = r4.t
            int r5 = r5.l()
            r6 = r5
            r5 = 0
            goto L35
        L33:
            r5 = 0
        L34:
            r6 = 0
        L35:
            androidx.recyclerview.widget.RecyclerView r0 = r4.f423b
            if (r0 == 0) goto L3f
            boolean r0 = r0.f398j
            if (r0 == 0) goto L3f
            r0 = 1
            goto L40
        L3f:
            r0 = 0
        L40:
            if (r0 == 0) goto L59
            b.t.b.o r0 = r4.x
            b.t.b.t r3 = r4.t
            int r3 = r3.k()
            int r3 = r3 - r6
            r0.f2308f = r3
            b.t.b.o r6 = r4.x
            b.t.b.t r0 = r4.t
            int r0 = r0.g()
            int r0 = r0 + r5
            r6.f2309g = r0
            goto L69
        L59:
            b.t.b.o r0 = r4.x
            b.t.b.t r3 = r4.t
            int r3 = r3.f()
            int r3 = r3 + r5
            r0.f2309g = r3
            b.t.b.o r5 = r4.x
            int r6 = -r6
            r5.f2308f = r6
        L69:
            b.t.b.o r5 = r4.x
            r5.f2310h = r1
            r5.f2303a = r2
            b.t.b.t r6 = r4.t
            int r6 = r6.i()
            if (r6 != 0) goto L80
            b.t.b.t r6 = r4.t
            int r6 = r6.f()
            if (r6 != 0) goto L80
            r1 = 1
        L80:
            r5.f2311i = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.A1(int, androidx.recyclerview.widget.RecyclerView$x):void");
    }

    public final void B1(f fVar, int i2, int i3) {
        int i4 = fVar.f515d;
        if (i2 == -1) {
            int i5 = fVar.f513b;
            if (i5 == Integer.MIN_VALUE) {
                fVar.c();
                i5 = fVar.f513b;
            }
            if (i5 + i4 <= i3) {
                this.A.set(fVar.f516e, false);
                return;
            }
            return;
        }
        int i6 = fVar.f514c;
        if (i6 == Integer.MIN_VALUE) {
            fVar.b();
            i6 = fVar.f514c;
        }
        if (i6 - i4 >= i3) {
            this.A.set(fVar.f516e, false);
        }
    }

    public final int C1(int i2, int i3, int i4) {
        if (i3 == 0 && i4 == 0) {
            return i2;
        }
        int mode = View.MeasureSpec.getMode(i2);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - i3) - i4), mode) : i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int K0(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        return x1(i2, sVar, xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void L0(int i2) {
        e eVar = this.H;
        if (eVar != null && eVar.f505d != i2) {
            eVar.f508g = null;
            eVar.f507f = 0;
            eVar.f505d = -1;
            eVar.f506e = -1;
        }
        this.B = i2;
        this.C = Integer.MIN_VALUE;
        J0();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int M0(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        return x1(i2, sVar, xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void P0(Rect rect, int i2, int i3) {
        int h2;
        int h3;
        int O = O() + N();
        int M = M() + P();
        if (this.v == 1) {
            h3 = RecyclerView.m.h(i3, rect.height() + M, K());
            h2 = RecyclerView.m.h(i2, (this.w * this.r) + O, L());
        } else {
            h2 = RecyclerView.m.h(i2, rect.width() + O, L());
            h3 = RecyclerView.m.h(i3, (this.w * this.r) + M, K());
        }
        this.f423b.setMeasuredDimension(h2, h3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean V() {
        return this.E != 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void V0(RecyclerView recyclerView, RecyclerView.x xVar, int i2) {
        p pVar = new p(recyclerView.getContext());
        pVar.f458a = i2;
        W0(pVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean X0() {
        return this.H == null;
    }

    public final int Y0(int i2) {
        if (y() == 0) {
            return this.z ? 1 : -1;
        }
        return (i2 < i1()) != this.z ? -1 : 1;
    }

    public boolean Z0() {
        int i1;
        if (y() != 0 && this.E != 0 && this.f430i) {
            if (this.z) {
                i1 = j1();
                i1();
            } else {
                i1 = i1();
                j1();
            }
            if (i1 == 0 && n1() != null) {
                this.D.a();
                this.f429h = true;
                J0();
                return true;
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.w.b
    public PointF a(int i2) {
        int Y0 = Y0(i2);
        PointF pointF = new PointF();
        if (Y0 == 0) {
            return null;
        }
        if (this.v == 0) {
            pointF.x = Y0;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = Y0;
        }
        return pointF;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void a0(int i2) {
        super.a0(i2);
        for (int i3 = 0; i3 < this.r; i3++) {
            f fVar = this.s[i3];
            int i4 = fVar.f513b;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f513b = i4 + i2;
            }
            int i5 = fVar.f514c;
            if (i5 != Integer.MIN_VALUE) {
                fVar.f514c = i5 + i2;
            }
        }
    }

    public final int a1(RecyclerView.x xVar) {
        if (y() == 0) {
            return 0;
        }
        return b.n.a.o(xVar, this.t, f1(!this.L), e1(!this.L), this, this.L);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void b0(int i2) {
        super.b0(i2);
        for (int i3 = 0; i3 < this.r; i3++) {
            f fVar = this.s[i3];
            int i4 = fVar.f513b;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f513b = i4 + i2;
            }
            int i5 = fVar.f514c;
            if (i5 != Integer.MIN_VALUE) {
                fVar.f514c = i5 + i2;
            }
        }
    }

    public final int b1(RecyclerView.x xVar) {
        if (y() == 0) {
            return 0;
        }
        return b.n.a.p(xVar, this.t, f1(!this.L), e1(!this.L), this, this.L, this.z);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void c0(RecyclerView.e eVar, RecyclerView.e eVar2) {
        this.D.a();
        for (int i2 = 0; i2 < this.r; i2++) {
            this.s[i2].d();
        }
    }

    public final int c1(RecyclerView.x xVar) {
        if (y() == 0) {
            return 0;
        }
        return b.n.a.q(xVar, this.t, f1(!this.L), e1(!this.L), this, this.L);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void d(String str) {
        RecyclerView recyclerView;
        if (this.H != null || (recyclerView = this.f423b) == null) {
            return;
        }
        recyclerView.i(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v21 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v5, types: [boolean, int] */
    public final int d1(RecyclerView.s sVar, o oVar, RecyclerView.x xVar) {
        int i2;
        f fVar;
        ?? r2;
        int i3;
        int c2;
        int k;
        int c3;
        int i4;
        int i5;
        int i6;
        boolean z = false;
        this.A.set(0, this.r, true);
        if (this.x.f2311i) {
            i2 = oVar.f2307e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
        } else {
            i2 = oVar.f2307e == 1 ? oVar.f2309g + oVar.f2304b : oVar.f2308f - oVar.f2304b;
        }
        z1(oVar.f2307e, i2);
        int g2 = this.z ? this.t.g() : this.t.k();
        boolean z2 = false;
        while (true) {
            int i7 = oVar.f2305c;
            if (!(i7 >= 0 && i7 < xVar.b()) || (!this.x.f2311i && this.A.isEmpty())) {
                break;
            }
            View view = sVar.j(oVar.f2305c, z, Long.MAX_VALUE).f400d;
            oVar.f2305c += oVar.f2306d;
            c cVar = (c) view.getLayoutParams();
            int a2 = cVar.a();
            int[] iArr = this.D.f499a;
            int i8 = (iArr == null || a2 >= iArr.length) ? -1 : iArr[a2];
            if (i8 == -1) {
                if (r1(oVar.f2307e)) {
                    i5 = this.r - 1;
                    i4 = -1;
                    i6 = -1;
                } else {
                    i4 = this.r;
                    i5 = 0;
                    i6 = 1;
                }
                f fVar2 = null;
                if (oVar.f2307e == 1) {
                    int k2 = this.t.k();
                    int i9 = Integer.MAX_VALUE;
                    while (i5 != i4) {
                        f fVar3 = this.s[i5];
                        int h2 = fVar3.h(k2);
                        if (h2 < i9) {
                            fVar2 = fVar3;
                            i9 = h2;
                        }
                        i5 += i6;
                    }
                } else {
                    int g3 = this.t.g();
                    int i10 = Integer.MIN_VALUE;
                    while (i5 != i4) {
                        f fVar4 = this.s[i5];
                        int k3 = fVar4.k(g3);
                        if (k3 > i10) {
                            fVar2 = fVar4;
                            i10 = k3;
                        }
                        i5 += i6;
                    }
                }
                fVar = fVar2;
                d dVar = this.D;
                dVar.b(a2);
                dVar.f499a[a2] = fVar.f516e;
            } else {
                fVar = this.s[i8];
            }
            f fVar5 = fVar;
            cVar.f498e = fVar5;
            if (oVar.f2307e == 1) {
                r2 = 0;
                c(view, -1, false);
            } else {
                r2 = 0;
                c(view, 0, false);
            }
            if (this.v == 1) {
                p1(view, RecyclerView.m.z(this.w, this.n, r2, ((ViewGroup.MarginLayoutParams) cVar).width, r2), RecyclerView.m.z(this.q, this.o, M() + P(), ((ViewGroup.MarginLayoutParams) cVar).height, true), r2);
            } else {
                p1(view, RecyclerView.m.z(this.p, this.n, O() + N(), ((ViewGroup.MarginLayoutParams) cVar).width, true), RecyclerView.m.z(this.w, this.o, 0, ((ViewGroup.MarginLayoutParams) cVar).height, false), false);
            }
            if (oVar.f2307e == 1) {
                int h3 = fVar5.h(g2);
                c2 = h3;
                i3 = this.t.c(view) + h3;
            } else {
                int k4 = fVar5.k(g2);
                i3 = k4;
                c2 = k4 - this.t.c(view);
            }
            if (oVar.f2307e == 1) {
                cVar.f498e.a(view);
            } else {
                cVar.f498e.n(view);
            }
            if (o1() && this.v == 1) {
                c3 = this.u.g() - (((this.r - 1) - fVar5.f516e) * this.w);
                k = c3 - this.u.c(view);
            } else {
                k = this.u.k() + (fVar5.f516e * this.w);
                c3 = this.u.c(view) + k;
            }
            int i11 = c3;
            int i12 = k;
            if (this.v == 1) {
                Z(view, i12, c2, i11, i3);
            } else {
                Z(view, c2, i12, i3, i11);
            }
            B1(fVar5, this.x.f2307e, i2);
            t1(sVar, this.x);
            if (this.x.f2310h && view.hasFocusable()) {
                this.A.set(fVar5.f516e, false);
            }
            z2 = true;
            z = false;
        }
        if (!z2) {
            t1(sVar, this.x);
        }
        int k5 = this.x.f2307e == -1 ? this.t.k() - l1(this.t.k()) : k1(this.t.g()) - this.t.g();
        if (k5 > 0) {
            return Math.min(oVar.f2304b, k5);
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean e() {
        return this.v == 0;
    }

    public View e1(boolean z) {
        int k = this.t.k();
        int g2 = this.t.g();
        View view = null;
        for (int y = y() - 1; y >= 0; y--) {
            View x = x(y);
            int e2 = this.t.e(x);
            int b2 = this.t.b(x);
            if (b2 > k && e2 < g2) {
                if (b2 <= g2 || !z) {
                    return x;
                }
                if (view == null) {
                    view = x;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean f() {
        return this.v == 1;
    }

    public View f1(boolean z) {
        int k = this.t.k();
        int g2 = this.t.g();
        int y = y();
        View view = null;
        for (int i2 = 0; i2 < y; i2++) {
            View x = x(i2);
            int e2 = this.t.e(x);
            if (this.t.b(x) > k && e2 < g2) {
                if (e2 >= k || !z) {
                    return x;
                }
                if (view == null) {
                    view = x;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean g(RecyclerView.n nVar) {
        return nVar instanceof c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void g0(RecyclerView recyclerView, RecyclerView.s sVar) {
        f0();
        Runnable runnable = this.N;
        RecyclerView recyclerView2 = this.f423b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(runnable);
        }
        for (int i2 = 0; i2 < this.r; i2++) {
            this.s[i2].d();
        }
        recyclerView.requestLayout();
    }

    public final void g1(RecyclerView.s sVar, RecyclerView.x xVar, boolean z) {
        int g2;
        int k1 = k1(Integer.MIN_VALUE);
        if (k1 != Integer.MIN_VALUE && (g2 = this.t.g() - k1) > 0) {
            int i2 = g2 - (-x1(-g2, sVar, xVar));
            if (!z || i2 <= 0) {
                return;
            }
            this.t.p(i2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:110:0x0038, code lost:
    
        if (r8.v == 1) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:113:0x003d, code lost:
    
        if (r8.v == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x004c, code lost:
    
        if (o1() == false) goto L45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x0058, code lost:
    
        if (o1() == false) goto L46;
     */
    @Override // androidx.recyclerview.widget.RecyclerView.m
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View h0(android.view.View r9, int r10, androidx.recyclerview.widget.RecyclerView.s r11, androidx.recyclerview.widget.RecyclerView.x r12) {
        /*
            Method dump skipped, instructions count: 333
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.h0(android.view.View, int, androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$x):android.view.View");
    }

    public final void h1(RecyclerView.s sVar, RecyclerView.x xVar, boolean z) {
        int k;
        int l1 = l1(Integer.MAX_VALUE);
        if (l1 != Integer.MAX_VALUE && (k = l1 - this.t.k()) > 0) {
            int x1 = k - x1(k, sVar, xVar);
            if (!z || x1 <= 0) {
                return;
            }
            this.t.p(-x1);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i(int i2, int i3, RecyclerView.x xVar, RecyclerView.m.c cVar) {
        int h2;
        int i4;
        if (this.v != 0) {
            i2 = i3;
        }
        if (y() == 0 || i2 == 0) {
            return;
        }
        s1(i2, xVar);
        int[] iArr = this.M;
        if (iArr == null || iArr.length < this.r) {
            this.M = new int[this.r];
        }
        int i5 = 0;
        for (int i6 = 0; i6 < this.r; i6++) {
            o oVar = this.x;
            if (oVar.f2306d == -1) {
                h2 = oVar.f2308f;
                i4 = this.s[i6].k(h2);
            } else {
                h2 = this.s[i6].h(oVar.f2309g);
                i4 = this.x.f2309g;
            }
            int i7 = h2 - i4;
            if (i7 >= 0) {
                this.M[i5] = i7;
                i5++;
            }
        }
        Arrays.sort(this.M, 0, i5);
        for (int i8 = 0; i8 < i5; i8++) {
            int i9 = this.x.f2305c;
            if (!(i9 >= 0 && i9 < xVar.b())) {
                return;
            }
            ((n.b) cVar).a(this.x.f2305c, this.M[i8]);
            o oVar2 = this.x;
            oVar2.f2305c += oVar2.f2306d;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i0(AccessibilityEvent accessibilityEvent) {
        RecyclerView.s sVar = this.f423b.f393e;
        j0(accessibilityEvent);
        if (y() > 0) {
            View f1 = f1(false);
            View e1 = e1(false);
            if (f1 == null || e1 == null) {
                return;
            }
            int Q = Q(f1);
            int Q2 = Q(e1);
            if (Q < Q2) {
                accessibilityEvent.setFromIndex(Q);
                accessibilityEvent.setToIndex(Q2);
            } else {
                accessibilityEvent.setFromIndex(Q2);
                accessibilityEvent.setToIndex(Q);
            }
        }
    }

    public int i1() {
        if (y() == 0) {
            return 0;
        }
        return Q(x(0));
    }

    public int j1() {
        int y = y();
        if (y == 0) {
            return 0;
        }
        return Q(x(y - 1));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int k(RecyclerView.x xVar) {
        return a1(xVar);
    }

    public final int k1(int i2) {
        int h2 = this.s[0].h(i2);
        for (int i3 = 1; i3 < this.r; i3++) {
            int h3 = this.s[i3].h(i2);
            if (h3 > h2) {
                h2 = h3;
            }
        }
        return h2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int l(RecyclerView.x xVar) {
        return b1(xVar);
    }

    public final int l1(int i2) {
        int k = this.s[0].k(i2);
        for (int i3 = 1; i3 < this.r; i3++) {
            int k2 = this.s[i3].k(i2);
            if (k2 < k) {
                k = k2;
            }
        }
        return k;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int m(RecyclerView.x xVar) {
        return c1(xVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0043 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x003c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m1(int r7, int r8, int r9) {
        /*
            r6 = this;
            boolean r0 = r6.z
            if (r0 == 0) goto L9
            int r0 = r6.j1()
            goto Ld
        L9:
            int r0 = r6.i1()
        Ld:
            r1 = 8
            if (r9 != r1) goto L1a
            if (r7 >= r8) goto L16
            int r2 = r8 + 1
            goto L1c
        L16:
            int r2 = r7 + 1
            r3 = r8
            goto L1d
        L1a:
            int r2 = r7 + r8
        L1c:
            r3 = r7
        L1d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r4 = r6.D
            r4.d(r3)
            r4 = 1
            if (r9 == r4) goto L3c
            r5 = 2
            if (r9 == r5) goto L36
            if (r9 == r1) goto L2b
            goto L41
        L2b:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.D
            r9.f(r7, r4)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r6.D
            r7.e(r8, r4)
            goto L41
        L36:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.D
            r9.f(r7, r8)
            goto L41
        L3c:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.D
            r9.e(r7, r8)
        L41:
            if (r2 > r0) goto L44
            return
        L44:
            boolean r7 = r6.z
            if (r7 == 0) goto L4d
            int r7 = r6.i1()
            goto L51
        L4d:
            int r7 = r6.j1()
        L51:
            if (r3 > r7) goto L56
            r6.J0()
        L56:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.m1(int, int, int):void");
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int n(RecyclerView.x xVar) {
        return a1(xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void n0(RecyclerView recyclerView, int i2, int i3) {
        m1(i2, i3, 1);
    }

    /* JADX WARN: Code restructure failed: missing block: B:42:0x00bc, code lost:
    
        if (r10 == r11) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00d2, code lost:
    
        r10 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00d0, code lost:
    
        r10 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00ce, code lost:
    
        if (r10 == r11) goto L51;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View n1() {
        /*
            Method dump skipped, instructions count: 246
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.n1():android.view.View");
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int o(RecyclerView.x xVar) {
        return b1(xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void o0(RecyclerView recyclerView) {
        this.D.a();
        J0();
    }

    public boolean o1() {
        return J() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int p(RecyclerView.x xVar) {
        return c1(xVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void p0(RecyclerView recyclerView, int i2, int i3, int i4) {
        m1(i2, i3, 8);
    }

    public final void p1(View view, int i2, int i3, boolean z) {
        Rect rect = this.J;
        RecyclerView recyclerView = this.f423b;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.M(view));
        }
        c cVar = (c) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) cVar).leftMargin;
        Rect rect2 = this.J;
        int C1 = C1(i2, i4 + rect2.left, ((ViewGroup.MarginLayoutParams) cVar).rightMargin + rect2.right);
        int i5 = ((ViewGroup.MarginLayoutParams) cVar).topMargin;
        Rect rect3 = this.J;
        int C12 = C1(i3, i5 + rect3.top, ((ViewGroup.MarginLayoutParams) cVar).bottomMargin + rect3.bottom);
        if (z ? U0(view, C1, C12, cVar) : S0(view, C1, C12, cVar)) {
            view.measure(C1, C12);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void q0(RecyclerView recyclerView, int i2, int i3) {
        m1(i2, i3, 2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:256:0x0417, code lost:
    
        if (Z0() != false) goto L249;
     */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01b9  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void q1(androidx.recyclerview.widget.RecyclerView.s r12, androidx.recyclerview.widget.RecyclerView.x r13, boolean r14) {
        /*
            Method dump skipped, instructions count: 1081
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.q1(androidx.recyclerview.widget.RecyclerView$s, androidx.recyclerview.widget.RecyclerView$x, boolean):void");
    }

    public final boolean r1(int i2) {
        if (this.v == 0) {
            return (i2 == -1) != this.z;
        }
        return ((i2 == -1) == this.z) == o1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void s0(RecyclerView recyclerView, int i2, int i3, Object obj) {
        m1(i2, i3, 4);
    }

    public void s1(int i2, RecyclerView.x xVar) {
        int i1;
        int i3;
        if (i2 > 0) {
            i1 = j1();
            i3 = 1;
        } else {
            i1 = i1();
            i3 = -1;
        }
        this.x.f2303a = true;
        A1(i1, xVar);
        y1(i3);
        o oVar = this.x;
        oVar.f2305c = i1 + oVar.f2306d;
        oVar.f2304b = Math.abs(i2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void t0(RecyclerView.s sVar, RecyclerView.x xVar) {
        q1(sVar, xVar, true);
    }

    public final void t1(RecyclerView.s sVar, o oVar) {
        if (!oVar.f2303a || oVar.f2311i) {
            return;
        }
        if (oVar.f2304b == 0) {
            if (oVar.f2307e == -1) {
                u1(sVar, oVar.f2309g);
                return;
            } else {
                v1(sVar, oVar.f2308f);
                return;
            }
        }
        int i2 = 1;
        if (oVar.f2307e == -1) {
            int i3 = oVar.f2308f;
            int k = this.s[0].k(i3);
            while (i2 < this.r) {
                int k2 = this.s[i2].k(i3);
                if (k2 > k) {
                    k = k2;
                }
                i2++;
            }
            int i4 = i3 - k;
            u1(sVar, i4 < 0 ? oVar.f2309g : oVar.f2309g - Math.min(i4, oVar.f2304b));
            return;
        }
        int i5 = oVar.f2309g;
        int h2 = this.s[0].h(i5);
        while (i2 < this.r) {
            int h3 = this.s[i2].h(i5);
            if (h3 < h2) {
                h2 = h3;
            }
            i2++;
        }
        int i6 = h2 - oVar.f2309g;
        v1(sVar, i6 < 0 ? oVar.f2308f : Math.min(i6, oVar.f2304b) + oVar.f2308f);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n u() {
        return this.v == 0 ? new c(-2, -1) : new c(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void u0(RecyclerView.x xVar) {
        this.B = -1;
        this.C = Integer.MIN_VALUE;
        this.H = null;
        this.K.b();
    }

    public final void u1(RecyclerView.s sVar, int i2) {
        for (int y = y() - 1; y >= 0; y--) {
            View x = x(y);
            if (this.t.e(x) < i2 || this.t.o(x) < i2) {
                return;
            }
            c cVar = (c) x.getLayoutParams();
            Objects.requireNonNull(cVar);
            if (cVar.f498e.f512a.size() == 1) {
                return;
            }
            cVar.f498e.l();
            F0(x, sVar);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n v(Context context, AttributeSet attributeSet) {
        return new c(context, attributeSet);
    }

    public final void v1(RecyclerView.s sVar, int i2) {
        while (y() > 0) {
            View x = x(0);
            if (this.t.b(x) > i2 || this.t.n(x) > i2) {
                return;
            }
            c cVar = (c) x.getLayoutParams();
            Objects.requireNonNull(cVar);
            if (cVar.f498e.f512a.size() == 1) {
                return;
            }
            cVar.f498e.m();
            F0(x, sVar);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n w(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new c((ViewGroup.MarginLayoutParams) layoutParams) : new c(layoutParams);
    }

    public final void w1() {
        if (this.v == 1 || !o1()) {
            this.z = this.y;
        } else {
            this.z = !this.y;
        }
    }

    public int x1(int i2, RecyclerView.s sVar, RecyclerView.x xVar) {
        if (y() == 0 || i2 == 0) {
            return 0;
        }
        s1(i2, xVar);
        int d1 = d1(sVar, this.x, xVar);
        if (this.x.f2304b >= d1) {
            i2 = i2 < 0 ? -d1 : d1;
        }
        this.t.p(-i2);
        this.F = this.z;
        o oVar = this.x;
        oVar.f2304b = 0;
        t1(sVar, oVar);
        return i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void y0(Parcelable parcelable) {
        if (parcelable instanceof e) {
            e eVar = (e) parcelable;
            this.H = eVar;
            if (this.B != -1) {
                eVar.f508g = null;
                eVar.f507f = 0;
                eVar.f505d = -1;
                eVar.f506e = -1;
                eVar.f508g = null;
                eVar.f507f = 0;
                eVar.f509h = 0;
                eVar.f510i = null;
                eVar.f511j = null;
            }
            J0();
        }
    }

    public final void y1(int i2) {
        o oVar = this.x;
        oVar.f2307e = i2;
        oVar.f2306d = this.z != (i2 == -1) ? -1 : 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public Parcelable z0() {
        int k;
        int k2;
        int[] iArr;
        e eVar = this.H;
        if (eVar != null) {
            return new e(eVar);
        }
        e eVar2 = new e();
        eVar2.k = this.y;
        eVar2.l = this.F;
        eVar2.m = this.G;
        d dVar = this.D;
        if (dVar == null || (iArr = dVar.f499a) == null) {
            eVar2.f509h = 0;
        } else {
            eVar2.f510i = iArr;
            eVar2.f509h = iArr.length;
            eVar2.f511j = dVar.f500b;
        }
        if (y() > 0) {
            eVar2.f505d = this.F ? j1() : i1();
            View e1 = this.z ? e1(true) : f1(true);
            eVar2.f506e = e1 != null ? Q(e1) : -1;
            int i2 = this.r;
            eVar2.f507f = i2;
            eVar2.f508g = new int[i2];
            for (int i3 = 0; i3 < this.r; i3++) {
                if (this.F) {
                    k = this.s[i3].h(Integer.MIN_VALUE);
                    if (k != Integer.MIN_VALUE) {
                        k2 = this.t.g();
                        k -= k2;
                        eVar2.f508g[i3] = k;
                    } else {
                        eVar2.f508g[i3] = k;
                    }
                } else {
                    k = this.s[i3].k(Integer.MIN_VALUE);
                    if (k != Integer.MIN_VALUE) {
                        k2 = this.t.k();
                        k -= k2;
                        eVar2.f508g[i3] = k;
                    } else {
                        eVar2.f508g[i3] = k;
                    }
                }
            }
        } else {
            eVar2.f505d = -1;
            eVar2.f506e = -1;
            eVar2.f507f = 0;
        }
        return eVar2;
    }

    public final void z1(int i2, int i3) {
        for (int i4 = 0; i4 < this.r; i4++) {
            if (!this.s[i4].f512a.isEmpty()) {
                B1(this.s[i4], i2, i3);
            }
        }
    }
}
