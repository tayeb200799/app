package androidx.media;

import android.media.AudioAttributes;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImplApi26.smali */
public class AudioAttributesImplApi26 extends AudioAttributesImplApi21 {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImplApi26$a.smali */
    public static class a extends AudioAttributesImplApi21$a {
        @Override // androidx.media.AudioAttributesImplApi21$a, androidx.media.AudioAttributesImpl.a
        public AudioAttributesImpl a() {
            return new AudioAttributesImplApi26(this.f364a.build());
        }
    }

    public AudioAttributesImplApi26() {
    }

    public AudioAttributesImplApi26(AudioAttributes audioAttributes) {
        super(audioAttributes, -1);
    }
}
