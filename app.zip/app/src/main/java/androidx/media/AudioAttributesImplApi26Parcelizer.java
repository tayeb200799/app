package androidx.media;

import android.media.AudioAttributes;
import b.a0.b;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImplApi26Parcelizer.smali */
public class AudioAttributesImplApi26Parcelizer {
    public static AudioAttributesImplApi26 read(b bVar) {
        AudioAttributesImplApi26 audioAttributesImplApi26 = new AudioAttributesImplApi26();
        ((AudioAttributesImplApi21) audioAttributesImplApi26).a = (AudioAttributes) bVar.m(((AudioAttributesImplApi21) audioAttributesImplApi26).a, 1);
        ((AudioAttributesImplApi21) audioAttributesImplApi26).b = bVar.k(((AudioAttributesImplApi21) audioAttributesImplApi26).b, 2);
        return audioAttributesImplApi26;
    }

    public static void write(AudioAttributesImplApi26 audioAttributesImplApi26, b bVar) {
        Objects.requireNonNull(bVar);
        AudioAttributes audioAttributes = ((AudioAttributesImplApi21) audioAttributesImplApi26).a;
        bVar.p(1);
        bVar.u(audioAttributes);
        int i2 = ((AudioAttributesImplApi21) audioAttributesImplApi26).b;
        bVar.p(2);
        bVar.t(i2);
    }
}
