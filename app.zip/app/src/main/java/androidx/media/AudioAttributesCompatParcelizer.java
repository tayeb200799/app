package androidx.media;

import b.a0.d;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImpl.smali */
public interface AudioAttributesImpl extends d {

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImpl$a.smali */
    public interface a {
        AudioAttributesImpl a();
    }
}
