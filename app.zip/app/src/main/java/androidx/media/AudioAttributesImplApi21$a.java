package androidx.media;

import android.media.AudioAttributes;
import androidx.media.AudioAttributesImpl;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImplApi21$a.smali */
public class AudioAttributesImplApi21$a implements AudioAttributesImpl.a {

    /* renamed from: a, reason: collision with root package name */
    public final AudioAttributes.Builder f364a = new AudioAttributes.Builder();

    @Override // androidx.media.AudioAttributesImpl.a
    public AudioAttributesImpl a() {
        return new AudioAttributesImplApi21(this.f364a.build());
    }
}
