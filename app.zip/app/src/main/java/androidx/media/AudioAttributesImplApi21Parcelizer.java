package androidx.media;

import android.media.AudioAttributes;
import b.a0.b;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImplApi21Parcelizer.smali */
public class AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(b bVar) {
        AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
        audioAttributesImplApi21.a = (AudioAttributes) bVar.m(audioAttributesImplApi21.a, 1);
        audioAttributesImplApi21.b = bVar.k(audioAttributesImplApi21.b, 2);
        return audioAttributesImplApi21;
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, b bVar) {
        Objects.requireNonNull(bVar);
        AudioAttributes audioAttributes = audioAttributesImplApi21.a;
        bVar.p(1);
        bVar.u(audioAttributes);
        int i2 = audioAttributesImplApi21.b;
        bVar.p(2);
        bVar.t(i2);
    }
}
