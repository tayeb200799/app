package androidx.media;

import b.a0.b;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesCompatParcelizer.smali */
public class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(b bVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        Object obj = audioAttributesCompat.f361a;
        if (bVar.i(1)) {
            obj = bVar.o();
        }
        audioAttributesCompat.f361a = (AudioAttributesImpl) obj;
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, b bVar) {
        Objects.requireNonNull(bVar);
        AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.f361a;
        bVar.p(1);
        bVar.w(audioAttributesImpl);
    }
}
