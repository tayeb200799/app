package androidx.media;

import b.a0.b;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\media\AudioAttributesImplBaseParcelizer.smali */
public class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(b bVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        audioAttributesImplBase.f365a = bVar.k(audioAttributesImplBase.f365a, 1);
        audioAttributesImplBase.f366b = bVar.k(audioAttributesImplBase.f366b, 2);
        audioAttributesImplBase.f367c = bVar.k(audioAttributesImplBase.f367c, 3);
        audioAttributesImplBase.f368d = bVar.k(audioAttributesImplBase.f368d, 4);
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, b bVar) {
        Objects.requireNonNull(bVar);
        int i2 = audioAttributesImplBase.f365a;
        bVar.p(1);
        bVar.t(i2);
        int i3 = audioAttributesImplBase.f366b;
        bVar.p(2);
        bVar.t(i3);
        int i4 = audioAttributesImplBase.f367c;
        bVar.p(3);
        bVar.t(i4);
        int i5 = audioAttributesImplBase.f368d;
        bVar.p(4);
        bVar.t(i5);
    }
}
