package androidx.databinding;

import b.k.a;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\databinding\MergedDataBinderMapper.smali */
public class MergedDataBinderMapper extends a {

    /* renamed from: a, reason: collision with root package name */
    public Set<Class<? extends a>> f311a = new HashSet();

    /* renamed from: b, reason: collision with root package name */
    public List<a> f312b = new CopyOnWriteArrayList();

    public MergedDataBinderMapper() {
        new CopyOnWriteArrayList();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void b(a aVar) {
        if (this.f311a.add(aVar.getClass())) {
            this.f312b.add(aVar);
            Iterator<a> it = aVar.a().iterator();
            while (it.hasNext()) {
                b(it.next());
            }
        }
    }
}
