package androidx.databinding;

import b.p.g;
import b.p.j;
import b.p.r;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\databinding\ViewDataBinding$OnStartListener.smali */
public class ViewDataBinding$OnStartListener implements j {
    @r(g.a.ON_START)
    public void onStart() {
        throw null;
    }
}
