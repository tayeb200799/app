package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import b.n.c.e;
import b.n.c.o;
import b.n.c.o0;
import b.n.c.r;
import b.n.c.t;
import b.n.c.v;
import b.p.a0;
import b.p.f;
import b.p.g;
import b.p.i;
import b.p.k;
import b.p.l;
import b.p.p;
import b.p.w;
import b.p.y;
import b.p.z;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Objects;
import java.util.UUID;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\fragment\app\Fragment.smali */
public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, k, a0, f, b.v.c {
    public static final Object W = new Object();
    public String A;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean F;
    public ViewGroup G;
    public View H;
    public boolean I;
    public a K;
    public boolean L;
    public boolean M;
    public float N;
    public LayoutInflater O;
    public boolean P;
    public l R;
    public o0 S;
    public y.b U;
    public b.v.b V;

    /* renamed from: e, reason: collision with root package name */
    public Bundle f314e;

    /* renamed from: f, reason: collision with root package name */
    public SparseArray<Parcelable> f315f;

    /* renamed from: g, reason: collision with root package name */
    public Boolean f316g;

    /* renamed from: i, reason: collision with root package name */
    public Bundle f318i;

    /* renamed from: j, reason: collision with root package name */
    public Fragment f319j;
    public int l;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;
    public boolean r;
    public boolean s;
    public int t;
    public r u;
    public o<?> v;
    public Fragment x;
    public int y;
    public int z;

    /* renamed from: d, reason: collision with root package name */
    public int f313d = -1;

    /* renamed from: h, reason: collision with root package name */
    public String f317h = UUID.randomUUID().toString();
    public String k = null;
    public Boolean m = null;
    public r w = new t();
    public boolean E = true;
    public boolean J = true;
    public g.b Q = g.b.RESUMED;
    public p<k> T = new p<>();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\fragment\app\Fragment$a.smali */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public View f321a;

        /* renamed from: b, reason: collision with root package name */
        public Animator f322b;

        /* renamed from: c, reason: collision with root package name */
        public int f323c;

        /* renamed from: d, reason: collision with root package name */
        public int f324d;

        /* renamed from: e, reason: collision with root package name */
        public int f325e;

        /* renamed from: f, reason: collision with root package name */
        public Object f326f;

        /* renamed from: g, reason: collision with root package name */
        public Object f327g;

        /* renamed from: h, reason: collision with root package name */
        public Object f328h;

        /* renamed from: i, reason: collision with root package name */
        public c f329i;

        /* renamed from: j, reason: collision with root package name */
        public boolean f330j;

        public a() {
            Object obj = Fragment.W;
            this.f326f = obj;
            this.f327g = obj;
            this.f328h = obj;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\fragment\app\Fragment$b.smali */
    public static class b extends RuntimeException {
        public b(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\fragment\app\Fragment$c.smali */
    public interface c {
    }

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\fragment\app\Fragment$d.smali */
    public static class d implements Parcelable {
        public static final Parcelable.Creator<d> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public final Bundle f331d;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\fragment\app\Fragment$d$a.smali */
        public static class a implements Parcelable.ClassLoaderCreator<d> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new d(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public d createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new d(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new d[i2];
            }
        }

        public d(Bundle bundle) {
            this.f331d = bundle;
        }

        public d(Parcel parcel, ClassLoader classLoader) {
            Bundle readBundle = parcel.readBundle();
            this.f331d = readBundle;
            if (classLoader == null || readBundle == null) {
                return;
            }
            readBundle.setClassLoader(classLoader);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeBundle(this.f331d);
        }
    }

    public Fragment() {
        N();
    }

    public Object A() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        Objects.requireNonNull(aVar);
        return null;
    }

    @Deprecated
    public void A0(boolean z) {
        if (!this.J && z && this.f313d < 3 && this.u != null && O() && this.P) {
            this.u.V(this);
        }
        this.J = z;
        this.I = this.f313d < 3 && !z;
        if (this.f314e != null) {
            this.f316g = Boolean.valueOf(z);
        }
    }

    public void B() {
        a aVar = this.K;
        if (aVar == null) {
            return;
        }
        Objects.requireNonNull(aVar);
    }

    public void B0(@SuppressLint({"UnknownNullness"}) Intent intent) {
        o<?> oVar = this.v;
        if (oVar == null) {
            throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " not attached to Activity"));
        }
        oVar.l(this, intent, -1, null);
    }

    public Object C() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        Objects.requireNonNull(aVar);
        return null;
    }

    public int D() {
        a aVar = this.K;
        if (aVar == null) {
            return 0;
        }
        return aVar.f324d;
    }

    public final r E() {
        r rVar = this.u;
        if (rVar != null) {
            return rVar;
        }
        throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " not associated with a fragment manager."));
    }

    public Object F() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.f327g;
        if (obj != W) {
            return obj;
        }
        C();
        return null;
    }

    public final Resources G() {
        return q0().getResources();
    }

    public Object H() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.f326f;
        if (obj != W) {
            return obj;
        }
        A();
        return null;
    }

    public Object I() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        Objects.requireNonNull(aVar);
        return null;
    }

    public Object J() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        Object obj = aVar.f328h;
        if (obj != W) {
            return obj;
        }
        I();
        return null;
    }

    public int K() {
        a aVar = this.K;
        if (aVar == null) {
            return 0;
        }
        return aVar.f323c;
    }

    public final String L(int i2) {
        return G().getString(i2);
    }

    public k M() {
        o0 o0Var = this.S;
        if (o0Var != null) {
            return o0Var;
        }
        throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
    }

    public final void N() {
        this.R = new l(this);
        this.V = new b.v.b(this);
        this.R.a(new i() { // from class: androidx.fragment.app.Fragment.2
            @Override // b.p.i
            public void d(k kVar, g.a aVar) {
                View view;
                if (aVar != g.a.ON_STOP || (view = Fragment.this.H) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
            }
        });
    }

    public final boolean O() {
        return this.v != null && this.n;
    }

    public boolean P() {
        a aVar = this.K;
        if (aVar == null) {
            return false;
        }
        return aVar.f330j;
    }

    public final boolean Q() {
        return this.t > 0;
    }

    public final boolean R() {
        Fragment fragment = this.x;
        return fragment != null && (fragment.o || fragment.R());
    }

    public final boolean S() {
        View view;
        return (!O() || this.B || (view = this.H) == null || view.getWindowToken() == null || this.H.getVisibility() != 0) ? false : true;
    }

    public void T(Bundle bundle) {
        this.F = true;
    }

    public void U(int i2, int i3, Intent intent) {
    }

    public void V(Context context) {
        this.F = true;
        o<?> oVar = this.v;
        if ((oVar == null ? null : oVar.f2045d) != null) {
            this.F = false;
            this.F = true;
        }
    }

    public void W(Bundle bundle) {
        Parcelable parcelable;
        this.F = true;
        if (bundle != null && (parcelable = bundle.getParcelable("android:support:fragments")) != null) {
            this.w.b0(parcelable);
            this.w.l();
        }
        r rVar = this.w;
        if (rVar.m >= 1) {
            return;
        }
        rVar.l();
    }

    public View X(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    public void Y() {
        this.F = true;
    }

    public void Z() {
        this.F = true;
    }

    @Override // b.p.k
    public g a() {
        return this.R;
    }

    public void a0() {
        this.F = true;
    }

    public LayoutInflater b0(Bundle bundle) {
        o<?> oVar = this.v;
        if (oVar == null) {
            throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
        }
        LayoutInflater i2 = oVar.i();
        i2.setFactory2(this.w.f2058f);
        return i2;
    }

    public void c0(AttributeSet attributeSet, Bundle bundle) {
        this.F = true;
        o<?> oVar = this.v;
        if ((oVar == null ? null : oVar.f2045d) != null) {
            this.F = false;
            this.F = true;
        }
    }

    @Override // b.v.c
    public final b.v.a d() {
        return this.V.f2432b;
    }

    public void d0() {
        this.F = true;
    }

    public void e0(int i2, String[] strArr, int[] iArr) {
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public void f0() {
        this.F = true;
    }

    public void g0(Bundle bundle) {
    }

    public void h0() {
        this.F = true;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public void i0() {
        this.F = true;
    }

    public void j0(View view, Bundle bundle) {
    }

    public void k0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.w.U();
        this.s = true;
        this.S = new o0();
        View X = X(layoutInflater, viewGroup, bundle);
        this.H = X;
        if (X == null) {
            if (this.S.f2049d != null) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.S = null;
        } else {
            o0 o0Var = this.S;
            if (o0Var.f2049d == null) {
                o0Var.f2049d = new l(o0Var);
            }
            this.T.i(this.S);
        }
    }

    @Override // b.p.f
    public y.b l() {
        if (this.u == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (this.U == null) {
            this.U = new w(p0().getApplication(), this, this.f318i);
        }
        return this.U;
    }

    public LayoutInflater l0(Bundle bundle) {
        LayoutInflater b0 = b0(bundle);
        this.O = b0;
        return b0;
    }

    public void m0() {
        this.F = true;
        this.w.o();
    }

    public void n(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String str2;
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.y));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.z));
        printWriter.print(" mTag=");
        printWriter.println(this.A);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f313d);
        printWriter.print(" mWho=");
        printWriter.print(this.f317h);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.t);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.n);
        printWriter.print(" mRemoving=");
        printWriter.print(this.o);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.p);
        printWriter.print(" mInLayout=");
        printWriter.println(this.q);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.B);
        printWriter.print(" mDetached=");
        printWriter.print(this.C);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.E);
        printWriter.print(" mHasMenu=");
        printWriter.println(false);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.D);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.J);
        if (this.u != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.u);
        }
        if (this.v != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.v);
        }
        if (this.x != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.x);
        }
        if (this.f318i != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.f318i);
        }
        if (this.f314e != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.f314e);
        }
        if (this.f315f != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.f315f);
        }
        Fragment fragment = this.f319j;
        if (fragment == null) {
            r rVar = this.u;
            fragment = (rVar == null || (str2 = this.k) == null) ? null : rVar.E(str2);
        }
        if (fragment != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(fragment);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.l);
        }
        if (D() != 0) {
            printWriter.print(str);
            printWriter.print("mNextAnim=");
            printWriter.println(D());
        }
        if (this.G != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.G);
        }
        if (this.H != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.H);
        }
        if (x() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(x());
            printWriter.print(str);
            printWriter.print("mStateAfterAnimating=");
            printWriter.println(K());
        }
        if (z() != null) {
            b.q.a.a.b(this).a(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.w + ":");
        this.w.x(c.a.a.a.a.f(str, "  "), fileDescriptor, printWriter, strArr);
    }

    public boolean n0(Menu menu) {
        if (this.B) {
            return false;
        }
        return false | this.w.u(menu);
    }

    public final void o0(String[] strArr, int i2) {
        o<?> oVar = this.v;
        if (oVar == null) {
            throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " not attached to Activity"));
        }
        oVar.j(this, strArr, i2);
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.F = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        p0().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
        this.F = true;
    }

    public final e p0() {
        e w = w();
        if (w != null) {
            return w;
        }
        throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " not attached to an activity."));
    }

    @Override // b.p.a0
    public z q() {
        r rVar = this.u;
        if (rVar == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        v vVar = rVar.B;
        z zVar = vVar.f2084e.get(this.f317h);
        if (zVar != null) {
            return zVar;
        }
        z zVar2 = new z();
        vVar.f2084e.put(this.f317h, zVar2);
        return zVar2;
    }

    public final Context q0() {
        Context z = z();
        if (z != null) {
            return z;
        }
        throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " not attached to a context."));
    }

    public final View r0() {
        View view = this.H;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }

    public void s0(View view) {
        v().f321a = view;
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        o<?> oVar = this.v;
        if (oVar == null) {
            throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " not attached to Activity"));
        }
        oVar.l(this, intent, i2, null);
    }

    public void t0(Animator animator) {
        v().f322b = animator;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.f317h);
        sb.append(")");
        if (this.y != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.y));
        }
        if (this.A != null) {
            sb.append(" ");
            sb.append(this.A);
        }
        sb.append('}');
        return sb.toString();
    }

    public void u0(Bundle bundle) {
        r rVar = this.u;
        if (rVar != null) {
            if (rVar == null ? false : rVar.P()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.f318i = bundle;
    }

    public final a v() {
        if (this.K == null) {
            this.K = new a();
        }
        return this.K;
    }

    public void v0(boolean z) {
        v().f330j = z;
    }

    public final e w() {
        o<?> oVar = this.v;
        if (oVar == null) {
            return null;
        }
        return (e) oVar.f2045d;
    }

    public void w0(boolean z) {
        if (this.E != z) {
            this.E = z;
        }
    }

    public View x() {
        a aVar = this.K;
        if (aVar == null) {
            return null;
        }
        return aVar.f321a;
    }

    public void x0(int i2) {
        if (this.K == null && i2 == 0) {
            return;
        }
        v().f324d = i2;
    }

    public final r y() {
        if (this.v != null) {
            return this.w;
        }
        throw new IllegalStateException(c.a.a.a.a.e("Fragment ", this, " has not been attached yet."));
    }

    public void y0(c cVar) {
        v();
        c cVar2 = this.K.f329i;
        if (cVar == cVar2) {
            return;
        }
        if (cVar != null && cVar2 != null) {
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
        if (cVar != null) {
            ((r.g) cVar).f2072c++;
        }
    }

    public Context z() {
        o<?> oVar = this.v;
        if (oVar == null) {
            return null;
        }
        return oVar.f2046e;
    }

    public void z0(int i2) {
        v().f323c = i2;
    }
}
