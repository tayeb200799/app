package androidx.databinding.library.baseAdapters;

import android.util.SparseIntArray;
import b.k.a;
import java.util.ArrayList;
import java.util.List;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\databinding\library\baseAdapters\DataBinderMapperImpl.smali */
public class DataBinderMapperImpl extends a {
    static {
        new SparseIntArray(0);
    }

    @Override // b.k.a
    public List<a> a() {
        return new ArrayList(0);
    }
}
