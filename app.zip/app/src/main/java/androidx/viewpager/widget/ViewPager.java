package androidx.viewpager.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import b.b0.a.a;
import b.h.d.a;
import b.h.k.q;
import b.h.k.y.b;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager.smali */
public class ViewPager extends ViewGroup {
    public static final int[] g0 = {R.attr.layout_gravity};
    public static final Comparator<e> h0 = new a();
    public static final Interpolator i0 = new b();
    public static final m j0 = new m();
    public boolean A;
    public boolean B;
    public int C;
    public int D;
    public int E;
    public float F;
    public float G;
    public float H;
    public float I;
    public int J;
    public VelocityTracker K;
    public int L;
    public int M;
    public int N;
    public int O;
    public EdgeEffect P;
    public EdgeEffect Q;
    public boolean R;
    public boolean S;
    public int T;
    public List<i> U;
    public i V;
    public List<h> W;
    public j a0;
    public int b0;
    public int c0;

    /* renamed from: d, reason: collision with root package name */
    public int f542d;
    public ArrayList<View> d0;

    /* renamed from: e, reason: collision with root package name */
    public final ArrayList<e> f543e;
    public final Runnable e0;

    /* renamed from: f, reason: collision with root package name */
    public final e f544f;
    public int f0;

    /* renamed from: g, reason: collision with root package name */
    public final Rect f545g;

    /* renamed from: h, reason: collision with root package name */
    public a f546h;

    /* renamed from: i, reason: collision with root package name */
    public int f547i;

    /* renamed from: j, reason: collision with root package name */
    public int f548j;
    public Parcelable k;
    public ClassLoader l;
    public Scroller m;
    public boolean n;
    public k o;
    public int p;
    public Drawable q;
    public int r;
    public int s;
    public float t;
    public float u;
    public int v;
    public boolean w;
    public boolean x;
    public boolean y;
    public int z;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$c.smali */
    public class c implements Runnable {
        public c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ViewPager.this.setScrollState(0);
            ViewPager viewPager = ViewPager.this;
            viewPager.r(viewPager.f547i);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$e.smali */
    public static class e {

        /* renamed from: a, reason: collision with root package name */
        public Object f550a;

        /* renamed from: b, reason: collision with root package name */
        public int f551b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f552c;

        /* renamed from: d, reason: collision with root package name */
        public float f553d;

        /* renamed from: e, reason: collision with root package name */
        public float f554e;
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$f.smali */
    public static class f extends ViewGroup.LayoutParams {

        /* renamed from: a, reason: collision with root package name */
        public boolean f555a;

        /* renamed from: b, reason: collision with root package name */
        public int f556b;

        /* renamed from: c, reason: collision with root package name */
        public float f557c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f558d;

        /* renamed from: e, reason: collision with root package name */
        public int f559e;

        /* renamed from: f, reason: collision with root package name */
        public int f560f;

        public f() {
            super(-1, -1);
            this.f557c = 0.0f;
        }

        public f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f557c = 0.0f;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.g0);
            this.f556b = obtainStyledAttributes.getInteger(0, 48);
            obtainStyledAttributes.recycle();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$g.smali */
    public class g extends b.h.k.a {
        public g() {
        }

        @Override // b.h.k.a
        public void c(View view, AccessibilityEvent accessibilityEvent) {
            a aVar;
            this.f1718a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
            a aVar2 = ViewPager.this.f546h;
            accessibilityEvent.setScrollable(aVar2 != null && aVar2.getCount() > 1);
            if (accessibilityEvent.getEventType() != 4096 || (aVar = ViewPager.this.f546h) == null) {
                return;
            }
            accessibilityEvent.setItemCount(aVar.getCount());
            accessibilityEvent.setFromIndex(ViewPager.this.f547i);
            accessibilityEvent.setToIndex(ViewPager.this.f547i);
        }

        @Override // b.h.k.a
        public void d(View view, b bVar) {
            this.f1718a.onInitializeAccessibilityNodeInfo(view, bVar.f1790a);
            bVar.f1790a.setClassName(ViewPager.class.getName());
            a aVar = ViewPager.this.f546h;
            bVar.f1790a.setScrollable(aVar != null && aVar.getCount() > 1);
            if (ViewPager.this.canScrollHorizontally(1)) {
                bVar.f1790a.addAction(4096);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                bVar.f1790a.addAction(8192);
            }
        }

        @Override // b.h.k.a
        public boolean g(View view, int i2, Bundle bundle) {
            if (super.g(view, i2, bundle)) {
                return true;
            }
            if (i2 == 4096) {
                if (!ViewPager.this.canScrollHorizontally(1)) {
                    return false;
                }
                ViewPager viewPager = ViewPager.this;
                viewPager.setCurrentItem(viewPager.f547i + 1);
                return true;
            }
            if (i2 != 8192 || !ViewPager.this.canScrollHorizontally(-1)) {
                return false;
            }
            ViewPager viewPager2 = ViewPager.this;
            viewPager2.setCurrentItem(viewPager2.f547i - 1);
            return true;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$h.smali */
    public interface h {
        void a(ViewPager viewPager, a aVar, a aVar2);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$i.smali */
    public interface i {
        void b(int i2, float f2, int i3);

        void f(int i2);

        void g(int i2);
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$j.smali */
    public interface j {
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$k.smali */
    public class k extends DataSetObserver {
        public k() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            ViewPager.this.f();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            ViewPager.this.f();
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$l.smali */
    public static class l extends b.j.a.a {
        public static final Parcelable.Creator<l> CREATOR = new a();

        /* renamed from: f, reason: collision with root package name */
        public int f563f;

        /* renamed from: g, reason: collision with root package name */
        public Parcelable f564g;

        /* renamed from: h, reason: collision with root package name */
        public ClassLoader f565h;

        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$l$a.smali */
        public static class a implements Parcelable.ClassLoaderCreator<l> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new l(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public l createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new l(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i2) {
                return new l[i2];
            }
        }

        public l(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? l.class.getClassLoader() : classLoader;
            this.f563f = parcel.readInt();
            this.f564g = parcel.readParcelable(classLoader);
            this.f565h = classLoader;
        }

        public l(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder n = c.a.a.a.a.n("FragmentPager.SavedState{");
            n.append(Integer.toHexString(System.identityHashCode(this)));
            n.append(" position=");
            n.append(this.f563f);
            n.append("}");
            return n.toString();
        }

        @Override // b.j.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.f1843d, i2);
            parcel.writeInt(this.f563f);
            parcel.writeParcelable(this.f564g, i2);
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\viewpager\widget\ViewPager$m.smali */
    public static class m implements Comparator<View> {
        @Override // java.util.Comparator
        public int compare(View view, View view2) {
            f fVar = (f) view.getLayoutParams();
            f fVar2 = (f) view2.getLayoutParams();
            boolean z = fVar.f555a;
            return z != fVar2.f555a ? z ? 1 : -1 : fVar.f559e - fVar2.f559e;
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f543e = new ArrayList<>();
        this.f544f = new e();
        this.f545g = new Rect();
        this.f548j = -1;
        this.k = null;
        this.l = null;
        this.t = -3.4028235E38f;
        this.u = Float.MAX_VALUE;
        this.z = 1;
        this.J = -1;
        this.R = true;
        this.e0 = new c();
        this.f0 = 0;
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context2 = getContext();
        this.m = new Scroller(context2, i0);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context2);
        float f2 = context2.getResources().getDisplayMetrics().density;
        this.E = viewConfiguration.getScaledPagingTouchSlop();
        this.L = (int) (400.0f * f2);
        this.M = viewConfiguration.getScaledMaximumFlingVelocity();
        this.P = new EdgeEffect(context2);
        this.Q = new EdgeEffect(context2);
        this.N = (int) (25.0f * f2);
        this.O = (int) (2.0f * f2);
        this.C = (int) (f2 * 16.0f);
        q.t(this, new g());
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        q.u(this, new b.b0.a.b(this));
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.x != z) {
            this.x = z;
        }
    }

    public e a(int i2, int i3) {
        e eVar = new e();
        eVar.f551b = i2;
        eVar.f550a = this.f546h.g(this, i2);
        Objects.requireNonNull(this.f546h);
        eVar.f553d = 1.0f;
        if (i3 < 0 || i3 >= this.f543e.size()) {
            this.f543e.add(eVar);
        } else {
            this.f543e.add(i3, eVar);
        }
        return eVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        e i4;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i5 = 0; i5 < getChildCount(); i5++) {
                View childAt = getChildAt(i5);
                if (childAt.getVisibility() == 0 && (i4 = i(childAt)) != null && i4.f551b == this.f547i) {
                    childAt.addFocusables(arrayList, i2, i3);
                }
            }
        }
        if ((descendantFocusability != 262144 || size == arrayList.size()) && isFocusable()) {
            if ((i3 & 1) == 1 && isInTouchMode() && !isFocusableInTouchMode()) {
                return;
            }
            arrayList.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addTouchables(ArrayList<View> arrayList) {
        e i2;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (i2 = i(childAt)) != null && i2.f551b == this.f547i) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        f fVar = (f) layoutParams;
        boolean z = fVar.f555a | (view.getClass().getAnnotation(d.class) != null);
        fVar.f555a = z;
        if (!this.w) {
            super.addView(view, i2, layoutParams);
        } else {
            if (z) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            fVar.f558d = true;
            addViewInLayout(view, i2, layoutParams);
        }
    }

    public void b(i iVar) {
        if (this.U == null) {
            this.U = new ArrayList();
        }
        this.U.add(iVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00ca  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean c(int r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.findFocus()
            r1 = 1
            r2 = 0
            r3 = 0
            if (r0 != r6) goto La
            goto L63
        La:
            if (r0 == 0) goto L64
            android.view.ViewParent r4 = r0.getParent()
        L10:
            boolean r5 = r4 instanceof android.view.ViewGroup
            if (r5 == 0) goto L1d
            if (r4 != r6) goto L18
            r4 = 1
            goto L1e
        L18:
            android.view.ViewParent r4 = r4.getParent()
            goto L10
        L1d:
            r4 = 0
        L1e:
            if (r4 != 0) goto L64
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.Class r5 = r0.getClass()
            java.lang.String r5 = r5.getSimpleName()
            r4.append(r5)
            android.view.ViewParent r0 = r0.getParent()
        L34:
            boolean r5 = r0 instanceof android.view.ViewGroup
            if (r5 == 0) goto L4d
            java.lang.String r5 = " => "
            r4.append(r5)
            java.lang.Class r5 = r0.getClass()
            java.lang.String r5 = r5.getSimpleName()
            r4.append(r5)
            android.view.ViewParent r0 = r0.getParent()
            goto L34
        L4d:
            java.lang.String r0 = "arrowScroll tried to find focus based on non-child current focused view "
            java.lang.StringBuilder r0 = c.a.a.a.a.n(r0)
            java.lang.String r4 = r4.toString()
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            java.lang.String r4 = "ViewPager"
            android.util.Log.e(r4, r0)
        L63:
            r0 = r3
        L64:
            android.view.FocusFinder r3 = android.view.FocusFinder.getInstance()
            android.view.View r3 = r3.findNextFocus(r6, r0, r7)
            r4 = 66
            r5 = 17
            if (r3 == 0) goto Lb5
            if (r3 == r0) goto Lb5
            if (r7 != r5) goto L95
            android.graphics.Rect r1 = r6.f545g
            android.graphics.Rect r1 = r6.h(r1, r3)
            int r1 = r1.left
            android.graphics.Rect r2 = r6.f545g
            android.graphics.Rect r2 = r6.h(r2, r0)
            int r2 = r2.left
            if (r0 == 0) goto L8f
            if (r1 < r2) goto L8f
            boolean r0 = r6.n()
            goto L93
        L8f:
            boolean r0 = r3.requestFocus()
        L93:
            r2 = r0
            goto Lc8
        L95:
            if (r7 != r4) goto Lc8
            android.graphics.Rect r1 = r6.f545g
            android.graphics.Rect r1 = r6.h(r1, r3)
            int r1 = r1.left
            android.graphics.Rect r2 = r6.f545g
            android.graphics.Rect r2 = r6.h(r2, r0)
            int r2 = r2.left
            if (r0 == 0) goto Lb0
            if (r1 > r2) goto Lb0
            boolean r0 = r6.o()
            goto L93
        Lb0:
            boolean r0 = r3.requestFocus()
            goto L93
        Lb5:
            if (r7 == r5) goto Lc4
            if (r7 != r1) goto Lba
            goto Lc4
        Lba:
            if (r7 == r4) goto Lbf
            r0 = 2
            if (r7 != r0) goto Lc8
        Lbf:
            boolean r2 = r6.o()
            goto Lc8
        Lc4:
            boolean r2 = r6.n()
        Lc8:
            if (r2 == 0) goto Ld1
            int r7 = android.view.SoundEffectConstants.getContantForFocusDirection(r7)
            r6.playSoundEffect(r7)
        Ld1:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.c(int):boolean");
    }

    @Override // android.view.View
    public boolean canScrollHorizontally(int i2) {
        if (this.f546h == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        return i2 < 0 ? scrollX > ((int) (((float) clientWidth) * this.t)) : i2 > 0 && scrollX < ((int) (((float) clientWidth) * this.u));
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof f) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void computeScroll() {
        this.n = true;
        if (this.m.isFinished() || !this.m.computeScrollOffset()) {
            e(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.m.getCurrX();
        int currY = this.m.getCurrY();
        if (scrollX != currX || scrollY != currY) {
            scrollTo(currX, currY);
            if (!p(currX)) {
                this.m.abortAnimation();
                scrollTo(0, currY);
            }
        }
        AtomicInteger atomicInteger = q.f1738a;
        postInvalidateOnAnimation();
    }

    public boolean d(View view, boolean z, int i2, int i3, int i4) {
        int i5;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i6 = i3 + scrollX;
                if (i6 >= childAt.getLeft() && i6 < childAt.getRight() && (i5 = i4 + scrollY) >= childAt.getTop() && i5 < childAt.getBottom() && d(childAt, true, i2, i6 - childAt.getLeft(), i5 - childAt.getTop())) {
                    return true;
                }
            }
        }
        return z && view.canScrollHorizontally(-i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:15:? A[RETURN, SYNTHETIC] */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean dispatchKeyEvent(android.view.KeyEvent r6) {
        /*
            r5 = this;
            boolean r0 = super.dispatchKeyEvent(r6)
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L5d
            int r0 = r6.getAction()
            if (r0 != 0) goto L5a
            int r0 = r6.getKeyCode()
            r3 = 21
            r4 = 2
            if (r0 == r3) goto L48
            r3 = 22
            if (r0 == r3) goto L36
            r3 = 61
            if (r0 == r3) goto L20
            goto L5a
        L20:
            boolean r0 = r6.hasNoModifiers()
            if (r0 == 0) goto L2b
            boolean r6 = r5.c(r4)
            goto L5b
        L2b:
            boolean r6 = r6.hasModifiers(r2)
            if (r6 == 0) goto L5a
            boolean r6 = r5.c(r2)
            goto L5b
        L36:
            boolean r6 = r6.hasModifiers(r4)
            if (r6 == 0) goto L41
            boolean r6 = r5.o()
            goto L5b
        L41:
            r6 = 66
            boolean r6 = r5.c(r6)
            goto L5b
        L48:
            boolean r6 = r6.hasModifiers(r4)
            if (r6 == 0) goto L53
            boolean r6 = r5.n()
            goto L5b
        L53:
            r6 = 17
            boolean r6 = r5.c(r6)
            goto L5b
        L5a:
            r6 = 0
        L5b:
            if (r6 == 0) goto L5e
        L5d:
            r1 = 1
        L5e:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        e i2;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (i2 = i(childAt)) != null && i2.f551b == this.f547i && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        a aVar;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean z = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (aVar = this.f546h) != null && aVar.getCount() > 1)) {
            if (!this.P.isFinished()) {
                int save = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate(getPaddingTop() + (-height), this.t * width);
                this.P.setSize(height, width);
                z = false | this.P.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (!this.Q.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate(-getPaddingTop(), (-(this.u + 1.0f)) * width2);
                this.Q.setSize(height2, width2);
                z |= this.Q.draw(canvas);
                canvas.restoreToCount(save2);
            }
        } else {
            this.P.finish();
            this.Q.finish();
        }
        if (z) {
            AtomicInteger atomicInteger = q.f1738a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.q;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        drawable.setState(getDrawableState());
    }

    public final void e(boolean z) {
        boolean z2 = this.f0 == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            if (!this.m.isFinished()) {
                this.m.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.m.getCurrX();
                int currY = this.m.getCurrY();
                if (scrollX != currX || scrollY != currY) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        p(currX);
                    }
                }
            }
        }
        this.y = false;
        for (int i2 = 0; i2 < this.f543e.size(); i2++) {
            e eVar = this.f543e.get(i2);
            if (eVar.f552c) {
                eVar.f552c = false;
                z2 = true;
            }
        }
        if (z2) {
            if (!z) {
                this.e0.run();
                return;
            }
            Runnable runnable = this.e0;
            AtomicInteger atomicInteger = q.f1738a;
            postOnAnimation(runnable);
        }
    }

    public void f() {
        int count = this.f546h.getCount();
        this.f542d = count;
        boolean z = this.f543e.size() < (this.z * 2) + 1 && this.f543e.size() < count;
        int i2 = this.f547i;
        int i3 = 0;
        boolean z2 = false;
        while (i3 < this.f543e.size()) {
            e eVar = this.f543e.get(i3);
            int e2 = this.f546h.e(eVar.f550a);
            if (e2 != -1) {
                if (e2 == -2) {
                    this.f543e.remove(i3);
                    i3--;
                    if (!z2) {
                        this.f546h.m(this);
                        z2 = true;
                    }
                    this.f546h.c(this, eVar.f551b, eVar.f550a);
                    int i4 = this.f547i;
                    if (i4 == eVar.f551b) {
                        i2 = Math.max(0, Math.min(i4, count - 1));
                    }
                } else {
                    int i5 = eVar.f551b;
                    if (i5 != e2) {
                        if (i5 == this.f547i) {
                            i2 = e2;
                        }
                        eVar.f551b = e2;
                    }
                }
                z = true;
            }
            i3++;
        }
        if (z2) {
            this.f546h.d(this);
        }
        Collections.sort(this.f543e, h0);
        if (z) {
            int childCount = getChildCount();
            for (int i6 = 0; i6 < childCount; i6++) {
                f fVar = (f) getChildAt(i6).getLayoutParams();
                if (!fVar.f555a) {
                    fVar.f557c = 0.0f;
                }
            }
            x(i2, false, true, 0);
            requestLayout();
        }
    }

    public final void g(int i2) {
        i iVar = this.V;
        if (iVar != null) {
            iVar.g(i2);
        }
        List<i> list = this.U;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                i iVar2 = this.U.get(i3);
                if (iVar2 != null) {
                    iVar2.g(i2);
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new f();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new f(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public a getAdapter() {
        return this.f546h;
    }

    @Override // android.view.ViewGroup
    public int getChildDrawingOrder(int i2, int i3) {
        if (this.c0 == 2) {
            i3 = (i2 - 1) - i3;
        }
        return ((f) this.d0.get(i3).getLayoutParams()).f560f;
    }

    public int getCurrentItem() {
        return this.f547i;
    }

    public int getOffscreenPageLimit() {
        return this.z;
    }

    public int getPageMargin() {
        return this.p;
    }

    public final Rect h(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left = viewGroup.getLeft() + rect.left;
            rect.right = viewGroup.getRight() + rect.right;
            rect.top = viewGroup.getTop() + rect.top;
            rect.bottom = viewGroup.getBottom() + rect.bottom;
            parent = viewGroup.getParent();
        }
        return rect;
    }

    public e i(View view) {
        for (int i2 = 0; i2 < this.f543e.size(); i2++) {
            e eVar = this.f543e.get(i2);
            if (this.f546h.h(view, eVar.f550a)) {
                return eVar;
            }
        }
        return null;
    }

    public final e j() {
        int i2;
        int clientWidth = getClientWidth();
        float f2 = 0.0f;
        float scrollX = clientWidth > 0 ? getScrollX() / clientWidth : 0.0f;
        float f3 = clientWidth > 0 ? this.p / clientWidth : 0.0f;
        e eVar = null;
        float f4 = 0.0f;
        int i3 = -1;
        int i4 = 0;
        boolean z = true;
        while (i4 < this.f543e.size()) {
            e eVar2 = this.f543e.get(i4);
            if (!z && eVar2.f551b != (i2 = i3 + 1)) {
                eVar2 = this.f544f;
                eVar2.f554e = f2 + f4 + f3;
                eVar2.f551b = i2;
                Objects.requireNonNull(this.f546h);
                eVar2.f553d = 1.0f;
                i4--;
            }
            f2 = eVar2.f554e;
            float f5 = eVar2.f553d + f2 + f3;
            if (!z && scrollX < f2) {
                return eVar;
            }
            if (scrollX < f5 || i4 == this.f543e.size() - 1) {
                return eVar2;
            }
            i3 = eVar2.f551b;
            f4 = eVar2.f553d;
            i4++;
            eVar = eVar2;
            z = false;
        }
        return eVar;
    }

    public e k(int i2) {
        for (int i3 = 0; i3 < this.f543e.size(); i3++) {
            e eVar = this.f543e.get(i3);
            if (eVar.f551b == i2) {
                return eVar;
            }
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0064  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void l(int r13, float r14, int r15) {
        /*
            Method dump skipped, instructions count: 254
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.l(int, float, int):void");
    }

    public final void m(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.J) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.F = motionEvent.getX(i2);
            this.J = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.K;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public boolean n() {
        int i2 = this.f547i;
        if (i2 <= 0) {
            return false;
        }
        w(i2 - 1, true);
        return true;
    }

    public boolean o() {
        a aVar = this.f546h;
        if (aVar == null || this.f547i >= aVar.getCount() - 1) {
            return false;
        }
        w(this.f547i + 1, true);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.R = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        removeCallbacks(this.e0);
        Scroller scroller = this.m;
        if (scroller != null && !scroller.isFinished()) {
            this.m.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        int i2;
        float f2;
        float f3;
        super.onDraw(canvas);
        if (this.p <= 0 || this.q == null || this.f543e.size() <= 0 || this.f546h == null) {
            return;
        }
        int scrollX = getScrollX();
        float width = getWidth();
        float f4 = this.p / width;
        int i3 = 0;
        e eVar = this.f543e.get(0);
        float f5 = eVar.f554e;
        int size = this.f543e.size();
        int i4 = eVar.f551b;
        int i5 = this.f543e.get(size - 1).f551b;
        while (i4 < i5) {
            while (true) {
                i2 = eVar.f551b;
                if (i4 <= i2 || i3 >= size) {
                    break;
                }
                i3++;
                eVar = this.f543e.get(i3);
            }
            if (i4 == i2) {
                float f6 = eVar.f554e;
                float f7 = eVar.f553d;
                f2 = (f6 + f7) * width;
                f5 = f6 + f7 + f4;
            } else {
                Objects.requireNonNull(this.f546h);
                f2 = (f5 + 1.0f) * width;
                f5 = 1.0f + f4 + f5;
            }
            if (this.p + f2 > scrollX) {
                f3 = f4;
                this.q.setBounds(Math.round(f2), this.r, Math.round(this.p + f2), this.s);
                this.q.draw(canvas);
            } else {
                f3 = f4;
            }
            if (f2 > scrollX + r2) {
                return;
            }
            i4++;
            f4 = f3;
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            u();
            return false;
        }
        if (action != 0) {
            if (this.A) {
                return true;
            }
            if (this.B) {
                return false;
            }
        }
        if (action == 0) {
            float x = motionEvent.getX();
            this.H = x;
            this.F = x;
            float y = motionEvent.getY();
            this.I = y;
            this.G = y;
            this.J = motionEvent.getPointerId(0);
            this.B = false;
            this.n = true;
            this.m.computeScrollOffset();
            if (this.f0 != 2 || Math.abs(this.m.getFinalX() - this.m.getCurrX()) <= this.O) {
                e(false);
                this.A = false;
            } else {
                this.m.abortAnimation();
                this.y = false;
                r(this.f547i);
                this.A = true;
                t(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i2 = this.J;
            if (i2 != -1) {
                int findPointerIndex = motionEvent.findPointerIndex(i2);
                float x2 = motionEvent.getX(findPointerIndex);
                float f2 = x2 - this.F;
                float abs = Math.abs(f2);
                float y2 = motionEvent.getY(findPointerIndex);
                float abs2 = Math.abs(y2 - this.I);
                if (f2 != 0.0f) {
                    float f3 = this.F;
                    if (!((f3 < ((float) this.D) && f2 > 0.0f) || (f3 > ((float) (getWidth() - this.D)) && f2 < 0.0f)) && d(this, false, (int) f2, (int) x2, (int) y2)) {
                        this.F = x2;
                        this.G = y2;
                        this.B = true;
                        return false;
                    }
                }
                int i3 = this.E;
                if (abs > i3 && abs * 0.5f > abs2) {
                    this.A = true;
                    t(true);
                    setScrollState(1);
                    float f4 = this.H;
                    float f5 = this.E;
                    this.F = f2 > 0.0f ? f4 + f5 : f4 - f5;
                    this.G = y2;
                    setScrollingCacheEnabled(true);
                } else if (abs2 > i3) {
                    this.B = true;
                }
                if (this.A && q(x2)) {
                    AtomicInteger atomicInteger = q.f1738a;
                    postInvalidateOnAnimation();
                }
            }
        } else if (action == 6) {
            m(motionEvent);
        }
        if (this.K == null) {
            this.K = VelocityTracker.obtain();
        }
        this.K.addMovement(motionEvent);
        return this.A;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x008e  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onLayout(boolean r19, int r20, int r21, int r22, int r23) {
        /*
            Method dump skipped, instructions count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x008e  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0089  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r14, int r15) {
        /*
            Method dump skipped, instructions count: 243
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        int i3;
        int i4;
        e i5;
        int childCount = getChildCount();
        int i6 = -1;
        if ((i2 & 2) != 0) {
            i6 = childCount;
            i3 = 0;
            i4 = 1;
        } else {
            i3 = childCount - 1;
            i4 = -1;
        }
        while (i3 != i6) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (i5 = i(childAt)) != null && i5.f551b == this.f547i && childAt.requestFocus(i2, rect)) {
                return true;
            }
            i3 += i4;
        }
        return false;
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof l)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        l lVar = (l) parcelable;
        super.onRestoreInstanceState(lVar.f1843d);
        a aVar = this.f546h;
        if (aVar != null) {
            aVar.j(lVar.f564g, lVar.f565h);
            x(lVar.f563f, false, true, 0);
        } else {
            this.f548j = lVar.f563f;
            this.k = lVar.f564g;
            this.l = lVar.f565h;
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        l lVar = new l(super.onSaveInstanceState());
        lVar.f563f = this.f547i;
        a aVar = this.f546h;
        if (aVar != null) {
            lVar.f564g = aVar.k();
        }
        return lVar;
    }

    @Override // android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 != i4) {
            int i6 = this.p;
            s(i2, i4, i6, i6);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        a aVar;
        boolean z = false;
        if ((motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) || (aVar = this.f546h) == null || aVar.getCount() == 0) {
            return false;
        }
        if (this.K == null) {
            this.K = VelocityTracker.obtain();
        }
        this.K.addMovement(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.m.abortAnimation();
            this.y = false;
            r(this.f547i);
            float x = motionEvent.getX();
            this.H = x;
            this.F = x;
            float y = motionEvent.getY();
            this.I = y;
            this.G = y;
            this.J = motionEvent.getPointerId(0);
        } else if (action != 1) {
            if (action == 2) {
                if (!this.A) {
                    int findPointerIndex = motionEvent.findPointerIndex(this.J);
                    if (findPointerIndex == -1) {
                        z = u();
                    } else {
                        float x2 = motionEvent.getX(findPointerIndex);
                        float abs = Math.abs(x2 - this.F);
                        float y2 = motionEvent.getY(findPointerIndex);
                        float abs2 = Math.abs(y2 - this.G);
                        if (abs > this.E && abs > abs2) {
                            this.A = true;
                            t(true);
                            float f2 = this.H;
                            this.F = x2 - f2 > 0.0f ? f2 + this.E : f2 - this.E;
                            this.G = y2;
                            setScrollState(1);
                            setScrollingCacheEnabled(true);
                            ViewParent parent = getParent();
                            if (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                            }
                        }
                    }
                }
                if (this.A) {
                    z = false | q(motionEvent.getX(motionEvent.findPointerIndex(this.J)));
                }
            } else if (action != 3) {
                if (action == 5) {
                    int actionIndex = motionEvent.getActionIndex();
                    this.F = motionEvent.getX(actionIndex);
                    this.J = motionEvent.getPointerId(actionIndex);
                } else if (action == 6) {
                    m(motionEvent);
                    this.F = motionEvent.getX(motionEvent.findPointerIndex(this.J));
                }
            } else if (this.A) {
                v(this.f547i, true, 0, false);
                z = u();
            }
        } else if (this.A) {
            VelocityTracker velocityTracker = this.K;
            velocityTracker.computeCurrentVelocity(1000, this.M);
            int xVelocity = (int) velocityTracker.getXVelocity(this.J);
            this.y = true;
            int clientWidth = getClientWidth();
            int scrollX = getScrollX();
            e j2 = j();
            float f3 = clientWidth;
            int i2 = j2.f551b;
            float f4 = ((scrollX / f3) - j2.f554e) / (j2.f553d + (this.p / f3));
            if (Math.abs((int) (motionEvent.getX(motionEvent.findPointerIndex(this.J)) - this.H)) <= this.N || Math.abs(xVelocity) <= this.L) {
                i2 += (int) (f4 + (i2 >= this.f547i ? 0.4f : 0.6f));
            } else if (xVelocity <= 0) {
                i2++;
            }
            if (this.f543e.size() > 0) {
                i2 = Math.max(this.f543e.get(0).f551b, Math.min(i2, this.f543e.get(r1.size() - 1).f551b));
            }
            x(i2, true, true, xVelocity);
            z = u();
        }
        if (z) {
            AtomicInteger atomicInteger = q.f1738a;
            postInvalidateOnAnimation();
        }
        return true;
    }

    public final boolean p(int i2) {
        if (this.f543e.size() == 0) {
            if (this.R) {
                return false;
            }
            this.S = false;
            l(0, 0.0f, 0);
            if (this.S) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        e j2 = j();
        int clientWidth = getClientWidth();
        int i3 = this.p;
        int i4 = clientWidth + i3;
        float f2 = clientWidth;
        int i5 = j2.f551b;
        float f3 = ((i2 / f2) - j2.f554e) / (j2.f553d + (i3 / f2));
        this.S = false;
        l(i5, f3, (int) (i4 * f3));
        if (this.S) {
            return true;
        }
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }

    public final boolean q(float f2) {
        boolean z;
        boolean z2;
        float f3 = this.F - f2;
        this.F = f2;
        float scrollX = getScrollX() + f3;
        float clientWidth = getClientWidth();
        float f4 = this.t * clientWidth;
        float f5 = this.u * clientWidth;
        boolean z3 = false;
        e eVar = this.f543e.get(0);
        ArrayList<e> arrayList = this.f543e;
        e eVar2 = arrayList.get(arrayList.size() - 1);
        if (eVar.f551b != 0) {
            f4 = eVar.f554e * clientWidth;
            z = false;
        } else {
            z = true;
        }
        if (eVar2.f551b != this.f546h.getCount() - 1) {
            f5 = eVar2.f554e * clientWidth;
            z2 = false;
        } else {
            z2 = true;
        }
        if (scrollX < f4) {
            if (z) {
                this.P.onPull(Math.abs(f4 - scrollX) / clientWidth);
                z3 = true;
            }
            scrollX = f4;
        } else if (scrollX > f5) {
            if (z2) {
                this.Q.onPull(Math.abs(scrollX - f5) / clientWidth);
                z3 = true;
            }
            scrollX = f5;
        }
        int i2 = (int) scrollX;
        this.F = (scrollX - i2) + this.F;
        scrollTo(i2, getScrollY());
        p(i2);
        return z3;
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x005c, code lost:
    
        if (r5 == r6) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void r(int r15) {
        /*
            Method dump skipped, instructions count: 923
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.viewpager.widget.ViewPager.r(int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        if (this.w) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    public final void s(int i2, int i3, int i4, int i5) {
        if (i3 > 0 && !this.f543e.isEmpty()) {
            if (!this.m.isFinished()) {
                this.m.setFinalX(getCurrentItem() * getClientWidth());
                return;
            } else {
                scrollTo((int) ((getScrollX() / (((i3 - getPaddingLeft()) - getPaddingRight()) + i5)) * (((i2 - getPaddingLeft()) - getPaddingRight()) + i4)), getScrollY());
                return;
            }
        }
        e k2 = k(this.f547i);
        int min = (int) ((k2 != null ? Math.min(k2.f554e, this.u) : 0.0f) * ((i2 - getPaddingLeft()) - getPaddingRight()));
        if (min != getScrollX()) {
            e(false);
            scrollTo(min, getScrollY());
        }
    }

    public void setAdapter(a aVar) {
        a aVar2 = this.f546h;
        if (aVar2 != null) {
            synchronized (aVar2) {
                aVar2.f1115b = null;
            }
            this.f546h.m(this);
            for (int i2 = 0; i2 < this.f543e.size(); i2++) {
                e eVar = this.f543e.get(i2);
                this.f546h.c(this, eVar.f551b, eVar.f550a);
            }
            this.f546h.d(this);
            this.f543e.clear();
            int i3 = 0;
            while (i3 < getChildCount()) {
                if (!((f) getChildAt(i3).getLayoutParams()).f555a) {
                    removeViewAt(i3);
                    i3--;
                }
                i3++;
            }
            this.f547i = 0;
            scrollTo(0, 0);
        }
        a aVar3 = this.f546h;
        this.f546h = aVar;
        this.f542d = 0;
        if (aVar != null) {
            if (this.o == null) {
                this.o = new k();
            }
            a aVar4 = this.f546h;
            k kVar = this.o;
            synchronized (aVar4) {
                aVar4.f1115b = kVar;
            }
            this.y = false;
            boolean z = this.R;
            this.R = true;
            this.f542d = this.f546h.getCount();
            if (this.f548j >= 0) {
                this.f546h.j(this.k, this.l);
                x(this.f548j, false, true, 0);
                this.f548j = -1;
                this.k = null;
                this.l = null;
            } else if (z) {
                requestLayout();
            } else {
                r(this.f547i);
            }
        }
        List<h> list = this.W;
        if (list == null || list.isEmpty()) {
            return;
        }
        int size = this.W.size();
        for (int i4 = 0; i4 < size; i4++) {
            this.W.get(i4).a(this, aVar3, aVar);
        }
    }

    public void setCurrentItem(int i2) {
        this.y = false;
        x(i2, !this.R, false, 0);
    }

    public void setOffscreenPageLimit(int i2) {
        if (i2 < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i2 + " too small; defaulting to 1");
            i2 = 1;
        }
        if (i2 != this.z) {
            this.z = i2;
            r(this.f547i);
        }
    }

    @Deprecated
    public void setOnPageChangeListener(i iVar) {
        this.V = iVar;
    }

    public void setPageMargin(int i2) {
        int i3 = this.p;
        this.p = i2;
        int width = getWidth();
        s(width, width, i2, i3);
        requestLayout();
    }

    public void setPageMarginDrawable(int i2) {
        Context context = getContext();
        Object obj = b.h.d.a.f1567a;
        setPageMarginDrawable(a.b.b(context, i2));
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.q = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setScrollState(int i2) {
        if (this.f0 == i2) {
            return;
        }
        this.f0 = i2;
        if (this.a0 != null) {
            boolean z = i2 != 0;
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                getChildAt(i3).setLayerType(z ? this.b0 : 0, null);
            }
        }
        i iVar = this.V;
        if (iVar != null) {
            iVar.f(i2);
        }
        List<i> list = this.U;
        if (list != null) {
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                i iVar2 = this.U.get(i4);
                if (iVar2 != null) {
                    iVar2.f(i2);
                }
            }
        }
    }

    public final void t(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    public final boolean u() {
        this.J = -1;
        this.A = false;
        this.B = false;
        VelocityTracker velocityTracker = this.K;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.K = null;
        }
        this.P.onRelease();
        this.Q.onRelease();
        return this.P.isFinished() || this.Q.isFinished();
    }

    public final void v(int i2, boolean z, int i3, boolean z2) {
        int scrollX;
        int abs;
        e k2 = k(i2);
        int max = k2 != null ? (int) (Math.max(this.t, Math.min(k2.f554e, this.u)) * getClientWidth()) : 0;
        if (!z) {
            if (z2) {
                g(i2);
            }
            e(false);
            scrollTo(max, 0);
            p(max);
            return;
        }
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
        } else {
            Scroller scroller = this.m;
            if ((scroller == null || scroller.isFinished()) ? false : true) {
                scrollX = this.n ? this.m.getCurrX() : this.m.getStartX();
                this.m.abortAnimation();
                setScrollingCacheEnabled(false);
            } else {
                scrollX = getScrollX();
            }
            int i4 = scrollX;
            int scrollY = getScrollY();
            int i5 = max - i4;
            int i6 = 0 - scrollY;
            if (i5 == 0 && i6 == 0) {
                e(false);
                r(this.f547i);
                setScrollState(0);
            } else {
                setScrollingCacheEnabled(true);
                setScrollState(2);
                int clientWidth = getClientWidth();
                int i7 = clientWidth / 2;
                float f2 = clientWidth;
                float f3 = i7;
                float sin = (((float) Math.sin((Math.min(1.0f, (Math.abs(i5) * 1.0f) / f2) - 0.5f) * 0.47123894f)) * f3) + f3;
                int abs2 = Math.abs(i3);
                if (abs2 > 0) {
                    abs = Math.round(Math.abs(sin / abs2) * 1000.0f) * 4;
                } else {
                    Objects.requireNonNull(this.f546h);
                    abs = (int) (((Math.abs(i5) / ((f2 * 1.0f) + this.p)) + 1.0f) * 100.0f);
                }
                int min = Math.min(abs, 600);
                this.n = false;
                this.m.startScroll(i4, scrollY, i5, i6, min);
                AtomicInteger atomicInteger = q.f1738a;
                postInvalidateOnAnimation();
            }
        }
        if (z2) {
            g(i2);
        }
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.q;
    }

    public void w(int i2, boolean z) {
        this.y = false;
        x(i2, z, false, 0);
    }

    public void x(int i2, boolean z, boolean z2, int i3) {
        b.b0.a.a aVar = this.f546h;
        if (aVar == null || aVar.getCount() <= 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (!z2 && this.f547i == i2 && this.f543e.size() != 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (i2 < 0) {
            i2 = 0;
        } else if (i2 >= this.f546h.getCount()) {
            i2 = this.f546h.getCount() - 1;
        }
        int i4 = this.z;
        int i5 = this.f547i;
        if (i2 > i5 + i4 || i2 < i5 - i4) {
            for (int i6 = 0; i6 < this.f543e.size(); i6++) {
                this.f543e.get(i6).f552c = true;
            }
        }
        boolean z3 = this.f547i != i2;
        if (!this.R) {
            r(i2);
            v(i2, z, i3, z3);
        } else {
            this.f547i = i2;
            if (z3) {
                g(i2);
            }
            requestLayout();
        }
    }

    public void y(boolean z, j jVar) {
        boolean z2 = true != (this.a0 != null);
        this.a0 = jVar;
        setChildrenDrawingOrderEnabled(true);
        this.c0 = z ? 2 : 1;
        this.b0 = 2;
        if (z2) {
            r(this.f547i);
        }
    }

    public final void z() {
        if (this.c0 != 0) {
            ArrayList<View> arrayList = this.d0;
            if (arrayList == null) {
                this.d0 = new ArrayList<>();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                this.d0.add(getChildAt(i2));
            }
            Collections.sort(this.d0, j0);
        }
    }
}
