package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import b.u.f;
import b.u.g;
import java.util.HashMap;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\room\MultiInstanceInvalidationService.smali */
public class MultiInstanceInvalidationService extends Service {

    /* renamed from: d, reason: collision with root package name */
    public int f518d = 0;

    /* renamed from: e, reason: collision with root package name */
    public final HashMap<Integer, String> f519e = new HashMap<>();

    /* renamed from: f, reason: collision with root package name */
    public final RemoteCallbackList<f> f520f = new a();

    /* renamed from: g, reason: collision with root package name */
    public final g f521g = new b();

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\room\MultiInstanceInvalidationService$a.smali */
    public class a extends RemoteCallbackList<f> {
        public a() {
        }

        @Override // android.os.RemoteCallbackList
        public void onCallbackDied(f fVar, Object obj) {
            MultiInstanceInvalidationService.this.f519e.remove(Integer.valueOf(((Integer) obj).intValue()));
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\androidx\room\MultiInstanceInvalidationService$b.smali */
    public class b extends g {
        public b() {
        }

        public void n0(int i2, String[] strArr) {
            synchronized (MultiInstanceInvalidationService.this.f520f) {
                String str = MultiInstanceInvalidationService.this.f519e.get(Integer.valueOf(i2));
                if (str == null) {
                    Log.w("ROOM", "Remote invalidation client ID not registered");
                    return;
                }
                int beginBroadcast = MultiInstanceInvalidationService.this.f520f.beginBroadcast();
                for (int i3 = 0; i3 < beginBroadcast; i3++) {
                    try {
                        int intValue = ((Integer) MultiInstanceInvalidationService.this.f520f.getBroadcastCookie(i3)).intValue();
                        String str2 = MultiInstanceInvalidationService.this.f519e.get(Integer.valueOf(intValue));
                        if (i2 != intValue && str.equals(str2)) {
                            try {
                                MultiInstanceInvalidationService.this.f520f.getBroadcastItem(i3).E(strArr);
                            } catch (RemoteException e2) {
                                Log.w("ROOM", "Error invoking a remote callback", e2);
                            }
                        }
                    } finally {
                        MultiInstanceInvalidationService.this.f520f.finishBroadcast();
                    }
                }
            }
        }

        public int o0(f fVar, String str) {
            if (str == null) {
                return 0;
            }
            synchronized (MultiInstanceInvalidationService.this.f520f) {
                MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
                int i2 = multiInstanceInvalidationService.f518d + 1;
                multiInstanceInvalidationService.f518d = i2;
                if (multiInstanceInvalidationService.f520f.register(fVar, Integer.valueOf(i2))) {
                    MultiInstanceInvalidationService.this.f519e.put(Integer.valueOf(i2), str);
                    return i2;
                }
                MultiInstanceInvalidationService multiInstanceInvalidationService2 = MultiInstanceInvalidationService.this;
                multiInstanceInvalidationService2.f518d--;
                return 0;
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return this.f521g;
    }
}
