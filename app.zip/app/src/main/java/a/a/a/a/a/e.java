package a.a.a.b;

import a.a.a.b.b;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\b\a.smali */
public interface a extends IInterface {

    /* renamed from: a.a.a.b.a$a, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\b\a$a.smali */
    public static abstract class AbstractBinderC0003a extends Binder implements a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int f7a = 0;

        /* renamed from: a.a.a.b.a$a$a, reason: collision with other inner class name */
        /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\b\a$a$a.smali */
        public static class C0004a implements a {

            /* renamed from: a, reason: collision with root package name */
            public IBinder f8a;

            public C0004a(IBinder iBinder) {
                this.f8a = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f8a;
            }
        }

        public AbstractBinderC0003a() {
            attachInterface(this, "android.support.v4.os.IResultReceiver");
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) {
            if (i2 != 1) {
                if (i2 != 1598968902) {
                    return super.onTransact(i2, parcel, parcel2, i3);
                }
                parcel2.writeString("android.support.v4.os.IResultReceiver");
                return true;
            }
            parcel.enforceInterface("android.support.v4.os.IResultReceiver");
            int readInt = parcel.readInt();
            Bundle bundle = parcel.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(parcel) : null;
            b.BinderC0005b binderC0005b = (b.BinderC0005b) this;
            Objects.requireNonNull(b.this);
            b.this.a(readInt, bundle);
            return true;
        }
    }
}
