package a.a.a.a.a;

import android.support.v4.media.session.MediaSessionCompat;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\a\a\e.smali */
public class e extends MediaSessionCompat.a {
    public e(MediaSessionCompat mediaSessionCompat) {
    }
}
