package a.a.a.b;

import a.a.a.b.a;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\b\b.smali */
public class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();

    /* renamed from: d, reason: collision with root package name */
    public a.a.a.b.a f9d;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\b\b$a.smali */
    public class a implements Parcelable.Creator<b> {
        @Override // android.os.Parcelable.Creator
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public b[] newArray(int i2) {
            return new b[i2];
        }
    }

    /* renamed from: a.a.a.b.b$b, reason: collision with other inner class name */
    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\b\b$b.smali */
    public class BinderC0005b extends a.AbstractBinderC0003a {
        public BinderC0005b() {
        }
    }

    public b(Parcel parcel) {
        a.a.a.b.a c0004a;
        IBinder readStrongBinder = parcel.readStrongBinder();
        int i2 = a.AbstractBinderC0003a.f7a;
        if (readStrongBinder == null) {
            c0004a = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("android.support.v4.os.IResultReceiver");
            c0004a = (queryLocalInterface == null || !(queryLocalInterface instanceof a.a.a.b.a)) ? new a.AbstractBinderC0003a.C0004a(readStrongBinder) : (a.a.a.b.a) queryLocalInterface;
        }
        this.f9d = c0004a;
    }

    public void a(int i2, Bundle bundle) {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        synchronized (this) {
            if (this.f9d == null) {
                this.f9d = new BinderC0005b();
            }
            parcel.writeStrongBinder(this.f9d.asBinder());
        }
    }
}
