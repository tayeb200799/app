package a.a.a.a.a;

import a.a.a.a.a.a;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.ParcelableVolumeInfo;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.SparseIntArray;
import androidx.media.AudioAttributesCompat;
import androidx.media.AudioAttributesImplApi21;
import androidx.media.AudioAttributesImplApi26;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\a\a\c.smali */
public abstract class c implements IBinder.DeathRecipient {

    /* renamed from: a, reason: collision with root package name */
    public a.a.a.a.a.a f4a;

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\a\a\c$a.smali */
    public static class a extends MediaController.Callback {

        /* renamed from: a, reason: collision with root package name */
        public final WeakReference<c> f5a;

        public a(c cVar) {
            this.f5a = new WeakReference<>(cVar);
        }

        @Override // android.media.session.MediaController.Callback
        public void onAudioInfoChanged(MediaController.PlaybackInfo playbackInfo) {
            if (this.f5a.get() != null) {
                playbackInfo.getPlaybackType();
                playbackInfo.getAudioAttributes();
                if (Build.VERSION.SDK_INT >= 26) {
                }
                playbackInfo.getVolumeControl();
                playbackInfo.getMaxVolume();
                playbackInfo.getCurrentVolume();
            }
        }

        @Override // android.media.session.MediaController.Callback
        public void onExtrasChanged(Bundle bundle) {
            MediaSessionCompat.a(bundle);
            this.f5a.get();
        }

        @Override // android.media.session.MediaController.Callback
        public void onMetadataChanged(MediaMetadata mediaMetadata) {
            if (this.f5a.get() != null) {
                b.e.a<String, Integer> aVar = MediaMetadataCompat.f20e;
                if (mediaMetadata != null) {
                    Parcel obtain = Parcel.obtain();
                    mediaMetadata.writeToParcel(obtain, 0);
                    obtain.setDataPosition(0);
                    MediaMetadataCompat createFromParcel = MediaMetadataCompat.CREATOR.createFromParcel(obtain);
                    obtain.recycle();
                    Objects.requireNonNull(createFromParcel);
                }
            }
        }

        @Override // android.media.session.MediaController.Callback
        public void onPlaybackStateChanged(PlaybackState playbackState) {
            ArrayList arrayList;
            PlaybackStateCompat.CustomAction customAction;
            c cVar = this.f5a.get();
            if (cVar == null || cVar.f4a != null) {
                return;
            }
            Bundle bundle = null;
            if (playbackState != null) {
                List<PlaybackState.CustomAction> j2 = PlaybackStateCompat.b.j(playbackState);
                if (j2 != null) {
                    ArrayList arrayList2 = new ArrayList(j2.size());
                    for (PlaybackState.CustomAction customAction2 : j2) {
                        if (customAction2 != null) {
                            PlaybackState.CustomAction customAction3 = customAction2;
                            Bundle l = PlaybackStateCompat.b.l(customAction3);
                            MediaSessionCompat.a(l);
                            customAction = new PlaybackStateCompat.CustomAction(PlaybackStateCompat.b.f(customAction3), PlaybackStateCompat.b.o(customAction3), PlaybackStateCompat.b.m(customAction3), l);
                        } else {
                            customAction = null;
                        }
                        arrayList2.add(customAction);
                    }
                    arrayList = arrayList2;
                } else {
                    arrayList = null;
                }
                if (Build.VERSION.SDK_INT >= 22) {
                    bundle = PlaybackStateCompat.c.a(playbackState);
                    MediaSessionCompat.a(bundle);
                }
                new PlaybackStateCompat(PlaybackStateCompat.b.r(playbackState), PlaybackStateCompat.b.q(playbackState), PlaybackStateCompat.b.i(playbackState), PlaybackStateCompat.b.p(playbackState), PlaybackStateCompat.b.g(playbackState), 0, PlaybackStateCompat.b.k(playbackState), PlaybackStateCompat.b.n(playbackState), arrayList, PlaybackStateCompat.b.h(playbackState), bundle);
            }
        }

        @Override // android.media.session.MediaController.Callback
        public void onQueueChanged(List<MediaSession.QueueItem> list) {
            MediaSessionCompat.QueueItem queueItem;
            if (this.f5a.get() == null || list == null) {
                return;
            }
            ArrayList arrayList = new ArrayList();
            for (MediaSession.QueueItem queueItem2 : list) {
                if (queueItem2 != null) {
                    MediaSession.QueueItem queueItem3 = queueItem2;
                    queueItem = new MediaSessionCompat.QueueItem(queueItem3, MediaDescriptionCompat.a(MediaSessionCompat.QueueItem.b.b(queueItem3)), MediaSessionCompat.QueueItem.b.c(queueItem3));
                } else {
                    queueItem = null;
                }
                arrayList.add(queueItem);
            }
        }

        @Override // android.media.session.MediaController.Callback
        public void onQueueTitleChanged(CharSequence charSequence) {
            this.f5a.get();
        }

        @Override // android.media.session.MediaController.Callback
        public void onSessionDestroyed() {
            this.f5a.get();
        }

        @Override // android.media.session.MediaController.Callback
        public void onSessionEvent(String str, Bundle bundle) {
            MediaSessionCompat.a(bundle);
            c cVar = this.f5a.get();
            if (cVar == null || cVar.f4a == null) {
                return;
            }
            int i2 = Build.VERSION.SDK_INT;
        }
    }

    /* loaded from: C:\Users\tayeb\Videos\apk-easy-tool-1-60\1-Decompiled APKs\com-mod-djezzy-mod-apk-v-v2-5-1-40019\smali\a\a\a\a\a\c$b.smali */
    public static class b extends a.AbstractBinderC0000a {

        /* renamed from: b, reason: collision with root package name */
        public final WeakReference<c> f6b;

        public b(c cVar) {
            this.f6b = new WeakReference<>(cVar);
        }

        @Override // a.a.a.a.a.a
        public void I(Bundle bundle) {
            this.f6b.get();
        }

        @Override // a.a.a.a.a.a
        public void N(List<MediaSessionCompat.QueueItem> list) {
            this.f6b.get();
        }

        @Override // a.a.a.a.a.a
        public void j(CharSequence charSequence) {
            this.f6b.get();
        }

        @Override // a.a.a.a.a.a
        public void l0(ParcelableVolumeInfo parcelableVolumeInfo) {
            if (this.f6b.get() == null || parcelableVolumeInfo == null) {
                return;
            }
            int i2 = parcelableVolumeInfo.f57e;
            SparseIntArray sparseIntArray = AudioAttributesCompat.f360b;
            AudioAttributesImplApi21.a aVar = Build.VERSION.SDK_INT >= 26 ? new AudioAttributesImplApi26.a() : new AudioAttributesImplApi21.a();
            aVar.f364a.setLegacyStreamType(i2);
            aVar.a();
        }

        @Override // a.a.a.a.a.a
        public void o() {
            this.f6b.get();
        }

        @Override // a.a.a.a.a.a
        public void q(MediaMetadataCompat mediaMetadataCompat) {
            this.f6b.get();
        }
    }

    public c() {
        new a(this);
    }

    @Override // android.os.IBinder.DeathRecipient
    public void binderDied() {
    }
}
